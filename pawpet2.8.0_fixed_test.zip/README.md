# PawPet 2.8.0+25 — test source

Services and manually managed sponsored advertisements replace the marketplace by default.

Start with **docs/RELEASE_2.8.0_FA.md** for Persian installation, pricing, management and rollback instructions. **supabase/migration_07_ads.sql** is the only new database migration; it requires the preceding migrations. Do not rerun setup.sql on an existing database.

The original 2.7.0 archive is preserved separately. Marketplace code and data are retained behind client and server switches. This source delivery is not a built APK or a production readiness claim.

Validation details: **docs/VALIDATION_2.8.0.md**. Architecture decisions: **docs/ARCHITECTURE_DECISIONS_2.8.0.md**.
