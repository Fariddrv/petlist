import 'dart:math';
import '../l10n.dart';

bool validAdDestination(String type, String value) {
  if (type == 'profile')
    return RegExp(
      r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
    ).hasMatch(value);
  if (type == 'call') return RegExp(r'^tel:\+?[0-9]{5,20}$').hasMatch(value);
  final uri = Uri.tryParse(value);
  return uri != null &&
      uri.scheme == 'https' &&
      uri.host.isNotEmpty &&
      uri.userInfo.isEmpty &&
      !RegExp(r'\s').hasMatch(value);
}

String requestToken() {
  final r = Random.secure();
  final b = List<int>.generate(16, (_) => r.nextInt(256));
  b[6] = (b[6] & 15) | 64;
  b[8] = (b[8] & 63) | 128;
  final h = b.map((v) => v.toRadixString(16).padLeft(2, '0')).join();
  return '${h.substring(0, 8)}-${h.substring(8, 12)}-${h.substring(12, 16)}-${h.substring(16, 20)}-${h.substring(20)}';
}

class ServiceAd {
  final Map<String, dynamic> row;
  ServiceAd(this.row);
  String get id => row['id'].toString();
  String get brand => row['brand'].toString();
  String get image => row['image_url'].toString();
  String get country => row['country'].toString();
  String get city => row['city'].toString();
  String get category => row['category'].toString();
  String get tier => row['tier'].toString();
  String get type => row['destination_type'].toString();
  String get destination => row['destination'].toString();
  bool get inFeed => row['show_in_feed'] == true;
  int get priority => (row['priority'] as num?)?.toInt() ?? 0;
  List<String> get badges => List<String>.from(row['badges'] ?? []);
  String description(AppLang l) {
    final j = Map<String, dynamic>.from(row['description'] ?? {});
    return (j[l.name] ?? j['en'] ?? j['fa'] ?? j['zh'] ?? '').toString();
  }

  bool matches(String c, String town) => country == c && city == town;
  bool live(DateTime now) =>
      row['active'] == true &&
      !DateTime.parse(row['starts_at']).isAfter(now) &&
      DateTime.parse(row['ends_at']).isAfter(now);
}

int compareAds(ServiceAd a, ServiceAd b) {
  const tiers = {'basic': 0, 'premium': 1, 'featured': 2};
  final rank = (tiers[b.tier] ?? 0).compareTo(tiers[a.tier] ?? 0);
  if (rank != 0) return rank;
  final priority = b.priority.compareTo(a.priority);
  return priority != 0 ? priority : a.id.compareTo(b.id);
}

/// Parse prices exactly in their currency units, including Persian digits.
int? parseAdPrice(String text, String currency) {
 const codes = ['IRT','USD','EUR','CNY','GBP','AED','TRY','JPY','KRW','CAD','AUD','CHF','SAR','INR','RUB','IQD'];
 if (!codes.contains(currency)) return null;
 const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
 final normalized = text.trim().split('').map((c) {
   final f = fa.indexOf(c), a = ar.indexOf(c);
   if (f >= 0) return '$f';
   if (a >= 0) return '$a';
   if (c == '٫') return '.';
   if (c == ',' || c == '٬' || c == ' ') return '';
   return c;
 }).join();
 if (!RegExp(r'^\d+(\.\d+)?$').hasMatch(normalized)) return null;
 final decimals = ['IRT','JPY','KRW','IQD'].contains(currency) ? 0 : 2;
 final parts = normalized.split('.');
 final fraction = parts.length == 2 ? parts[1] : '';
 if (fraction.length > decimals) return null;
 final result = int.tryParse(parts[0] + fraction.padRight(decimals, '0'));
 return result != null && result <= 999999999999999 ? result : null;
}
