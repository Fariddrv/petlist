import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../state.dart';
import '../models.dart';
import '../theme.dart';
import 'care_text.dart';

String documentId(){final r=Random.secure();final bytes=List<int>.generate(16,(_)=>r.nextInt(256));bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;final h=bytes.map((n)=>n.toRadixString(16).padLeft(2,'0')).join();return '${h.substring(0,8)}-${h.substring(8,12)}-${h.substring(12,16)}-${h.substring(16,20)}-${h.substring(20)}';}
String? documentMime(Uint8List b){
 if(b.length>=5&&b[0]==37&&b[1]==80&&b[2]==68&&b[3]==70&&b[4]==45)return 'application/pdf';
 if(b.length>=8&&b[0]==137&&b[1]==80&&b[2]==78&&b[3]==71&&b[4]==13&&b[5]==10&&b[6]==26&&b[7]==10)return 'image/png';
 if(b.length>=3&&b[0]==255&&b[1]==216&&b[2]==255)return 'image/jpeg';return null;
}
class PetDocumentsPage extends StatefulWidget{
 final AppState s;final Pet pet;const PetDocumentsPage({super.key,required this.s,required this.pet});
 @override State<PetDocumentsPage>createState()=>_PetDocumentsPageState();
}
class _PetDocumentsPageState extends State<PetDocumentsPage>{
 SupabaseClient get db=>Supabase.instance.client;
 List<Map<String,dynamic>> rows=[];bool loading=true,busy=false,failed=false,hasMore=false;
 String get owner=>widget.s.meId??'';
 String t(String fa,String en,String zh)=>petText(widget.s.lang,fa,en,zh);
 @override void initState(){super.initState();_load();}
 Future<void> _load({bool more=false})async{
  final user=owner;setState(()=>loading=true);
  try{final data=await db.from('pet_documents').select().eq('pet_id',widget.pet.id).order('created_at',ascending:false).order('id').range(more?rows.length:0,(more?rows.length:0)+29);
   if(!mounted||user!=owner)return;setState((){if(!more)rows=[];rows.addAll((data as List).map((r)=>Map<String,dynamic>.from(r)));hasMore=data.length==30;failed=false;});
  }catch(_){if(mounted)setState(()=>failed=true);}if(mounted)setState(()=>loading=false);
 }
 void _error(){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(t('عملیات کامل نشد؛ اتصال و SQL جدید را بررسی کنید.','Operation failed. Check connection and new SQL.','操作失败，请检查连接和新 SQL。'))));}
 Future<void> _upload()async{
  if(busy)return;final user=owner;
  final picked=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['jpg','jpeg','png','pdf'],withData:false);if(picked==null||!mounted)return;
  final selected=picked.files.single;if(selected.path==null||selected.size>8388608){_error();return;}
  final title=await showDialog<String>(context:context,builder:(ctx)=>_DocumentTitle(initial:selected.name));if(title==null||title.trim().isEmpty||!mounted)return;
  setState(()=>busy=true);String? uploaded;
  try{
   final file=File(selected.path!);if(await file.length()>8388608)throw StateError('too large');
   final bytes=await file.readAsBytes();final mime=documentMime(bytes);if(mime==null||bytes.isEmpty)throw StateError('unsupported file');
   if(user!=owner)throw StateError('account changed');
   final ext=mime=='application/pdf'?'pdf':mime=='image/png'?'png':'jpg';final path='$user/${widget.pet.id}/${documentId()}.$ext';
   await db.storage.from('pet-documents').uploadBinary(path,bytes,fileOptions:FileOptions(contentType:mime,upsert:false));uploaded=path;
   if(user!=owner)throw StateError('account changed');
   await db.from('pet_documents').insert({'pet_id':widget.pet.id,'title':title.trim(),'file_path':path,'mime_type':mime,'size_bytes':bytes.length});uploaded=null;
   if(mounted)await _load();
  }catch(_){if(uploaded!=null&&user==owner){try{await db.storage.from('pet-documents').remove([uploaded]);}catch(_){}}_error();}
  if(mounted)setState(()=>busy=false);
 }
 Future<void> _open(Map<String,dynamic> row)async{
  if(busy)return;setState(()=>busy=true);final user=owner;
  try{final bytes=await db.storage.from('pet-documents').download(row['file_path']);if(!mounted||user!=owner)return;
   if(row['mime_type']!='application/pdf'){
    await Navigator.push(context,MaterialPageRoute(builder:(_)=>Scaffold(appBar:AppBar(title:Text(row['title'])),body:Center(child:InteractiveViewer(child:Image.memory(bytes,errorBuilder:(c,e,st)=>const Icon(Icons.broken_image_outlined,size:64)))))));
   }else{
    final agreed=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(content:Text(t('برای بازکردن PDF، نسخه‌ای از این مدرک خصوصی به برنامه‌ای که انتخاب می‌کنید ارسال می‌شود. ادامه؟','Opening PDF shares a copy of this private document with an app you choose. Continue?','打开 PDF 会将此私人文件副本发送到你选择的应用。继续？')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:Text(t('انصراف','Cancel','取消'))),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:Text(t('ادامه','Continue','继续')))]));
    if(agreed==true&&mounted&&user==owner){final dir=await getTemporaryDirectory();final file=File('${dir.path}/pawpet-document-${documentId()}.pdf');await file.writeAsBytes(bytes);try{await Share.shareXFiles([XFile(file.path)],subject:row['title']);}finally{await file.delete();}}
   }
  }catch(_){_error();}finally{if(mounted)setState(()=>busy=false);}
 }
 Future<void> _delete(Map<String,dynamic> row)async{
  final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(content:Text(t('این مدرک حذف شود؟','Delete this document?','删除此文件？')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:Text(t('انصراف','Cancel','取消'))),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:Text(t('حذف','Delete','删除')))]));if(ok!=true||!mounted)return;
  setState(()=>busy=true);
  try{await db.storage.from('pet-documents').remove([row['file_path']]);await db.from('pet_documents').delete().eq('id',row['id']).eq('pet_id',widget.pet.id);await _load();}catch(_){_error();}if(mounted)setState(()=>busy=false);
 }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(t('مدارک پزشکی','Medical documents','医疗文件'))),body:RefreshIndicator(onRefresh:()=>_load(),child:ListView(padding:const EdgeInsets.all(16),physics:const AlwaysScrollableScrollPhysics(),children:[
  Container(padding:const EdgeInsets.all(16),decoration:AppPal.softCard(),child:Text(t('خصوصی برای حساب شما · تصویر JPG / PNG یا PDF · حداکثر ۸ مگابایت برای هر فایل و ۲۰۰ مدرک در هر حساب.','Private to your account · JPG / PNG or PDF · 8 MB per file, 200 documents per account.','仅你的账号可见 · JPG / PNG 或 PDF · 每文件 8 MB，每账号 200 个文件。'))),const SizedBox(height:16),
  FilledButton.icon(onPressed:busy?null:_upload,icon:const Icon(Icons.upload_file),label:Text(t('افزودن مدرک','Add document','添加文件'))),if(loading||busy)const LinearProgressIndicator(),if(failed)TextButton(onPressed:()=>_load(),child:Text(t('تلاش دوباره','Retry','重试'))),
  if(!loading&&rows.isEmpty)Padding(padding:const EdgeInsets.all(30),child:Text(t('مدرکی ثبت نشده است.','No documents yet.','暂无文件。'),textAlign:TextAlign.center)),
  for(final row in rows)Card(child:ListTile(leading:Icon(row['mime_type']=='application/pdf'?Icons.picture_as_pdf:Icons.image_outlined,color:AppPal.purple),title:Text(row['title']),subtitle:Text('${(row['size_bytes']/1024).round()} KB'),onTap:busy?null:()=>_open(row),trailing:IconButton(onPressed:busy?null:()=>_delete(row),icon:const Icon(Icons.delete_outline)))),
  if(hasMore)TextButton(onPressed:loading?null:()=>_load(more:true),child:Text(t('نمایش بیشتر','Load more','加载更多'))),
 ])));
}
class _DocumentTitle extends StatefulWidget{
 final String initial;const _DocumentTitle({required this.initial});@override State<_DocumentTitle>createState()=>_DocumentTitleState();
}
class _DocumentTitleState extends State<_DocumentTitle>{
 late final controller=TextEditingController(text:widget.initial.length>160?widget.initial.substring(0,160):widget.initial);
 @override void dispose(){controller.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>AlertDialog(content:TextField(controller:controller,maxLength:160,autofocus:true),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Icon(Icons.close)),FilledButton(onPressed:()=>Navigator.pop(context,controller.text),child:const Icon(Icons.check))]);
}
