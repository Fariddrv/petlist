import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../l10n.dart';
import 'care_models.dart';

class CareNotifications {
 final FlutterLocalNotificationsPlugin plugin;
 final bool androidSupported;
 CareNotifications({FlutterLocalNotificationsPlugin? plugin,bool? androidSupported}):plugin=plugin??FlutterLocalNotificationsPlugin(),androidSupported=androidSupported??Platform.isAndroid;
 bool _ready=false;Future<void>? _initializing;Future<void> _queue=Future.value();int _generation=0;
 String? pendingUser,pendingPet;
 String _fingerprint='';
 void Function()? onOpen;
 static const details=NotificationDetails(android:AndroidNotificationDetails('pet_care_v2','Pet care reminders',channelDescription:'Care reminders set by the pet owner',importance:Importance.high,priority:Priority.high,visibility:NotificationVisibility.private));
 void _open(String? payload){
  final parts=payload?.split('|');if(parts==null||parts.length<3||parts[0]!='care')return;
  pendingUser=parts[1];pendingPet=parts[2];onOpen?.call();
 }
 Future<void> initialize(){
  if(_ready||!androidSupported)return Future.value();
  return _initializing??=_initialize().whenComplete(()=>_initializing=null);
 }
 Future<void> _initialize()async{
  tzdata.initializeTimeZones();
  await plugin.initialize(const InitializationSettings(android:AndroidInitializationSettings('ic_care')),onDidReceiveNotificationResponse:(r)=>_open(r.payload));
  _ready=true;
  final launch=await plugin.getNotificationAppLaunchDetails();
  if(launch?.didNotificationLaunchApp==true)_open(launch?.notificationResponse?.payload);
 }
 AndroidFlutterLocalNotificationsPlugin? get android=>plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
 Future<bool> enable()async{await initialize();if(!_ready)return false;await android?.requestNotificationsPermission();_fingerprint='';return allowed();}
 Future<bool> allowed()async{await initialize();if(!_ready)return false;return await android?.areNotificationsEnabled()??false;}
 Future<bool> enableExact()async{await initialize();if(!_ready)return false;await android?.requestExactAlarmsPermission();_fingerprint='';return await android?.canScheduleExactNotifications()??false;}
 Future<AndroidScheduleMode> _mode()async=>(await android?.canScheduleExactNotifications()??false)?AndroidScheduleMode.exactAllowWhileIdle:AndroidScheduleMode.inexactAllowWhileIdle;
 Future<void> clear(){
  final gen=++_generation;pendingUser=null;pendingPet=null;_fingerprint='';
  _queue=_queue.catchError((Object _){}).then((_)async{await initialize();if(gen==_generation&&_ready)await plugin.cancelAll();});return _queue;
 }
 Future<void> sync(String user,List<CareTask> tasks,AppLang lang){
  final gen=++_generation;final future=scheduledCare(tasks,DateTime.now());
  _queue=_queue.catchError((Object _){}).then((_)async{
   await initialize();if(gen!=_generation||!_ready)return;
   if(!await allowed()){_fingerprint='';return;}
   final mode=await _mode();
   final active={for(final task in tasks.where((t)=>t.notify&&!t.completed))task.id:task};
   final futureIds=future.map((t)=>t.id).toSet();
   final fingerprint='$user|$lang|$mode|${active.values.map((t)=>'${t.id}:${t.due.toUtc().toIso8601String()}').join(',')}|${future.map((t)=>t.id).join(',')}';
   if(fingerprint==_fingerprint)return;
   // Preserve a due alarm awaiting delayed Android delivery. Refresh must not cancel it.
   final pending=await plugin.pendingNotificationRequests();
   final occupied=<int>{};final kept=<String>{};
   for(final request in pending){
    if(gen!=_generation)return;
    if(request.id<6000||request.id>=6500)continue;
    final parts=request.payload?.split('|')??<String>[];
    final task=parts.length>=5&&parts[0]=='care'&&parts[1]==user?active[parts[3]]:null;
    final same=task!=null&&parts[4]==task.due.toUtc().toIso8601String();
    final due=task!=null&&same&&!task.due.isAfter(DateTime.now());
    final sameMode=parts.length>=6&&parts[5]==mode.name;
    if(task!=null&&same&&(due||(futureIds.contains(task.id)&&sameMode))){occupied.add(request.id);kept.add(task.id);}
    else{await plugin.cancel(request.id);}
   }
   var id=6000;
   for(final task in future){
    if(gen!=_generation)return;
    if(kept.contains(task.id)||!task.due.isAfter(DateTime.now()))continue;
    while(occupied.contains(id)){id++;}if(id>=6500)break;occupied.add(id);
    await plugin.zonedSchedule(id++,lang==AppLang.fa?'یادآور مراقبت PawPet':lang==AppLang.zh?'PawPet 照护提醒':'PawPet care reminder',lang==AppLang.fa?'یک مراقبت ثبت‌شده موعد دارد. برای جزئیات اپ را باز کنید.':lang==AppLang.zh?'一项照护任务已到期。请打开应用查看详情。':'A care task is due. Open the app for details.',tz.TZDateTime.from(task.due.toUtc(),tz.UTC),details,androidScheduleMode:mode,payload:'care|$user|${task.petId}|${task.id}|${task.due.toUtc().toIso8601String()}|${mode.name}');
   }
   if(gen==_generation)_fingerprint=fingerprint;
  });return _queue;
 }
 Future<void> test(AppLang lang)async{
  if(!await allowed())throw StateError('notifications disabled');
  await plugin.show(5999,'PawPet',lang==AppLang.fa?'اعلان آزمایشی مراقبت':lang==AppLang.zh?'照护测试通知':'Care reminder test',details);
 }
 Future<void> testScheduled(AppLang lang)async{
  if(!await allowed())throw StateError('notifications disabled');
  await plugin.zonedSchedule(5998,'PawPet',lang==AppLang.fa?'تست یادآور زمان‌دار':lang==AppLang.zh?'定时照护测试':'Scheduled care test',tz.TZDateTime.now(tz.UTC).add(const Duration(minutes:1)),details,androidScheduleMode:await _mode());
 }
}
