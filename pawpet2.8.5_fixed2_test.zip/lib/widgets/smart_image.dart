import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../theme.dart';

/// Public media can be cached on disk; private signed media stays in memory only.
class SmartImage extends StatelessWidget {
 final String? src;final BoxFit fit;final String? fallbackAsset;
 const SmartImage({super.key,this.src,this.fit=BoxFit.cover,this.fallbackAsset});
 Widget _ph()=>fallbackAsset!=null?Image.asset(fallbackAsset!,fit:fit):Container(color:AppPal.bg,alignment:Alignment.center,child:const Icon(Icons.broken_image_outlined,color:AppPal.inkSoft,size:40));
 Widget _loading()=>Container(color:AppPal.bg,alignment:Alignment.center,child:const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)));
 @override Widget build(BuildContext context){
  final s=src;if(s==null||s.isEmpty)return _ph();
  if(!s.startsWith('http'))return Image.file(File(s),fit:fit,errorBuilder:(c,e,st)=>_ph());
  return LayoutBuilder(builder:(context,constraints){
   final width=constraints.maxWidth.isFinite?constraints.maxWidth:360.0;
   final pixels=(width*MediaQuery.devicePixelRatioOf(context)).round().clamp(80,1200).toInt();
   final uri=Uri.tryParse(s);final private=uri?.path.contains('/object/sign/')==true||uri?.queryParameters.containsKey('token')==true;
   if(private)return Image.network(s,fit:fit,cacheWidth:pixels,errorBuilder:(c,e,st)=>_ph(),loadingBuilder:(c,child,p)=>p==null?child:_loading());
   return CachedNetworkImage(imageUrl:s,fit:fit,memCacheWidth:pixels,fadeInDuration:const Duration(milliseconds:120),placeholder:(c,url)=>_loading(),errorWidget:(c,url,e)=>_ph());
  });
 }
}
