import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show Supabase;
import 'config.dart';

import 'i18n2.dart';
import 'l10n.dart';
import 'state.dart';
import 'theme.dart';
import 'pages/auth_pages.dart';
import 'pages/events_page.dart';
import 'pages/home_page.dart';
import 'pages/menu_pages.dart';
import 'pages/new_post_page.dart';
import 'pets/care_pages.dart';
import 'pages/profile_page.dart';
import 'pages/post_detail.dart';
import 'widgets/comments.dart';
import 'pages/edit_post_page.dart';
import 'pages/reels_page.dart';
import 'pages/search_page.dart';
import 'pages/shop_dashboard_page.dart';
import 'pages/shop_page.dart';
import 'models.dart';
import 'ads/ads_store.dart';
import 'ads/ads_text.dart';
import 'ads/ads_widgets.dart';
import 'pages/services_page.dart';
import 'pages/messages_page.dart';
import 'pages/notifications_page.dart';
import 'widgets/pigeon.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: kSupabaseUrl, anonKey: kSupabaseKey);
  runApp(const PetListApp());
}

class PetListApp extends StatefulWidget {
  const PetListApp({super.key});

  @override
  State<PetListApp> createState() => _PetListAppState();
}

class _PetListAppState extends State<PetListApp> {
  final AppState s = AppState();

  @override
  void initState() {
    super.initState();
    s.load();
  }

  @override
  void dispose() {
    s.dispose();
    super.dispose();
  }

  ThemeData _theme() => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppPal.purple,
      brightness: Brightness.light,
    ),
    scaffoldBackgroundColor: AppPal.bg,
    dividerColor: const Color(0xFFE9E5F2),
    appBarTheme: const AppBarTheme(scrolledUnderElevation: 0),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(backgroundColor: AppPal.purple, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
    cardTheme: CardThemeData(color: Colors.white, surfaceTintColor: Colors.transparent, elevation: 1, shadowColor: const Color(0x187C5CFF), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFFF3F4F8),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppPal.purple, width: 1.5),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: AppPal.ink,
      contentTextStyle: const TextStyle(color: Colors.white),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      indicatorColor: const Color(0xFFEDE7FF),
      elevation: 2,
      labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
        (states) => TextStyle(
          fontWeight: FontWeight.w700,
          fontSize: 12,
          color: states.contains(WidgetState.selected)
              ? AppPal.purpleDark
              : AppPal.inkSoft,
        ),
      ),
      iconTheme: WidgetStateProperty.resolveWith<IconThemeData>(
        (states) => IconThemeData(
          size: 24,
          color: states.contains(WidgetState.selected)
              ? AppPal.purple
              : AppPal.inkSoft,
        ),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        final t = L10n.of(s.lang);
        final Widget home;
        if (!s.ready) {
          home = const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        } else if (s.me == null) {
          home = LoginPage(s: s);
        } else if (!s.me!.setupDone) {
          home = ProfileSetupPage(s: s);
        } else {
          home = MainShell(s: s);
        }
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: t.appTitle,
          theme: _theme(),
          // جهت متن (RTL/LTR) برای همه‌ی صفحه‌ها، از جمله صفحه‌های بازشده روی هم
          builder: (ctx, child) => Directionality(
            textDirection: s.lang.direction,
            child: child ?? const SizedBox(),
          ),
          home: home,
        );
      },
    );
  }
}

/// قاب اصلی اپ بعد از ورود: ۵ تب + منوی کشویی.
class MainShell extends StatefulWidget {
  final AppState s;
  const MainShell({super.key, required this.s});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> with WidgetsBindingObserver {
  final GlobalKey<ScaffoldState> _key = GlobalKey<ScaffoldState>();
  int _tab = 0;

  AppState get s => widget.s;
  late final AdsStore ads = AdsStore(s);

  @override
  void initState() {
    super.initState();
    ads.initialize();
    WidgetsBinding.instance.addObserver(this);
    s.care.notifications.onOpen=_openCareNotification;
    WidgetsBinding.instance.addPostFrameCallback((_)=>_openCareNotification());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    s.care.notifications.onOpen=null;
    ads.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state){s.foreground=state==AppLifecycleState.resumed;if(s.foreground){s.care.load();}}
  void _openCareNotification(){
    final notifications=s.care.notifications,user=notifications.pendingUser,petId=notifications.pendingPet;
    if(!mounted||user==null||petId==null)return;
    notifications.pendingUser=null;notifications.pendingPet=null;
    if(user!=s.meId)return;
    setState(()=>_tab=1);
    final list=s.myPets.where((p)=>p.id==petId);
    if(list.isNotEmpty)openPetCare(context,s,list.first);
  }

  void _snack(String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  String _errMsg(String key) =>
      (key == 'errNet' || key == 'errFeed') && s.lastError.isNotEmpty
      ? '${tr(s.lang, key)}\n[${s.lastError}]'
      : tr(s.lang, key);

  Future<void> _openNewPost() async {
    final t = L10n.of(s.lang);
    final me = s.me!;
    final result = await Navigator.push<UserPost>(
      context,
      MaterialPageRoute(
        builder: (_) =>
            NewPostPage(lang: s.lang, defaultAuthor: me.username, state: s),
      ),
    );
    if (result == null) return;
    _snack(tr(s.lang, 'posting'));
    final err = await s.addPost(
      UserPost(
        id: result.id,
        author: me.username,
        text: result.text,
        imagePath: result.imagePath,
        mediaType: result.mediaType,
        thumbUrl: result.thumbUrl,
        locationText: result.locationText,
        lat: result.lat,
        lng: result.lng,
        tags: result.tags,
        likes: 0,
        ownerId: me.id,
      ),
    );
    if (!mounted) return;
    if (err != null) {
      _snack(_errMsg(err));
      return;
    }
    _snack(t.postPublished);
    setState(() => _tab = 0);
  }

  Future<void> _openNewEvent() async {
    final ok = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => EventFormPage(s: s)),
    );
    if (ok == true && mounted) _snack(tr(s.lang, 'eventPosted'));
  }

  Future<void> _openUser(String id) async {
    if (id == s.meId) {
      setState(() => _tab = 2);
      return;
    }
    await s.fetchUser(id);
    if (!mounted || s.userById(id) == null) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProfilePage(s: s, userId: id, standalone: true),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(s.lang);
    final me = s.me!;
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) => Scaffold(
        key: _key,
        endDrawer: AppDrawer(s: s),
        appBar: AppBar(
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  'assets/logo/app_logo.png',
                  width: 28,
                  height: 28,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(width: 8),
              Flexible(child: Text(t.appTitle, maxLines: 1, overflow: TextOverflow.ellipsis)),
            ],
          ),
          centerTitle: true,
          backgroundColor: Colors.transparent,
          elevation: 0,
          foregroundColor: Colors.white,
          titleTextStyle: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w800,
          ),
          iconTheme: const IconThemeData(color: Colors.white),
          flexibleSpace: Container(
            decoration: const BoxDecoration(gradient: AppPal.purpleGradient),
          ),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
          ),
          automaticallyImplyLeading: false,
          leadingWidth: _tab == 2 ? 98 : ((_tab == 3 || (_tab == 4 && !kMarketplaceEnabled)) ? 135 : 0),
          leading: _tab == 2 ? Row(
            children: [
              IconButton(
                tooltip: tr(s.lang, 'notifications'),
                icon: Icon(
                  s.hasUnreadNotifications
                      ? Icons.favorite
                      : Icons.favorite_border,
                  color: s.hasUnreadNotifications
                      ? const Color(0xFFFFCFD9)
                      : Colors.white,
                ),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => NotificationsPage(s: s)),
                ),
              ),
              IconButton(
                tooltip: tr(s.lang, 'messages'),
                icon: Badge(
                  isLabelVisible: s.hasUnreadMessages,
                  child: PigeonIcon(size: 28, color: Colors.white),
                ),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => MessagesPage(s: s)),
                ),
              ),
            ],
          ) : (_tab == 3 ? Center(child: EventLocationBar(s:s)) : (_tab == 4 && !kMarketplaceEnabled ? Center(child: AdsLocationBar(store: ads, lang: s.lang)) : null)),

          actions: [
            if (kMarketplaceEnabled)
              IconButton(
                icon: const Icon(Icons.storefront_outlined),
                tooltip: tr(s.lang, 'shMyShop'),
                onPressed: () => openMyShop(context, s),
              ),
            PopupMenuButton<AppLang>(
              icon: const Icon(Icons.translate),
              tooltip: t.changeLang,
              onSelected: s.setLang,
              itemBuilder: (ctx) => [
                for (final l in AppLang.values)
                  PopupMenuItem(
                    value: l,
                    child: Row(
                      children: [
                        Icon(
                          l == s.lang ? Icons.check : Icons.circle_outlined,
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Text(l.label),
                      ],
                    ),
                  ),
              ],
            ),
            IconButton(
              icon: const Icon(Icons.menu),
              tooltip: tr(s.lang, 'menu'),
              onPressed: () => _key.currentState?.openEndDrawer(),
            ),
          ],
        ),
        body: IndexedStack(
          index: _tab,
          children: [
            HomePage(
              lang: s.lang,
              adsStore: ads,
              userPosts: s.visiblePosts(),
              interactions: s.inter,
              showSaved: false,
              meId: me.id,
              onOpenUser: _openUser,
              onRefresh: s.loadFeed,
              errorText: s.feedError,
              onOpenPost: (id) {
                final p = s.findPost(id);
                if (p != null && p.mediaType == 'video') {
                  final vids = s
                      .visiblePosts()
                      .where((x) => x.mediaType == 'video')
                      .toList();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          ReelsPage(s: s, posts: vids, initialId: id),
                    ),
                  );
                } else {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PostDetailPage(s: s, postId: id),
                    ),
                  );
                }
              },
              onOpenComments: (id) => showCommentsSheet(context, s, id),
              onEdit: (id) {
                final p = s.findPost(id);
                if (p == null) return;
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => EditPostPage(s: s, post: p),
                  ),
                );
              },
              onReport: (id) => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ReportPage(s: s, type: 'post', targetId: id),
                ),
              ),
              onSearch: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => SearchPage(s: s)),
              ),
              onRemovePost: s.removePost,
              onToggleSavedTab: (v) {},
              onToggleLike: s.toggleLike,
              onToggleSave: (id) {
                final was = s.inter[id]?.saved ?? false;
                s.toggleSave(id);
                _snack(!was ? t.savedLabel : t.save);
              },
              onComment: s.addComment,
              onShare: (id, author, text) => showShareSheet(context, s, id),
            ),
            PetsDashboard(s:s),
            ProfilePage(s: s, userId: me.id),
            EventsPage(s: s),
            kMarketplaceEnabled
                ? ShopPage(s: s)
                : ServicesPage(s: s, store: ads),
          ],
        ),
        floatingActionButton: (_tab == 0 || _tab == 2 || _tab == 3)
            ? FloatingActionButton.extended(
                onPressed: _tab == 3 ? _openNewEvent : _openNewPost,
                backgroundColor: AppPal.purple,
                foregroundColor: Colors.white,
                icon: Icon(
                  _tab == 3
                      ? Icons.event_available_outlined
                      : Icons.add_a_photo_outlined,
                ),
                label: Text(
                  _tab == 3 ? tr(s.lang, 'newEvent') : t.newPost,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              )
            : null,
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() => _tab = i),
          destinations: [
            NavigationDestination(
              icon: const Icon(Icons.home_outlined),
              selectedIcon: const Icon(Icons.home),
              label: t.tabHome,
            ),
            NavigationDestination(
              icon: const Icon(Icons.pets_outlined),
              selectedIcon: const Icon(Icons.pets),
              label: t.tabPets,
            ),
            NavigationDestination(
              icon: const Icon(Icons.person_outline),
              selectedIcon: const Icon(Icons.person),
              label: tr(s.lang, 'profile'),
            ),
            NavigationDestination(
              icon: const Icon(Icons.event_outlined),
              selectedIcon: const Icon(Icons.event),
              label: t.tabEvents,
            ),
            NavigationDestination(
              icon: const Icon(Icons.storefront_outlined),
              selectedIcon: const Icon(Icons.storefront),
              label: kMarketplaceEnabled
                  ? t.tabShop
                  : adText(s.lang, 'services'),
            ),
          ],
        ),
      ),
    );
  }
}
