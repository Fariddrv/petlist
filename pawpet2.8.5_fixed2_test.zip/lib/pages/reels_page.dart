import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../l10n.dart';
import '../models.dart';
import '../state.dart';
import '../widgets/avatar.dart';
import '../widgets/comments.dart';
import '../i18n2.dart';
import '../widgets/post_media.dart';
import 'edit_post_page.dart';
import 'post_detail.dart';
import 'profile_page.dart';

/// پخش ویدئو به سبک اینستاگرام: با کشیدن انگشت به بالا/پایین، ویدئوی بعدی/قبلی.
/// در پروفایل فقط ویدئوهای همان شخص، در خانه ویدئوهای فید.
class ReelsPage extends StatefulWidget {
  final AppState s;
  final List<UserPost> posts;
  final String initialId;
  const ReelsPage(
      {super.key, required this.s, required this.posts, required this.initialId});

  @override
  State<ReelsPage> createState() => _ReelsPageState();
}

class _ReelsPageState extends State<ReelsPage> {
  late final PageController _pc;
  late List<UserPost> _posts = List.of(widget.posts);
  int _index = 0;

  UserPost? get _current =>
      (_index >= 0 && _index < _posts.length) ? _posts[_index] : null;

  Future<void> _delete(UserPost p) async {
    final t = L10n.of(widget.s.lang);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(t.deleteConfirm),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false), child: Text(t.cancel)),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(t.delete,
                  style: const TextStyle(color: Color(0xFFB3261E)))),
        ],
      ),
    );
    if (ok != true) return;
    await widget.s.removePost(p);
    if (!mounted) return;
    if (_posts.length <= 1) {
      Navigator.pop(context);
      return;
    }
    setState(() {
      _posts = _posts.where((x) => x.id != p.id).toList();
      if (_index >= _posts.length) _index = _posts.length - 1;
    });
  }

  @override
  void initState() {
    super.initState();
    final i = widget.posts.indexWhere((p) => p.id == widget.initialId);
    _index = i < 0 ? 0 : i;
    _pc = PageController(initialPage: _index);
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
        actions: [
          if (_current != null)
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert, color: Colors.white),
              onSelected: (v) {
                final p = _current;
                if (p == null) return;
                final own = p.ownerId == widget.s.meId;
                if (v == 'delete' && own) _delete(p);
                if (v == 'edit' && own) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => EditPostPage(s: widget.s, post: p)));
                }
                if (v == 'report') {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ReportPage(
                              s: widget.s, type: 'post', targetId: p.id)));
                }
              },
              itemBuilder: (ctx) {
                final l = widget.s.lang;
                final own = _current?.ownerId == widget.s.meId;
                return [
                  if (own) ...[
                    PopupMenuItem(value: 'edit', child: Text(tr(l, 'editPost'))),
                    PopupMenuItem(
                        value: 'delete', child: Text(tr(l, 'removePost'))),
                  ] else
                    PopupMenuItem(
                        value: 'report', child: Text(tr(l, 'reportPost'))),
                ];
              },
            ),
        ],
      ),
      body: PageView.builder(
        scrollDirection: Axis.vertical,
        controller: _pc,
        itemCount: _posts.length,
        onPageChanged: (i) => setState(() => _index = i),
        itemBuilder: (c, i) => _ReelItem(
          key: ValueKey(_posts[i].id),
          s: widget.s,
          post: _posts[i],
          active: i == _index,
        ),
      ),
    );
  }
}

class _ReelItem extends StatefulWidget {
  final AppState s;
  final UserPost post;
  final bool active;
  const _ReelItem(
      {super.key, required this.s, required this.post, required this.active});

  @override
  State<_ReelItem> createState() => _ReelItemState();
}

class _ReelItemState extends State<_ReelItem> {
  VideoPlayerController? _c;
  bool _ready = false;
  bool _failed = false;
  bool _playing = false;
  bool _buffering = false;

  @override
  void initState() {
    super.initState();
    final url = widget.post.imagePath;
    if (url == null || url.isEmpty) {
      _failed = true;
      return;
    }
    final c = VideoPlayerController.networkUrl(Uri.parse(url));
    _c = c;
    c.initialize().then((_) {
      if (!mounted) return;
      c.setLooping(true);
      setState(() => _ready = true);
      if (widget.active) c.play();
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
    c.addListener(() {
      final value=c.value;
      if(mounted&&(value.isPlaying!=_playing||value.isBuffering!=_buffering)){setState((){_playing=value.isPlaying;_buffering=value.isBuffering;});}
    });
  }

  @override
  void didUpdateWidget(covariant _ReelItem old) {
    super.didUpdateWidget(old);
    final c = _c;
    if (c == null || !_ready) return;
    if (widget.active && !old.active) {
      c.play();
    } else if (!widget.active && old.active) {
      c.pause();
    }
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  Widget _action(IconData icon, String label, VoidCallback onTap,
      {Color color = Colors.white}) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Column(children: [
          Icon(icon, color: color, size: 32),
          if (label.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(label,
                  style: const TextStyle(color: Colors.white, fontSize: 12.5)),
            ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final p = widget.post;
    final c = _c;
    final t = L10n.of(s.lang);
    return ListenableBuilder(
      listenable: s,
      builder: (ctx, _) {
        final st = s.inter[p.id];
        final liked = st?.liked ?? false;
        final saved = st?.saved ?? false;
        final likes = p.likes + (liked ? 1 : 0);
        final comments = st?.comments.length ?? 0;
        final owner = s.userById(p.ownerId);
        return Stack(
          fit: StackFit.expand,
          children: [
            // ویدئو
            GestureDetector(
              onTap: () {
                if (c == null || !_ready) return;
                c.value.isPlaying ? c.pause() : c.play();
              },
              child: Container(
                color: Colors.black,
                alignment: Alignment.center,
                child: _failed
                    ? const Icon(Icons.error_outline,
                        color: Colors.white70, size: 48)
                    : !_ready
                        ? const CircularProgressIndicator()
                        : AspectRatio(
                            aspectRatio: c!.value.aspectRatio == 0
                                ? 9 / 16
                                : c.value.aspectRatio,
                            child: VideoPlayer(c),
                          ),
              ),
            ),
            if (_ready && c != null && !c.value.isPlaying)
              const IgnorePointer(
                child: Center(
                  child: Icon(Icons.play_circle_fill,
                      size: 72, color: Colors.white54),
                ),
              ),
            // موقعیت در بالا
            if ((p.locationText ?? '').trim().isNotEmpty)
              PositionedDirectional(
                top: MediaQuery.of(context).padding.top + kToolbarHeight,
                start: 12,
                end: 70,
                child: Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: .5),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.location_on,
                          size: 15, color: Colors.white),
                      const SizedBox(width: 4),
                      Flexible(
                        child: Text(p.locationText!.trim(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12.5,
                                fontWeight: FontWeight.w600)),
                      ),
                    ]),
                  ),
                ),
              ),
            // تگ دوستان: پایین سمت چپ
            if (p.tags.isNotEmpty)
              Positioned(
                left: 12,
                bottom: 150,
                right: 90,
                child: Wrap(spacing: 6, runSpacing: 6, children: [
                  for (final tg in p.tags.take(4))
                    GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProfilePage(
                              s: s, userId: tg.id, standalone: true),
                        ),
                      ),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: .5),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          AvatarCircle(url: tg.avatar, name: tg.name, size: 18),
                          const SizedBox(width: 5),
                          Text(tg.name,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 12)),
                        ]),
                      ),
                    ),
                ]),
              ),
            // دکمه‌های کناری
            PositionedDirectional(
              end: 10,
              bottom: 110,
              child: Column(children: [
                _action(liked ? Icons.favorite : Icons.favorite_border,
                    t.num(likes), () => s.toggleLike(p.id),
                    color: liked ? const Color(0xFFFF4D6D) : Colors.white),
                _action(Icons.chat_bubble_outline, t.num(comments),
                    () => showCommentsSheet(context, s, p.id)),
                _action(Icons.send_outlined, '',
                    () => showShareSheet(context, s, p.id)),
                _action(saved ? Icons.bookmark : Icons.bookmark_border, '',
                    () => s.toggleSave(p.id)),
              ]),
            ),
            // نام و توضیح
            PositionedDirectional(
              start: 14,
              end: 80,
              bottom: 58,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  GestureDetector(
                    onTap: () {
                      if (p.ownerId.isEmpty) return;
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProfilePage(
                              s: s, userId: p.ownerId, standalone: true),
                        ),
                      );
                    },
                    child: Row(children: [
                      AvatarCircle(
                          url: owner?.avatarUrl ?? p.authorAvatar,
                          name: p.author,
                          size: 36),
                      const SizedBox(width: 10),
                      Flexible(
                        child: Text(p.author,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                fontSize: 15)),
                      ),
                    ]),
                  ),
                  if (p.text.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(p.text,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white, height: 1.4)),
                    ),
                ],
              ),
            ),
            // نوار پیشرفت (قابل کشیدن برای جلو و عقب بردن)
            if (_ready && c != null)
              PositionedDirectional(
                start: 8,
                end: 8,
                bottom: 14,
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(children: [
                    Text(_fmt(c.value.position),
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 11.5)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: VideoProgressIndicator(
                        c,
                        allowScrubbing: true,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        colors: const VideoProgressColors(
                          playedColor: Colors.white,
                          bufferedColor: Colors.white30,
                          backgroundColor: Colors.white12,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(_fmt(c.value.duration),
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 11.5)),
                  ]),
                ),
              ),
          ],
        );
      },
    );
  }
}
