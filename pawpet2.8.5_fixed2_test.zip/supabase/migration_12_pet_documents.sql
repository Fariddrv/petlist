-- PawPet 2.8.5: private medical documents and bounded profile queries.
begin;
create table if not exists public.pet_documents (
 id uuid primary key default gen_random_uuid(),
 pet_id uuid not null references public.pets(id) on delete cascade,
 title text not null check(length(trim(title)) between 1 and 160),
 file_path text not null unique,
 mime_type text not null check(mime_type in('image/jpeg','image/png','application/pdf')),
 size_bytes integer not null check(size_bytes between 1 and 8388608),
 created_at timestamptz not null default now(),
 check(file_path ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}/[0-9a-f-]{36}\.(jpg|png|pdf)$')
);
create index if not exists pet_documents_pet_idx on public.pet_documents(pet_id,created_at desc,id);
alter table public.pet_documents enable row level security;
drop policy if exists pet_documents_read on public.pet_documents;
create policy pet_documents_read on public.pet_documents for select to authenticated using(
 exists(select 1 from public.pets p where p.id=pet_id and p.owner_id=auth.uid())
);
drop policy if exists pet_documents_add on public.pet_documents;
create policy pet_documents_add on public.pet_documents for insert to authenticated with check(
 split_part(file_path,'/',1)=auth.uid()::text and split_part(file_path,'/',2)=pet_id::text
 and exists(select 1 from public.pets p where p.id=pet_id and p.owner_id=auth.uid())
 and exists(select 1 from storage.objects o where o.bucket_id='pet-documents' and o.name=file_path)
);
drop policy if exists pet_documents_delete on public.pet_documents;
create policy pet_documents_delete on public.pet_documents for delete to authenticated using(
 exists(select 1 from public.pets p where p.id=pet_id and p.owner_id=auth.uid())
);
create or replace function public.pet_document_guard()returns trigger language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null or not exists(select 1 from public.pets where id=new.pet_id and owner_id=auth.uid())then raise exception 'owner only';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,7285));
 if (select count(*)from public.pet_documents d join public.pets p on p.id=d.pet_id where p.owner_id=auth.uid())>=200 then raise exception 'document limit';end if;
 new.created_at:=now();return new;
end $$;
revoke all on function public.pet_document_guard() from public,anon,authenticated;
drop trigger if exists pet_document_guard on public.pet_documents;
create trigger pet_document_guard before insert on public.pet_documents for each row execute function public.pet_document_guard();
revoke all on public.pet_documents from public,anon,authenticated;
grant select,delete on public.pet_documents to authenticated;
grant insert(pet_id,title,file_path,mime_type,size_bytes)on public.pet_documents to authenticated;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('pet-documents','pet-documents',false,8388608,array['image/jpeg','image/png','application/pdf'])
on conflict(id)do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists pet_document_file_add on storage.objects;
create policy pet_document_file_add on storage.objects for insert to authenticated with check(
 bucket_id='pet-documents' and split_part(name,'/',1)=auth.uid()::text
 and name ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}/[0-9a-f-]{36}\.(jpg|png|pdf)$'
 and exists(select 1 from public.pets p where p.id::text=split_part(storage.objects.name,'/',2)and p.owner_id=auth.uid())
);
drop policy if exists pet_document_file_read on storage.objects;
create policy pet_document_file_read on storage.objects for select to authenticated using(
 bucket_id='pet-documents' and split_part(name,'/',1)=auth.uid()::text
);
-- Owner select access also permits Storage API cleanup of their own orphaned files.
-- Owner may remove an orphan after pet deletion or an interrupted upload.
drop policy if exists pet_document_file_delete on storage.objects;
create policy pet_document_file_delete on storage.objects for delete to authenticated using(
 bucket_id='pet-documents' and split_part(name,'/',1)=auth.uid()::text
);
create index if not exists pawpet_posts_owner_created_idx on public.posts(owner_id,created_at desc,id);
create index if not exists pawpet_comments_post_created_idx on public.comments(post_id,created_at);
commit;
