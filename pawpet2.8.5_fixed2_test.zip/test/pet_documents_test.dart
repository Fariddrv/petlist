import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:petlist_test/pets/pet_documents.dart';
void main(){
 test('document type uses bytes rather than filename extension',(){
  expect(documentMime(Uint8List.fromList([37,80,68,70,45,49])), 'application/pdf');
  expect(documentMime(Uint8List.fromList([137,80,78,71,13,10,26,10])), 'image/png');
  expect(documentMime(Uint8List.fromList([255,216,255,224])), 'image/jpeg');
  expect(documentMime(Uint8List.fromList([60,115,99,114,105,112,116])),isNull);
  expect(documentMime(Uint8List(0)),isNull);
 });
 test('document identifiers are UUID v4 compatible and distinct',(){
  final ids=List.generate(100,(_)=>documentId());expect(ids.toSet().length,100);
  for(final id in ids){expect(RegExp(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$').hasMatch(id),isTrue);}
 });
}
