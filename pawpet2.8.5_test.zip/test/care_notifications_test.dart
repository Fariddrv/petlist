import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:petlist_test/l10n.dart';
import 'package:petlist_test/pets/care_models.dart';
import 'package:petlist_test/pets/care_notifications.dart';

void main(){
 TestWidgetsFlutterBinding.ensureInitialized();
 const channel=MethodChannel('dexterous.com/flutter/local_notifications');
 final calls=<MethodCall>[];bool exact=false;List<Map<String,dynamic>> pending=[];
 CareTask task()=>CareTask({'id':'t1','pet_id':'p1','kind':'checkup','title':'care','due_at':DateTime.now().add(const Duration(hours:1)).toUtc().toIso8601String(),'notify':true,'completed':false});
 setUp((){
  debugDefaultTargetPlatformOverride=TargetPlatform.android;calls.clear();exact=false;pending=[];
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(channel,(call)async{
   calls.add(call);
   if(call.method=='areNotificationsEnabled'||call.method=='requestNotificationsPermission'||call.method=='initialize')return true;
   if(call.method=='canScheduleExactNotifications'||call.method=='requestExactAlarmsPermission')return exact;
   if(call.method=='pendingNotificationRequests')return pending;
   return null;
  });
 });
 tearDown((){debugDefaultTargetPlatformOverride=null;TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(channel,null);});
 test('immediate test shows now instead of scheduling an alarm',()async{
  final n=CareNotifications(androidSupported:true);await n.test(AppLang.en);
  expect(calls.where((c)=>c.method=='show').length,1);expect(calls.where((c)=>c.method=='zonedSchedule'),isEmpty);
 });
 test('refresh preserves scheduled tests and skips unchanged schedules',()async{
  final n=CareNotifications(androidSupported:true);final t=task();pending=[{'id':5998,'title':'test','body':'test','payload':null},{'id':6000,'title':'care','body':'care','payload':null}];
  await n.sync('u1',[t],AppLang.en);await n.sync('u1',[t],AppLang.en);
  expect(calls.where((c)=>c.method=='cancelAll'),isEmpty);
  final cancelled=calls.where((c)=>c.method=='cancel').map((c)=>(c.arguments as Map)['id']).toList();
  expect(cancelled,[6000]);expect(calls.where((c)=>c.method=='zonedSchedule').length,1);
 });
 test('logout clears all schedules',()async{
  final n=CareNotifications(androidSupported:true);await n.clear();expect(calls.where((c)=>c.method=='cancelAll').length,1);
 });
 test('enabling exact mode reschedules an unchanged task',()async{
  final n=CareNotifications(androidSupported:true);final t=task();await n.sync('u1',[t],AppLang.en);exact=true;await n.enableExact();await n.sync('u1',[t],AppLang.en);
  expect(calls.where((c)=>c.method=='zonedSchedule').length,2);
 });
 test('a due alarm awaiting Android delivery survives refresh',()async{
  final n=CareNotifications(androidSupported:true);
  final due=DateTime.now().subtract(const Duration(minutes:1)).toUtc().toIso8601String();
  final t=CareTask({'id':'late','pet_id':'p1','kind':'checkup','title':'care','due_at':due,'notify':true,'completed':false});
  pending=[{'id':6000,'title':'care','body':'care','payload':'care|u1|p1|late|$due|inexactAllowWhileIdle'}];
  await n.sync('u1',[t],AppLang.en);
  expect(calls.where((c)=>c.method=='cancel'),isEmpty);expect(calls.where((c)=>c.method=='cancelAll'),isEmpty);
 });

}
