import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:cached_network_image/cached_network_image.dart';
import '../state.dart';
import '../models.dart';
import '../l10n.dart';
import '../data/catalog.dart';
import '../data/jalali.dart';
import '../theme.dart';
import 'care_text.dart';
import 'care_models.dart';

class PetExportPage extends StatefulWidget{
 final AppState s;final Pet pet;final bool lost;
 const PetExportPage({super.key,required this.s,required this.pet,required this.lost});
 @override State<PetExportPage>createState()=>_PetExportPageState();
}
class _PetExportPageState extends State<PetExportPage>{
 final contact=TextEditingController(),area=TextEditingController(),description=TextEditingController();
 final boundary=GlobalKey();bool consent=false,busy=false,photoReady=false;
 ImageProvider? photo;
 String t(String fa,String en,String zh)=>petText(widget.s.lang,fa,en,zh);
 @override void initState(){super.initState();description.text=widget.pet.name;WidgetsBinding.instance.addPostFrameCallback((_)=>_preparePhoto());}
 Future<void> _preparePhoto()async{
  final src=widget.pet.photoPath;photo=src!=null&&src.startsWith('http')?CachedNetworkImageProvider(src):src!=null&&src.isNotEmpty?FileImage(File(src)):AssetImage(widget.pet.image);
  try{await precacheImage(photo!,context,onError:(e,st){photo=null;});}catch(_){photo=null;}if(mounted)setState(()=>photoReady=true);
 }
 @override void dispose(){contact.dispose();area.dispose();description.dispose();super.dispose();}
 Future<void> _share()async{
  if(busy||!consent)return;setState(()=>busy=true);File? output;final user=widget.s.meId;
  try{
   final dir=await getTemporaryDirectory();
   if(widget.lost){
    await WidgetsBinding.instance.endOfFrame;if(!mounted)return;
    final render=boundary.currentContext!.findRenderObject()as RenderRepaintBoundary;
    final image=await render.toImage(pixelRatio:3);final bytes=await image.toByteData(format:ui.ImageByteFormat.png);image.dispose();
    output=File('${dir.path}/pawpet-lost-${DateTime.now().microsecondsSinceEpoch}.png');await output.writeAsBytes(bytes!.buffer.asUint8List());
   }else{
    await widget.s.care.loadPet(widget.pet.id,force:true);if(!mounted||user!=widget.s.meId)return;
    final bytes=await careSummaryPdf(widget.s,widget.pet);
    output=File('${dir.path}/pawpet-care-${DateTime.now().microsecondsSinceEpoch}.pdf');await output.writeAsBytes(bytes);
   }
   if(!mounted||user!=widget.s.meId)return;
   await Share.shareXFiles([XFile(output.path)],subject:widget.pet.name);
  }catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(t('خروجی ساخته نشد؛ دوباره تلاش کنید.','Could not create export. Please retry.','无法生成文件，请重试。'))));}
  finally{if(output!=null&&await output.exists())await output.delete();if(mounted)setState(()=>busy=false);}
 }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.lost?t('کارت گم‌شدن','Lost-pet card','寻宠卡'):t('خلاصهٔ پرونده PDF','Care summary PDF','照护摘要 PDF'))),body:ListView(padding:const EdgeInsets.all(16),children:[
  if(widget.lost)...[
   TextField(controller:contact,maxLength:120,decoration:InputDecoration(labelText:t('راه تماس قابل انتشار','Public contact','公开联系方式')),onChanged:(_)=>setState((){})),
   TextField(controller:area,maxLength:200,decoration:InputDecoration(labelText:t('آخرین محل دیده‌شدن؛ بدون آدرس خصوصی','Last seen area; avoid private addresses','最后出现区域；请勿填写私人地址')),onChanged:(_)=>setState((){})),
   TextField(controller:description,maxLength:300,minLines:2,maxLines:4,decoration:InputDecoration(labelText:t('نشانه‌ها و توضیح کوتاه','Description / distinguishing features','描述 / 特征')),onChanged:(_)=>setState((){})),const SizedBox(height:12),
   RepaintBoundary(key:boundary,child:Container(color:Colors.white,padding:const EdgeInsets.all(22),child:Column(children:[
    Text('PawPet',style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold,color:AppPal.purple)),const SizedBox(height:10),
    Text(t('گم شده‌ام؛ کمکم کنید به خانه برگردم','Lost — help me get home','我走失了，请帮我回家'),textAlign:TextAlign.center,style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900,color:Color(0xFF35215B))),const SizedBox(height:16),
    ClipRRect(borderRadius:BorderRadius.circular(20),child:SizedBox(height:210,width:double.infinity,child:photo==null?const ColoredBox(color:Color(0xFFF0EBFF),child:Icon(Icons.pets,size:90,color:AppPal.purple)):Image(image:photo!,fit:BoxFit.cover))),const SizedBox(height:12),
    Text(widget.pet.name,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),Text(speciesOf(widget.pet.species).name(widget.s.lang)),const SizedBox(height:10),
    Text(description.text,textAlign:TextAlign.center),if(area.text.trim().isNotEmpty)Padding(padding:const EdgeInsets.only(top:10),child:Text('${t('آخرین محل','Last seen','最后出现')}: ${area.text}',textAlign:TextAlign.center)),
    if(contact.text.trim().isNotEmpty)Container(width:double.infinity,margin:const EdgeInsets.only(top:14),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFFF0EBFF),borderRadius:BorderRadius.circular(12)),child:Text(contact.text,textAlign:TextAlign.center,style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold,color:AppPal.purple))),
   ]))),
  ]else Container(padding:const EdgeInsets.all(18),decoration:AppPal.softCard(),child:Text(t('PDF شامل مشخصات، اطلاعات پزشکی و دامپزشک، واکسن‌های شناسنامه و حداکثر ۲۰ مورد اخیر از مراقبت‌ها و وزن‌هاست. فایل‌های ضمیمه در خروجی نیستند. پیش از ارسال، مقصد را بررسی کنید.','PDF includes identity, health and vet notes, passport vaccines and up to 20 recent care records and weights. Attachments are excluded. Check your recipient before sharing.','PDF 包含宠物资料、健康和兽医备注、档案疫苗及最多 20 条近期照护和体重记录，不含附件。分享前请确认接收者。'))),
  const SizedBox(height:16),CheckboxListTile(contentPadding:EdgeInsets.zero,value:consent,onChanged:busy?null:(v)=>setState(()=>consent=v??false),title:Text(widget.lost?t('اجازهٔ انتشار تصویر و اطلاعات این کارت را می‌دهم.','I agree to publish the photo and details on this card.','我同意公开此卡片上的图片和信息。'):t('اجازهٔ ارسال نسخهٔ پرونده به برنامهٔ انتخاب‌شده را می‌دهم.','I agree to send a copy of my care summary to the chosen app.','我同意向所选应用发送照护摘要副本。'))),
  FilledButton.icon(onPressed:busy||!consent||(widget.lost&&(!photoReady||contact.text.trim().isEmpty))?null:_share,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):Icon(widget.lost?Icons.share:Icons.picture_as_pdf),label:Text(widget.lost?t('اشتراک کارت تصویری','Share image card','分享图片卡'):t('ساخت و اشتراک PDF','Create and share PDF','生成并分享 PDF'))),
 ]));
}

/// Raster PDF: Flutter's installed fonts and bidi rendering work offline in fa/en/zh.
/// No external font download and no private data uploaded during export.
Future<List<int>> careSummaryPdf(AppState s,Pet pet)async{
 final l=s.lang;String t(String fa,String en,String zh)=>petText(l,fa,en,zh);
 final h=s.care.health[pet.id]??{};
 final tasks=[...(s.care.tasks[pet.id]??<CareTask>[])];tasks.sort((a,b)=>b.due.compareTo(a.due));
 final weights=s.care.weights[pet.id]??<WeightEntry>[];
 final blocks=<String>[
  'PawPet · ${t('خلاصهٔ پروندهٔ مراقبت','Care journal summary','照护档案摘要')}',
  '${pet.name} · ${speciesOf(pet.species).name(l)}',
  '${t('تاریخ خروجی','Export date','导出日期')}: ${formatDate(DateTime.now(),l)}',
  '${t('تاریخ تولد','Birth date','出生日期')}: ${pet.birth.isEmpty?'—':pet.birth}',
  '${t('یادداشت','Notes','备注')}: ${pet.notes}',
  '${t('حساسیت‌ها','Allergies','过敏')}: ${h['allergies']??''}',
  '${t('بیماری‌ها','Conditions','疾病')}: ${h['conditions']??''}',
  '${t('دارو و دستور دامپزشک','Medication / vet instructions','药物 / 兽医指导')}: ${h['medications']??''}',
  '${t('دامپزشک','Vet','兽医')}: ${h['vet_name']??''}\n${h['vet_phone']??''}\n${h['vet_address']??''}',
  t('واکسن‌های شناسنامه','Passport vaccines','档案疫苗'),
  for(final v in pet.vaccines)'${v.name} · ${v.dateTime==null?'—':formatDate(v.dateTime!,l)}',
  t('حداکثر ۲۰ مراقبت اخیر؛ فایل ضمیمه در خروجی نیست','Up to 20 recent care records; attachments excluded','最多 20 条近期照护记录；不含附件'),
  for(final c in tasks.take(20))'${c.title} · ${formatDate(c.due,l)} · ${c.completed?t('انجام‌شده','Completed','已完成'):t('پیش‌رو','Upcoming','待办')}',
  t('حداکثر ۲۰ وزن اخیر','Up to 20 recent weights','最多 20 条近期体重记录'),
  for(final w in weights.take(20))'${formatDate(w.date,l)} · ${weightText(w.kg,false)} kg',
  t('این پرونده توسط مالک ثبت شده است و گواهی پزشکی نیست.','Owner-entered records; this is not a medical certificate.','记录由主人填写，并非医疗证明。'),
 ];
 const width=794.0,height=1123.0,margin=50.0,usable=height-100;
 final painters=<TextPainter>[];final positions=<double>[];final lineEnds=<double>[];double y=0;
 for(var i=0;i<blocks.length;i++){
  final p=TextPainter(text:TextSpan(text:blocks[i],style:TextStyle(color:const Color(0xFF251B38),fontSize:i==0?26:17,fontWeight:i<2?FontWeight.bold:FontWeight.normal,height:1.5)),textDirection:l==AppLang.fa?TextDirection.rtl:TextDirection.ltr,locale:Locale(l==AppLang.fa?'fa':l==AppLang.zh?'zh':'en'))..layout(maxWidth:width-margin*2);
  painters.add(p);positions.add(y);
  for(final line in p.computeLineMetrics()){lineEnds.add(y+line.baseline+line.descent);}
  y+=p.height+18;
 }
 final breaks=<double>[0];
 while(breaks.last+usable<y){final limit=breaks.last+usable;final options=lineEnds.where((v)=>v>breaks.last&&v<=limit);breaks.add(options.isEmpty?limit:options.last);}
 breaks.add(y);final pages=math.max(1,breaks.length-1);final doc=pw.Document();
 for(var page=0;page<pages;page++){
  final recorder=ui.PictureRecorder();final canvas=Canvas(recorder)..scale(2);
  canvas.drawRect(const Rect.fromLTWH(0,0,width,height),Paint()..color=Colors.white);
  canvas.save();canvas.clipRect(Rect.fromLTWH(margin,margin,width-2*margin,math.min(usable,breaks[page+1]-breaks[page])));
  for(var i=0;i<painters.length;i++){final top=positions[i]-breaks[page];if(top+painters[i].height>0&&top<usable)painters[i].paint(canvas,Offset(margin,margin+top));}
  canvas.restore();final footer=TextPainter(text:TextSpan(text:'PawPet · ${page+1}/$pages',style:const TextStyle(fontSize:12,color:Colors.grey)),textDirection:TextDirection.ltr)..layout();footer.paint(canvas,const Offset(margin,height-32));footer.dispose();
  final picture=recorder.endRecording();final image=await picture.toImage((width*2).round(),(height*2).round());picture.dispose();final data=await image.toByteData(format:ui.ImageByteFormat.png);image.dispose();
  doc.addPage(pw.Page(pageFormat:PdfPageFormat.a4,margin:pw.EdgeInsets.zero,build:(_)=>pw.Image(pw.MemoryImage(data!.buffer.asUint8List()),fit:pw.BoxFit.contain)));
 }
 for(final p in painters){p.dispose();}return doc.save();
}
