import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';

/// تب ایونت‌ها: لیست نمونه + دکمه‌ی شرکت (فاز بعد: ساخت ایونت توسط کاربران).
class EventsPage extends StatefulWidget {
  final AppLang lang;
  const EventsPage({super.key, required this.lang});

  @override
  State<EventsPage> createState() => _EventsPageState();
}

class _EventsPageState extends State<EventsPage> {
  final Set<int> _joined = {};

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color.fromRGBO(21, 101, 192, 0.10),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(t.eventsBanner,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 14, height: 1.7)),
        ),
        const SizedBox(height: 16),
        for (var i = 0; i < sampleEvents.length; i++)
          _eventCard(i, sampleEvents[i]),
      ],
    );
  }

  Widget _eventCard(int i, EventItem e) {
    final joined = _joined.contains(i);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              child: Text(e.emoji, style: const TextStyle(fontSize: 26)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(e.title.of(widget.lang),
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text(e.date.of(widget.lang),
                      style: const TextStyle(color: Colors.grey, fontSize: 13)),
                ],
              ),
            ),
            joined
                ? ElevatedButton(
                    onPressed: () => setState(() => _joined.remove(i)),
                    child: Text(t.eventJoined),
                  )
                : OutlinedButton(
                    onPressed: () => setState(() => _joined.add(i)),
                    child: Text(t.eventJoin),
                  ),
          ],
        ),
      ),
    );
  }
}
