import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';

/// تب خانه: فید اشتراک پست‌ها (فعلاً نمونه).
class HomePage extends StatefulWidget {
  final AppLang lang;
  const HomePage({super.key, required this.lang});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Set<int> _liked = {};

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color.fromRGBO(46, 125, 50, 0.10),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              Text(t.homeWelcome,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(t.homeWelcomeSub,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.grey)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        for (var i = 0; i < samplePosts.length; i++) _postCard(i, samplePosts[i]),
      ],
    );
  }

  Widget _postCard(int i, Post p) {
    final liked = _liked.contains(i);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 22,
                  child: Text(p.emoji, style: const TextStyle(fontSize: 24)),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.author,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      Text(p.title.of(widget.lang)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                IconButton(
                  onPressed: () =>
                      setState(() => liked ? _liked.remove(i) : _liked.add(i)),
                  icon: Icon(liked ? Icons.favorite : Icons.favorite_border,
                      color: liked ? Colors.red : null),
                ),
                Text('${p.likes + (liked ? 1 : 0)}'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
