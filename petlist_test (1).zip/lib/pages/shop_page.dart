import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';

/// تب فروشگاه: ویترین نمونه (فاز بعد: فروشندگان واقعی + پرداخت).
class ShopPage extends StatelessWidget {
  final AppLang lang;
  const ShopPage({super.key, required this.lang});

  void _snack(BuildContext context, String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color.fromRGBO(230, 126, 34, 0.12),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(t.shopBanner,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 14, height: 1.7)),
        ),
        const SizedBox(height: 16),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.78,
          children: [
            for (final p in sampleProducts)
              Card(
                child: InkWell(
                  onTap: () => _snack(context, t.shopTapHint),
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(p.emoji, style: const TextStyle(fontSize: 40)),
                        const SizedBox(height: 8),
                        Text(p.title.of(lang),
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                        const SizedBox(height: 6),
                        Text(t.price(p.price),
                            style: const TextStyle(
                                color: Color(0xFF2E7D32),
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}
