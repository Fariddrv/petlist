import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';

/// تب پت‌های من: افزودن/حذف پت (فعلاً در حافظه؛ فاز بعد: ذخیره‌ی دائمی).
class PetsPage extends StatefulWidget {
  final AppLang lang;
  final List<Pet> pets;
  final ValueChanged<Pet> onAdd;
  final ValueChanged<Pet> onRemove;

  const PetsPage({
    super.key,
    required this.lang,
    required this.pets,
    required this.onAdd,
    required this.onRemove,
  });

  @override
  State<PetsPage> createState() => _PetsPageState();
}

class _PetsPageState extends State<PetsPage> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _age = TextEditingController();
  PetKind _kind = PetKind.cat;

  @override
  void dispose() {
    _name.dispose();
    _age.dispose();
    super.dispose();
  }

  void _snack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg)));

  void _save() {
    final t = L10n.of(widget.lang);
    final name = _name.text.trim();
    if (name.isEmpty) {
      _snack(t.nameRequired);
      return;
    }
    widget.onAdd(Pet(
      name: name,
      kind: _kind,
      age: int.tryParse(_age.text.trim()) ?? 0,
    ));
    _name.clear();
    _age.clear();
    _snack(t.petSaved);
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _name,
                  decoration: InputDecoration(
                    labelText: t.petNameHint,
                    border: const OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                Text(t.petKindLabel,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    ChoiceChip(
                      label: Text(t.kindCat),
                      selected: _kind == PetKind.cat,
                      onSelected: (_) => setState(() => _kind = PetKind.cat),
                    ),
                    ChoiceChip(
                      label: Text(t.kindDog),
                      selected: _kind == PetKind.dog,
                      onSelected: (_) => setState(() => _kind = PetKind.dog),
                    ),
                    ChoiceChip(
                      label: Text(t.kindOther),
                      selected: _kind == PetKind.other,
                      onSelected: (_) => setState(() => _kind = PetKind.other),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _age,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: t.petAgeHint,
                    border: const OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.pets),
                  label: Text(t.petSave),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        if (widget.pets.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 32),
            child: Column(
              children: [
                const Text('🐾', style: TextStyle(fontSize: 56)),
                const SizedBox(height: 12),
                Text(t.petsEmpty,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(t.petsEmptySub,
                    style: const TextStyle(color: Colors.grey)),
              ],
            ),
          )
        else
          for (final p in widget.pets)
            Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: CircleAvatar(child: Text(p.kind.emoji)),
                title: Text(p.name),
                subtitle: Text('${p.age} ${t.yearsOld}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () {
                    widget.onRemove(p);
                    _snack(t.petDeleted);
                  },
                ),
              ),
            ),
      ],
    );
  }
}
