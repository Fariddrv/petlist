import 'l10n.dart';

/// متنی که برای هر سه زبان ترجمه دارد.
class LocalizedText {
  final String fa, en, zh;
  const LocalizedText(this.fa, this.en, this.zh);
  String of(AppLang l) => switch (l) {
        AppLang.fa => fa,
        AppLang.en => en,
        AppLang.zh => zh,
      };
}

enum PetKind { cat, dog, other }

extension PetKindInfo on PetKind {
  String get emoji => switch (this) {
        PetKind.cat => '🐈',
        PetKind.dog => '🐕',
        PetKind.other => '🐾',
      };
}

/// یک پت ثبت‌شده توسط کاربر.
class Pet {
  final String name;
  final PetKind kind;
  final int age;
  const Pet({required this.name, required this.kind, required this.age});
}

class Post {
  final LocalizedText title;
  final String author;
  final String emoji;
  final int likes;
  const Post(this.title, this.author, this.emoji, this.likes);
}

class EventItem {
  final LocalizedText title;
  final LocalizedText date;
  final String emoji;
  const EventItem(this.title, this.date, this.emoji);
}

class Product {
  final LocalizedText title;
  final int price;
  final String emoji;
  const Product(this.title, this.price, this.emoji);
}

/// داده‌های نمونه برای فید (بعداً با داده‌ی واقعی کاربران جایگزین می‌شود).
const List<Post> samplePosts = [
  Post(
    LocalizedText(
      'بسی امروز اولین بار پارک رفت!',
      'Basie went to the park for the first time today!',
      '巴塞今天第一次去公园！',
    ),
    'Sara',
    '🐕',
    24,
  ),
  Post(
    LocalizedText(
      'گربه‌ام عاشق این جعبه شد 📦',
      'My cat fell in love with this box 📦',
      '我的猫爱上了这个盒子 📦',
    ),
    'Ali',
    '🐈',
    41,
  ),
  Post(
    LocalizedText(
      'طوطی کیان یک حرف جدید یاد گرفت!',
      'Kian the parrot learned a new word!',
      '鹦鹉基安学会了新词！',
    ),
    'Mina',
    '🦜',
    17,
  ),
];

/// ایونت‌های نمونه (فاز بعدی: ساخت ایونت توسط کاربران).
const List<EventItem> sampleEvents = [
  EventItem(
    LocalizedText('پیاده‌روی جمعه پارک لاله', 'Friday walk at Laleh Park', '周五拉莱公园散步'),
    LocalizedText('جمعه ۱۰ مهر', 'Fri, Oct 2', '10月2日 周五'),
    '🌳',
  ),
  EventItem(
    LocalizedText('کارگاه نگهداری از گربه', 'Cat care workshop', '猫咪护理工作坊'),
    LocalizedText('شنبه ۱۸ مهر', 'Sat, Oct 10', '10月10日 周六'),
    '🎓',
  ),
  EventItem(
    LocalizedText('جشنواره‌ی پت‌های تهران', 'Tehran pets festival', '德黑兰宠物节'),
    LocalizedText('پنجشنبه ۳۰ مهر', 'Thu, Oct 22', '10月22日 周四'),
    '🎪',
  ),
];

/// محصولات نمونه‌ی فروشگاه (فاز بعدی: فروشندگان واقعی).
const List<Product> sampleProducts = [
  Product(LocalizedText('غذای خشک سگ ۲ کیلویی', 'Dry dog food 2kg', '狗粮 2公斤'), 450000, '🦴'),
  Product(LocalizedText('خاک گربه ۵ لیتری', 'Cat litter 5L', '猫砂 5升'), 180000, '🐈'),
  Product(LocalizedText('اسباب‌بازی جویدنی', 'Chew toy', '咀嚼玩具'), 95000, '🧸'),
  Product(LocalizedText('قلاده‌ی چراغ‌دار', 'LED collar', '发光项圈'), 220000, '💡'),
];
