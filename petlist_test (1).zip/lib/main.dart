import 'package:flutter/material.dart';

import 'l10n.dart';
import 'models.dart';
import 'pages/home_page.dart';
import 'pages/pets_page.dart';
import 'pages/events_page.dart';
import 'pages/shop_page.dart';

void main() => runApp(const PetListApp());

/// اسکلت اصلی اپلیکیشن پت‌لیست: چهار تب + سه زبان.
class PetListApp extends StatefulWidget {
  const PetListApp({super.key});

  @override
  State<PetListApp> createState() => _PetListAppState();
}

class _PetListAppState extends State<PetListApp> {
  AppLang _lang = AppLang.fa; // زبان اصلی: فارسی
  int _tab = 0;
  final List<Pet> _pets = [];

  void _addPet(Pet p) => setState(() => _pets.add(p));
  void _removePet(Pet p) => setState(() => _pets.remove(p));

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(_lang);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: t.appTitle,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2E7D32),
      ),
      home: Directionality(
        textDirection: _lang.direction,
        child: Scaffold(
          appBar: AppBar(
            title: Text(t.appTitle),
            centerTitle: true,
            actions: [
              PopupMenuButton<AppLang>(
                icon: const Icon(Icons.translate),
                tooltip: t.changeLang,
                onSelected: (l) => setState(() => _lang = l),
                itemBuilder: (ctx) => [
                  for (final l in AppLang.values)
                    PopupMenuItem(
                      value: l,
                      child: Row(
                        children: [
                          Icon(
                            l == _lang ? Icons.check : Icons.circle_outlined,
                            size: 18,
                          ),
                          const SizedBox(width: 8),
                          Text(l.label),
                        ],
                      ),
                    ),
                ],
              ),
            ],
          ),
          body: IndexedStack(
            children: [
              HomePage(lang: _lang),
              PetsPage(
                lang: _lang,
                pets: _pets,
                onAdd: _addPet,
                onRemove: _removePet,
              ),
              EventsPage(lang: _lang),
              ShopPage(lang: _lang),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.home_outlined),
                selectedIcon: const Icon(Icons.home),
                label: t.tabHome,
              ),
              NavigationDestination(
                icon: const Icon(Icons.pets_outlined),
                selectedIcon: const Icon(Icons.pets),
                label: t.tabPets,
              ),
              NavigationDestination(
                icon: const Icon(Icons.event_outlined),
                selectedIcon: const Icon(Icons.event),
                label: t.tabEvents,
              ),
              NavigationDestination(
                icon: const Icon(Icons.storefront_outlined),
                selectedIcon: const Icon(Icons.storefront),
                label: t.tabShop,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
