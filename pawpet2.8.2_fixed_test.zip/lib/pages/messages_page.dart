import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/material.dart';
import '../ads/ads_models.dart';
import '../widgets/chat_attachment.dart';
import 'package:flutter/services.dart';

import '../i18n2.dart';
import '../l10n.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/emoji_panel.dart';
import '../widgets/post_media.dart';
import '../widgets/smart_image.dart';
import 'post_detail.dart';

/// فهرست گفتگوها.
Widget _deleteBg(AppLang l, AlignmentGeometry align) => Container(
      color: const Color(0xFFE53935),
      alignment: align,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.delete_outline, color: Colors.white),
        const SizedBox(width: 8),
        Text(tr(l, 'deleteChat'),
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.w800)),
      ]),
    );

Future<bool> _confirmDelete(BuildContext context, AppLang l) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      content: Text(tr(l, 'deleteChatConfirm')),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr(l, 'no'))),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(tr(l, 'deleteChat'),
              style: const TextStyle(
                  color: Color(0xFFE53935), fontWeight: FontWeight.w800)),
        ),
      ],
    ),
  );
  return ok == true;
}

class MessagesPage extends StatelessWidget {
  final AppState s;
  const MessagesPage({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final partners = s.threadPartners();
        return Scaffold(
          appBar: AppBar(title: Text(tr(l, 'messages'))),
          body: partners.isEmpty
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.mail_outline, size: 54, color: AppPal.inkSoft),
                    const SizedBox(height: 10),
                    Text(tr(l, 'noMessages'),
                        style: const TextStyle(color: AppPal.inkSoft)),
                  ]),
                )
              : ListView.separated(
                  itemCount: partners.length,
                  separatorBuilder: (c, i) => const Divider(height: 1, indent: 72),
                  itemBuilder: (c, i) {
                    final u = s.userById(partners[i]);
                    final last = s.thread(partners[i]).last;
                    final unread = s.unreadFrom(partners[i]);
                    return Dismissible(
                      key: ValueKey('chat_${partners[i]}'),
                      direction: DismissDirection.horizontal,
                      background: _deleteBg(l, AlignmentDirectional.centerStart),
                      secondaryBackground:
                          _deleteBg(l, AlignmentDirectional.centerEnd),
                      confirmDismiss: (_) => _confirmDelete(context, l),
                      onDismissed: (_) => s.deleteChat(partners[i]),
                      child: ListTile(
                      onLongPress: () async {
                        if (await _confirmDelete(context, l)) {
                          s.deleteChat(partners[i]);
                        }
                      },
                      leading: UserAvatar(user: u, size: 46),
                      title: Text(u?.username ?? '?',
                          style: TextStyle(
                              fontWeight:
                                  unread ? FontWeight.w900 : FontWeight.w700)),
                      subtitle: Text(
                          last.mediaPath != null ? (last.mediaType == 'video' ? '🎬' : last.mediaType == 'gif' ? 'GIF' : '📷') : last.text.isEmpty && last.postId != null
                              ? tr(l, 'sharedPost')
                              : last.text,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontWeight:
                                  unread ? FontWeight.w800 : FontWeight.w400)),
                      trailing: unread
                          ? Container(
                              width: 12,
                              height: 12,
                              decoration: const BoxDecoration(
                                  color: Color(0xFFE0245E),
                                  shape: BoxShape.circle),
                            )
                          : null,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  ChatPage(s: s, otherId: partners[i]))),
                    ),
                    );
                  },
                ),
        );
      },
    );
  }
}

/// صفحه‌ی گفتگو (مثل دایرکت اینستاگرام: جدیدترین پیام پایین صفحه).
class ChatPage extends StatefulWidget {
  final AppState s;
  final String otherId;
  const ChatPage({super.key, required this.s, required this.otherId});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final _focus = FocusNode();
  bool _showEmoji = false;
  bool _sending = false;
  Msg? _replyTo;

  AppState get s => widget.s;

  @override
  void initState() {
    super.initState();
    _focus.addListener(() {
      if (_focus.hasFocus && _showEmoji) setState(() => _showEmoji = false);
    });
    s.loadMessages();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    _focus.dispose();
    super.dispose();
  }

  String _label(String fa, String en, String zh) => s.lang == AppLang.fa ? fa : s.lang == AppLang.zh ? zh : en;

  void _bottom() => WidgetsBinding.instance.addPostFrameCallback((_) {
    if (mounted && _scroll.hasClients) _scroll.animateTo(0, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
  });

  Future<void> _send() async {
    if (_sending || _ctrl.text.trim().isEmpty) return;
    final txt = _ctrl.text;
    setState(() => _sending = true);
    final ok = await s.sendMsg(widget.otherId, txt, replyTo: _replyTo?.id);
    if (!mounted) return;
    setState(() { _sending = false; if (ok) { if (_ctrl.text == txt) _ctrl.clear(); _replyTo = null; } });
    if (ok) _bottom(); else _snack(_label('پیام ارسال نشد؛ دوباره تلاش کنید.', 'Message failed. Please retry.', '发送失败，请重试。'));
  }

  Future<void> _attach() async {
    if (_sending) return;
    final kind = await showModalBottomSheet<String>(context: context, builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
      ListTile(leading: const Icon(Icons.image_outlined), title: Text(_label('تصویر','Photo','图片')), onTap: () => Navigator.pop(ctx,'image')),
      ListTile(leading: const Icon(Icons.videocam_outlined), title: Text(_label('ویدیو','Video','视频')), onTap: () => Navigator.pop(ctx,'video')),
      ListTile(leading: const Icon(Icons.gif_box_outlined), title: Text(_label('GIF از فایل‌های دستگاه','GIF from device','从设备选择 GIF')), onTap: () => Navigator.pop(ctx,'gif')),
    ])));
    if (kind == null || !mounted) return;
    String? filePath;
    try {
      if (kind == 'gif') {
        final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['gif']);
        filePath = result?.files.single.path;
      } else {
        final picker = ImagePicker();
        final picked = kind == 'video' ? await picker.pickVideo(source: ImageSource.gallery) : await picker.pickImage(source: ImageSource.gallery);
        filePath = picked?.path;
      }
      if (filePath == null || !mounted) return;
      final file = File(filePath);
      final size = await file.length();
      if (size > (kind == 'video' ? 25 : 10) * 1024 * 1024) throw const FormatException('size');
      final ext = filePath.split('.').last.toLowerCase().replaceAll('jpeg','jpg');
      const mimes = {'jpg':'image/jpeg','png':'image/png','webp':'image/webp','gif':'image/gif','mp4':'video/mp4','mov':'video/quicktime'};
      if (!mimes.containsKey(ext) || (kind == 'gif' && ext != 'gif') || (kind == 'video' && !['mp4','mov'].contains(ext)) || (kind == 'image' && !['jpg','png','webp'].contains(ext))) throw const FormatException('format');
      if (!mounted) return;
      final approved = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: Text(_label('ارسال پیوست؟','Send attachment?','发送附件？')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          if (kind != 'video') SizedBox(height: 180, child: Image.file(file, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)))
          else const Icon(Icons.videocam, size: 60),
          Text('${(size / 1024 / 1024).toStringAsFixed(1)} MB · ${filePath!.split('/').last}'),
        ]), actions: [TextButton(onPressed: () => Navigator.pop(ctx,false), child: Text(tr(s.lang,'cancel'))), FilledButton(onPressed: () => Navigator.pop(ctx,true), child: const Icon(Icons.send))],
      ));
      if (approved != true || !mounted) return;
      setState(() => _sending = true);
      final bucket = Supabase.instance.client.storage.from('chat-media');
      final path = '${s.meId}/${widget.otherId}/${requestToken()}.$ext';
      await bucket.upload(path, file, fileOptions: FileOptions(contentType: mimes[ext]!, upsert: false));
      final ok = await s.sendMsg(widget.otherId, '', replyTo: _replyTo?.id, mediaPath: path, mediaType: kind);
      if (!ok) { try { await bucket.remove([path]); } catch (_) {} throw StateError('send'); }
      if (mounted) { setState(() => _replyTo = null); _bottom(); }
    } catch (_) {
      if (mounted) _snack(_label('ارسال نشد. تصویر و GIF تا ۱۰ و ویدیو تا ۲۵ مگابایت؛ فرمت‌های JPG/PNG/WebP/GIF/MP4/MOV پشتیبانی می‌شوند. SQL جدید را نیز اجرا کنید.', 'Upload failed. Photo/GIF: 10 MB; video: 25 MB. Supported: JPG/PNG/WebP/GIF/MP4/MOV. Apply the new SQL migration.', '上传失败。图片/GIF 最大 10 MB，视频最大 25 MB。支持 JPG/PNG/WebP/GIF/MP4/MOV。请运行新的 SQL 迁移。'));
    } finally { if (mounted) setState(() => _sending = false); }
  }

  void _toggleEmoji() {
    if (_showEmoji) {
      setState(() => _showEmoji = false);
      _focus.requestFocus();
    } else {
      _focus.unfocus();
      setState(() => _showEmoji = true);
    }
  }

  void _insert(String e) {
    final v = _ctrl.value;
    final start = v.selection.start < 0 ? v.text.length : v.selection.start;
    final end = v.selection.end < 0 ? v.text.length : v.selection.end;
    final t = v.text.replaceRange(start, end, e);
    _ctrl.value = TextEditingValue(
      text: t,
      selection: TextSelection.collapsed(offset: start + e.length),
    );
  }

  void _snack(String m) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(m)));

  void _actions(Msg m) {
    final l = s.lang;
    final mine = m.from == s.meId;
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.reply, color: AppPal.purple),
            title: Text(tr(l, 'reply')),
            onTap: () {
              Navigator.pop(ctx);
              setState(() => _replyTo = m);
              _focus.requestFocus();
            },
          ),
          if (m.text.isNotEmpty)
            ListTile(
              leading: const Icon(Icons.copy, color: AppPal.purple),
              title: Text(tr(l, 'copy')),
              onTap: () {
                Navigator.pop(ctx);
                Clipboard.setData(ClipboardData(text: m.text));
                _snack(tr(l, 'copied'));
              },
            ),
          if (mine && m.text.isNotEmpty)
            ListTile(
              leading: const Icon(Icons.content_cut, color: AppPal.purple),
              title: Text(tr(l, 'cut')),
              onTap: () {
                Navigator.pop(ctx);
                Clipboard.setData(ClipboardData(text: m.text));
                s.deleteMessage(m.id);
                _snack(tr(l, 'copied'));
              },
            ),
          ListTile(
            leading: const Icon(Icons.paste, color: AppPal.purple),
            title: Text(tr(l, 'paste')),
            onTap: () async {
              Navigator.pop(ctx);
              final d = await Clipboard.getData(Clipboard.kTextPlain);
              if (d?.text != null && d!.text!.isNotEmpty) _insert(d.text!);
            },
          ),
          if (mine)
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Color(0xFFB3261E)),
              title: Text(tr(l, 'deleteMsg'),
                  style: const TextStyle(color: Color(0xFFB3261E))),
              onTap: () {
                Navigator.pop(ctx);
                s.deleteMessage(m.id);
              },
            ),
        ]),
      ),
    );
  }

  String _who(Msg m) => m.from == s.meId
      ? (s.me?.username ?? '')
      : (s.userById(m.from)?.username ?? '');

  Widget _bubble(Msg m) {
    final l = s.lang;
    final mine = m.from == s.meId;
    final fg = mine ? Colors.white : AppPal.ink;
    final quoted = m.replyTo == null ? null : s.messageById(m.replyTo!);
    final post = m.postId == null ? null : s.findPost(m.postId!);
    return Align(
      alignment:
          mine ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
      child: GestureDetector(
        onLongPress: () => _actions(m),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          constraints:
              BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .75),
          decoration: BoxDecoration(
            color: mine ? AppPal.purple : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: mine ? null : Border.all(color: const Color(0x14000000)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (quoted != null)
                Container(
                  margin: const EdgeInsets.only(bottom: 6),
                  padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
                  decoration: BoxDecoration(
                    color: (mine ? Colors.white : AppPal.purple)
                        .withValues(alpha: .15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border(
                        left: BorderSide(
                            color: mine ? Colors.white : AppPal.purple, width: 3)),
                  ),
                  child: Text(
                    '${_who(quoted)}: ${quoted.text.isEmpty ? tr(l, 'sharedPost') : quoted.text}',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: fg.withValues(alpha: .85), fontSize: 12.5),
                  ),
                ),
              if (m.postId != null)
                InkWell(
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => PostDetailPage(s: s, postId: m.postId!))),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    clipBehavior: Clip.antiAlias,
                    width: 210,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (post?.imagePath != null && post!.imagePath!.isNotEmpty)
                          SizedBox(
                              height: 130,
                              width: double.infinity,
                              child: post.mediaType == 'video'
                                  ? VideoThumb(thumbUrl: post.thumbUrl, iconSize: 40)
                                  : SmartImage(
                                      src: post.imagePath, fit: BoxFit.cover)),
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: Text(
                            post == null
                                ? tr(l, 'sharedPost')
                                : '${post.author}${post.text.isEmpty ? '' : '\n${post.text}'}',
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: AppPal.ink, fontSize: 12.5, height: 1.4),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              if (m.mediaPath != null) ChatAttachment(message: m),
              if (m.text.isNotEmpty)
                Text(m.text,
                    style: TextStyle(color: fg, fontSize: 15, height: 1.4)),
              const SizedBox(height: 3),
              Text('${DateTime.fromMillisecondsSinceEpoch(m.at).hour.toString().padLeft(2,"0")}:${DateTime.fromMillisecondsSinceEpoch(m.at).minute.toString().padLeft(2,"0")}', style: TextStyle(fontSize: 9, color: fg.withValues(alpha: .65))),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final other = s.userById(widget.otherId);
        // reverse: true → اولین آیتم پایین صفحه است؛ پس جدیدترین را اول می‌گذاریم
        final list = s.thread(widget.otherId).reversed.toList();
        if (s.unreadFrom(widget.otherId)) {
          WidgetsBinding.instance
              .addPostFrameCallback((_) => s.markChatRead(widget.otherId));
        }
        return Scaffold(
          appBar: AppBar(
            title: Row(children: [
              UserAvatar(user: other, size: 34),
              const SizedBox(width: 10),
              Text(other?.username ?? '?'),
            ]),
          ),
          body: Column(children: [
            Expanded(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: ListView.builder(
                  reverse: true,
                  shrinkWrap: false,
                  controller: _scroll,
                  padding: const EdgeInsets.all(14),
                  itemCount: list.length,
                  itemBuilder: (c, i) => _bubble(list[i]),
                ),
              ),
            ),
            if (_replyTo != null)
              Container(
                color: const Color(0xFFF3F4F8),
                padding: const EdgeInsets.fromLTRB(14, 6, 6, 6),
                child: Row(children: [
                  const Icon(Icons.reply, size: 18, color: AppPal.purple),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '${tr(l, 'replyingTo')} ${_who(_replyTo!)}: ${_replyTo!.text.isEmpty ? tr(l, 'sharedPost') : _replyTo!.text}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: AppPal.inkSoft, fontSize: 12.5),
                    ),
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: () => setState(() => _replyTo = null),
                    icon: const Icon(Icons.close, size: 18),
                  ),
                ]),
              ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
                child: Row(children: [
                  IconButton(
                    tooltip: _label('پیوست','Attach','附件'),
                    onPressed: _sending ? null : _attach,
                    icon: const Icon(Icons.add_circle_outline, color: AppPal.purple),
                  ),
                  IconButton(
                    onPressed: _toggleEmoji,
                    icon: Icon(
                      _showEmoji
                          ? Icons.keyboard_alt_outlined
                          : Icons.emoji_emotions_outlined,
                      color: AppPal.purple,
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      focusNode: _focus,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.newline,
                      decoration: InputDecoration(hintText: tr(l, 'typeMessage')),
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton.filled(
                    onPressed: _sending ? null : _send,
                    style: IconButton.styleFrom(backgroundColor: AppPal.purple),
                    icon: _sending ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.send_rounded),
                  ),
                ]),
              ),
            ),
            if (_showEmoji) EmojiPanel(onPick: _insert),
          ]),
        );
      },
    );
  }
}
