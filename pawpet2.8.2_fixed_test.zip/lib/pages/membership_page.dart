import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../state.dart';
import '../stories/stories_widgets.dart';
import '../theme.dart';
import '../data/shop_catalog.dart';

class MembershipPage extends StatefulWidget{
 final AppState s;const MembershipPage({super.key,required this.s});
 @override State<MembershipPage> createState()=>_MembershipPageState();
}
class _MembershipPageState extends State<MembershipPage>{
 late Future<List<Map<String,dynamic>>> data;
 Future<List<Map<String,dynamic>>> _load()async{final rows=await Supabase.instance.client.from('membership_catalog').select().eq('country',widget.s.me?.country??'IR');return (rows as List).map((r)=>Map<String,dynamic>.from(r)).toList()..sort((a,b)=>const {'normal':0,'supporter':1,'gold':2}[a['tier']]!.compareTo(const {'normal':0,'supporter':1,'gold':2}[b['tier']]!));}
 @override void initState(){super.initState();data=_load();}
 @override Widget build(BuildContext context){final l=widget.s.lang;return Scaffold(appBar:AppBar(title:Text(storyText(l,'عضویت PawPet','PawPet membership','PawPet 会员'))),body:FutureBuilder<List<Map<String,dynamic>>>(future:data,builder:(ctx,snapshot){
 if(snapshot.hasError)return Center(child:TextButton(onPressed:()=>setState(()=>data=_load()),child:Text(storyText(l,'تلاش دوباره','Retry','重试'))));if(!snapshot.hasData)return const Center(child:CircularProgressIndicator());
 return ListView(padding:const EdgeInsets.all(18),children:[
 Text(storyText(l,'طرح‌های پیشنهادی؛ خرید هنوز فعال نیست. سهمیه و قیمت‌های زیر پیش‌نویس‌اند و محدودیتی روی استفاده فعلی ایجاد نمی‌کنند.','Proposed plans: purchases are not enabled. Draft quotas and prices do not restrict current usage.','拟定方案：购买尚未启用。草案配额和价格不会限制当前使用。'),style:const TextStyle(color:AppPal.inkSoft)),
 for(final r in snapshot.data!)Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
 Row(children:[Icon(r['tier']=='gold'?Icons.workspace_premium: r['tier']=='supporter'?Icons.favorite:Icons.person_outline,color:r['tier']=='gold'?AppPal.yellowDark:r['tier']=='supporter'?Colors.green:AppPal.purple),const SizedBox(width:8),Text(r['tier']=='gold'?'PawPet Gold':r['tier']=='supporter'?storyText(l,'حامی حیوانات','Animal supporter','动物支持者'):storyText(l,'عادی','Free','普通会员'),style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18))]),
 const SizedBox(height:10),Text('${r['free_events']} ${storyText(l,'ایونت ماهانه در طرح پیشنهادی','monthly events in the proposed plan','拟定方案的每月活动数')}'),
 if(r['profile_frame']==true)Text(storyText(l,'قاب ویژه پروفایل','Special profile frame','专属头像框')),
 Text('${storyText(l,'تخفیف Boost','Boost discount','推广折扣')}: ${r['boost_discount']}%'),
 Text(r['monthly_price_minor']==null?storyText(l,'قیمت هنوز تعیین نشده','Price not set','价格尚未设定'):formatMoney((r['monthly_price_minor'] as num).toInt(),r['currency'],l)),
 const SizedBox(height:8),Text(storyText(l,'نشان عضویت، تأیید هویت یا کیفیت خدمات نیست.','Membership badge does not verify identity or service quality.','会员标识不代表身份或服务质量认证。'),style:const TextStyle(fontSize:11,color:AppPal.inkSoft)),
 ]))),
 ]);
 }));}
}
