import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../data/jalali.dart';
import '../data/media.dart';
import '../data/places.dart';
import '../data/timeago.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/ad_slider.dart';
import '../widgets/avatar.dart';
import '../widgets/comments.dart';
import '../widgets/smart_image.dart';
import 'participants_page.dart';
import 'profile_page.dart';

/// تب رویدادها: رویدادهای واقعی کاربران (فیلتر کشور و شهر) + بنر تبلیغاتی.
class EventsPage extends StatelessWidget {
  final AppState s;
  const EventsPage({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final list = s.events;
        return RefreshIndicator(
          onRefresh: s.loadEvents,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(16),
            children: [
              AdSlider(key: ValueKey('event-banner-${s.me?.country}'), lang: l, placement: 'events', country: s.me?.country),
              const SizedBox(height: 14),
              Row(children: [
                ChoiceChip(
                  label: Text(tr(l, 'myArea')),
                  selected: s.eventsLocalOnly,
                  onSelected: (_) => s.setEventsLocalOnly(true),
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: Text(tr(l, 'allAreas')),
                  selected: !s.eventsLocalOnly,
                  onSelected: (_) => s.setEventsLocalOnly(false),
                ),
              ]),
              const SizedBox(height: 14),
              if (list.isEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 40),
                  child: Column(children: [
                    const Text('📅', style: TextStyle(fontSize: 48)),
                    const SizedBox(height: 10),
                    Text(tr(l, 'noEvents'),
                        textAlign: TextAlign.center,
                        style:
                            const TextStyle(color: AppPal.inkSoft, height: 1.6)),
                    if (s.eventsError.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text('[${s.eventsError}]',
                            textDirection: TextDirection.ltr,
                            style: const TextStyle(
                                color: Color(0xFFB3261E), fontSize: 11.5)),
                      ),
                  ]),
                )
              else
                for (final e in list) _EventCard(s: s, e: e),
            ],
          ),
        );
      },
    );
  }
}

class _OwnerChip extends StatelessWidget {
  final AppState s;
  final String ownerId;
  const _OwnerChip({required this.s, required this.ownerId});

  @override
  Widget build(BuildContext context) {
    final u = s.userById(ownerId);
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => ProfilePage(s: s, userId: ownerId, standalone: true)),
      ),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 4, 4, 4),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .93),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Text(u?.username ?? '?',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
          const SizedBox(width: 6),
          AvatarCircle(url: u?.avatarUrl, name: u?.username ?? '?', size: 28),
        ]),
      ),
    );
  }
}

class _EventCard extends StatelessWidget {
  final AppState s;
  final AppEvent e;
  const _EventCard({required this.s, required this.e});

  @override
  Widget build(BuildContext context) {
    final l = s.lang;
    final t = L10n.of(l);
    final comments = s.inter[e.id]?.comments.length ?? 0;
    return GestureDetector(
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => EventDetailPage(s: s, eventId: e.id))),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        clipBehavior: Clip.antiAlias,
        decoration: AppPal.softCard(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(children: [
              AspectRatio(
                aspectRatio: 16 / 9,
                child: (e.imageUrl != null && e.imageUrl!.isNotEmpty)
                    ? SmartImage(src: e.imageUrl, fit: BoxFit.cover)
                    : Container(
                        decoration: const BoxDecoration(
                            gradient: AppPal.purpleGradient),
                        alignment: Alignment.center,
                        child: const Text('🐾', style: TextStyle(fontSize: 54)),
                      ),
              ),
              Positioned(
                right: 10,
                top: 10,
                child: _OwnerChip(s: s, ownerId: e.ownerId),
              ),
              Positioned(
                left: 10,
                top: 10,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppPal.yellow,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(formatDate(e.date, l),
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 12.5)),
                ),
              ),
            ]),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
              child: Text(e.title,
                  style: const TextStyle(
                      fontWeight: FontWeight.w900, fontSize: 16.5)),
            ),
            if (e.city.isNotEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: Row(children: [
                  const Icon(Icons.location_on_outlined,
                      size: 15, color: AppPal.inkSoft),
                  const SizedBox(width: 3),
                  Text('${cityName(e.country, e.city, l)}، ${countryName(e.country, l)}',
                      style: const TextStyle(
                          color: AppPal.inkSoft, fontSize: 12.5)),
                ]),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 14, 10),
              child: Row(children: [
                IconButton(
                  onPressed: () => s.toggleLike(e.id),
                  icon: Icon(e.liked ? Icons.favorite : Icons.favorite_border,
                      color: e.liked ? const Color(0xFFE0245E) : AppPal.ink),
                ),
                Text(t.num(e.likes),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(width: 10),
                const Icon(Icons.chat_bubble_outline, size: 20),
                const SizedBox(width: 4),
                Text(t.num(comments),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                const Spacer(),
                InkWell(
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) =>
                              ParticipantsPage(s: s, eventId: e.id))),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Text(
                        '${t.num(e.participants)} ${tr(l, 'participants')}',
                        style: const TextStyle(decoration: TextDecoration.underline, color: AppPal.inkSoft, fontSize: 12.5)),
                  ),
                ),
                const SizedBox(width: 10),
                _JoinButton(s: s, e: e),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

class _JoinButton extends StatelessWidget {
  final AppState s;
  final AppEvent e;
  const _JoinButton({required this.s, required this.e});

  @override
  Widget build(BuildContext context) {
    final l = s.lang;
    return FilledButton(
      onPressed: () => s.toggleJoin(e.id),
      style: FilledButton.styleFrom(
        backgroundColor: e.joined ? const Color(0xFFE5E7EB) : AppPal.purple,
        foregroundColor: e.joined ? AppPal.ink : Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: Text(tr(l, e.joined ? 'cancelJoin' : 'joinEvent'),
          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
    );
  }
}

// ======================= جزئیات رویداد =======================
class EventDetailPage extends StatefulWidget {
  final AppState s;
  final String eventId;
  const EventDetailPage({super.key, required this.s, required this.eventId});

  @override
  State<EventDetailPage> createState() => _EventDetailPageState();
}

class _EventDetailPageState extends State<EventDetailPage> {
  ReplyTarget? _reply;
  AppState get s => widget.s;

  Future<void> _delete() async {
    final l = s.lang;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(tr(l, 'deleteEventConfirm')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(tr(l, 'no'))),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(tr(l, 'yes'),
                  style: const TextStyle(color: Color(0xFFB3261E)))),
        ],
      ),
    );
    if (ok == true) {
      await s.deleteEvent(widget.eventId);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final t = L10n.of(l);
        final e = s.eventById(widget.eventId);
        if (e == null) {
          return Scaffold(
              appBar: AppBar(),
              body: Center(child: Text(tr(l, 'unavailable'))));
        }
        final own = e.ownerId == s.meId;
        return Scaffold(
          appBar: AppBar(
            title: Text(e.title, maxLines: 1, overflow: TextOverflow.ellipsis),
            actions: [
              if (own)
                IconButton(
                    onPressed: _delete,
                    icon: const Icon(Icons.delete_outline,
                        color: Color(0xFFB3261E))),
            ],
          ),
          body: Column(children: [
            Expanded(
              child: ListView(children: [
                Stack(children: [
                  AspectRatio(
                    aspectRatio: 16 / 9,
                    child: (e.imageUrl != null && e.imageUrl!.isNotEmpty)
                        ? SmartImage(src: e.imageUrl, fit: BoxFit.cover)
                        : Container(
                            decoration: const BoxDecoration(
                                gradient: AppPal.purpleGradient),
                            alignment: Alignment.center,
                            child: const Text('🐾',
                                style: TextStyle(fontSize: 60)),
                          ),
                  ),
                  Positioned(
                      right: 10,
                      top: 10,
                      child: _OwnerChip(s: s, ownerId: e.ownerId)),
                ]),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(e.title,
                          style: const TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 20)),
                      const SizedBox(height: 10),
                      Row(children: [
                        const Icon(Icons.event, size: 18, color: AppPal.purple),
                        const SizedBox(width: 6),
                        Text(formatDate(e.date, l),
                            style:
                                const TextStyle(fontWeight: FontWeight.w700)),
                      ]),
                      if (e.city.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Row(children: [
                          const Icon(Icons.location_on_outlined,
                              size: 18, color: AppPal.purple),
                          const SizedBox(width: 6),
                          Text(
                              '${cityName(e.country, e.city, l)}، ${countryName(e.country, l)}'),
                        ]),
                      ],
                      const SizedBox(height: 6),
                      Row(children: [
                        const Icon(Icons.schedule, size: 18, color: AppPal.inkSoft),
                        const SizedBox(width: 6),
                        Text(timeAgo(e.createdAt, l),
                            style: const TextStyle(color: AppPal.inkSoft)),
                      ]),
                      if (e.description.isNotEmpty) ...[
                        const SizedBox(height: 14),
                        Text(e.description,
                            style: const TextStyle(height: 1.7, fontSize: 15)),
                      ],
                      const SizedBox(height: 14),
                      Row(children: [
                        IconButton(
                          onPressed: () => s.toggleLike(e.id),
                          icon: Icon(
                              e.liked ? Icons.favorite : Icons.favorite_border,
                              color: e.liked
                                  ? const Color(0xFFE0245E)
                                  : AppPal.ink),
                        ),
                        Text(t.num(e.likes),
                            style: const TextStyle(fontWeight: FontWeight.w800)),
                        const Spacer(),
                        InkWell(
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) =>
                              ParticipantsPage(s: s, eventId: e.id))),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Text(
                        '${t.num(e.participants)} ${tr(l, 'participants')}',
                        style: const TextStyle(decoration: TextDecoration.underline, fontWeight: FontWeight.w700)),
                  ),
                ),
                        const SizedBox(width: 10),
                        _JoinButton(s: s, e: e),
                      ]),
                    ],
                  ),
                ),
                const Divider(height: 1),
                CommentsList(
                    s: s,
                    postId: e.id,
                    onReply: (r) => setState(() => _reply = r)),
                const SizedBox(height: 12),
              ]),
            ),
            SafeArea(
              top: false,
              child: CommentInputBar(
                s: s,
                postId: e.id,
                reply: _reply,
                onClearReply: () => setState(() => _reply = null),
              ),
            ),
          ]),
        );
      },
    );
  }
}

// ======================= ثبت رویداد جدید =======================
class EventFormPage extends StatefulWidget {
  final AppState s;
  const EventFormPage({super.key, required this.s});

  @override
  State<EventFormPage> createState() => _EventFormPageState();
}

class _EventFormPageState extends State<EventFormPage> {
  final _title = TextEditingController();
  final _desc = TextEditingController();
  DateTime? _date;
  String? _image;
  String? _err;
  bool _busy = false;

  AppState get s => widget.s;

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    super.dispose();
  }

  Future<void> _pick(ImageSource src) async {
    try {
      final f = await ImagePicker()
          .pickImage(source: src, imageQuality: 85, maxWidth: 1600);
      if (f == null) return;
      final saved = await persistImage(f.path);
      if (mounted) setState(() => _image = saved);
    } catch (_) {}
  }

  void _imageSheet() {
    final t = L10n.of(s.lang);
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_library_outlined,
                color: AppPal.purple),
            title: Text(t.gallery),
            onTap: () {
              Navigator.pop(ctx);
              _pick(ImageSource.gallery);
            },
          ),
          ListTile(
            leading:
                const Icon(Icons.photo_camera_outlined, color: AppPal.purple),
            title: Text(t.camera),
            onTap: () {
              Navigator.pop(ctx);
              _pick(ImageSource.camera);
            },
          ),
        ]),
      ),
    );
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final d = await pickDate(context, s.lang,
        initial: _date ?? now, firstYear: now.year, lastYear: now.year + 5);
    if (d != null) setState(() => _date = d);
  }

  Future<void> _submit() async {
    if (_title.text.trim().isEmpty || _date == null) {
      setState(() => _err = 'errFill');
      return;
    }
    final m = s.me;
    if (m == null || m.country.isEmpty) {
      setState(() => _err = 'errNeedLocation');
      return;
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    final e = await s.createEvent(
      title: _title.text,
      description: _desc.text,
      date: _date!,
      imagePath: _image,
    );
    if (!mounted) return;
    if (e != null) {
      setState(() {
        _busy = false;
        _err = e;
      });
      return;
    }
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final l = s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'newEvent'))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        GestureDetector(
          onTap: _imageSheet,
          child: Container(
            height: 190,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: const Color(0xFFEDE7FF),
              borderRadius: BorderRadius.circular(18),
            ),
            child: _image == null
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.add_a_photo_outlined,
                          size: 38, color: AppPal.purple),
                      const SizedBox(height: 8),
                      Text(tr(l, 'eventImage'),
                          style: const TextStyle(color: AppPal.purpleDark)),
                    ],
                  )
                : Image.file(File(_image!), fit: BoxFit.cover),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
            controller: _title,
            decoration: InputDecoration(labelText: tr(l, 'eventName'))),
        const SizedBox(height: 12),
        InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: _pickDate,
          child: InputDecorator(
            decoration: InputDecoration(
              labelText: tr(l, 'eventDate'),
              suffixIcon: const Icon(Icons.calendar_month_outlined),
            ),
            child: Text(
              _date == null ? tr(l, 'pickDate') : formatDate(_date!, l),
              style:
                  TextStyle(color: _date == null ? AppPal.inkSoft : AppPal.ink),
            ),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _desc,
          minLines: 4,
          maxLines: 10,
          decoration: InputDecoration(labelText: tr(l, 'eventDesc')),
        ),
        const SizedBox(height: 10),
        if (s.me != null && s.me!.country.isNotEmpty)
          Text(
              '📍 ${cityName(s.me!.country, s.me!.city, l)}، ${countryName(s.me!.country, l)}',
              style: const TextStyle(color: AppPal.inkSoft)),
        if (_err != null)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(
                _err == 'errNet' && s.lastError.isNotEmpty
                    ? '${tr(l, _err!)}\n[${s.lastError}]'
                    : tr(l, _err!),
                style: const TextStyle(color: Color(0xFFB3261E), fontSize: 13)),
          ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: _busy ? null : _submit,
          style: FilledButton.styleFrom(
            backgroundColor: AppPal.purple,
            minimumSize: const Size.fromHeight(52),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: Text(tr(l, 'submitEvent'),
              style:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
      ]),
    );
  }
}
