import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart'
    show
        Supabase,
        SupabaseClient,
        AuthException,
        PostgrestException,
        FileOptions,
        UserAttributes;

import 'config.dart';
import 'l10n.dart';
import 'models.dart';
import 'shop_state.dart';
import 'stories/stories_store.dart';

/// پروفایل یک کاربر (برای خود کاربر فیلدهای خصوصی هم پر می‌شود).
class AppUser {
  final String id;
  String username, bio;
  String? avatarUrl;
  bool isPrivate, setupDone;
  int followersCount, followingCount, postsCount;
  // فقط برای کاربر فعلی
  String email, mobile, country, city;
  DateTime? birth;
  bool twoFactor;
  List<String> requests, blocked, links;

  AppUser({
    required this.id,
    this.username = '',
    this.bio = '',
    this.avatarUrl,
    this.isPrivate = false,
    this.setupDone = false,
    this.followersCount = 0,
    this.followingCount = 0,
    this.postsCount = 0,
    this.email = '',
    this.mobile = '',
    this.country = '',
    this.city = '',
    this.twoFactor = false,
    List<String>? requests,
    List<String>? blocked,
    List<String>? links,
  })  : requests = requests ?? [],
        blocked = blocked ?? [],
        links = links ?? [];

  factory AppUser.fromRow(Map<String, dynamic> j) => AppUser(
        id: j['id'].toString(),
        username: (j['username'] ?? '').toString(),
        bio: (j['bio'] ?? '').toString(),
        avatarUrl: j['avatar_url'] as String?,
        isPrivate: (j['is_private'] ?? false) as bool,
        setupDone: (j['setup_done'] ?? false) as bool,
        links: j['links'] is List
            ? (j['links'] as List).map((e) => e.toString()).toList()
            : <String>[],
      );
}

class Msg {
  final String id, from, to, text;
  final int at;
  final String? postId;
  final String? replyTo;
  final String? mediaPath, mediaType;
  const Msg(this.id, this.from, this.to, this.text, this.at,
      {this.postId, this.replyTo, this.mediaPath, this.mediaType});

  factory Msg.fromRow(Map<String, dynamic> j) => Msg(
        j['id'].toString(),
        j['sender_id'].toString(),
        j['receiver_id'].toString(),
        (j['text'] ?? '').toString(),
        DateTime.tryParse((j['created_at'] ?? '').toString())
                ?.millisecondsSinceEpoch ??
            0,
        postId: j['post_id']?.toString(),
        replyTo: j['reply_to']?.toString(),
        mediaPath: j['media_path']?.toString(),
        mediaType: j['media_type']?.toString(),
      );
}

class NotifItem {
  final String kind; // like | comment | reply | tag | commentLike
  final String userId;
  final String? postId;
  final int at;
  final String text;
  const NotifItem(this.kind, this.userId, this.postId, this.at, this.text);
}

List<Map<String, dynamic>> _rows(dynamic r) =>
    (r as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();

int _ms(dynamic v) =>
    DateTime.tryParse((v ?? '').toString())?.millisecondsSinceEpoch ?? 0;

class AppState extends ChangeNotifier {
  final SupabaseClient _sb = Supabase.instance.client;

  AppLang lang = AppLang.fa;
  bool ready = false;
  String? meId;

  final Map<String, AppUser> _users = {};
  Map<String, String> myFollows = {}; // شناسه‌ی هدف -> pending | accepted
  List<UserPost> posts = []; // فید
  Map<String, List<UserPost>> userPosts = {};
  List<UserPost> savedPosts = [];
  Map<String, PostInter> inter = {};
  List<Pet> pets = [];
  List<Msg> msgs = [];

  /// آخرین خطای فنی (برای عیب‌یابی؛ در صفحه‌ی ورود/ثبت‌نام نشان داده می‌شود)
  String lastError = '';

  /// خطای آخرین بارگذاری فید (اگر خالی باشد یعنی سالم)
  String feedError = '';

  Timer? _timer;
  bool _polling = false;
  int _tick = 0;

  AppUser? get me => userById(meId);
  AppUser? userById(String? id) => id == null ? null : _users[id];
  List<Pet> get myPets => pets;

  @override
  void dispose() {
    _timer?.cancel();
    stories.dispose();
    super.dispose();
  }

  // ---------- شروع ----------
  Future<void> load() async {
    try {
      final sp = await SharedPreferences.getInstance();
      lang = AppLang.values.firstWhere(
        (l) => l.name == sp.getString('lang_v1'),
        orElse: () => AppLang.fa,
      );
      final cu = _sb.auth.currentUser;
      if (cu != null) {
        meId = cu.id;
        await _bootstrap();
      }
    } catch (e) {
      lastError = e.toString();
    }
    ready = true;
    notifyListeners();
  }

  /// مارکت‌پلیس (فروشگاه‌ها، محصولات و خدمات)
  late final ShopStore shop = ShopStore(this);
  late final StoriesStore stories = StoriesStore(this);

  /// آپلود عکس عمومی (لوگو، عکس محصول) و برگرداندن آدرس
  Future<String?> uploadMedia(String? path, String folder) => _upload(path, folder);

  Future<void> _bootstrap() async {
    await Future.wait(
        [refreshMe(), loadFollows(), loadPets(), loadChatClears(), loadMessages()]);
    await _loadReadState();
    await loadFeed(); // بعد از loadFollows تا ترتیب فید درست باشد
    loadEvents();
    stories.load();
    loadNotifications();
    if (kMarketplaceEnabled) {
      shop.loadMyShop();
      shop.loadCommission();
    }
    _startTimer();
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 6), (_) async {
      if (meId == null || _polling) return;
      _polling = true;
      try {
        await Future.wait([loadMessages(), refreshRequests()]);
        if (++_tick % 4 == 0) {
          await Future.wait([loadFeed(), loadNotifications(), stories.load()]);
        }
      } finally {
        _polling = false;
      }
    });
  }

  void _clear() {
    _timer?.cancel();
    meId = null;
    _users.clear();
    myFollows = {};
    posts = [];
    userPosts = {};
    savedPosts = [];
    inter = {};
    pets = [];
    msgs = [];
    events = [];
    _eventIds.clear();
    notifs = [];
    chatReadAt = {};
    notifSeenAt = 0;
    shop.reset();
    stories.reset();
  }

  // ---------- زبان ----------
  void setLang(AppLang l) {
    lang = l;
    notifyListeners();
    SharedPreferences.getInstance().then((sp) => sp.setString('lang_v1', l.name));
  }

  // ---------- ورود / ثبت‌نام ----------
  Future<String?> signUp({
    required String first,
    required String last,
    required String gender,
    required String email,
    required String mobile,
    required String pass,
    required int birth,
    String country = '',
    String city = '',
  }) async {
    try {
      final d = DateTime.fromMillisecondsSinceEpoch(birth);
      String p2(int n) => n.toString().padLeft(2, '0');
      final res = await _sb.auth.signUp(
        email: email.trim().toLowerCase(),
        password: pass,
        data: {
          'first_name': first.trim(),
          'last_name': last.trim(),
          'gender': gender,
          'mobile': mobile.trim(),
          'birth_date': '${d.year}-${p2(d.month)}-${p2(d.day)}',
          'region': kRegion,
          'country': country,
          'city': city,
        },
      );
      if (res.session == null || res.user == null) return 'errConfirmEmail';
      meId = res.user!.id;
      await _bootstrap();
      notifyListeners();
      return null;
    } on AuthException catch (e) {
      lastError = 'auth ${e.statusCode ?? ''}: ${e.message}';
      final m = e.message.toLowerCase();
      if (m.contains('already')) return 'errEmailUsed';
      if (m.contains('password')) return 'errPassShort';
      if (m.contains('invalid') && m.contains('email')) return 'errEmail';
      return 'errNet';
    } catch (e) {
      lastError = e.toString();
      return 'errNet';
    }
  }

  Future<String?> login(String idOrEmail, String pass) async {
    final k = idOrEmail.trim().toLowerCase();
    if (!k.contains('@')) return 'errUseEmail';
    try {
      final res = await _sb.auth.signInWithPassword(email: k, password: pass);
      if (res.user == null) return 'errLogin';
      meId = res.user!.id;
      await _bootstrap();
      notifyListeners();
      return null;
    } on AuthException catch (e) {
      lastError = 'auth ${e.statusCode ?? ''}: ${e.message}';
      final m = e.message.toLowerCase();
      if (m.contains('invalid') || m.contains('credentials')) return 'errLogin';
      return 'errNet';
    } catch (e) {
      lastError = e.toString();
      return 'errNet';
    }
  }

  Future<void> logout() async {
    try {
      await _sb.auth.signOut();
    } catch (_) {}
    _clear();
    notifyListeners();
  }

  Future<String?> changePassword(String oldPass, String newPass) async {
    final m = me;
    if (m == null) return 'errLogin';
    try {
      await _sb.auth.signInWithPassword(email: m.email, password: oldPass);
    } on AuthException {
      return 'errOldPass';
    } catch (_) {
      return 'errNet';
    }
    try {
      await _sb.auth.updateUser(UserAttributes(password: newPass));
      return null;
    } on AuthException {
      return 'errPassShort';
    } catch (_) {
      return 'errNet';
    }
  }

  // ---------- آپلود عکس ----------
  Future<String?> _upload(String? path, String folder) async {
    if (path == null || path.isEmpty) return null;
    if (path.startsWith('http')) return path;
    final uid = meId;
    if (uid == null) return null;
    try {
      final ext = path.contains('.') ? path.split('.').last.toLowerCase() : 'jpg';
      final name = '$uid/$folder-${DateTime.now().microsecondsSinceEpoch}.$ext';
      await _sb.storage.from('media').upload(
            name,
            File(path),
            fileOptions: FileOptions(
              contentType: switch (ext) {
                'png' => 'image/png',
                'webp' => 'image/webp',
                'gif' => 'image/gif',
                'mp4' => 'video/mp4',
                'mov' => 'video/quicktime',
                'webm' => 'video/webm',
                '3gp' => 'video/3gpp',
                _ => 'image/jpeg',
              },
            ),
          );
      return _sb.storage.from('media').getPublicUrl(name);
    } catch (e) {
      lastError = 'upload: $e';
      return null;
    }
  }

  // ---------- پروفایل ----------
  Future<AppUser?> fetchUser(String id, {bool force = false}) async {
    if (!force && _users.containsKey(id)) return _users[id];
    try {
      final row = await _sb.from('profiles').select().eq('id', id).maybeSingle();
      if (row == null) return _users[id];
      final u = AppUser.fromRow(Map<String, dynamic>.from(row));
      final old = _users[id];
      if (old != null) {
        u.email = old.email;
        u.mobile = old.mobile;
        u.country = old.country;
        u.city = old.city;
        u.birth = old.birth;
        u.twoFactor = old.twoFactor;
        u.requests = old.requests;
        u.blocked = old.blocked;
      }
      try {
        final st = await _sb.rpc('profile_stats', params: {'uid': id});
        if (st is Map) {
          u.followersCount = (st['followers'] as num?)?.toInt() ?? 0;
          u.followingCount = (st['following'] as num?)?.toInt() ?? 0;
          u.postsCount = (st['posts'] as num?)?.toInt() ?? 0;
        }
      } catch (_) {}
      _users[id] = u;
      notifyListeners();
      return u;
    } catch (_) {
      return _users[id];
    }
  }

  Future<void> _cacheProfiles(Iterable<String> ids) async {
    final need = ids.where((i) => !_users.containsKey(i)).toSet().toList();
    if (need.isEmpty) return;
    try {
      final rows = _rows(await _sb.from('profiles').select().inFilter('id', need));
      for (final r in rows) {
        _users[r['id'].toString()] = AppUser.fromRow(r);
      }
    } catch (_) {}
  }

  Future<void> refreshMe() async {
    final id = meId;
    if (id == null) return;
    final u = await fetchUser(id, force: true);
    if (u == null) return;
    u.email = _sb.auth.currentUser?.email ?? u.email;
    await Future.wait([
      () async {
        try {
          final pi =
              await _sb.from('private_info').select().eq('id', id).maybeSingle();
          if (pi != null) {
            u.mobile = (pi['mobile'] ?? '').toString();
            u.country = (pi['country'] ?? '').toString();
            u.city = (pi['city'] ?? '').toString();
            u.birth = DateTime.tryParse((pi['birth_date'] ?? '').toString());
            u.twoFactor = (pi['two_factor'] ?? false) as bool;
          }
        } catch (_) {}
      }(),
      refreshRequests(),
      () async {
        try {
          final bl = _rows(
              await _sb.from('blocks').select('blocked_id').eq('blocker_id', id));
          u.blocked = bl.map((e) => e['blocked_id'].toString()).toList();
          await _cacheProfiles(u.blocked);
        } catch (_) {}
      }(),
    ]);
    notifyListeners();
  }

  /// فقط درخواست‌های دنبال‌کردنِ در انتظار (برای به‌روزرسانی سبک)
  Future<void> refreshRequests() async {
    final id = meId;
    final u = me;
    if (id == null || u == null) return;
    try {
      final req = _rows(await _sb
          .from('follows')
          .select('follower_id')
          .eq('followee_id', id)
          .eq('status', 'pending'));
      u.requests = req.map((e) => e['follower_id'].toString()).toList();
      await _cacheProfiles(u.requests);
      notifyListeners();
    } catch (_) {}
  }

  Future<String?> saveProfile({
    required String username,
    required String bio,
    String? avatarPath,
    List<String> links = const [],
  }) async {
    final m = me;
    if (m == null) return 'errLogin';
    final n = username.trim();
    if (!RegExp(r'^[A-Za-z0-9_.]{3,20}$').hasMatch(n)) return 'errUsername';
    try {
      final data = <String, dynamic>{
        'username': n,
        'bio': bio.trim(),
        'links': links,
        'setup_done': true,
      };
      if (avatarPath != null) {
        final url = await _upload(avatarPath, 'avatar');
        if (url != null) data['avatar_url'] = url;
      }
      await _sb.from('profiles').update(data).eq('id', m.id);
      await fetchUser(m.id, force: true);
      await refreshMe();
      return null;
    } on PostgrestException catch (e) {
      lastError = 'db ${e.code ?? ''}: ${e.message}';
      if (e.code == '23505') return 'errUsernameUsed';
      return 'errNet';
    } catch (e) {
      lastError = e.toString();
      return 'errNet';
    }
  }

  Future<bool> updateLocation(String country, String city) async {
    final m = me;
    if (m == null) return false;
    try {
      await _sb
          .from('private_info')
          .update({'country': country, 'city': city}).eq('id', m.id);
      m.country = country;
      m.city = city;
      notifyListeners();
      return true;
    } catch (e) {
      lastError = 'location: $e';
      return false;
    }
  }

  /// جستجوی کاربران با نام کاربری (کشور و شهر مهم نیست)
  Future<List<AppUser>> searchUsers(String q) async {
    final t = q
        .trim()
        .replaceAll(RegExp(r'[%,()]'), '')
        .replaceAll('_', r'\_');
    if (t.length < 2) return [];
    try {
      final rows = _rows(await _sb
          .from('profiles')
          .select()
          .ilike('username', '%$t%')
          .eq('setup_done', true)
          .limit(30));
      final out = <AppUser>[];
      for (final r in rows) {
        final u = AppUser.fromRow(r);
        if (u.id == meId) continue;
        if (me?.blocked.contains(u.id) ?? false) continue;
        _users.putIfAbsent(u.id, () => u);
        out.add(_users[u.id]!);
      }
      return out;
    } catch (e) {
      lastError = 'search: $e';
      return [];
    }
  }

  Future<bool> submitSupport(String name, String subject, String message) async {
    final id = meId;
    if (id == null) return false;
    try {
      await _sb.from('support_messages').insert({
        'user_id': id,
        'name': name.trim(),
        'subject': subject.trim(),
        'message': message.trim(),
      });
      return true;
    } catch (e) {
      lastError = 'support: $e';
      return false;
    }
  }

  Future<void> setPrivate(bool v) async {
    final m = me;
    if (m == null) return;
    m.isPrivate = v;
    notifyListeners();
    try {
      await _sb.from('profiles').update({'is_private': v}).eq('id', m.id);
      if (!v) {
        await _sb
            .from('follows')
            .update({
              'status': 'accepted',
              'accepted_at': DateTime.now().toUtc().toIso8601String(),
            })
            .eq('followee_id', m.id)
            .eq('status', 'pending');
      }
    } catch (_) {}
    await refreshMe();
  }

  Future<void> setTwoFactor(bool v) async {
    final m = me;
    if (m == null) return;
    m.twoFactor = v;
    notifyListeners();
    try {
      await _sb.from('private_info').update({'two_factor': v}).eq('id', m.id);
    } catch (_) {}
  }

  // ---------- دنبال‌کردن و مسدودسازی ----------
  Future<void> loadFollows() async {
    final id = meId;
    if (id == null) return;
    try {
      final rows = _rows(await _sb
          .from('follows')
          .select('followee_id,status')
          .eq('follower_id', id));
      myFollows = {
        for (final r in rows) r['followee_id'].toString(): r['status'].toString()
      };
      notifyListeners();
    } catch (_) {}
  }

  /// none | requested | following
  String relation(AppUser t) => switch (myFollows[t.id]) {
        'accepted' => 'following',
        'pending' => 'requested',
        _ => 'none',
      };

  Future<void> follow(AppUser t) async {
    myFollows[t.id] = t.isPrivate ? 'pending' : 'accepted';
    notifyListeners();
    try {
      final st = await _sb.rpc('follow_user', params: {'target': t.id});
      myFollows[t.id] = st.toString();
      notifyListeners();
    } catch (_) {
      myFollows.remove(t.id);
      notifyListeners();
    }
    await Future.wait([
      fetchUser(t.id, force: true),
      loadUserPosts(t.id),
      loadFeed(),
    ]);
  }

  Future<void> unfollow(AppUser t) async {
    final id = meId;
    if (id == null) return;
    myFollows.remove(t.id);
    notifyListeners();
    try {
      await _sb
          .from('follows')
          .delete()
          .eq('follower_id', id)
          .eq('followee_id', t.id);
    } catch (_) {}
    await Future.wait([
      fetchUser(t.id, force: true),
      loadUserPosts(t.id),
      loadFeed(),
    ]);
  }

  Future<void> approve(String uid) async {
    final id = meId;
    if (id == null) return;
    try {
      await _sb
          .from('follows')
          .update({
            'status': 'accepted',
            'accepted_at': DateTime.now().toUtc().toIso8601String(),
          })
          .eq('follower_id', uid)
          .eq('followee_id', id);
    } catch (_) {}
    await refreshMe();
  }

  Future<void> decline(String uid) async {
    final id = meId;
    if (id == null) return;
    try {
      await _sb
          .from('follows')
          .delete()
          .eq('follower_id', uid)
          .eq('followee_id', id);
    } catch (_) {}
    await refreshMe();
  }

  Future<void> block(AppUser t) async {
    try {
      await _sb.rpc('block_user', params: {'target': t.id});
    } catch (_) {}
    myFollows.remove(t.id);
    await refreshMe();
    await loadFeed();
  }

  Future<void> unblock(String id) async {
    final m = meId;
    if (m == null) return;
    try {
      await _sb.from('blocks').delete().eq('blocker_id', m).eq('blocked_id', id);
    } catch (_) {}
    await refreshMe();
    await loadFeed();
  }

  bool canSee(AppUser t) {
    final m = me;
    if (m == null) return false;
    if (t.id == m.id) return true;
    if (m.blocked.contains(t.id)) return false;
    return !t.isPrivate || myFollows[t.id] == 'accepted';
  }

  // ---------- پست‌ها ----------
  String _nameOf(String uid) => _users[uid]?.username ?? '?';

  /// پست‌ها را کامل می‌کند (نویسنده، لایک، نظر، ذخیره). درخواست‌ها موازی
  /// ارسال می‌شوند و خطا در یک بخش باعث خالی‌شدن کل فید نمی‌شود.
  Future<List<UserPost>> _hydrate(List<Map<String, dynamic>> rows) async {
    if (rows.isEmpty) return [];
    final me0 = meId;
    final ids = rows.map((r) => r['id'].toString()).toList();

    var likes = <Map<String, dynamic>>[];
    var coms = <Map<String, dynamic>>[];
    var saves = <Map<String, dynamic>>[];
    var tagRows = <Map<String, dynamic>>[];
    await Future.wait([
      _cacheProfiles(rows.map((r) => r['owner_id'].toString())),
      () async {
        try {
          tagRows = _rows(await _sb
              .from('post_tags')
              .select('post_id,user_id')
              .inFilter('post_id', ids));
          await _cacheProfiles(tagRows.map((t) => t['user_id'].toString()));
        } catch (e) {
          lastError = 'tags: $e';
        }
      }(),
      () async {
        try {
          likes = _rows(await _sb
              .from('post_likes')
              .select('post_id,user_id')
              .inFilter('post_id', ids));
        } catch (e) {
          lastError = 'likes: $e';
        }
      }(),
      () async {
        try {
          coms = _rows(await _sb
              .from('comments')
              .select('id,post_id,user_id,text,created_at,parent_id')
              .inFilter('post_id', ids)
              .order('created_at'));
        } catch (e) {
          lastError = 'comments: $e';
        }
      }(),
      () async {
        try {
          saves = _rows(await _sb
              .from('post_saves')
              .select('post_id')
              .eq('user_id', me0 ?? '')
              .inFilter('post_id', ids));
        } catch (e) {
          lastError = 'saves: $e';
        }
      }(),
    ]);

    final cmap = await _buildComments(coms);

    final likeCount = <String, int>{};
    final myLikes = <String>{};
    for (final l in likes) {
      final p = l['post_id'].toString();
      likeCount[p] = (likeCount[p] ?? 0) + 1;
      if (l['user_id'].toString() == me0) myLikes.add(p);
    }
    final mySaves = saves.map((e) => e['post_id'].toString()).toSet();

    final tagMap = <String, List<PostTag>>{};
    for (final t in tagRows) {
      final u = _users[t['user_id'].toString()];
      if (u == null) continue;
      (tagMap[t['post_id'].toString()] ??= [])
          .add(PostTag(u.id, u.username, u.avatarUrl));
    }

    final out = <UserPost>[];
    for (final r in rows) {
      final id = r['id'].toString();
      final owner = r['owner_id'].toString();
      final liked = myLikes.contains(id);
      inter[id] = PostInter(
        liked: liked,
        saved: mySaves.contains(id),
        comments: cmap[id] ?? <Comment>[],
      );
      out.add(UserPost(
        id: id,
        author: _nameOf(owner),
        text: (r['text'] ?? '').toString(),
        imagePath: r['image_url'] as String?,
        likes: (likeCount[id] ?? 0) - (liked ? 1 : 0),
        ownerId: owner,
        authorAvatar: _users[owner]?.avatarUrl,
        createdAt: _ms(r['created_at']),
        mediaType: (r['media_type'] ?? 'image').toString(),
        locationText: r['location_text'] as String?,
        lat: (r['lat'] as num?)?.toDouble(),
        lng: (r['lng'] as num?)?.toDouble(),
        tags: tagMap[id] ?? const <PostTag>[],
        editedAt: _ms(r['edited_at']),
        thumbUrl: r['thumb_url'] as String?,
      ));
    }
    for (final p in out) {
      _postCache[p.id] = p;
    }
    return out;
  }

  /// ردیف‌های کامنت را (همراه لایک‌ها و نام نویسنده) به Comment تبدیل می‌کند.
  Future<Map<String, List<Comment>>> _buildComments(
      List<Map<String, dynamic>> coms,
      {String likesTable = 'comment_likes', String refCol = 'post_id'}) async {
    final out = <String, List<Comment>>{};
    if (coms.isEmpty) return out;
    final me0 = meId;
    var clikes = <Map<String, dynamic>>[];
    await Future.wait([
      _cacheProfiles(coms.map((c) => c['user_id'].toString())),
      () async {
        try {
          clikes = _rows(await _sb
              .from(likesTable)
              .select('comment_id,user_id')
              .inFilter('comment_id', coms.map((c) => c['id'].toString()).toList()));
        } catch (e) {
          lastError = 'comment_likes: $e';
        }
      }(),
    ]);
    final cnt = <String, int>{};
    final mine = <String>{};
    for (final l in clikes) {
      final c = l['comment_id'].toString();
      cnt[c] = (cnt[c] ?? 0) + 1;
      if (l['user_id'].toString() == me0) mine.add(c);
    }
    for (final c in coms) {
      final pid = c[refCol].toString();
      final id = c['id'].toString();
      (out[pid] ??= []).add(Comment(
        id: id,
        author: _nameOf(c['user_id'].toString()),
        userId: c['user_id'].toString(),
        text: (c['text'] ?? '').toString(),
        createdAt: _ms(c['created_at']),
        parentId: c['parent_id']?.toString(),
        likes: cnt[id] ?? 0,
        liked: mine.contains(id),
      ));
    }
    return out;
  }

  final Map<String, UserPost> _postCache = {};

  /// پیدا کردن یک پست از حافظه (فید، پروفایل‌ها، ذخیره‌شده‌ها)
  UserPost? findPost(String id) => _postCache[id];

  /// گرفتن یک پست از سرور (برای پست‌های فرستاده‌شده در پیام)
  Future<UserPost?> fetchPost(String id) async {
    if (_postCache.containsKey(id)) return _postCache[id];
    try {
      final rows = _rows(
          await _sb.from('posts').select(_postCols).eq('id', id).limit(1));
      if (rows.isEmpty) return null;
      final l = await _hydrate(rows);
      notifyListeners();
      return l.isEmpty ? null : l.first;
    } catch (_) {
      return null;
    }
  }

  /// نظرات یک پست را دوباره از سرور می‌خواند
  Future<void> reloadComments(String postId) async {
    try {
      final ev = _eventIds.contains(postId);
      final rows = _rows(await _sb
          .from(ev ? 'event_comments' : 'comments')
          .select(ev
              ? 'id,event_id,user_id,text,created_at,parent_id'
              : 'id,post_id,user_id,text,created_at,parent_id')
          .eq(ev ? 'event_id' : 'post_id', postId)
          .order('created_at'));
      final m = await _buildComments(rows,
          likesTable: ev ? 'event_comment_likes' : 'comment_likes',
          refCol: ev ? 'event_id' : 'post_id');
      final cur = inter[postId] ?? const PostInter(comments: []);
      inter[postId] = cur.copyWith(comments: m[postId] ?? <Comment>[]);
      notifyListeners();
    } catch (e) {
      lastError = 'reloadComments: $e';
    }
  }

  static const _postCols =
      'id,owner_id,text,image_url,media_type,thumb_url,created_at,location_text,lat,lng,edited_at';

  Future<void> loadFeed() async {
    if (meId == null) return;
    try {
      final rows = _rows(await _sb
          .from('posts')
          .select(_postCols)
          .order('created_at', ascending: false)
          .limit(100));
      // اولویت با پست‌های خودم و افرادی که دنبال می‌کنم، بعد بقیه (هر گروه جدید به قدیم)
      final fol = <String>{
        for (final e in myFollows.entries)
          if (e.value == 'accepted') e.key,
        if (meId != null) meId!,
      };
      rows.sort((a, b) {
        final fa = fol.contains(a['owner_id'].toString()) ? 0 : 1;
        final fb = fol.contains(b['owner_id'].toString()) ? 0 : 1;
        if (fa != fb) return fa.compareTo(fb);
        return b['created_at'].toString().compareTo(a['created_at'].toString());
      });
      posts = await _hydrate(rows);
      feedError = '';
    } catch (e) {
      feedError = e.toString();
    }
    notifyListeners();
  }

  List<UserPost> visiblePosts() => posts;

  Future<void> loadUserPosts(String uid) async {
    if (meId == null) return;
    try {
      final rows = _rows(await _sb
          .from('posts')
          .select(_postCols)
          .eq('owner_id', uid)
          .order('created_at', ascending: false)
          .limit(100));
      userPosts[uid] = await _hydrate(rows);
      notifyListeners();
    } catch (e) {
      lastError = 'userPosts: $e';
    }
  }

  Future<void> loadSaved() async {
    final id = meId;
    if (id == null) return;
    try {
      final r = _rows(await _sb
          .from('post_saves')
          .select('post_id,created_at')
          .eq('user_id', id)
          .order('created_at', ascending: false));
      final ids = r.map((e) => e['post_id'].toString()).toList();
      if (ids.isEmpty) {
        savedPosts = [];
      } else {
        final rows = _rows(
            await _sb.from('posts').select(_postCols).inFilter('id', ids));
        rows.sort((a, b) => ids
            .indexOf(a['id'].toString())
            .compareTo(ids.indexOf(b['id'].toString())));
        savedPosts = await _hydrate(rows);
      }
      notifyListeners();
    } catch (e) {
      lastError = 'saved: $e';
    }
  }

  /// null یعنی موفق؛ در غیر این‌صورت کلید پیام خطا.
  Future<String?> addPost(UserPost p) async {
    final id = meId;
    if (id == null) return 'errLogin';
    lastError = '';
    String? url;
    if (p.imagePath != null && p.imagePath!.isNotEmpty) {
      url = await _upload(p.imagePath, 'post');
      if (url == null) {
        if (lastError.isEmpty) lastError = 'image upload failed';
        return 'errNet';
      }
    }
    String? thumb;
    if (p.mediaType == 'video' && p.thumbUrl != null && p.thumbUrl!.isNotEmpty) {
      thumb = await _upload(p.thumbUrl, 'thumb');
    }
    try {
      final row = await _sb
          .from('posts')
          .insert({
            'owner_id': id,
            'text': p.text,
            'image_url': url,
            'media_type': p.mediaType,
            'thumb_url': thumb,
            'location_text': (p.locationText ?? '').isEmpty ? null : p.locationText,
            'lat': p.lat,
            'lng': p.lng,
          })
          .select('id')
          .single();
      if (p.tags.isNotEmpty) {
        final pid = row['id'].toString();
        try {
          await _sb.from('post_tags').insert([
            for (final t in p.tags) {'post_id': pid, 'user_id': t.id}
          ]);
        } catch (e) {
          lastError = 'tags insert: $e';
        }
      }
    } catch (e) {
      lastError = 'insert: $e';
      return 'errNet';
    }
    await Future.wait([
      loadFeed(),
      loadUserPosts(id),
      fetchUser(id, force: true),
    ]);
    if (feedError.isNotEmpty) {
      lastError = feedError;
      return 'errFeed';
    }
    if (!posts.any((x) => x.ownerId == id)) {
      lastError = 'post saved but not visible when reading the feed';
      return 'errFeed';
    }
    return null;
  }

  /// ویرایش متن، موقعیت و تگ‌های یک پست (عکس/ویدئو عوض نمی‌شود).
  Future<bool> updatePost(
    String postId, {
    required String text,
    String? locationText,
    double? lat,
    double? lng,
    required List<String> tagIds,
  }) async {
    final id = meId;
    if (id == null) return false;
    try {
      await _sb.from('posts').update({
        'text': text.trim(),
        'location_text': (locationText ?? '').trim().isEmpty ? null : locationText!.trim(),
        'lat': lat,
        'lng': lng,
        'edited_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', postId);
      await _sb.from('post_tags').delete().eq('post_id', postId);
      if (tagIds.isNotEmpty) {
        await _sb.from('post_tags').insert([
          for (final t in tagIds) {'post_id': postId, 'user_id': t}
        ]);
      }
    } catch (e) {
      lastError = 'updatePost: $e';
      return false;
    }
    _postCache.remove(postId);
    await Future.wait([loadFeed(), loadUserPosts(id)]);
    return true;
  }

  /// اطلاعیه‌های رسمی اپ (ادمین می‌نویسد)
  List<Announcement> announcements = [];
  Future<void> loadAnnouncements() async {
    try {
      final rows = _rows(await _sb
          .from('announcements')
          .select('id,title,body,image_url,created_at')
          .eq('published', true)
          .order('created_at', ascending: false)
          .limit(50));
      announcements = [
        for (final r in rows)
          Announcement(r['id'].toString(), (r['title'] ?? '').toString(),
              (r['body'] ?? '').toString(), r['image_url'] as String?,
              _ms(r['created_at']))
      ];
      notifyListeners();
    } catch (e) {
      lastError = 'announcements: $e';
    }
  }

  Future<void> removePost(UserPost p) async {
    posts = posts.where((x) => x.id != p.id).toList();
    userPosts[p.ownerId] =
        (userPosts[p.ownerId] ?? []).where((x) => x.id != p.id).toList();
    inter.remove(p.id);
    notifyListeners();
    try {
      await _sb.from('posts').delete().eq('id', p.id);
    } catch (_) {}
    final id = meId;
    if (id != null) await fetchUser(id, force: true);
  }

  void toggleLike(String id) {
    final m = meId;
    if (m == null) return;
    final cur = inter[id] ?? const PostInter(comments: []);
    final now = !cur.liked;
    inter[id] = cur.copyWith(liked: now);
    if (_eventIds.contains(id)) {
      events = [
        for (final e in events)
          if (e.id == id)
            e.copyWith(liked: now, likes: e.likes + (now ? 1 : -1))
          else
            e
      ];
    }
    notifyListeners();
    () async {
      try {
        final ev = _eventIds.contains(id);
        final tbl = ev ? 'event_likes' : 'post_likes';
        final col = ev ? 'event_id' : 'post_id';
        if (now) {
          await _sb.from(tbl).insert({col: id, 'user_id': m});
        } else {
          await _sb.from(tbl).delete().eq(col, id).eq('user_id', m);
        }
      } catch (_) {}
    }();
  }

  void toggleSave(String id) {
    final m = meId;
    if (m == null) return;
    final cur = inter[id] ?? const PostInter(comments: []);
    final now = !cur.saved;
    inter[id] = cur.copyWith(saved: now);
    notifyListeners();
    () async {
      try {
        if (now) {
          await _sb.from('post_saves').insert({'post_id': id, 'user_id': m});
        } else {
          await _sb
              .from('post_saves')
              .delete()
              .eq('post_id', id)
              .eq('user_id', m);
        }
      } catch (_) {}
      await loadSaved();
    }();
  }

  /// [parentId]: شناسه‌ی نظری که به آن پاسخ داده می‌شود (اختیاری)
  void addComment(String postId, String text, {String? parentId}) {
    final m = meId;
    if (m == null) return;
    final cur = inter[postId] ?? const PostInter(comments: []);
    final cm = Comment(
      id: 'tmp${DateTime.now().microsecondsSinceEpoch}',
      author: me?.username ?? 'Me',
      userId: m,
      text: text,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      parentId: parentId,
    );
    inter[postId] = cur.copyWith(comments: [...cur.comments, cm]);
    notifyListeners();
    () async {
      try {
        final ev = _eventIds.contains(postId);
        await _sb.from(ev ? 'event_comments' : 'comments').insert({
          ev ? 'event_id' : 'post_id': postId,
          'user_id': m,
          'text': text,
          'parent_id': parentId,
        });
      } catch (e) {
        lastError = 'comment: $e';
      }
      await reloadComments(postId);
    }();
  }

  void toggleCommentLike(String postId, String commentId) {
    final m = meId;
    if (m == null || commentId.startsWith('tmp')) return;
    final cur = inter[postId];
    if (cur == null) return;
    var now = false;
    final list = <Comment>[];
    for (final c in cur.comments) {
      if (c.id == commentId) {
        now = !c.liked;
        list.add(c.copyWith(liked: now, likes: c.likes + (now ? 1 : -1)));
      } else {
        list.add(c);
      }
    }
    inter[postId] = cur.copyWith(comments: list);
    notifyListeners();
    () async {
      try {
        final tbl =
            _eventIds.contains(postId) ? 'event_comment_likes' : 'comment_likes';
        if (now) {
          await _sb.from(tbl).insert({'comment_id': commentId, 'user_id': m});
        } else {
          await _sb
              .from(tbl)
              .delete()
              .eq('comment_id', commentId)
              .eq('user_id', m);
        }
      } catch (e) {
        lastError = 'commentLike: $e';
      }
    }();
  }

  // ---------- رویدادها ----------
  List<AppEvent> events = [];
  final Set<String> _eventIds = {};
  bool eventsLocalOnly = true; // فقط رویدادهای کشور و شهر من
  String eventsError = '';

  void setEventsLocalOnly(bool v) {
    eventsLocalOnly = v;
    notifyListeners();
    loadEvents();
  }

  Future<void> loadEvents() async {
    final id = meId;
    if (id == null) return;
    try {
      var q = _sb.from('events').select();
      final m = me;
      if (eventsLocalOnly && m != null && m.country.isNotEmpty) {
        q = q.eq('country', m.country);
        if (m.city.isNotEmpty) q = q.eq('city', m.city);
      }
      final rows =
          _rows(await q.order('event_date', ascending: true).limit(100));
      if (rows.isEmpty) {
        events = [];
        eventsError = '';
        notifyListeners();
        return;
      }
      final ids = rows.map((r) => r['id'].toString()).toList();
      var parts = <Map<String, dynamic>>[];
      var likes = <Map<String, dynamic>>[];
      var coms = <Map<String, dynamic>>[];
      await Future.wait([
        _cacheProfiles(rows.map((r) => r['owner_id'].toString())),
        () async {
          try {
            parts = _rows(await _sb
                .from('event_participants')
                .select('event_id,user_id')
                .inFilter('event_id', ids));
          } catch (e) {
            lastError = 'participants: $e';
          }
        }(),
        () async {
          try {
            likes = _rows(await _sb
                .from('event_likes')
                .select('event_id,user_id')
                .inFilter('event_id', ids));
          } catch (e) {
            lastError = 'event_likes: $e';
          }
        }(),
        () async {
          try {
            coms = _rows(await _sb
                .from('event_comments')
                .select('id,event_id,user_id,text,created_at,parent_id')
                .inFilter('event_id', ids)
                .order('created_at'));
          } catch (e) {
            lastError = 'event_comments: $e';
          }
        }(),
      ]);
      final cmap = await _buildComments(coms,
          likesTable: 'event_comment_likes', refCol: 'event_id');
      final pc = <String, int>{};
      final mine = <String>{};
      for (final r in parts) {
        final e = r['event_id'].toString();
        pc[e] = (pc[e] ?? 0) + 1;
        if (r['user_id'].toString() == id) mine.add(e);
      }
      final lc = <String, int>{};
      final lm = <String>{};
      for (final r in likes) {
        final e = r['event_id'].toString();
        lc[e] = (lc[e] ?? 0) + 1;
        if (r['user_id'].toString() == id) lm.add(e);
      }
      final out = <AppEvent>[];
      for (final r in rows) {
        final eid = r['id'].toString();
        _eventIds.add(eid);
        inter[eid] = PostInter(
            liked: lm.contains(eid), comments: cmap[eid] ?? <Comment>[]);
        out.add(AppEvent(
          id: eid,
          ownerId: r['owner_id'].toString(),
          title: (r['title'] ?? '').toString(),
          description: (r['description'] ?? '').toString(),
          imageUrl: r['image_url'] as String?,
          date: DateTime.tryParse((r['event_date'] ?? '').toString()) ??
              DateTime.now(),
          country: (r['country'] ?? '').toString(),
          city: (r['city'] ?? '').toString(),
          createdAt: _ms(r['created_at']),
          participants: pc[eid] ?? 0,
          joined: mine.contains(eid),
          likes: lc[eid] ?? 0,
          liked: lm.contains(eid),
        ));
      }
      events = out;
      eventsError = '';
    } catch (e) {
      eventsError = e.toString();
    }
    notifyListeners();
  }

  AppEvent? eventById(String id) {
    for (final e in events) {
      if (e.id == id) return e;
    }
    return null;
  }

  /// null یعنی موفق؛ در غیر این‌صورت کلید پیام خطا.
  Future<String?> createEvent({
    required String title,
    required String description,
    required DateTime date,
    String? imagePath,
  }) async {
    final id = meId;
    final m = me;
    if (id == null || m == null) return 'errLogin';
    lastError = '';
    String? url;
    if (imagePath != null && imagePath.isNotEmpty) {
      url = await _upload(imagePath, 'event');
      if (url == null) return 'errNet';
    }
    String p2(int n) => n.toString().padLeft(2, '0');
    try {
      await _sb.from('events').insert({
        'owner_id': id,
        'title': title.trim(),
        'description': description.trim(),
        'image_url': url,
        'event_date': '${date.year}-${p2(date.month)}-${p2(date.day)}',
        'country': m.country,
        'city': m.city,
      });
    } catch (e) {
      lastError = 'event: $e';
      return 'errNet';
    }
    await loadEvents();
    return null;
  }

  Future<void> deleteEvent(String eventId) async {
    events = events.where((e) => e.id != eventId).toList();
    notifyListeners();
    try {
      await _sb.from('events').delete().eq('id', eventId);
    } catch (e) {
      lastError = 'deleteEvent: $e';
    }
  }

  /// شرکت می‌کنم / لغو شرکت
  void toggleJoin(String eventId) {
    final m = meId;
    if (m == null) return;
    var now = false;
    final list = <AppEvent>[];
    for (final e in events) {
      if (e.id == eventId) {
        now = !e.joined;
        list.add(e.copyWith(
            joined: now, participants: e.participants + (now ? 1 : -1)));
      } else {
        list.add(e);
      }
    }
    events = list;
    notifyListeners();
    () async {
      try {
        if (now) {
          await _sb
              .from('event_participants')
              .insert({'event_id': eventId, 'user_id': m});
        } else {
          await _sb
              .from('event_participants')
              .delete()
              .eq('event_id', eventId)
              .eq('user_id', m);
        }
      } catch (e) {
        lastError = 'join: $e';
      }
    }();
  }

  // ---------- حیوانات ----------
  Future<void> loadPets() async {
    final id = meId;
    if (id == null) return;
    try {
      final rows = _rows(await _sb
          .from('pets')
          .select()
          .eq('owner_id', id)
          .order('created_at'));
      pets = rows
          .map((r) => Pet(
                id: r['id'].toString(),
                name: (r['name'] ?? '').toString(),
                species: (r['species'] ?? 'other').toString(),
                age: (r['age'] as num?)?.toInt() ?? 0,
                gender: (r['gender'] ?? '').toString(),
                birth: (r['birth_date'] ?? '').toString(),
                notes: (r['notes'] ?? '').toString(),
                vaccines: ((r['vaccines'] as List?) ?? const [])
                    .map((e) =>
                        PetVaccine.fromJson(Map<String, dynamic>.from(e as Map)))
                    .toList(),
                photoPath: r['photo_url'] as String?,
                ownerId: id,
              ))
          .toList();
      notifyListeners();
    } catch (e) {
      lastError = 'pets: $e';
    }
  }

  Map<String, dynamic> _petRow(Pet p, String? url) => {
        'name': p.name,
        'species': p.species,
        'age': p.age,
        'gender': p.gender,
        'birth_date': p.birth.isEmpty ? null : p.birth,
        'notes': p.notes,
        'vaccines': p.vaccines.map((v) => v.toJson()).toList(),
        'photo_url': url,
      };

  Future<void> addPet(Pet p) async {
    final id = meId;
    if (id == null) return;
    final url = await _upload(p.photoPath, 'pet');
    try {
      await _sb.from('pets').insert({'owner_id': id, ..._petRow(p, url)});
    } catch (e) {
      lastError = 'addPet: $e';
    }
    await loadPets();
  }

  Future<void> updatePet(Pet p) async {
    final id = meId;
    if (id == null) return;
    final url = await _upload(p.photoPath, 'pet');
    try {
      await _sb.from('pets').update(_petRow(p, url)).eq('id', p.id);
    } catch (e) {
      lastError = 'updatePet: $e';
    }
    await loadPets();
  }

  Future<void> removePet(Pet p) async {
    pets = pets.where((x) => x.id != p.id).toList();
    notifyListeners();
    try {
      await _sb.from('pets').delete().eq('id', p.id);
    } catch (_) {}
  }

  // ---------- اعلان‌ها و خوانده‌نشده‌ها ----------
  List<NotifItem> notifs = [];
  int notifSeenAt = 0;
  Map<String, int> chatReadAt = {};

  Future<void> _loadReadState() async {
    final id = meId;
    if (id == null) return;
    try {
      final sp = await SharedPreferences.getInstance();
      notifSeenAt = sp.getInt('notif_seen_$id') ?? 0;
      final raw = sp.getString('chat_read_$id');
      chatReadAt = raw == null
          ? {}
          : (jsonDecode(raw) as Map)
              .map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
    } catch (_) {}
  }

  bool get hasUnreadNotifications =>
      (me?.requests.isNotEmpty ?? false) ||
      notifs.any((n) => n.at > notifSeenAt);

  Future<void> markNotificationsSeen() async {
    final id = meId;
    if (id == null) return;
    notifSeenAt = DateTime.now().millisecondsSinceEpoch;
    notifyListeners();
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setInt('notif_seen_$id', notifSeenAt);
    } catch (_) {}
  }

  bool unreadFrom(String partner) {
    final last = chatReadAt[partner] ?? 0;
    return msgs.any((x) =>
        _visibleMsg(x) && x.from == partner && x.to == meId && x.at > last);
  }

  bool get hasUnreadMessages =>
      msgs.any((x) =>
          _visibleMsg(x) && x.to == meId && x.at > (chatReadAt[x.from] ?? 0));

  Future<void> markChatRead(String partner) async {
    final id = meId;
    if (id == null || !unreadFrom(partner)) return;
    var latest = DateTime.now().millisecondsSinceEpoch;
    for (final x in msgs) {
      if (x.from == partner && x.at > latest) latest = x.at;
    }
    chatReadAt[partner] = latest;
    notifyListeners();
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString('chat_read_$id', jsonEncode(chatReadAt));
    } catch (_) {}
  }

  /// اعلان‌ها را از روی لایک/نظر/پاسخ/تگ‌ها می‌سازد (بدون جدول جدا)
  Future<void> loadNotifications() async {
    final id = meId;
    final myName = me?.username;
    if (id == null || myName == null) return;
    try {
      final items = <NotifItem>[];
      final seenComments = <String>{};

      final myPosts = _rows(await _sb
          .from('posts')
          .select('id')
          .eq('owner_id', id)
          .order('created_at', ascending: false)
          .limit(100));
      final postIds = myPosts.map((e) => e['id'].toString()).toList();
      final myComs = _rows(await _sb
          .from('comments')
          .select('id')
          .eq('user_id', id)
          .order('created_at', ascending: false)
          .limit(200));
      final comIds = myComs.map((e) => e['id'].toString()).toList();
      final tag = myName.replaceAll('_', r'\_');

      var likes = <Map<String, dynamic>>[];
      var coms = <Map<String, dynamic>>[];
      var replies = <Map<String, dynamic>>[];
      var clikes = <Map<String, dynamic>>[];
      var tagComs = <Map<String, dynamic>>[];
      final photoTags = <NotifItem>[];
      var tagPosts = <Map<String, dynamic>>[];
      var newFollowers = <Map<String, dynamic>>[];
      var acceptedMine = <Map<String, dynamic>>[];
      await Future.wait([
        () async {
          try {
            newFollowers = _rows(await _sb
                .from('follows')
                .select('follower_id,created_at,accepted_at')
                .eq('followee_id', id)
                .eq('status', 'accepted')
                .order('created_at', ascending: false)
                .limit(40));
          } catch (_) {
            try {
              newFollowers = _rows(await _sb
                  .from('follows')
                  .select('follower_id,created_at')
                  .eq('followee_id', id)
                  .eq('status', 'accepted')
                  .order('created_at', ascending: false)
                  .limit(40));
            } catch (_) {}
          }
        }(),
        () async {
          try {
            acceptedMine = _rows(await _sb
                .from('follows')
                .select('followee_id,accepted_at')
                .eq('follower_id', id)
                .eq('status', 'accepted')
                .not('accepted_at', 'is', null)
                .order('accepted_at', ascending: false)
                .limit(40));
          } catch (_) {}
        }(),
        () async {
          if (postIds.isEmpty) return;
          likes = _rows(await _sb
              .from('post_likes')
              .select('post_id,user_id,created_at')
              .inFilter('post_id', postIds)
              .neq('user_id', id)
              .order('created_at', ascending: false)
              .limit(60));
        }(),
        () async {
          if (postIds.isEmpty) return;
          coms = _rows(await _sb
              .from('comments')
              .select('id,post_id,user_id,text,created_at,parent_id')
              .inFilter('post_id', postIds)
              .neq('user_id', id)
              .order('created_at', ascending: false)
              .limit(60));
        }(),
        () async {
          if (comIds.isEmpty) return;
          replies = _rows(await _sb
              .from('comments')
              .select('id,post_id,user_id,text,created_at,parent_id')
              .inFilter('parent_id', comIds)
              .neq('user_id', id)
              .order('created_at', ascending: false)
              .limit(60));
          clikes = _rows(await _sb
              .from('comment_likes')
              .select('comment_id,user_id,created_at')
              .inFilter('comment_id', comIds)
              .neq('user_id', id)
              .order('created_at', ascending: false)
              .limit(60));
        }(),
        () async {
          try {
            final tg = _rows(await _sb
                .from('post_tags')
                .select('post_id,created_at')
                .eq('user_id', id)
                .order('created_at', ascending: false)
                .limit(30));
            if (tg.isEmpty) return;
            final ps = _rows(await _sb
                .from('posts')
                .select('id,owner_id')
                .inFilter('id', tg.map((e) => e['post_id'].toString()).toList()));
            final owners = {
              for (final p in ps) p['id'].toString(): p['owner_id'].toString()
            };
            for (final t in tg) {
              final o = owners[t['post_id'].toString()];
              if (o == null || o == id) continue;
              photoTags.add(NotifItem('photoTag', o, t['post_id'].toString(),
                  _ms(t['created_at']), ''));
            }
          } catch (_) {}
        }(),
        () async {
          tagComs = _rows(await _sb
              .from('comments')
              .select('id,post_id,user_id,text,created_at')
              .ilike('text', '%@$tag%')
              .neq('user_id', id)
              .order('created_at', ascending: false)
              .limit(30));
          tagPosts = _rows(await _sb
              .from('posts')
              .select('id,owner_id,created_at')
              .ilike('text', '%@$tag%')
              .neq('owner_id', id)
              .order('created_at', ascending: false)
              .limit(30));
        }(),
      ]);

      for (final r in replies) {
        seenComments.add(r['id'].toString());
        items.add(NotifItem('reply', r['user_id'].toString(),
            r['post_id'].toString(), _ms(r['created_at']), (r['text'] ?? '').toString()));
      }
      for (final r in tagComs) {
        if (!seenComments.add(r['id'].toString())) continue;
        items.add(NotifItem('tag', r['user_id'].toString(),
            r['post_id'].toString(), _ms(r['created_at']), (r['text'] ?? '').toString()));
      }
      for (final r in coms) {
        if (!seenComments.add(r['id'].toString())) continue;
        items.add(NotifItem('comment', r['user_id'].toString(),
            r['post_id'].toString(), _ms(r['created_at']), (r['text'] ?? '').toString()));
      }
      for (final r in tagPosts) {
        items.add(NotifItem('tag', r['owner_id'].toString(), r['id'].toString(),
            _ms(r['created_at']), ''));
      }
      for (final r in likes) {
        items.add(NotifItem('like', r['user_id'].toString(),
            r['post_id'].toString(), _ms(r['created_at']), ''));
      }
      for (final r in clikes) {
        items.add(NotifItem('commentLike', r['user_id'].toString(), null,
            _ms(r['created_at']), ''));
      }
      for (final r in newFollowers) {
        items.add(NotifItem('follow', r['follower_id'].toString(), null,
            _ms(r['accepted_at'] ?? r['created_at']), ''));
      }
      for (final r in acceptedMine) {
        items.add(NotifItem('followAccepted', r['followee_id'].toString(), null,
            _ms(r['accepted_at']), ''));
      }
      items.addAll(photoTags);
      items.sort((a, b) => b.at.compareTo(a.at));
      notifs = items.take(100).toList();
      await _cacheProfiles(notifs.map((n) => n.userId));
      notifyListeners();
    } catch (e) {
      lastError = 'notifications: $e';
    }
  }

  // ---------- گزارش، لیست فالوورها ----------
  Future<bool> submitReport(String type, String targetId, String reason) async {
    final id = meId;
    if (id == null) return false;
    try {
      await _sb.from('reports').insert({
        'reporter_id': id,
        'target_type': type,
        'target_id': targetId,
        'reason': reason,
      });
      return true;
    } catch (e) {
      lastError = 'report: $e';
      return false;
    }
  }

  /// فهرست فالوورها یا دنبال‌شده‌های یک کاربر (فقط اگر اجازه‌ی دیدن پروفایلش را داشته باشیم)
  Future<List<AppUser>> followList(String uid, {required bool followers}) async {
    try {
      final r = await _sb.rpc('follow_list',
          params: {'uid': uid, 'want_followers': followers});
      final ids = (r as List).map((e) => e.toString()).toList();
      await _cacheProfiles(ids);
      return [
        for (final i in ids)
          if (_users[i] != null) _users[i]!
      ];
    } catch (e) {
      lastError = 'followList: $e';
      return [];
    }
  }

  Future<bool> updateBirth(DateTime d) async {
    final m = me;
    if (m == null) return false;
    String p2(int n) => n.toString().padLeft(2, '0');
    try {
      await _sb
          .from('private_info')
          .update({'birth_date': '${d.year}-${p2(d.month)}-${p2(d.day)}'}).eq('id', m.id);
      m.birth = d;
      notifyListeners();
      return true;
    } catch (e) {
      lastError = 'birth: $e';
      return false;
    }
  }

  // ---------- پیام‌ها ----------
  Future<void> loadMessages() async {
    final id = meId;
    if (id == null) return;
    try {
      final rows = _rows(await _sb
          .from('messages')
          .select()
          .or('sender_id.eq.$id,receiver_id.eq.$id')
          .order('created_at', ascending: false)
          .limit(500));
      msgs = rows.map(Msg.fromRow).toList()..sort((a,b) => a.at.compareTo(b.at));
      notifyListeners();
      await _cacheProfiles(threadPartners());
      for (final x in msgs) {
        final pid = x.postId;
        if (pid != null && !_postCache.containsKey(pid)) {
          await fetchPost(pid);
        }
      }
      notifyListeners();
    } catch (_) {}
  }

  /// زمان آخرین «حذف گفتگو» برای هر شخص (پیام‌های قدیمی‌تر پنهان می‌شوند)
  Map<String, int> clearedAt = {};

  bool _visibleMsg(Msg x) {
    final other = x.from == meId ? x.to : x.from;
    return x.at > (clearedAt[other] ?? 0);
  }

  Future<void> loadChatClears() async {
    final id = meId;
    if (id == null) return;
    try {
      final rows = _rows(await _sb
          .from('chat_clears')
          .select('partner_id,cleared_at')
          .eq('user_id', id));
      clearedAt = {
        for (final r in rows) r['partner_id'].toString(): _ms(r['cleared_at'])
      };
      notifyListeners();
    } catch (_) {}
  }

  Future<void> deleteChat(String partner) async {
    final id = meId;
    if (id == null) return;
    clearedAt[partner] = DateTime.now().millisecondsSinceEpoch;
    notifyListeners();
    try {
      await _sb.from('chat_clears').upsert({
        'user_id': id,
        'partner_id': partner,
        'cleared_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id,partner_id');
    } catch (e) {
      lastError = 'deleteChat: $e';
    }
  }

  List<Msg> thread(String other) {
    final m = meId;
    return msgs
        .where((x) =>
            _visibleMsg(x) &&
            ((x.from == m && x.to == other) || (x.from == other && x.to == m)))
        .toList();
  }

  List<String> threadPartners() {
    final m = meId;
    final seen = <String>[];
    for (final x in msgs.reversed) {
      if (!_visibleMsg(x)) continue;
      final other = x.from == m ? x.to : x.from;
      if (!seen.contains(other)) seen.add(other);
    }
    return seen;
  }

  /// شرکت‌کنندگان یک رویداد
  Future<List<AppUser>> loadParticipants(String eventId) async {
    try {
      final rows = _rows(await _sb
          .from('event_participants')
          .select('user_id')
          .eq('event_id', eventId)
          .order('created_at'));
      final ids = rows.map((r) => r['user_id'].toString()).toList();
      await _cacheProfiles(ids);
      return [
        for (final i in ids)
          if (_users[i] != null) _users[i]!
      ];
    } catch (e) {
      lastError = 'participants: $e';
      return [];
    }
  }

  Future<bool> sendMsg(String to, String text,
      {String? postId, String? replyTo, String? mediaPath, String? mediaType}) async {
    final m = meId;
    final t = text.trim();
    if (m == null || (t.isEmpty && postId == null && mediaPath == null)) return false;
    final tmp = Msg('tmp${DateTime.now().microsecondsSinceEpoch}', m, to, t,
        DateTime.now().millisecondsSinceEpoch,
        postId: postId, replyTo: replyTo, mediaPath: mediaPath, mediaType: mediaType);
    msgs = [...msgs, tmp];
    notifyListeners();
    try {
      await _sb.from('messages').insert({
        'sender_id': m,
        'receiver_id': to,
        'text': t,
        'post_id': postId,
        if (mediaPath != null) 'media_path': mediaPath,
        if (mediaPath != null) 'media_type': mediaType,
        'reply_to':
            (replyTo != null && !replyTo.startsWith('tmp')) ? replyTo : null,
      });
    } catch (e) {
      lastError = 'sendMsg: $e';
      msgs = msgs.where((x) => x.id != tmp.id).toList();
      notifyListeners();
      return false;
    }
    await loadMessages();
    return true;
  }

  Msg? messageById(String id) {
    for (final x in msgs) {
      if (x.id == id) return x;
    }
    return null;
  }

  Future<void> deleteMessage(String id) async {
    msgs = msgs.where((x) => x.id != id).toList();
    notifyListeners();
    if (id.startsWith('tmp')) return;
    try {
      await _sb.from('messages').delete().eq('id', id);
    } catch (e) {
      lastError = 'deleteMsg: $e';
    }
  }

  /// افرادی که می‌شود پست را برایشان فرستاد: دنبال‌شده‌ها + گفتگوهای قبلی
  Future<List<AppUser>> shareTargets() async {
    final id = meId;
    if (id == null) return [];
    final ids = <String>{...threadPartners()};
    try {
      final rows = _rows(await _sb
          .from('follows')
          .select('followee_id')
          .eq('follower_id', id)
          .eq('status', 'accepted'));
      ids.addAll(rows.map((e) => e['followee_id'].toString()));
    } catch (_) {}
    ids.remove(id);
    await _cacheProfiles(ids);
    return [
      for (final i in ids)
        if (_users[i] != null) _users[i]!
    ];
  }
}
