import 'dart:async';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../l10n.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import 'stories_store.dart';

String storyText(AppLang l,String fa,String en,String zh)=>l==AppLang.fa?fa:l==AppLang.zh?zh:en;
Future<void> addStory(BuildContext context,AppState app) async {
 final source=await showModalBottomSheet<ImageSource>(context:context,builder:(ctx)=>SafeArea(child:Column(mainAxisSize:MainAxisSize.min,children:[
  ListTile(leading:const Icon(Icons.photo_library_outlined),title:Text(storyText(app.lang,'گالری','Gallery','相册')),onTap:()=>Navigator.pop(ctx,ImageSource.gallery)),
  ListTile(leading:const Icon(Icons.camera_alt_outlined),title:Text(storyText(app.lang,'دوربین','Camera','相机')),onTap:()=>Navigator.pop(ctx,ImageSource.camera)),
 ])));
 if(source==null||!context.mounted)return;
 File? output;
 try{
  final picked=await ImagePicker().pickImage(source:source,maxWidth:1920,maxHeight:1920,imageQuality:90);
  if(picked==null||!context.mounted)return;
  final codec=await ui.instantiateImageCodec(await picked.readAsBytes());
  final frame=await codec.getNextFrame();final image=frame.image;
  const target=Size(1080,1920);final input=Size(image.width.toDouble(),image.height.toDouble());
  final fitted=applyBoxFit(BoxFit.cover,input,target);
  final recorder=ui.PictureRecorder();final canvas=Canvas(recorder);
  canvas.drawImageRect(image,Alignment.center.inscribe(fitted.source,Offset.zero&input),Offset.zero&target,Paint()..filterQuality=FilterQuality.high);
  final picture=recorder.endRecording();final resized=await picture.toImage(1080,1920);
  final bytes=await resized.toByteData(format:ui.ImageByteFormat.png);
  image.dispose();resized.dispose();picture.dispose();codec.dispose();
  if(bytes==null)throw StateError('encode');
  final dir=await getTemporaryDirectory();output=File('${dir.path}/story-${DateTime.now().microsecondsSinceEpoch}.png');await output.writeAsBytes(bytes.buffer.asUint8List());
  if(!context.mounted)return;
  await Navigator.push(context,MaterialPageRoute(builder:(_)=>StoryCompose(app:app,file:output!)));
 }catch(_){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(storyText(app.lang,'تصویر آماده نشد؛ دوباره تلاش کنید.','Could not prepare image. Please retry.','无法准备图片，请重试。'))));}
 finally{if(output!=null&&await output.exists())await output.delete();}
}
class StoryCompose extends StatefulWidget{
 final AppState app;final File file;
 const StoryCompose({super.key,required this.app,required this.file});
 @override State<StoryCompose> createState()=>_StoryComposeState();
}
class _StoryComposeState extends State<StoryCompose>{
 bool busy=false;
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:Colors.black,
 appBar:AppBar(backgroundColor:Colors.black,foregroundColor:Colors.white,title:Text(storyText(widget.app.lang,'پیش‌نمایش استوری','Story preview','动态预览'))),
 body:Column(children:[Expanded(child:Center(child:AspectRatio(aspectRatio:9/16,child:Image.file(widget.file,fit:BoxFit.contain)))),
 SafeArea(top:false,child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
 Text(storyText(widget.app.lang,'تصویر با برش وسط ۹:۱۶ منتشر می‌شود؛ نمایش ۲۴ ساعت. حریم خصوصی پروفایل رعایت می‌شود.','Center-cropped 9:16 photo, visible for 24 hours. Profile privacy applies.','照片居中裁剪为 9:16，显示 24 小时，遵循个人资料隐私设置。'),style:const TextStyle(color:Colors.white70,fontSize:12),textAlign:TextAlign.center),
 const SizedBox(height:10),FilledButton.icon(onPressed:busy?null:()async{setState(()=>busy=true);final ok=await widget.app.stories.publish(widget.file);if(!context.mounted)return;if(ok){Navigator.pop(context);}else{setState(()=>busy=false);ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(storyText(widget.app.lang,'ارسال نشد؛ اتصال و SQL جدید را بررسی کنید. حداکثر ۲۰ استوری در ۲۴ ساعت.','Upload failed. Check connection and migration. Limit: 20 stories in 24 hours.','上传失败，请检查连接和 SQL。24 小时最多 20 条。'))));}},icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.add),label:Text(storyText(widget.app.lang,'انتشار استوری','Share story','发布动态'))),
 ]))),]));
}
void viewStories(BuildContext context,AppState app,String owner) async {await app.stories.loadOwner(owner);if(!context.mounted)return;final list=app.stories.byOwner(owner);if(list.isNotEmpty)Navigator.push(context,MaterialPageRoute(builder:(_)=>StoryViewer(app:app,stories:list)));}
class StoryAvatar extends StatelessWidget{
 final AppState app;final String owner;final double size;const StoryAvatar({super.key,required this.app,required this.owner,this.size=58});
 @override Widget build(BuildContext context)=>ListenableBuilder(listenable:app.stories,builder:(context,_){
 final list=app.stories.byOwner(owner);final user=app.userById(owner);final avatar=list.isEmpty?null:list.first.avatar;
 return GestureDetector(onTap:()=>list.isNotEmpty?viewStories(context,app,owner):(owner==app.meId?addStory(context,app):null),child:Container(padding:const EdgeInsets.all(3),decoration:BoxDecoration(shape:BoxShape.circle,gradient:list.isNotEmpty&&app.stories.unseen(owner)?AppPal.purpleGradient:null,border:Border.all(color:list.isEmpty?Colors.transparent:const Color(0xFFD1CCD9),width:1.5)),child:user!=null?UserAvatar(user:user,size:size):CircleAvatar(radius:size/2,backgroundColor:const Color(0xFFEDE7FF),backgroundImage:avatar==null||avatar.isEmpty?null:NetworkImage(avatar),child:avatar==null||avatar.isEmpty?const Icon(Icons.person_outline):null)));
 });
}
class StoriesBar extends StatelessWidget{
 final AppState app;const StoriesBar({super.key,required this.app});
 @override Widget build(BuildContext context)=>ListenableBuilder(listenable:app.stories,builder:(context,_){
 if(app.meId==null)return const SizedBox.shrink();
 final store=app.stories;final owners=store.items.where((s)=>s.expires.isAfter(DateTime.now().toUtc())&&s.owner!=app.meId).map((s)=>s.owner).toSet().toList();
 owners.sort((a,b)=> (store.unseen(a)?0:1).compareTo(store.unseen(b)?0:1));
 return Column(children:[SizedBox(height:104,child:ListView(scrollDirection:Axis.horizontal,children:[
 SizedBox(width:82,child:Column(children:[Stack(children:[StoryAvatar(app:app,owner:app.meId!,size:56),PositionedDirectional(bottom:0,end:0,child:GestureDetector(onTap:()=>addStory(context,app),child:const CircleAvatar(radius:12,backgroundColor:AppPal.purple,child:Icon(Icons.add,color:Colors.white,size:18))))]),const SizedBox(height:5),Text(storyText(app.lang,'استوری شما','Your story','你的动态'),style:const TextStyle(fontSize:10))])),
 for(final owner in owners)SizedBox(width:82,child:Column(children:[StoryAvatar(app:app,owner:owner,size:56),const SizedBox(height:5),Text(app.userById(owner)?.username??store.byOwner(owner).first.name,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:10))])),
 if(store.hasMore)SizedBox(width:82,child:IconButton(onPressed:store.moreLoading?null:store.loadMore,tooltip:storyText(app.lang,'استوری‌های بیشتر','More stories','更多动态'),icon:const Icon(Icons.more_horiz))),
 ])),if(store.loading)const LinearProgressIndicator(minHeight:2),if(store.failed)TextButton(onPressed:store.load,child:Text(storyText(app.lang,'استوری‌ها بارگذاری نشدند؛ تلاش دوباره','Stories unavailable. Retry','无法加载动态，重试')))]);
 });
}
class StoryViewer extends StatefulWidget{
 final AppState app;final List<PetStory> stories;const StoryViewer({super.key,required this.app,required this.stories});
 @override State<StoryViewer> createState()=>_StoryViewerState();
}
class _StoryViewerState extends State<StoryViewer> with SingleTickerProviderStateMixin{
 late final AnimationController progress;late Future<String> url;int index=0;bool paused=false;bool ready=false;
 PetStory get story=>widget.stories[index];
 @override void initState(){super.initState();progress=AnimationController(vsync:this,duration:const Duration(seconds:6))..addStatusListener((status){if(status==AnimationStatus.completed)_next();});_load();}
 void _load(){ready=false;progress.reset();url=widget.app.stories.imageUrl(story);}
 void _loaded(){if(!mounted||ready)return;ready=true;widget.app.stories.markSeen(story.id);if(!paused)progress.forward();}
 void _next(){if(!mounted)return;if(index+1>=widget.stories.length){Navigator.pop(context);return;}setState((){index++;_load();});}
 void _previous(){if(index>0)setState((){index--;_load();});else progress.forward(from:0);}
 @override void dispose(){progress.dispose();super.dispose();}
 Future<void> _menu()async{
 progress.stop();paused=true;final own=story.owner==widget.app.meId;
 final action=await showModalBottomSheet<String>(context:context,builder:(ctx)=>SafeArea(child:ListTile(leading:Icon(own?Icons.delete_outline:Icons.flag_outlined),title:Text(storyText(widget.app.lang,own?'حذف استوری':'گزارش استوری',own?'Delete story':'Report story',own?'删除动态':'举报动态')),onTap:()=>Navigator.pop(ctx,own?'delete':'report'))));
 if(!mounted)return;
 try{
 if(action=='delete'){await widget.app.stories.remove(story);if(mounted)Navigator.pop(context);return;}
 if(action=='report'){
 final ctrl=TextEditingController();final reason=await showDialog<String>(context:context,builder:(ctx)=>AlertDialog(title:Text(storyText(widget.app.lang,'دلیل گزارش','Report reason','举报原因')),content:TextField(controller:ctrl,maxLength:1000),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Icon(Icons.close)),FilledButton(onPressed:()=>ctrl.text.trim().length>=3?Navigator.pop(ctx,ctrl.text.trim()):null,child:const Icon(Icons.send))]));ctrl.dispose();if(reason!=null)await widget.app.stories.report(story,reason);
 }
 }catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(storyText(widget.app.lang,'عملیات انجام نشد.','Action failed.','操作失败。'))));}
 if(mounted){paused=false;if(ready)progress.forward();}
 }
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:Colors.black,body:SafeArea(child:GestureDetector(
 onLongPressStart:(_){paused=true;progress.stop();},onLongPressEnd:(_){paused=false;if(ready)progress.forward();},
 onTapUp:(details){if(details.localPosition.dx<MediaQuery.sizeOf(context).width/3)_previous();else _next();},
 onVerticalDragEnd:(details){if((details.primaryVelocity??0)>200)Navigator.pop(context);},
 child:Stack(fit:StackFit.expand,children:[
 FutureBuilder<String>(future:url,builder:(context,snapshot){if(snapshot.hasError)return Center(child:IconButton(onPressed:()=>setState(_load),icon:const Icon(Icons.refresh,color:Colors.white)));if(!snapshot.hasData||snapshot.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());final storyId=story.id;return Center(child:Image.network(snapshot.data!,fit:BoxFit.contain,frameBuilder:(ctx,child,frame,sync){if(sync||frame!=null)WidgetsBinding.instance.addPostFrameCallback((_) { if(story.id==storyId)_loaded(); });return child;},errorBuilder:(_,__,___)=>Center(child:IconButton(onPressed:()=>setState(_load),icon:const Icon(Icons.refresh,color:Colors.white)))));}),
 Positioned(top:8,left:10,right:10,child:Column(children:[AnimatedBuilder(animation:progress,builder:(ctx,_)=>Row(children:[for(var i=0;i<widget.stories.length;i++)Expanded(child:Padding(padding:const EdgeInsets.symmetric(horizontal:2),child:LinearProgressIndicator(value:i<index?1:i==index?progress.value:0,minHeight:3,backgroundColor:Colors.white30,color:Colors.white)))])),Row(children:[Expanded(child:Text(widget.app.userById(story.owner)?.username??story.name,style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold))),IconButton(onPressed:_menu,icon:const Icon(Icons.more_horiz,color:Colors.white)),IconButton(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.close,color:Colors.white))])])),
 ]))));
}
