#!/usr/bin/env python3
"""تنظیمات اندروید پروژه (بعد از flutter create اجرا می‌شود).

همه‌ی تنظیمات اندروید داخل خود zip نگه داشته می‌شود تا برای تغییرشان
لازم نباشد فایل workflow در GitHub را دستی عوض کنیم:
  - اجازه‌ی اینترنت (بدون آن اپ release به سرور وصل نمی‌شود)
  - نام نمایشی اپ و شناسه‌ی بسته
  - اجازه‌ی باز کردن لینک / ایمیل / پیامک
"""
import pathlib
import re

APP_ID = "com.pawpet.app"
LABEL = "pawpet"

manifest = pathlib.Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    s = manifest.read_text(encoding="utf-8")

    if "android.permission.INTERNET" not in s:
        s = s.replace(
            "<application",
            '<uses-permission android:name="android.permission.INTERNET"/>\n    <application',
            1,
        )
        print("[android] INTERNET permission added")
    else:
        print("[android] INTERNET permission already present")

    s = re.sub(r'android:label="[^"]*"', f'android:label="{LABEL}"', s, count=1)

    intents = (
        '\n        <intent><action android:name="android.intent.action.VIEW"/>'
        '<data android:scheme="https"/></intent>'
        '\n        <intent><action android:name="android.intent.action.SENDTO"/>'
        '<data android:scheme="mailto"/></intent>'
        '\n        <intent><action android:name="android.intent.action.SENDTO"/>'
        '<data android:scheme="smsto"/></intent>'
    )
    if 'android:scheme="mailto"' not in s:
        if "<queries>" in s:
            s = s.replace("<queries>", "<queries>" + intents, 1)
        else:
            s = s.replace(
                "<application",
                "<queries>" + intents + "\n    </queries>\n    <application",
                1,
            )
        print("[android] queries added")
    manifest.write_text(s, encoding="utf-8")
else:
    print("[android] AndroidManifest.xml not found")

for name in ("build.gradle.kts", "build.gradle"):
    g = pathlib.Path("android/app") / name
    if g.exists():
        t = g.read_text(encoding="utf-8")
        t2 = re.sub(r'applicationId\s*=?\s*"[^"]*"', f'applicationId = "{APP_ID}"', t, count=1)
        if t2 != t:
            g.write_text(t2, encoding="utf-8")
            print(f"[android] applicationId set to {APP_ID} in {name}")
        break
