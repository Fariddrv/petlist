#!/usr/bin/env python3
"""تنظیم امضای release در پروژه اندروید بر اساس متغیرهای محیطی.

مقادیر از environment خوانده می‌شوند:
  KEYSTORE_FILE, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD
اگر هر یک خالی باشد، هیچ تغییری اعمال نمی‌شود (بیلد با امضای debug ادامه می‌یابد).
"""
import os
import pathlib
import re
import sys


def ensure_internet_permission():
    """اجازه‌ی اینترنت را به مانیفست اندروید اضافه می‌کند.

    قالب پیش‌فرض Flutter این اجازه را فقط برای debug دارد؛ بدون آن،
    اپ release به هیچ سروری وصل نمی‌شود و خطای
    'Failed host lookup' می‌دهد.
    """
    mf = pathlib.Path("android/app/src/main/AndroidManifest.xml")
    if not mf.exists():
        print("[manifest] AndroidManifest.xml not found")
        return
    text = mf.read_text(encoding="utf-8")
    if "android.permission.INTERNET" in text:
        print("[manifest] INTERNET permission already present")
        return
    text = text.replace(
        "<application",
        '<uses-permission android:name="android.permission.INTERNET"/>\n    <application',
        1,
    )
    mf.write_text(text, encoding="utf-8")
    print("[manifest] INTERNET permission added")


ensure_internet_permission()

KEYS = ["KEYSTORE_FILE", "KEYSTORE_PASSWORD", "KEY_ALIAS", "KEY_PASSWORD"]
vals = {k: os.environ.get(k, "") for k in KEYS}
if not all(vals.values()):
    print("[sign] missing env vars -> keeping debug signing")
    print("[sign] present:", {k: bool(v) for k, v in vals.items()})
    sys.exit(0)

app_dir = pathlib.Path("android/app")
kts = app_dir / "build.gradle.kts"
groovy = app_dir / "build.gradle"

KTS_BLOCK = """
    signingConfigs {
        create("release") {
            storeFile = file(System.getenv("KEYSTORE_FILE"))
            storePassword = System.getenv("KEYSTORE_PASSWORD")
            keyAlias = System.getenv("KEY_ALIAS")
            keyPassword = System.getenv("KEY_PASSWORD")
        }
    }
"""

GROOVY_BLOCK = """
    signingConfigs {
        release {
            storeFile file(System.getenv("KEYSTORE_FILE"))
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS")
            keyPassword System.getenv("KEY_PASSWORD")
        }
    }
"""

if kts.exists():
    s = kts.read_text(encoding="utf-8")
    if "signingConfigs" not in s:
        s = s.replace("android {", "android {" + KTS_BLOCK, 1)
    s = s.replace('signingConfig = signingConfigs.getByName("debug")',
                  'signingConfig = signingConfigs.getByName("release")')
    kts.write_text(s, encoding="utf-8")
    print("[sign] patched android/app/build.gradle.kts")
elif groovy.exists():
    s = groovy.read_text(encoding="utf-8")
    if "signingConfigs" not in s:
        s = s.replace("android {", "android {" + GROOVY_BLOCK, 1)
    s = re.sub(r"signingConfig\s*=?\s*signingConfigs\.debug",
               "signingConfig = signingConfigs.release", s)
    groovy.write_text(s, encoding="utf-8")
    print("[sign] patched android/app/build.gradle")
else:
    print("[sign] no build.gradle found!")
    sys.exit(1)

print("[sign] release signing configured successfully")
