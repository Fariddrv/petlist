import 'package:flutter/material.dart';

const List<String> _emojis = [
  '😀','😃','😄','😁','😆','😅','😂','🤣','😊','😇','🙂','😉','😍','🥰','😘','😋',
  '😎','🤩','🥳','😏','😒','😞','😔','😢','😭','😤','😡','🤯','😱','😴','🤔','🙄',
  '👍','👎','👏','🙌','🙏','💪','👋','🤝','✌️','🤞','👌','🤙','❤️','🧡','💛','💚',
  '💙','💜','🖤','💔','💖','💕','🔥','✨','🎉','🎂','🎁','⭐','🌟','💯','✅','❌',
  '🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐨','🐯','🦁','🐮','🐷','🐸','🐵','🐔',
  '🐧','🐦','🦜','🐢','🐍','🐠','🐟','🦋','🐝','🐾','🦴','🐕','🐈','🐇','🐎','🦮',
  '🌸','🌹','🌻','🌴','🍀','🌈','☀️','🌙','⚡','❄️','🍎','🍕','🍔','☕','🍰','🎵',
];

/// پنل ساده‌ی ایموجی؛ با انتخاب هر ایموجی، [onPick] صدا زده می‌شود.
class EmojiPanel extends StatelessWidget {
  final ValueChanged<String> onPick;
  const EmojiPanel({super.key, required this.onPick});

  @override
  Widget build(BuildContext context) => Container(
        height: 230,
        color: const Color(0xFFF7F7FB),
        child: GridView.builder(
          padding: const EdgeInsets.all(8),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 8, mainAxisSpacing: 4, crossAxisSpacing: 4),
          itemCount: _emojis.length,
          itemBuilder: (c, i) => InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () => onPick(_emojis[i]),
            child: Center(
                child: Text(_emojis[i], style: const TextStyle(fontSize: 24))),
          ),
        ),
      );
}
