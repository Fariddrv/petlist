import 'package:flutter/material.dart';

import '../data/timeago.dart';
import '../i18n2.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import 'avatar.dart';

/// هدف پاسخ: شناسه‌ی نظر اصلی (ریشه) و نام نویسنده‌ی نظری که به آن پاسخ می‌دهیم.
class ReplyTarget {
  final String rootId;
  final String author;
  const ReplyTarget(this.rootId, this.author);
}

/// فهرست نظرات یک پست با پاسخ‌ها و لایک هر نظر (مثل اینستاگرام).
class CommentsList extends StatelessWidget {
  final AppState s;
  final String postId;
  final ValueChanged<ReplyTarget> onReply;
  const CommentsList(
      {super.key, required this.s, required this.postId, required this.onReply});

  Widget _tile(BuildContext context, Comment c, {required bool isReply}) {
    final l = s.lang;
    final u = s.userById(c.userId);
    final size = isReply ? 28.0 : 36.0;
    return Padding(
      padding: EdgeInsets.fromLTRB(isReply ? 48 : 14, 8, 8, 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AvatarCircle(
              url: u?.avatarUrl, name: c.author, size: size),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text.rich(TextSpan(children: [
                  TextSpan(
                      text: '${c.author}  ',
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, color: AppPal.ink)),
                  TextSpan(
                      text: c.text,
                      style: const TextStyle(color: AppPal.ink, height: 1.5)),
                ])),
                const SizedBox(height: 4),
                Row(children: [
                  Text(timeAgo(c.createdAt, l),
                      style: const TextStyle(
                          color: AppPal.inkSoft, fontSize: 11.5)),
                  if (c.likes > 0) ...[
                    const SizedBox(width: 12),
                    Text('${c.likes} ♥',
                        style: const TextStyle(
                            color: AppPal.inkSoft,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700)),
                  ],
                  const SizedBox(width: 14),
                  InkWell(
                    onTap: () => onReply(ReplyTarget(c.parentId ?? c.id, c.author)),
                    child: Text(tr(l, 'reply'),
                        style: const TextStyle(
                            color: AppPal.inkSoft,
                            fontSize: 12,
                            fontWeight: FontWeight.w800)),
                  ),
                ]),
              ],
            ),
          ),
          IconButton(
            visualDensity: VisualDensity.compact,
            onPressed: () => s.toggleCommentLike(postId, c.id),
            icon: Icon(
              c.liked ? Icons.favorite : Icons.favorite_border,
              size: 18,
              color: c.liked ? const Color(0xFFE0245E) : AppPal.inkSoft,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final all = s.inter[postId]?.comments ?? const <Comment>[];
        final tops = all.where((x) => x.parentId == null).toList();
        final replies = <String, List<Comment>>{};
        for (final x in all) {
          if (x.parentId != null) (replies[x.parentId!] ??= []).add(x);
        }
        if (all.isEmpty) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 30),
            child: Column(children: [
              const Icon(Icons.forum_outlined, size: 40, color: AppPal.inkSoft),
              const SizedBox(height: 8),
              Text(tr(s.lang, 'noCommentsYet'),
                  style: const TextStyle(color: AppPal.inkSoft)),
            ]),
          );
        }
        return Column(children: [
          for (final t in tops) ...[
            _tile(context, t, isReply: false),
            for (final r in replies[t.id] ?? const <Comment>[])
              _tile(context, r, isReply: true),
          ],
        ]);
      },
    );
  }
}

/// کادر نوشتن نظر / پاسخ.
class CommentInputBar extends StatefulWidget {
  final AppState s;
  final String postId;
  final ReplyTarget? reply;
  final VoidCallback onClearReply;
  const CommentInputBar({
    super.key,
    required this.s,
    required this.postId,
    required this.reply,
    required this.onClearReply,
  });

  @override
  State<CommentInputBar> createState() => _CommentInputBarState();
}

class _CommentInputBarState extends State<CommentInputBar> {
  final _ctrl = TextEditingController();
  final _focus = FocusNode();

  @override
  void didUpdateWidget(covariant CommentInputBar old) {
    super.didUpdateWidget(old);
    if (widget.reply != null && widget.reply?.rootId != old.reply?.rootId ||
        (widget.reply != null && old.reply == null)) {
      _ctrl.text = '@${widget.reply!.author} ';
      _ctrl.selection = TextSelection.collapsed(offset: _ctrl.text.length);
      _focus.requestFocus();
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _send() {
    final v = _ctrl.text.trim();
    if (v.isEmpty) return;
    widget.s.addComment(widget.postId, v, parentId: widget.reply?.rootId);
    _ctrl.clear();
    widget.onClearReply();
    FocusScope.of(context).unfocus();
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return SafeArea(
      top: false,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (widget.reply != null)
          Container(
            color: const Color(0xFFF3F4F8),
            padding: const EdgeInsets.fromLTRB(14, 6, 6, 6),
            child: Row(children: [
              Expanded(
                child: Text('${tr(l, 'replyingTo')} @${widget.reply!.author}',
                    style: const TextStyle(
                        color: AppPal.inkSoft, fontSize: 12.5)),
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                onPressed: () {
                  _ctrl.clear();
                  widget.onClearReply();
                },
                icon: const Icon(Icons.close, size: 18),
              ),
            ]),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _ctrl,
                focusNode: _focus,
                minLines: 1,
                maxLines: 4,
                decoration: InputDecoration(hintText: tr(l, 'writeComment')),
              ),
            ),
            IconButton(
              onPressed: _send,
              icon: const Icon(Icons.send, color: AppPal.purple),
            ),
          ]),
        ),
      ]),
    );
  }
}

/// پایین‌کش نظرات (برای صفحه‌ی خانه)
void showCommentsSheet(BuildContext context, AppState s, String postId) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
    ),
    builder: (ctx) => _CommentsSheet(s: s, postId: postId),
  );
}

class _CommentsSheet extends StatefulWidget {
  final AppState s;
  final String postId;
  const _CommentsSheet({required this.s, required this.postId});

  @override
  State<_CommentsSheet> createState() => _CommentsSheetState();
}

class _CommentsSheetState extends State<_CommentsSheet> {
  ReplyTarget? _reply;

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * .72,
        child: Column(children: [
          Container(
            margin: const EdgeInsets.only(top: 10),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFFDDDDE3),
              borderRadius: BorderRadius.circular(999),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Text(tr(l, 'commentsTitle'),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          const Divider(height: 1),
          Expanded(
            child: SingleChildScrollView(
              child: CommentsList(
                s: widget.s,
                postId: widget.postId,
                onReply: (r) => setState(() => _reply = r),
              ),
            ),
          ),
          CommentInputBar(
            s: widget.s,
            postId: widget.postId,
            reply: _reply,
            onClearReply: () => setState(() => _reply = null),
          ),
        ]),
      ),
    );
  }
}
