import 'package:flutter/material.dart';

import '../data/places.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../theme.dart';

class _Opt {
  final String key, label;
  const _Opt(this.key, this.label);
}

Future<String?> _pick(BuildContext context, AppLang lang, String title,
    List<_Opt> items) {
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
    ),
    builder: (ctx) {
      var q = '';
      return StatefulBuilder(
        builder: (ctx, setS) {
          final shown = items
              .where((o) => o.label.toLowerCase().contains(q.toLowerCase()))
              .toList();
          return Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
            child: SizedBox(
              height: MediaQuery.of(ctx).size.height * .7,
              child: Column(
                children: [
                  const SizedBox(height: 14),
                  Text(title,
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 16)),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: TextField(
                      onChanged: (v) => setS(() => q = v),
                      decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search), hintText: '...'),
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: shown.length,
                      itemBuilder: (c, i) => ListTile(
                        title: Text(shown[i].label),
                        onTap: () => Navigator.pop(ctx, shown[i].key),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

/// انتخاب کشور و شهر. کشور از فهرست یا «سایر»؛ شهر برای ایران و چین از فهرست،
/// برای بقیه آزاد.
class LocationFields extends StatefulWidget {
  final AppLang lang;
  final String country;
  final String city;
  final void Function(String country, String city) onChanged;
  const LocationFields({
    super.key,
    required this.lang,
    required this.country,
    required this.city,
    required this.onChanged,
  });

  @override
  State<LocationFields> createState() => _LocationFieldsState();
}

class _LocationFieldsState extends State<LocationFields> {
  static const _other = '__other__';
  String _code = ''; // کد کشور، _other، یا خالی
  bool _cityOther = false;
  final _countryCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    final c = widget.country;
    if (c.isNotEmpty) {
      if (countries.any((p) => p.key == c)) {
        _code = c;
      } else {
        _code = _other;
        _countryCtrl.text = c;
      }
    }
    final list = cities[_code];
    if (widget.city.isNotEmpty) {
      if (list != null && list.any((p) => p.key == widget.city)) {
        _cityCtrl.text = widget.city;
      } else {
        _cityCtrl.text = widget.city;
        _cityOther = list != null;
      }
    }
  }

  @override
  void dispose() {
    _countryCtrl.dispose();
    _cityCtrl.dispose();
    super.dispose();
  }

  void _emit() {
    final country = _code == _other ? _countryCtrl.text.trim() : _code;
    widget.onChanged(country, _cityCtrl.text.trim());
  }

  Widget _tile(String label, String value, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: InputDecorator(
          decoration: InputDecoration(
              labelText: label, suffixIcon: const Icon(Icons.arrow_drop_down)),
          child: Text(value.isEmpty ? '—' : value,
              style: TextStyle(
                  color: value.isEmpty ? AppPal.inkSoft : AppPal.ink)),
        ),
      );

  Future<void> _pickCountry() async {
    final l = widget.lang;
    final items = [
      for (final p in countries) _Opt(p.key, p.name(l)),
      _Opt(_other, tr(l, 'otherOption')),
    ];
    final v = await _pick(context, l, tr(l, 'country'), items);
    if (v == null) return;
    setState(() {
      _code = v;
      _cityCtrl.clear();
      _cityOther = false;
    });
    _emit();
  }

  Future<void> _pickCity() async {
    final l = widget.lang;
    final list = cities[_code]!;
    final items = [
      for (final p in list) _Opt(p.key, p.name(l)),
      _Opt(_other, tr(l, 'otherOption')),
    ];
    final v = await _pick(context, l, tr(l, 'city'), items);
    if (v == null) return;
    setState(() {
      if (v == _other) {
        _cityOther = true;
        _cityCtrl.clear();
      } else {
        _cityOther = false;
        _cityCtrl.text = v;
      }
    });
    _emit();
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.lang;
    final countryLabel = _code.isEmpty
        ? ''
        : (_code == _other ? tr(l, 'otherOption') : countryName(_code, l));
    final list = cities[_code];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _tile(tr(l, 'country'), countryLabel, _pickCountry),
        if (_code == _other) ...[
          const SizedBox(height: 12),
          TextField(
            controller: _countryCtrl,
            onChanged: (_) => _emit(),
            decoration: InputDecoration(labelText: tr(l, 'country')),
          ),
        ],
        const SizedBox(height: 12),
        if (list != null && !_cityOther)
          _tile(tr(l, 'city'), cityName(_code, _cityCtrl.text, l), _pickCity)
        else
          TextField(
            controller: _cityCtrl,
            onChanged: (_) => _emit(),
            decoration: InputDecoration(
              labelText: tr(l, 'city'),
              suffixIcon: list != null
                  ? IconButton(
                      icon: const Icon(Icons.list),
                      onPressed: () => setState(() {
                        _cityOther = false;
                        _cityCtrl.clear();
                        _emit();
                      }),
                    )
                  : null,
            ),
          ),
      ],
    );
  }
}
