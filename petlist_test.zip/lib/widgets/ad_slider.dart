import 'dart:async';
import 'package:flutter/material.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../theme.dart';

/// بنر تبلیغاتی اسلایدی بالای فید.
/// فعلاً سه تبلیغ نمونه؛ بعداً از سرور خوانده می‌شود.
class AdSlider extends StatefulWidget {
  final AppLang lang;
  const AdSlider({super.key, required this.lang});

  @override
  State<AdSlider> createState() => _AdSliderState();
}

class _AdSliderState extends State<AdSlider> {
  final PageController _ctrl = PageController();
  Timer? _timer;
  int _page = 0;

  static const _ads = [
    ('ad1', '🛍️', BrandColors.purple, Color(0xFF9E86FF)),
    ('ad2', '🩺', BrandColors.gray, Color(0xFF9CA3AF)),
    ('ad3', '📣', BrandColors.yellow, Color(0xFFFFD976)),
  ];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!_ctrl.hasClients) return;
      final next = (_page + 1) % _ads.length;
      _ctrl.animateToPage(next,
          duration: const Duration(milliseconds: 450), curve: Curves.easeInOut);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 96,
          child: PageView.builder(
            controller: _ctrl,
            itemCount: _ads.length,
            onPageChanged: (i) => setState(() => _page = i),
            itemBuilder: (c, i) {
              final a = _ads[i];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 2),
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [a.$3, a.$4],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Text(a.$2, style: const TextStyle(fontSize: 30)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        tr(widget.lang, a.$1),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 14.5,
                            height: 1.5),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: .28),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(tr(widget.lang, 'ad'),
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10.5,
                              fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < _ads.length; i++)
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: i == _page ? 18 : 6,
                height: 6,
                decoration: BoxDecoration(
                  color: i == _page ? AppPal.purple : const Color(0xFFD1D5DB),
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
          ],
        ),
      ],
    );
  }
}
