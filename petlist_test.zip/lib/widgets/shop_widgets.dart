import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../data/media.dart';
import '../data/shop_catalog.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../shop_models.dart';
import '../theme.dart';
import 'smart_image.dart';

/// نشان تاییدشده کنار نام فروشگاه.
class VerifiedBadge extends StatelessWidget {
  final double size;
  const VerifiedBadge({super.key, this.size = 15});
  @override
  Widget build(BuildContext context) =>
      Icon(Icons.verified, size: size, color: const Color(0xFF1D9BF0));
}

/// لوگوی گرد فروشگاه (یا حرف اول نام).
class ShopLogo extends StatelessWidget {
  final String? url;
  final String name;
  final double size;
  const ShopLogo({super.key, this.url, required this.name, this.size = 40});

  @override
  Widget build(BuildContext context) {
    final has = url != null && url!.isNotEmpty;
    return ClipRRect(
      borderRadius: BorderRadius.circular(size * .28),
      child: SizedBox(
        width: size,
        height: size,
        child: has
            ? SmartImage(src: url, fit: BoxFit.cover)
            : Container(
                decoration: const BoxDecoration(gradient: AppPal.purpleGradient),
                alignment: Alignment.center,
                child: Text(
                  (name.isNotEmpty ? name[0] : '?').toUpperCase(),
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: size * .42),
                ),
              ),
      ),
    );
  }
}

/// کارت یک محصول یا خدمت در شبکه‌ی فروشگاه.
class ListingCard extends StatelessWidget {
  final Listing item;
  final AppLang lang;
  final VoidCallback onTap;
  const ListingCard(
      {super.key, required this.item, required this.lang, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final img = item.images.isNotEmpty ? item.images.first : null;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: AppPal.softCard(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(fit: StackFit.expand, children: [
                img == null
                    ? Container(
                        color: AppPal.bg,
                        alignment: Alignment.center,
                        child: Text(categoryOf(item.categoryKey)?.emoji ?? '🐾',
                            style: const TextStyle(fontSize: 40)),
                      )
                    : SmartImage(src: img, fit: BoxFit.cover),
                if (item.soldOut)
                  Container(
                    color: Colors.black45,
                    alignment: Alignment.center,
                    child: Text(tr(lang, 'shSoldOut'),
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w800)),
                  ),
                if (item.isService)
                  PositionedDirectional(
                    top: 6,
                    start: 6,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppPal.purple,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(tr(lang, 'shService'),
                          style: const TextStyle(color: Colors.white, fontSize: 10.5)),
                    ),
                  ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
                  const SizedBox(height: 4),
                  Text(formatMoney(item.priceMinor, item.currency, lang),
                      style: const TextStyle(
                          color: AppPal.purpleDark,
                          fontWeight: FontWeight.w900,
                          fontSize: 13.5)),
                  const SizedBox(height: 4),
                  Row(children: [
                    Flexible(
                      child: Text(item.shopName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: AppPal.inkSoft, fontSize: 11.5)),
                    ),
                    if (item.shopVerified) ...[
                      const SizedBox(width: 3),
                      const VerifiedBadge(size: 13),
                    ],
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


/// انتخاب عکس از گالری یا دوربین؛ مسیر فایل ذخیره‌شده را برمی‌گرداند.
Future<String?> pickImagePath(BuildContext context, AppLang lang) async {
  final t = L10n.of(lang);
  final src = await showModalBottomSheet<ImageSource>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(
          leading: const Icon(Icons.photo_library_outlined, color: AppPal.purple),
          title: Text(t.gallery),
          onTap: () => Navigator.pop(ctx, ImageSource.gallery),
        ),
        ListTile(
          leading: const Icon(Icons.photo_camera_outlined, color: AppPal.purple),
          title: Text(t.camera),
          onTap: () => Navigator.pop(ctx, ImageSource.camera),
        ),
      ]),
    ),
  );
  if (src == null) return null;
  try {
    final f = await ImagePicker()
        .pickImage(source: src, imageQuality: 85, maxWidth: 1600);
    if (f == null) return null;
    return await persistImage(f.path);
  } catch (_) {
    return null;
  }
}


/// عکس کوچک آگهی (برای فهرست‌ها).
class ListingThumb extends StatelessWidget {
  final String url;
  const ListingThumb({super.key, required this.url});
  @override
  Widget build(BuildContext context) => SmartImage(src: url, fit: BoxFit.cover);
}
