import 'package:flutter/material.dart';

/// آیکون کبوتر نامه‌رسان (کبوتری که یک نامه در منقار دارد).
class PigeonIcon extends StatelessWidget {
  final double size;
  final Color color;
  const PigeonIcon({super.key, this.size = 34, this.color = const Color(0xFF7C5CFF)});

  @override
  Widget build(BuildContext context) => CustomPaint(
        size: Size(size, size),
        painter: _PigeonPainter(color),
      );
}

class _PigeonPainter extends CustomPainter {
  final Color color;
  _PigeonPainter(this.color);

  @override
  void paint(Canvas c, Size s) {
    final w = s.width, h = s.height;
    final body = Paint()..color = color;
    const gold = Color(0xFFFFC12E);

    // دم
    c.drawPath(
        Path()
          ..moveTo(w * .04, h * .80)
          ..lineTo(w * .30, h * .56)
          ..lineTo(w * .32, h * .80)
          ..close(),
        body);
    // بدن
    c.drawOval(Rect.fromLTWH(w * .20, h * .45, w * .50, h * .36), body);
    // سر
    c.drawCircle(Offset(w * .68, h * .40), w * .11, body);
    // منقار
    c.drawPath(
        Path()
          ..moveTo(w * .77, h * .37)
          ..lineTo(w * .88, h * .43)
          ..lineTo(w * .77, h * .47)
          ..close(),
        Paint()..color = gold);
    // بال
    c.drawPath(
        Path()
          ..moveTo(w * .30, h * .56)
          ..quadraticBezierTo(w * .26, h * .10, w * .58, h * .05)
          ..quadraticBezierTo(w * .50, h * .30, w * .62, h * .56)
          ..close(),
        Paint()..color = color.withValues(alpha: .72));
    // چشم
    c.drawCircle(Offset(w * .70, h * .38), w * .018, Paint()..color = Colors.white);
    // نامه
    final env = Rect.fromLTWH(w * .80, h * .50, w * .20, h * .28);
    c.drawRRect(RRect.fromRectAndRadius(env, Radius.circular(w * .02)),
        Paint()..color = gold);
    c.drawPath(
        Path()
          ..moveTo(env.left, env.top)
          ..lineTo(env.center.dx, env.top + env.height * .55)
          ..lineTo(env.right, env.top),
        Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = w * .02);
  }

  @override
  bool shouldRepaint(covariant _PigeonPainter old) => old.color != color;
}
