import 'package:flutter/material.dart';
import 'smart_image.dart';

/// نمایش تمام‌صفحه‌ی عکس با امکان زوم.
class ImageViewerPage extends StatelessWidget {
  final String src;
  const ImageViewerPage({super.key, required this.src});

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        body: Center(
          child: InteractiveViewer(
            minScale: 1,
            maxScale: 5,
            child: SmartImage(src: src, fit: BoxFit.contain),
          ),
        ),
      );
}
