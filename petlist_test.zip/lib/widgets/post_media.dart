import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'smart_image.dart';

/// کاور ویدئو در شبکه‌ی پروفایل، فید و پیام‌ها؛ اگر کاور نبود، پس‌زمینه‌ی تیره.
class VideoThumb extends StatelessWidget {
  final String? thumbUrl;
  final double iconSize;
  const VideoThumb({super.key, this.thumbUrl, this.iconSize = 56});

  @override
  Widget build(BuildContext context) {
    final has = thumbUrl != null && thumbUrl!.isNotEmpty;
    return Stack(
      fit: StackFit.expand,
      children: [
        if (has)
          SmartImage(src: thumbUrl, fit: BoxFit.cover)
        else
          const ColoredBox(color: Color(0xFF1B1B26)),
        Center(
          child: Icon(
            Icons.play_circle_fill,
            size: iconSize,
            color: Colors.white.withValues(alpha: .9),
            shadows: const [Shadow(blurRadius: 8, color: Colors.black54)],
          ),
        ),
      ],
    );
  }
}

/// پخش‌کننده‌ی ویدئو با نوار پیشرفت قابل‌کشیدن (جلو و عقب‌بردن).
/// [autoPlay]: شروع خودکار؛ [active]: اگر false شود پخش متوقف می‌شود
/// (برای صفحه‌های عمودی ویدئو).
class PostVideo extends StatefulWidget {
  final String url;
  final bool autoPlay;
  final bool active;
  final bool dark;
  const PostVideo({
    super.key,
    required this.url,
    this.autoPlay = false,
    this.active = true,
    this.dark = false,
  });

  @override
  State<PostVideo> createState() => _PostVideoState();
}

class _PostVideoState extends State<PostVideo> {
  late final VideoPlayerController _c;
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _c = VideoPlayerController.networkUrl(Uri.parse(widget.url));
    _c.initialize().then((_) {
      if (!mounted) return;
      setState(() => _ready = true);
      if (widget.autoPlay) {
        _c.setLooping(true);
        if (widget.active) _c.play();
      }
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
    _c.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void didUpdateWidget(covariant PostVideo old) {
    super.didUpdateWidget(old);
    if (!_ready || old.active == widget.active) return;
    if (!widget.active) {
      _c.pause();
    } else if (widget.autoPlay) {
      _c.play();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_failed) {
      return const AspectRatio(
        aspectRatio: 16 / 9,
        child: ColoredBox(
          color: Color(0xFF1B1B26),
          child: Center(
              child: Icon(Icons.error_outline, color: Colors.white70, size: 40)),
        ),
      );
    }
    if (!_ready) {
      return const AspectRatio(
        aspectRatio: 16 / 9,
        child: ColoredBox(
          color: Color(0xFF1B1B26),
          child: Center(child: CircularProgressIndicator()),
        ),
      );
    }
    final playing = _c.value.isPlaying;
    final ratio = _c.value.aspectRatio == 0 ? 16 / 9 : _c.value.aspectRatio;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: () => playing ? _c.pause() : _c.play(),
          child: Stack(
            alignment: Alignment.center,
            children: [
              AspectRatio(aspectRatio: ratio, child: VideoPlayer(_c)),
              if (!playing)
                const Icon(Icons.play_circle_fill,
                    size: 64, color: Colors.white70),
            ],
          ),
        ),
        SizedBox(
          height: 28,
          child: VideoProgressIndicator(
            _c,
            allowScrubbing: true,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
            colors: VideoProgressColors(
              playedColor: widget.dark ? Colors.white : const Color(0xFF7C5CFF),
              bufferedColor: Colors.white30,
              backgroundColor: Colors.white12,
            ),
          ),
        ),
      ],
    );
  }
}
