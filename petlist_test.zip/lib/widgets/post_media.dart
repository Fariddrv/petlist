import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

/// پیش‌نمایش ساده‌ی ویدئو (برای فید، پروفایل و پیام‌ها).
class VideoThumb extends StatelessWidget {
  final double iconSize;
  const VideoThumb({super.key, this.iconSize = 56});

  @override
  Widget build(BuildContext context) => Container(
        color: const Color(0xFF1B1B26),
        alignment: Alignment.center,
        child: Icon(Icons.play_circle_fill,
            size: iconSize, color: Colors.white70),
      );
}

/// پخش‌کننده‌ی ویدئوی پست (با دکمه‌ی پخش/توقف و نوار پیشرفت).
class PostVideo extends StatefulWidget {
  final String url;
  const PostVideo({super.key, required this.url});

  @override
  State<PostVideo> createState() => _PostVideoState();
}

class _PostVideoState extends State<PostVideo> {
  late final VideoPlayerController _c;
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _c = VideoPlayerController.networkUrl(Uri.parse(widget.url));
    _c.initialize().then((_) {
      if (mounted) setState(() => _ready = true);
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
    _c.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_failed) {
      return const AspectRatio(
        aspectRatio: 16 / 9,
        child: ColoredBox(
          color: Color(0xFF1B1B26),
          child: Center(
              child: Icon(Icons.error_outline, color: Colors.white70, size: 40)),
        ),
      );
    }
    if (!_ready) {
      return const AspectRatio(
        aspectRatio: 16 / 9,
        child: ColoredBox(
          color: Color(0xFF1B1B26),
          child: Center(child: CircularProgressIndicator()),
        ),
      );
    }
    final playing = _c.value.isPlaying;
    return Column(
      children: [
        GestureDetector(
          onTap: () => playing ? _c.pause() : _c.play(),
          child: Stack(
            alignment: Alignment.center,
            children: [
              AspectRatio(
                aspectRatio: _c.value.aspectRatio == 0 ? 16 / 9 : _c.value.aspectRatio,
                child: VideoPlayer(_c),
              ),
              if (!playing)
                const Icon(Icons.play_circle_fill,
                    size: 64, color: Colors.white70),
            ],
          ),
        ),
        VideoProgressIndicator(_c, allowScrubbing: true),
      ],
    );
  }
}
