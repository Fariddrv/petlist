import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../i18n2.dart';
import '../l10n.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import 'avatar.dart';

/// موقعیت انتخاب‌شده برای یک پست. [text] خالی یعنی «حذف موقعیت».
class PostLocation {
  final String text;
  final double? lat;
  final double? lng;
  const PostLocation(this.text, [this.lat, this.lng]);
}

/// موقعیت فعلی را با GPS می‌گیرد (نیاز به اجازه‌ی کاربر).
Future<Position?> _gps() async {
  try {
    if (!await Geolocator.isLocationServiceEnabled()) return null;
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      return null;
    }
    return await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.medium,
        timeLimit: Duration(seconds: 20),
      ),
    );
  } catch (_) {
    return null;
  }
}

/// نام محل را از روی مختصات می‌گیرد (OpenStreetMap). اگر نشد، خود مختصات.
Future<String> _placeName(double lat, double lng, AppLang l) async {
  final fallback = '${lat.toStringAsFixed(4)}, ${lng.toStringAsFixed(4)}';
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final lang = switch (l) { AppLang.fa => 'fa', AppLang.en => 'en', AppLang.zh => 'zh' };
    final req = await c.getUrl(Uri.parse(
        'https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=14&lat=$lat&lon=$lng&accept-language=$lang'));
    req.headers.set('User-Agent', 'pawpet-app/1.0');
    final res = await req.close().timeout(const Duration(seconds: 10));
    final body = await res.transform(utf8.decoder).join();
    final j = jsonDecode(body);
    final a = (j is Map && j['address'] is Map) ? j['address'] as Map : const {};
    final parts = <String>[];
    for (final k in ['suburb', 'neighbourhood', 'city', 'town', 'village', 'county', 'state', 'country']) {
      final v = a[k]?.toString();
      if (v != null && v.isNotEmpty && !parts.contains(v)) parts.add(v);
      if (parts.length >= 2) break;
    }
    return parts.isEmpty ? fallback : parts.join('، ');
  } catch (_) {
    return fallback;
  } finally {
    c.close(force: true);
  }
}

/// برگه‌ی انتخاب موقعیت: «موقعیت فعلی (آنلاین)» یا «نوشتن/انتخاب دستی».
/// null = انصراف؛ PostLocation('') = حذف موقعیت.
Future<PostLocation?> pickPostLocation(
    BuildContext context, AppState s, String current) {
  final l = s.lang;
  final ctrl = TextEditingController(text: current);
  var busy = false;
  var failed = false;
  return showModalBottomSheet<PostLocation>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
    ),
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => Padding(
        padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(tr(l, 'addLocation'),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 10),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: busy
                  ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(strokeWidth: 2.5))
                  : const Icon(Icons.my_location, color: AppPal.purple),
              title: Text(busy ? tr(l, 'locating') : tr(l, 'useCurrentLocation')),
              subtitle: failed
                  ? Text(tr(l, 'locationFailed'),
                      style: const TextStyle(color: Color(0xFFB3261E)))
                  : null,
              onTap: busy
                  ? null
                  : () async {
                      setS(() {
                        busy = true;
                        failed = false;
                      });
                      final pos = await _gps();
                      if (pos == null) {
                        setS(() {
                          busy = false;
                          failed = true;
                        });
                        return;
                      }
                      final name = await _placeName(pos.latitude, pos.longitude, l);
                      if (ctx.mounted) {
                        Navigator.pop(
                            ctx, PostLocation(name, pos.latitude, pos.longitude));
                      }
                    },
            ),
            if ((s.me?.city ?? '').isNotEmpty)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.location_city, color: AppPal.purple),
                title: Text(tr(l, 'myCity')),
                subtitle: Text(s.me!.city),
                onTap: () => Navigator.pop(ctx, PostLocation(s.me!.city)),
              ),
            const SizedBox(height: 4),
            TextField(
              controller: ctrl,
              decoration: InputDecoration(
                labelText: tr(l, 'typePlace'),
                prefixIcon: const Icon(Icons.edit_location_alt_outlined),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.check_circle, color: AppPal.purple),
                  onPressed: () {
                    final t = ctrl.text.trim();
                    if (t.isNotEmpty) Navigator.pop(ctx, PostLocation(t));
                  },
                ),
              ),
              onSubmitted: (v) {
                final t = v.trim();
                if (t.isNotEmpty) Navigator.pop(ctx, PostLocation(t));
              },
            ),
            if (current.isNotEmpty)
              TextButton.icon(
                onPressed: () => Navigator.pop(ctx, const PostLocation('')),
                icon: const Icon(Icons.close, color: Color(0xFFB3261E)),
                label: Text(tr(l, 'removeLocation'),
                    style: const TextStyle(color: Color(0xFFB3261E))),
              ),
            const SizedBox(height: 14),
          ],
        ),
      ),
    ),
  );
}

/// برگه‌ی تگ کردن دوستان (از بین دنبال‌شده‌ها و گفتگوهای قبلی).
Future<List<PostTag>?> pickPostTags(
    BuildContext context, AppState s, List<PostTag> current) {
  final l = s.lang;
  final chosen = <String, PostTag>{for (final t in current) t.id: t};
  return showModalBottomSheet<List<PostTag>>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
    ),
    builder: (ctx) => SizedBox(
      height: MediaQuery.of(ctx).size.height * .7,
      child: FutureBuilder<List<AppUser>>(
        future: s.shareTargets(),
        builder: (c, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final users = snap.data!;
          return StatefulBuilder(
            builder: (c, setS) => Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 8, 8),
                child: Row(children: [
                  Expanded(
                    child: Text(tr(l, 'tagFriends'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 16)),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx, chosen.values.toList()),
                    child: Text(tr(l, 'tagDone')),
                  ),
                ]),
              ),
              Expanded(
                child: users.isEmpty
                    ? Center(
                        child: Text(tr(l, 'noFriendsToTag'),
                            style: const TextStyle(color: AppPal.inkSoft)))
                    : ListView(children: [
                        for (final u in users)
                          CheckboxListTile(
                            value: chosen.containsKey(u.id),
                            activeColor: AppPal.purple,
                            secondary: UserAvatar(user: u, size: 40),
                            title: Text(u.username),
                            onChanged: (v) => setS(() {
                              if (v == true) {
                                chosen[u.id] = PostTag(u.id, u.username, u.avatarUrl);
                              } else {
                                chosen.remove(u.id);
                              }
                            }),
                          ),
                      ]),
              ),
            ]),
          );
        },
      ),
    ),
  );
}
