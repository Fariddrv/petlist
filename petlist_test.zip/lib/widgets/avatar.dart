import 'dart:io';
import 'package:flutter/material.dart';
import '../state.dart';
import '../theme.dart';

/// دایره‌ی آواتار: عکس محلی، عکس سرور، یا حرف اول نام.
class AvatarCircle extends StatelessWidget {
  final String? url;
  final String? localPath;
  final String name;
  final double size;
  const AvatarCircle(
      {super.key, this.url, this.localPath, this.name = '?', this.size = 44});

  Widget _letter() => Container(
        decoration: const BoxDecoration(gradient: AppPal.purpleGradient),
        alignment: Alignment.center,
        child: Text(
          (name.isNotEmpty ? name[0] : '?').toUpperCase(),
          style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: size * .42),
        ),
      );

  @override
  Widget build(BuildContext context) {
    Widget child;
    if (localPath != null && File(localPath!).existsSync()) {
      child = Image.file(File(localPath!), fit: BoxFit.cover);
    } else if (url != null && url!.isNotEmpty) {
      child = Image.network(url!,
          fit: BoxFit.cover, errorBuilder: (c, e, s) => _letter());
    } else {
      child = _letter();
    }
    return ClipOval(child: SizedBox(width: size, height: size, child: child));
  }
}

class UserAvatar extends StatelessWidget {
  final AppUser? user;
  final String? filePath;
  final double size;
  const UserAvatar({super.key, this.user, this.filePath, this.size = 44});

  @override
  Widget build(BuildContext context) => AvatarCircle(
        url: user?.avatarUrl,
        localPath: filePath,
        name: user?.username ?? '?',
        size: size,
      );
}
