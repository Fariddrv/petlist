import 'dart:io';
import 'package:flutter/material.dart';
import '../state.dart';
import '../theme.dart';

/// آواتار کاربر: عکس انتخابی، عکس نمونه، یا حرف اول نام.
class UserAvatar extends StatelessWidget {
  final AppUser? user;
  final String? filePath;
  final double size;
  const UserAvatar({super.key, this.user, this.filePath, this.size = 44});

  @override
  Widget build(BuildContext context) {
    final path = filePath ?? user?.avatarPath;
    Widget child;
    if (path != null && File(path).existsSync()) {
      child = Image.file(File(path), fit: BoxFit.cover);
    } else if (user?.avatarAsset != null) {
      child = Image.asset(user!.avatarAsset!, fit: BoxFit.cover);
    } else {
      final n = user?.username ?? '?';
      child = Container(
        decoration: const BoxDecoration(gradient: AppPal.purpleGradient),
        alignment: Alignment.center,
        child: Text(
          (n.isNotEmpty ? n[0] : '?').toUpperCase(),
          style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: size * .42),
        ),
      );
    }
    return ClipOval(child: SizedBox(width: size, height: size, child: child));
  }
}
