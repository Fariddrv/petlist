import 'dart:io';
import 'package:flutter/material.dart';
import '../theme.dart';

/// نمایش عکس از آدرس اینترنتی (سرور) یا فایل محلی.
class SmartImage extends StatelessWidget {
  final String? src;
  final BoxFit fit;
  final String? fallbackAsset;
  const SmartImage(
      {super.key, this.src, this.fit = BoxFit.cover, this.fallbackAsset});

  Widget _ph() => fallbackAsset != null
      ? Image.asset(fallbackAsset!, fit: fit)
      : Container(
          color: AppPal.bg,
          alignment: Alignment.center,
          child: const Icon(Icons.broken_image_outlined,
              color: AppPal.inkSoft, size: 40),
        );

  @override
  Widget build(BuildContext context) {
    final s = src;
    if (s == null || s.isEmpty) return _ph();
    if (s.startsWith('http')) {
      return Image.network(
        s,
        fit: fit,
        errorBuilder: (c, e, st) => _ph(),
        loadingBuilder: (c, child, p) => p == null
            ? child
            : Container(
                color: AppPal.bg,
                alignment: Alignment.center,
                child: const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2)),
              ),
      );
    }
    return Image.file(File(s), fit: fit, errorBuilder: (c, e, st) => _ph());
  }
}
