import 'package:flutter/material.dart';

import 'l10n.dart';
import 'models.dart';
import 'theme.dart';
import 'pages/home_page.dart';
import 'pages/pets_page.dart';
import 'pages/events_page.dart';
import 'pages/shop_page.dart';

void main() => runApp(const PetListApp());

/// اسکلت اصلی اپلیکیشن پت‌لیست: چهار تب + سه زبان.
class PetListApp extends StatefulWidget {
  const PetListApp({super.key});

  @override
  State<PetListApp> createState() => _PetListAppState();
}

class _PetListAppState extends State<PetListApp> {
  AppLang _lang = AppLang.fa; // زبان اصلی: فارسی
  int _tab = 0;
  final List<Pet> _pets = [];

  void _addPet(Pet p) => setState(() => _pets.add(p));
  void _removePet(Pet p) => setState(() => _pets.remove(p));

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(_lang);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: t.appTitle,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppPal.purple,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: AppPal.bg,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFFF3F4F8),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: AppPal.purple, width: 1.5),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
        chipTheme: ChipThemeData(
          backgroundColor: const Color(0xFFEFF1F5),
          selectedColor: const Color(0xFFEDE7FF),
          labelStyle:
              const TextStyle(color: AppPal.ink, fontWeight: FontWeight.w600),
          secondaryLabelStyle: const TextStyle(
              color: AppPal.purpleDark, fontWeight: FontWeight.w700),
          side: BorderSide.none,
          shape: const StadiumBorder(),
          checkmarkColor: AppPal.purpleDark,
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppPal.ink,
          contentTextStyle: const TextStyle(color: Colors.white),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: Colors.white,
          indicatorColor: const Color(0xFFEDE7FF),
          elevation: 2,
          labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
            (states) => TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 12.5,
              color: states.contains(WidgetState.selected)
                  ? AppPal.purpleDark
                  : AppPal.inkSoft,
            ),
          ),
          iconTheme: WidgetStateProperty.resolveWith<IconThemeData>(
            (states) => IconThemeData(
              size: 24,
              color: states.contains(WidgetState.selected)
                  ? AppPal.purple
                  : AppPal.inkSoft,
            ),
          ),
        ),
      ),
      home: Directionality(
        textDirection: _lang.direction,
        child: Scaffold(
          appBar: AppBar(
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset('assets/logo/app_logo.png',
                      width: 28, height: 28, fit: BoxFit.cover),
                ),
                const SizedBox(width: 8),
                Text(t.appTitle),
              ],
            ),
            centerTitle: true,
            backgroundColor: Colors.transparent,
            elevation: 0,
            foregroundColor: Colors.white,
            titleTextStyle: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w800,
            ),
            iconTheme: const IconThemeData(color: Colors.white),
            flexibleSpace: Container(
              decoration: const BoxDecoration(gradient: AppPal.purpleGradient),
            ),
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
            ),
            actions: [
              PopupMenuButton<AppLang>(
                icon: const Icon(Icons.translate),
                tooltip: t.changeLang,
                onSelected: (l) => setState(() => _lang = l),
                itemBuilder: (ctx) => [
                  for (final l in AppLang.values)
                    PopupMenuItem(
                      value: l,
                      child: Row(
                        children: [
                          Icon(
                            l == _lang ? Icons.check : Icons.circle_outlined,
                            size: 18,
                          ),
                          const SizedBox(width: 8),
                          Text(l.label),
                        ],
                      ),
                    ),
                ],
              ),
            ],
          ),
          body: IndexedStack(
            children: [
              HomePage(lang: _lang),
              PetsPage(
                lang: _lang,
                pets: _pets,
                onAdd: _addPet,
                onRemove: _removePet,
              ),
              EventsPage(lang: _lang),
              ShopPage(lang: _lang),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.home_outlined),
                selectedIcon: const Icon(Icons.home),
                label: t.tabHome,
              ),
              NavigationDestination(
                icon: const Icon(Icons.pets_outlined),
                selectedIcon: const Icon(Icons.pets),
                label: t.tabPets,
              ),
              NavigationDestination(
                icon: const Icon(Icons.event_outlined),
                selectedIcon: const Icon(Icons.event),
                label: t.tabEvents,
              ),
              NavigationDestination(
                icon: const Icon(Icons.storefront_outlined),
                selectedIcon: const Icon(Icons.storefront),
                label: t.tabShop,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
