import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'l10n.dart';
import 'models.dart';
import 'theme.dart';
import 'pages/home_page.dart';
import 'pages/pets_page.dart';
import 'pages/events_page.dart';
import 'pages/shop_page.dart';
import 'pages/new_post_page.dart';

void main() => runApp(const PetListApp());

/// اسکلت اصلی اپلیکیشن پت‌لیست: چهار تب، سه زبان، ساخت پست و
/// تعامل‌های اجتماعی (لایک/نظر/ذخیره/اشتراک‌گذاری).
class PetListApp extends StatefulWidget {
  const PetListApp({super.key});

  @override
  State<PetListApp> createState() => _PetListAppState();
}

class _PetListAppState extends State<PetListApp> {
  static const _kPetsKey = 'pets_v1';
  static const _kPostsKey = 'posts_v1';
  static const _kInterKey = 'inter_v1';
  static const _kLangKey = 'lang_v1';
  static const _kNameKey = 'username_v1';

  AppLang _lang = AppLang.fa;
  int _tab = 0;
  List<Pet> _pets = [];
  List<UserPost> _posts = [];
  Map<String, PostInter> _inter = {};
  String _username = '';
  bool _ready = false;
  bool _showSaved = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final sp = await SharedPreferences.getInstance();

      final pets = <Pet>[];
      final rawPets = sp.getString(_kPetsKey);
      if (rawPets != null && rawPets.isNotEmpty) {
        for (final it in jsonDecode(rawPets) as List) {
          pets.add(Pet.fromJson(Map<String, dynamic>.from(it as Map)));
        }
      }

      final posts = <UserPost>[];
      final rawPosts = sp.getString(_kPostsKey);
      if (rawPosts != null && rawPosts.isNotEmpty) {
        for (final it in jsonDecode(rawPosts) as List) {
          posts.add(UserPost.fromJson(Map<String, dynamic>.from(it as Map)));
        }
      }

      final inter = <String, PostInter>{};
      final rawInter = sp.getString(_kInterKey);
      if (rawInter != null && rawInter.isNotEmpty) {
        final map = Map<String, dynamic>.from(jsonDecode(rawInter) as Map);
        map.forEach((k, v) {
          inter[k] = PostInter.fromJson(Map<String, dynamic>.from(v as Map));
        });
      }

      final lang = AppLang.values.firstWhere(
        (l) => l.name == sp.getString(_kLangKey),
        orElse: () => AppLang.fa,
      );

      if (!mounted) return;
      setState(() {
        _pets = pets;
        _posts = posts;
        _inter = inter;
        _username = sp.getString(_kNameKey) ?? '';
        _lang = lang;
        _ready = true;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _ready = true);
    }
  }

  Future<void> _savePets() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(
        _kPetsKey, jsonEncode(_pets.map((p) => p.toJson()).toList()));
  }

  Future<void> _savePosts() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(
        _kPostsKey, jsonEncode(_posts.map((p) => p.toJson()).toList()));
  }

  Future<void> _saveInter() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kInterKey,
        jsonEncode(_inter.map((k, v) => MapEntry(k, v.toJson()))));
  }

  void _addPet(Pet p) {
    setState(() => _pets.add(p));
    _savePets();
  }

  void _removePet(Pet p) {
    setState(() => _pets.remove(p));
    _savePets();
  }

  void _removePost(UserPost p) {
    setState(() {
      _posts.remove(p);
      _inter.remove(p.id);
    });
    _savePosts();
    _saveInter();
  }

  // ---------- تعامل‌ها ----------
  void _toggleLike(String id) {
    final cur = _inter[id] ?? const PostInter(comments: []);
    setState(() => _inter[id] = cur.copyWith(liked: !cur.liked));
    _saveInter();
  }

  void _toggleSave(String id) {
    final cur = _inter[id] ?? const PostInter(comments: []);
    setState(() => _inter[id] = cur.copyWith(saved: !cur.saved));
    _saveInter();
    final t = L10n.of(_lang);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          duration: const Duration(milliseconds: 900),
          content: Text(!cur.saved ? t.savedLabel : t.save)),
    );
  }

  void _addComment(String postId, String text) {
    final cur = _inter[postId] ?? const PostInter(comments: []);
    final cm = Comment(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      author: _username.isNotEmpty ? _username : 'Me',
      text: text,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
    setState(() => _inter[postId] =
        cur.copyWith(comments: [...cur.comments, cm]));
    _saveInter();
  }

  void _share(String postId, String author, String text) {
    final t = L10n.of(_lang);
    final raw = text.isNotEmpty ? text : '$author 🐾';
    Clipboard.setData(ClipboardData(text: raw));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(t.shareCopied)),
    );
  }

  void _changeLang(AppLang l) {
    setState(() => _lang = l);
    SharedPreferences.getInstance()
        .then((sp) => sp.setString(_kLangKey, l.name));
  }

  Future<void> _openNewPost() async {
    final t = L10n.of(_lang);
    final result = await Navigator.push<UserPost>(
      context,
      MaterialPageRoute(
        builder: (_) => NewPostPage(lang: _lang, defaultAuthor: _username),
      ),
    );
    if (result == null) return;

    if (result.author.isNotEmpty && result.author != _username) {
      _username = result.author;
      final sp = await SharedPreferences.getInstance();
      await sp.setString(_kNameKey, _username);
    }
    setState(() => _posts.add(result));
    _savePosts();

    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(t.postPublished)));
    setState(() => _tab = 0);
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(_lang);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: t.appTitle,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppPal.purple,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: AppPal.bg,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFFF3F4F8),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: AppPal.purple, width: 1.5),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppPal.ink,
          contentTextStyle: const TextStyle(color: Colors.white),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: Colors.white,
          indicatorColor: const Color(0xFFEDE7FF),
          elevation: 2,
          labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
            (states) => TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 12.5,
              color: states.contains(WidgetState.selected)
                  ? AppPal.purpleDark
                  : AppPal.inkSoft,
            ),
          ),
          iconTheme: WidgetStateProperty.resolveWith<IconThemeData>(
            (states) => IconThemeData(
              size: 24,
              color: states.contains(WidgetState.selected)
                  ? AppPal.purple
                  : AppPal.inkSoft,
            ),
          ),
        ),
      ),
      home: Directionality(
        textDirection: _lang.direction,
        child: Scaffold(
          appBar: AppBar(
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset('assets/logo/app_logo.png',
                      width: 28, height: 28, fit: BoxFit.cover),
                ),
                const SizedBox(width: 8),
                Text(t.appTitle),
              ],
            ),
            centerTitle: true,
            backgroundColor: Colors.transparent,
            elevation: 0,
            foregroundColor: Colors.white,
            titleTextStyle: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w800),
            iconTheme: const IconThemeData(color: Colors.white),
            flexibleSpace: Container(
              decoration: const BoxDecoration(gradient: AppPal.purpleGradient),
            ),
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
            ),
            actions: [
              PopupMenuButton<AppLang>(
                icon: const Icon(Icons.translate),
                tooltip: t.changeLang,
                onSelected: _changeLang,
                itemBuilder: (ctx) => [
                  for (final l in AppLang.values)
                    PopupMenuItem(
                      value: l,
                      child: Row(
                        children: [
                          Icon(
                            l == _lang ? Icons.check : Icons.circle_outlined,
                            size: 18,
                          ),
                          const SizedBox(width: 8),
                          Text(l.label),
                        ],
                      ),
                    ),
                ],
              ),
            ],
          ),
          body: !_ready
              ? const Center(child: CircularProgressIndicator())
              : IndexedStack(
                  index: _tab,
                  children: [
                    HomePage(
                      lang: _lang,
                      userPosts: _posts,
                      interactions: _inter,
                      showSaved: _showSaved,
                      onRemovePost: _removePost,
                      onToggleSavedTab: (v) => setState(() => _showSaved = v),
                      onToggleLike: _toggleLike,
                      onToggleSave: _toggleSave,
                      onComment: _addComment,
                      onShare: _share,
                    ),
                    PetsPage(
                      lang: _lang,
                      pets: _pets,
                      onAdd: _addPet,
                      onRemove: _removePet,
                    ),
                    EventsPage(lang: _lang),
                    ShopPage(lang: _lang),
                  ],
                ),
          floatingActionButton: _tab == 0
              ? FloatingActionButton.extended(
                  onPressed: _openNewPost,
                  backgroundColor: AppPal.purple,
                  foregroundColor: Colors.white,
                  icon: const Icon(Icons.add_a_photo_outlined),
                  label: Text(
                    t.newPost,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                )
              : null,
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.home_outlined),
                selectedIcon: const Icon(Icons.home),
                label: t.tabHome,
              ),
              NavigationDestination(
                icon: const Icon(Icons.pets_outlined),
                selectedIcon: const Icon(Icons.pets),
                label: t.tabPets,
              ),
              NavigationDestination(
                icon: const Icon(Icons.event_outlined),
                selectedIcon: const Icon(Icons.event),
                label: t.tabEvents,
              ),
              NavigationDestination(
                icon: const Icon(Icons.storefront_outlined),
                selectedIcon: const Icon(Icons.storefront),
                label: t.tabShop,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
