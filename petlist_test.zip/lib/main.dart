import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'i18n2.dart';
import 'l10n.dart';
import 'state.dart';
import 'theme.dart';
import 'pages/auth_pages.dart';
import 'pages/events_page.dart';
import 'pages/home_page.dart';
import 'pages/menu_pages.dart';
import 'pages/new_post_page.dart';
import 'pages/pets_page.dart';
import 'pages/profile_page.dart';
import 'pages/shop_page.dart';
import 'models.dart';

void main() => runApp(const PetListApp());

class PetListApp extends StatefulWidget {
  const PetListApp({super.key});

  @override
  State<PetListApp> createState() => _PetListAppState();
}

class _PetListAppState extends State<PetListApp> {
  final AppState s = AppState();

  @override
  void initState() {
    super.initState();
    s.load();
  }

  @override
  void dispose() {
    s.dispose();
    super.dispose();
  }

  ThemeData _theme() => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppPal.purple,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: AppPal.bg,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFFF3F4F8),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: AppPal.purple, width: 1.5),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppPal.ink,
          contentTextStyle: const TextStyle(color: Colors.white),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: Colors.white,
          indicatorColor: const Color(0xFFEDE7FF),
          elevation: 2,
          labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
            (states) => TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 12,
              color: states.contains(WidgetState.selected)
                  ? AppPal.purpleDark
                  : AppPal.inkSoft,
            ),
          ),
          iconTheme: WidgetStateProperty.resolveWith<IconThemeData>(
            (states) => IconThemeData(
              size: 24,
              color: states.contains(WidgetState.selected)
                  ? AppPal.purple
                  : AppPal.inkSoft,
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        final t = L10n.of(s.lang);
        final Widget home;
        if (!s.ready) {
          home = const Scaffold(body: Center(child: CircularProgressIndicator()));
        } else if (s.me == null) {
          home = LoginPage(s: s);
        } else if (!s.me!.setupDone) {
          home = ProfileSetupPage(s: s);
        } else {
          home = MainShell(s: s);
        }
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: t.appTitle,
          theme: _theme(),
          // جهت متن (RTL/LTR) برای همه‌ی صفحه‌ها، از جمله صفحه‌های بازشده روی هم
          builder: (ctx, child) => Directionality(
            textDirection: s.lang.direction,
            child: child ?? const SizedBox(),
          ),
          home: home,
        );
      },
    );
  }
}

/// قاب اصلی اپ بعد از ورود: ۵ تب + منوی کشویی.
class MainShell extends StatefulWidget {
  final AppState s;
  const MainShell({super.key, required this.s});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final GlobalKey<ScaffoldState> _key = GlobalKey<ScaffoldState>();
  int _tab = 0;

  AppState get s => widget.s;

  void _snack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _openNewPost() async {
    final t = L10n.of(s.lang);
    final me = s.me!;
    final result = await Navigator.push<UserPost>(
      context,
      MaterialPageRoute(
        builder: (_) => NewPostPage(lang: s.lang, defaultAuthor: me.username),
      ),
    );
    if (result == null) return;
    s.addPost(UserPost(
      id: result.id,
      author: me.username,
      text: result.text,
      imagePath: result.imagePath,
      likes: result.likes,
      ownerId: me.id,
    ));
    if (!mounted) return;
    _snack(t.postPublished);
    setState(() => _tab = 0);
  }

  void _openUser(String id) {
    if (s.userById(id) == null) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProfilePage(s: s, userId: id, standalone: true),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(s.lang);
    final me = s.me!;
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) => Scaffold(
        key: _key,
        endDrawer: AppDrawer(s: s),
        appBar: AppBar(
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset('assets/logo/app_logo.png',
                    width: 28, height: 28, fit: BoxFit.cover),
              ),
              const SizedBox(width: 8),
              Text(t.appTitle),
            ],
          ),
          centerTitle: true,
          backgroundColor: Colors.transparent,
          elevation: 0,
          foregroundColor: Colors.white,
          titleTextStyle: const TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800),
          iconTheme: const IconThemeData(color: Colors.white),
          flexibleSpace: Container(
            decoration: const BoxDecoration(gradient: AppPal.purpleGradient),
          ),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
          ),
          automaticallyImplyLeading: false,
          actions: [
            PopupMenuButton<AppLang>(
              icon: const Icon(Icons.translate),
              tooltip: t.changeLang,
              onSelected: s.setLang,
              itemBuilder: (ctx) => [
                for (final l in AppLang.values)
                  PopupMenuItem(
                    value: l,
                    child: Row(children: [
                      Icon(l == s.lang ? Icons.check : Icons.circle_outlined,
                          size: 18),
                      const SizedBox(width: 8),
                      Text(l.label),
                    ]),
                  ),
              ],
            ),
            IconButton(
              icon: const Icon(Icons.menu),
              tooltip: tr(s.lang, 'menu'),
              onPressed: () => _key.currentState?.openEndDrawer(),
            ),
          ],
        ),
        body: IndexedStack(
          index: _tab,
          children: [
            HomePage(
              lang: s.lang,
              userPosts: s.visiblePosts(),
              interactions: s.inter,
              showSaved: false,
              meId: me.id,
              hiddenOwners: s.hiddenDemoOwners(),
              onOpenUser: _openUser,
              onRemovePost: s.removePost,
              onToggleSavedTab: (v) {},
              onToggleLike: s.toggleLike,
              onToggleSave: (id) {
                final was = s.inter[id]?.saved ?? false;
                s.toggleSave(id);
                _snack(!was ? t.savedLabel : t.save);
              },
              onComment: s.addComment,
              onShare: (id, author, text) {
                Clipboard.setData(
                    ClipboardData(text: text.isNotEmpty ? text : '$author 🐾'));
                _snack(t.shareCopied);
              },
            ),
            PetsPage(
              lang: s.lang,
              pets: s.myPets,
              onAdd: s.addPet,
              onRemove: s.removePet,
            ),
            ProfilePage(s: s, userId: me.id),
            EventsPage(lang: s.lang),
            ShopPage(lang: s.lang),
          ],
        ),
        floatingActionButton: _tab == 0
            ? FloatingActionButton.extended(
                onPressed: _openNewPost,
                backgroundColor: AppPal.purple,
                foregroundColor: Colors.white,
                icon: const Icon(Icons.add_a_photo_outlined),
                label: Text(t.newPost,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              )
            : null,
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() => _tab = i),
          destinations: [
            NavigationDestination(
              icon: const Icon(Icons.home_outlined),
              selectedIcon: const Icon(Icons.home),
              label: t.tabHome,
            ),
            NavigationDestination(
              icon: const Icon(Icons.pets_outlined),
              selectedIcon: const Icon(Icons.pets),
              label: t.tabPets,
            ),
            NavigationDestination(
              icon: const Icon(Icons.person_outline),
              selectedIcon: const Icon(Icons.person),
              label: tr(s.lang, 'profile'),
            ),
            NavigationDestination(
              icon: const Icon(Icons.event_outlined),
              selectedIcon: const Icon(Icons.event),
              label: t.tabEvents,
            ),
            NavigationDestination(
              icon: const Icon(Icons.storefront_outlined),
              selectedIcon: const Icon(Icons.storefront),
              label: t.tabShop,
            ),
          ],
        ),
      ),
    );
  }
}
