import 'package:flutter/material.dart';

void main() => runApp(const PetListTestApp());

/// زبان‌های پشتیبانی‌شده‌ی اپلیکیشن.
enum AppLang { fa, en, zh }

extension AppLangInfo on AppLang {
  /// جهت متن: فارسی راست‌به‌چپ و بقیه چپ‌به‌راست.
  TextDirection get direction =>
      this == AppLang.fa ? TextDirection.rtl : TextDirection.ltr;

  /// کد زبان برای نمایش.
  String get code => switch (this) {
        AppLang.fa => 'fa',
        AppLang.en => 'en',
        AppLang.zh => 'zh',
      };
}

/// ترجمه‌ها. برای افزودن زبان یا متن جدید فقط همین‌جا را کامل کن.
class L10n {
  final String appTitle;
  final String hello;
  final String subtitle;
  final String changeLang;
  final String comingSoon;
  final String madeWith;

  const L10n({
    required this.appTitle,
    required this.hello,
    required this.subtitle,
    required this.changeLang,
    required this.comingSoon,
    required this.madeWith,
  });

  static const Map<AppLang, L10n> all = {
    AppLang.fa: L10n(
      appTitle: 'پت‌لیست',
      hello: 'سلام! این اولین اپ ماست 🐾',
      subtitle: 'یک قدم کوچک برای شروع پروژه‌ی پت‌لیست.',
      changeLang: 'تغییر زبان',
      comingSoon: 'بزودی: پروفایل پت، اشتراک عکس، ایونت و فروشگاه',
      madeWith: 'ساخته‌شده با ❤️ برای دوستداران حیوانات',
    ),
    AppLang.en: L10n(
      appTitle: 'PetList',
      hello: 'Hi! This is our very first app 🐾',
      subtitle: 'A small first step for the PetList project.',
      changeLang: 'Change language',
      comingSoon: 'Coming soon: pet profiles, photo feed, events & shop',
      madeWith: 'Made with ❤️ for pet lovers',
    ),
    AppLang.zh: L10n(
      appTitle: '宠物社区',
      hello: '你好！这是我们的第一个应用 🐾',
      subtitle: '宠物社区项目迈出的第一小步。',
      changeLang: '切换语言',
      comingSoon: '即将推出：宠物档案、照片动态、活动与商店',
      madeWith: '用心为宠物爱好者打造 ❤️',
    ),
  };

  static L10n of(AppLang l) => all[l]!;
}

class PetListTestApp extends StatefulWidget {
  const PetListTestApp({super.key});

  @override
  State<PetListTestApp> createState() => _PetListTestAppState();
}

class _PetListTestAppState extends State<PetListTestApp> {
  AppLang _lang = AppLang.fa; // زبان اصلی: فارسی

  void _setLang(AppLang l) => setState(() => _lang = l);

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(_lang);
    final dir = _lang.direction;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: t.appTitle,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2E7D32),
      ),
      home: Directionality(
        textDirection: dir,
        child: Builder(
          builder: (context) => Scaffold(
            appBar: AppBar(
              title: Text(t.appTitle),
              centerTitle: true,
            ),
            body: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('🐕🐈', textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 56)),
                  const SizedBox(height: 16),
                  Text(
                    t.hello,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    t.subtitle,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                  const SizedBox(height: 32),
                  Text(
                    t.changeLang,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 8,
                    children: [
                      _LangChip(
                        label: 'فارسی',
                        selected: _lang == AppLang.fa,
                        onTap: () => _setLang(AppLang.fa),
                      ),
                      _LangChip(
                        label: 'English',
                        selected: _lang == AppLang.en,
                        onTap: () => _setLang(AppLang.en),
                      ),
                      _LangChip(
                        label: '中文',
                        selected: _lang == AppLang.zh,
                        onTap: () => _setLang(AppLang.zh),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.green.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      t.comingSoon,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 15, height: 1.8),
                    ),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                t.madeWith,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _LangChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _LangChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onTap(),
    );
  }
}
