import 'dart:io';
import 'package:path_provider/path_provider.dart';

/// عکس انتخاب‌شده را از مسیر موقت به حافظه‌ی دائمی اپ کپی می‌کند
/// تا اندروید آن را پاک نکند. اگر کپی نشد، مسیر اصلی برمی‌گردد.
Future<String> persistImage(String path) async {
  try {
    final dir = await getApplicationDocumentsDirectory();
    final ext = path.contains('.') ? path.split('.').last : 'jpg';
    final dest =
        '${dir.path}/img_${DateTime.now().microsecondsSinceEpoch}.$ext';
    await File(path).copy(dest);
    return dest;
  } catch (_) {
    return path;
  }
}
