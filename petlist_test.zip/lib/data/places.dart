import '../l10n.dart';

class Place {
  final String key; // کد کشور یا نام انگلیسی شهر
  final String en, fa, zh;
  const Place(this.key, this.en, this.fa, this.zh);
  String name(AppLang l) => switch (l) {
        AppLang.fa => fa,
        AppLang.en => en,
        AppLang.zh => zh,
      };
}

const List<Place> countries = [
  Place('IR', 'Iran', 'ایران', '伊朗'),
  Place('CN', 'China', 'چین', '中国'),
  Place('US', 'United States', 'ایالات متحده', '美国'),
  Place('GB', 'United Kingdom', 'بریتانیا', '英国'),
  Place('DE', 'Germany', 'آلمان', '德国'),
  Place('FR', 'France', 'فرانسه', '法国'),
  Place('IT', 'Italy', 'ایتالیا', '意大利'),
  Place('ES', 'Spain', 'اسپانیا', '西班牙'),
  Place('TR', 'Turkey', 'ترکیه', '土耳其'),
  Place('AE', 'United Arab Emirates', 'امارات متحده عربی', '阿联酋'),
  Place('CA', 'Canada', 'کانادا', '加拿大'),
  Place('AU', 'Australia', 'استرالیا', '澳大利亚'),
  Place('JP', 'Japan', 'ژاپن', '日本'),
  Place('KR', 'South Korea', 'کره جنوبی', '韩国'),
  Place('IN', 'India', 'هند', '印度'),
  Place('PK', 'Pakistan', 'پاکستان', '巴基斯坦'),
  Place('AF', 'Afghanistan', 'افغانستان', '阿富汗'),
  Place('IQ', 'Iraq', 'عراق', '伊拉克'),
  Place('RU', 'Russia', 'روسیه', '俄罗斯'),
  Place('NL', 'Netherlands', 'هلند', '荷兰'),
  Place('SE', 'Sweden', 'سوئد', '瑞典'),
  Place('NO', 'Norway', 'نروژ', '挪威'),
  Place('CH', 'Switzerland', 'سوئیس', '瑞士'),
  Place('AT', 'Austria', 'اتریش', '奥地利'),
  Place('BE', 'Belgium', 'بلژیک', '比利时'),
  Place('DK', 'Denmark', 'دانمارک', '丹麦'),
  Place('FI', 'Finland', 'فنلاند', '芬兰'),
  Place('PT', 'Portugal', 'پرتغال', '葡萄牙'),
  Place('GR', 'Greece', 'یونان', '希腊'),
  Place('PL', 'Poland', 'لهستان', '波兰'),
  Place('UA', 'Ukraine', 'اوکراین', '乌克兰'),
  Place('SA', 'Saudi Arabia', 'عربستان سعودی', '沙特阿拉伯'),
  Place('QA', 'Qatar', 'قطر', '卡塔尔'),
  Place('KW', 'Kuwait', 'کویت', '科威特'),
  Place('OM', 'Oman', 'عمان', '阿曼'),
  Place('BH', 'Bahrain', 'بحرین', '巴林'),
  Place('EG', 'Egypt', 'مصر', '埃及'),
  Place('AZ', 'Azerbaijan', 'جمهوری آذربایجان', '阿塞拜疆'),
  Place('AM', 'Armenia', 'ارمنستان', '亚美尼亚'),
  Place('GE', 'Georgia', 'گرجستان', '格鲁吉亚'),
  Place('KZ', 'Kazakhstan', 'قزاقستان', '哈萨克斯坦'),
  Place('UZ', 'Uzbekistan', 'ازبکستان', '乌兹别克斯坦'),
  Place('MY', 'Malaysia', 'مالزی', '马来西亚'),
  Place('SG', 'Singapore', 'سنگاپور', '新加坡'),
  Place('TH', 'Thailand', 'تایلند', '泰国'),
  Place('HK', 'Hong Kong', 'هنگ‌کنگ', '香港'),
  Place('TW', 'Taiwan', 'تایوان', '台湾'),
  Place('BR', 'Brazil', 'برزیل', '巴西'),
  Place('MX', 'Mexico', 'مکزیک', '墨西哥'),
  Place('AR', 'Argentina', 'آرژانتین', '阿根廷'),
  Place('ZA', 'South Africa', 'آفریقای جنوبی', '南非'),
  Place('NZ', 'New Zealand', 'نیوزیلند', '新西兰'),
  Place('IE', 'Ireland', 'ایرلند', '爱尔兰'),
];

const Map<String, List<Place>> cities = {
  'IR': [
    Place('Tehran', 'Tehran', 'تهران', '德黑兰'),
    Place('Mashhad', 'Mashhad', 'مشهد', '马什哈德'),
    Place('Isfahan', 'Isfahan', 'اصفهان', '伊斯法罕'),
    Place('Shiraz', 'Shiraz', 'شیراز', '设拉子'),
    Place('Tabriz', 'Tabriz', 'تبریز', '大不里士'),
    Place('Karaj', 'Karaj', 'کرج', '卡拉季'),
    Place('Ahvaz', 'Ahvaz', 'اهواز', '阿瓦士'),
    Place('Qom', 'Qom', 'قم', '库姆'),
    Place('Kermanshah', 'Kermanshah', 'کرمانشاه', '克尔曼沙汗'),
    Place('Rasht', 'Rasht', 'رشت', '拉什特'),
    Place('Urmia', 'Urmia', 'ارومیه', '乌鲁米耶'),
    Place('Yazd', 'Yazd', 'یزد', '亚兹德'),
    Place('Kerman', 'Kerman', 'کرمان', '克尔曼'),
    Place('Zahedan', 'Zahedan', 'زاهدان', '扎黑丹'),
    Place('Hamadan', 'Hamadan', 'همدان', '哈马丹'),
    Place('Arak', 'Arak', 'اراک', '阿拉克'),
    Place('Bandar Abbas', 'Bandar Abbas', 'بندرعباس', '阿巴斯港'),
    Place('Sari', 'Sari', 'ساری', '萨里'),
    Place('Qazvin', 'Qazvin', 'قزوین', '加兹温'),
    Place('Zanjan', 'Zanjan', 'زنجان', '赞詹'),
    Place('Kish', 'Kish', 'کیش', '基什岛'),
  ],
  'CN': [
    Place('Beijing', 'Beijing', 'پکن', '北京'),
    Place('Shanghai', 'Shanghai', 'شانگهای', '上海'),
    Place('Guangzhou', 'Guangzhou', 'گوانگژو', '广州'),
    Place('Shenzhen', 'Shenzhen', 'شنژن', '深圳'),
    Place('Chengdu', 'Chengdu', 'چنگدو', '成都'),
    Place('Hangzhou', 'Hangzhou', 'هانگژو', '杭州'),
    Place('Wuhan', 'Wuhan', 'ووهان', '武汉'),
    Place("Xi'an", "Xi'an", 'شیان', '西安'),
    Place('Chongqing', 'Chongqing', 'چونگ‌چینگ', '重庆'),
    Place('Nanjing', 'Nanjing', 'نانجینگ', '南京'),
    Place('Tianjin', 'Tianjin', 'تیانجین', '天津'),
    Place('Suzhou', 'Suzhou', 'سوژو', '苏州'),
    Place('Zhengzhou', 'Zhengzhou', 'ژنگژو', '郑州'),
    Place('Changsha', 'Changsha', 'چانگشا', '长沙'),
    Place('Qingdao', 'Qingdao', 'چینگدائو', '青岛'),
    Place('Shenyang', 'Shenyang', 'شنیانگ', '沈阳'),
    Place('Harbin', 'Harbin', 'هاربین', '哈尔滨'),
    Place('Dalian', 'Dalian', 'دالیان', '大连'),
    Place('Kunming', 'Kunming', 'کونمینگ', '昆明'),
    Place('Xiamen', 'Xiamen', 'شیامن', '厦门'),
  ],
};

Place? _find(List<Place> l, String key) {
  for (final p in l) {
    if (p.key == key) return p;
  }
  return null;
}

/// نام کشور در زبان فعلی (اگر در فهرست نبود، همان متن ذخیره‌شده)
String countryName(String code, AppLang l) =>
    _find(countries, code)?.name(l) ?? code;

/// نام شهر در زبان فعلی (اگر در فهرست نبود، همان متن ذخیره‌شده)
String cityName(String country, String city, AppLang l) {
  final list = cities[country];
  if (list == null) return city;
  return _find(list, city)?.name(l) ?? city;
}
