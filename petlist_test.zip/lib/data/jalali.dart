import 'package:flutter/material.dart';
import '../l10n.dart';

/// تبدیل تاریخ میلادی به شمسی: [سال، ماه، روز]
List<int> toJalali(int gy, int gm, int gd) {
  const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  final gy2 = gm > 2 ? gy + 1 : gy;
  var days = 355666 +
      (365 * gy) +
      ((gy2 + 3) ~/ 4) -
      ((gy2 + 99) ~/ 100) +
      ((gy2 + 399) ~/ 400) +
      gd +
      gdm[gm - 1];
  var jy = -1595 + (33 * (days ~/ 12053));
  days %= 12053;
  jy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) {
    jy += (days - 1) ~/ 365;
    days = (days - 1) % 365;
  }
  final jm = days < 186 ? 1 + days ~/ 31 : 7 + (days - 186) ~/ 30;
  final jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

/// تبدیل تاریخ شمسی به میلادی: [سال، ماه، روز]
List<int> toGregorian(int jy, int jm, int jd) {
  jy += 1595;
  var days = -355668 +
      (365 * jy) +
      ((jy ~/ 33) * 8) +
      (((jy % 33) + 3) ~/ 4) +
      jd +
      (jm < 7 ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
  var gy = 400 * (days ~/ 146097);
  days %= 146097;
  if (days > 36524) {
    days -= 1;
    gy += 100 * (days ~/ 36524);
    days %= 36524;
    if (days >= 365) days += 1;
  }
  gy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) {
    gy += (days - 1) ~/ 365;
    days = (days - 1) % 365;
  }
  var gd = days + 1;
  final leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0;
  final sal = [0, 31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  var gm = 0;
  while (gm < 13 && gd > sal[gm]) {
    gd -= sal[gm];
    gm++;
  }
  return [gy, gm, gd];
}

const _faMonths = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];

String _p2(int n) => n.toString().padLeft(2, '0');

/// نمایش تاریخ: شمسی برای فارسی، میلادی برای بقیه‌ی زبان‌ها.
String formatDate(DateTime d, AppLang lang) {
  if (lang == AppLang.fa) {
    final j = toJalali(d.year, d.month, d.day);
    return '${j[0]}/${_p2(j[1])}/${_p2(j[2])}';
  }
  return '${d.year}/${_p2(d.month)}/${_p2(d.day)}';
}

bool _validJalali(int y, int m, int d) {
  final g = toGregorian(y, m, d);
  final back = toJalali(g[0], g[1], g[2]);
  return back[0] == y && back[1] == m && back[2] == d;
}

int _daysInJalaliMonth(int y, int m) {
  if (m <= 6) return 31;
  if (m <= 11) return 30;
  return _validJalali(y, 12, 30) ? 30 : 29;
}

/// انتخاب تاریخ: فارسی → تقویم شمسی، انگلیسی/چینی → تقویم میلادی.
/// [firstYear] و [lastYear] سال میلادی هستند.
Future<DateTime?> pickDate(
  BuildContext context,
  AppLang lang, {
  DateTime? initial,
  int? firstYear,
  int? lastYear,
}) async {
  final first = firstYear ?? 1920;
  final last = lastYear ?? DateTime.now().year + 5;
  var init = initial ?? DateTime(2000, 1, 1);
  if (init.year < first) init = DateTime(first, 1, 1);
  if (init.year > last) init = DateTime(last, 12, 28);

  if (lang != AppLang.fa) {
    return showDatePicker(
      context: context,
      initialDate: init,
      firstDate: DateTime(first),
      lastDate: DateTime(last, 12, 31),
    );
  }

  final j = toJalali(init.year, init.month, init.day);
  var y = j[0], m = j[1], d = j[2];
  final minY = toJalali(first, 6, 1)[0];
  final maxY = toJalali(last, 6, 1)[0];

  return showDialog<DateTime>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) {
        final dim = _daysInJalaliMonth(y, m);
        if (d > dim) d = dim;
        return AlertDialog(
          title: const Text('انتخاب تاریخ'),
          content: Row(
            children: [
              Expanded(
                child: DropdownButton<int>(
                  isExpanded: true,
                  value: d,
                  items: [
                    for (var i = 1; i <= dim; i++)
                      DropdownMenuItem(value: i, child: Text('$i')),
                  ],
                  onChanged: (v) => setS(() => d = v ?? d),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                flex: 2,
                child: DropdownButton<int>(
                  isExpanded: true,
                  value: m,
                  items: [
                    for (var i = 1; i <= 12; i++)
                      DropdownMenuItem(value: i, child: Text(_faMonths[i - 1])),
                  ],
                  onChanged: (v) => setS(() => m = v ?? m),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                flex: 2,
                child: DropdownButton<int>(
                  isExpanded: true,
                  value: y,
                  items: [
                    for (var i = maxY; i >= minY; i--)
                      DropdownMenuItem(value: i, child: Text('$i')),
                  ],
                  onChanged: (v) => setS(() => y = v ?? y),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx), child: const Text('لغو')),
            TextButton(
              onPressed: () {
                final g = toGregorian(y, m, d);
                Navigator.pop(ctx, DateTime(g[0], g[1], g[2]));
              },
              child: const Text('تایید'),
            ),
          ],
        );
      },
    ),
  );
}
