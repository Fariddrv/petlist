import 'dart:math' as math;

import '../l10n.dart';

/// دسته‌ی یک محصول یا خدمت.
class ShopCategory {
  final String key;
  final String kind; // product | service
  final String emoji;
  final String fa, en, zh;
  final bool restricted; // نیازمند مجوز ویژه (مثل فروش حیوان زنده)
  const ShopCategory(this.key, this.kind, this.emoji, this.fa, this.en, this.zh,
      {this.restricted = false});
  String name(AppLang l) => switch (l) {
        AppLang.fa => fa,
        AppLang.en => en,
        AppLang.zh => zh,
      };
}

const List<ShopCategory> shopCategories = [
  // ----- محصولات (پت‌شاپ) -----
  ShopCategory('food', 'product', '🍖', 'غذا و تشویقی', 'Food & treats', '食品与零食'),
  ShopCategory('supplies', 'product', '🦴', 'لوازم و اکسسوری', 'Supplies & accessories', '用品与配件'),
  ShopCategory('toys', 'product', '🧸', 'اسباب‌بازی', 'Toys', '玩具'),
  ShopCategory('hygiene', 'product', '🧴', 'بهداشت و نظافت', 'Hygiene & grooming products', '清洁与护理'),
  ShopCategory('housing', 'product', '🏠', 'خانه، قفس و باکس حمل', 'Beds, cages & carriers', '窝、笼与航空箱'),
  ShopCategory('aquarium', 'product', '🐠', 'آکواریوم و ماهی', 'Aquarium & fish supplies', '水族用品'),
  ShopCategory('bird_small', 'product', '🦜', 'پرندگان و حیوانات کوچک', 'Birds & small pets supplies', '鸟类与小宠用品'),
  ShopCategory('live_pets', 'product', '🐾', 'حیوان خانگی (فروش در پت‌شاپ)', 'Pets for sale (pet shops)', '宠物销售（宠物店）',
      restricted: true),
  ShopCategory('other_product', 'product', '📦', 'سایر محصولات', 'Other products', '其他商品'),
  // ----- خدمات -----
  ShopCategory('svc_vet', 'service', '🩺', 'دامپزشکی', 'Veterinary', '兽医'),
  ShopCategory('svc_grooming', 'service', '✂️', 'آرایشگاه حیوانات (گرومر)', 'Pet grooming', '宠物美容'),
  ShopCategory('svc_boarding', 'service', '🏨', 'پانسیون و نگهداری', 'Boarding & daycare', '寄养与日托'),
  ShopCategory('svc_training', 'service', '🎓', 'مربی‌گری و آموزش', 'Training', '训练'),
  ShopCategory('svc_walking', 'service', '🚶', 'پرستار و پت‌واکر', 'Pet sitting & walking', '宠物陪护与遛狗'),
  ShopCategory('svc_transport', 'service', '🚗', 'حمل‌ونقل حیوانات', 'Pet transport', '宠物托运'),
  ShopCategory('svc_other', 'service', '🛠️', 'سایر خدمات', 'Other services', '其他服务'),
];

ShopCategory? categoryOf(String key) {
  for (final c in shopCategories) {
    if (c.key == key) return c;
  }
  return null;
}

String categoryName(String key, AppLang l) => categoryOf(key)?.name(l) ?? key;

/// نوع فعالیت فروشگاه (هنگام ساخت فروشگاه انتخاب می‌شود) و مدارک لازم.
class ShopType {
  final String key;
  final String emoji;
  final String fa, en, zh;
  final String? extraDoc; // مدرک اضافه‌ی لازم: vet_council | animal_permit | business_license
  final bool extraRequired;
  const ShopType(this.key, this.emoji, this.fa, this.en, this.zh,
      {this.extraDoc, this.extraRequired = false});
  String name(AppLang l) => switch (l) {
        AppLang.fa => fa,
        AppLang.en => en,
        AppLang.zh => zh,
      };
}

const List<ShopType> shopTypes = [
  ShopType('vet', '🩺', 'دامپزشک / کلینیک', 'Veterinarian / clinic', '兽医 / 诊所',
      extraDoc: 'vet_council', extraRequired: true),
  ShopType('petshop', '🛍️', 'پت‌شاپ', 'Pet shop', '宠物店',
      extraDoc: 'business_license'),
  ShopType('groomer', '✂️', 'آرایشگر حیوانات (گرومر)', 'Groomer', '宠物美容师',
      extraDoc: 'business_license'),
  ShopType('boarding', '🏨', 'پانسیون حیوانات', 'Pet boarding', '宠物寄养',
      extraDoc: 'animal_permit', extraRequired: true),
  ShopType('trainer', '🎓', 'مربی', 'Trainer', '训练师', extraDoc: 'animal_permit'),
  ShopType('walker', '🚶', 'پرستار و پت‌واکر', 'Pet sitter / walker', '宠物陪护 / 遛狗'),
  ShopType('transport', '🚗', 'حمل‌ونقل حیوانات', 'Pet transport', '宠物托运',
      extraDoc: 'business_license'),
  ShopType('other', '🛠️', 'سایر', 'Other', '其他'),
];

ShopType? shopTypeOf(String key) {
  for (final t in shopTypes) {
    if (t.key == key) return t;
  }
  return null;
}

// ============================== ارزها ==============================

class Currency {
  final String code; // IRT = تومان ایران
  final int decimals;
  final String symbol; // برای en/zh
  final String fa, en, zh; // نام کوتاه
  const Currency(this.code, this.decimals, this.symbol, this.fa, this.en, this.zh);
  String name(AppLang l) => switch (l) {
        AppLang.fa => fa,
        AppLang.en => en,
        AppLang.zh => zh,
      };
}

/// چهار ارز اول مهم‌ترین‌ها هستند؛ بقیه بعد از آن‌ها.
const List<Currency> currencies = [
  Currency('IRT', 0, 'Toman', 'تومان', 'Toman (Iran)', '伊朗土曼'),
  Currency('USD', 2, r'$', 'دلار آمریکا', 'US Dollar', '美元'),
  Currency('EUR', 2, '€', 'یورو', 'Euro', '欧元'),
  Currency('CNY', 2, 'CN¥', 'یوآن چین', 'Chinese Yuan', '人民币'),
  Currency('GBP', 2, '£', 'پوند بریتانیا', 'British Pound', '英镑'),
  Currency('AED', 2, 'AED', 'درهم امارات', 'UAE Dirham', '阿联酋迪拉姆'),
  Currency('TRY', 2, '₺', 'لیر ترکیه', 'Turkish Lira', '土耳其里拉'),
  Currency('JPY', 0, 'JP¥', 'ین ژاپن', 'Japanese Yen', '日元'),
  Currency('KRW', 0, '₩', 'وون کره', 'South Korean Won', '韩元'),
  Currency('CAD', 2, 'C\$', 'دلار کانادا', 'Canadian Dollar', '加拿大元'),
  Currency('AUD', 2, 'A\$', 'دلار استرالیا', 'Australian Dollar', '澳大利亚元'),
  Currency('CHF', 2, 'CHF', 'فرانک سوئیس', 'Swiss Franc', '瑞士法郎'),
  Currency('SAR', 2, 'SAR', 'ریال عربستان', 'Saudi Riyal', '沙特里亚尔'),
  Currency('INR', 2, '₹', 'روپیه هند', 'Indian Rupee', '印度卢比'),
  Currency('RUB', 2, '₽', 'روبل روسیه', 'Russian Ruble', '俄罗斯卢布'),
  Currency('IQD', 0, 'IQD', 'دینار عراق', 'Iraqi Dinar', '伊拉克第纳尔'),
];

Currency currencyOf(String code) {
  for (final c in currencies) {
    if (c.code == code) return c;
  }
  return currencies[1];
}

const _faDigits = '۰۱۲۳۴۵۶۷۸۹';
const _prefixCodes = {'USD', 'EUR', 'CNY', 'GBP', 'TRY', 'JPY', 'KRW', 'CAD', 'AUD', 'INR', 'RUB'};

String _toFaDigits(String s) {
  final b = StringBuffer();
  for (final ch in s.split('')) {
    final d = int.tryParse(ch);
    b.write(d == null ? ch : _faDigits[d]);
  }
  return b.toString();
}

String _group(String digits, String sep) {
  final out = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) out.write(sep);
    out.write(digits[i]);
  }
  return out.toString();
}

/// نمایش مبلغ: «۱٬۲۰۰٬۰۰۰ تومان» یا «$20.50».
String formatMoney(int minor, String code, AppLang l) {
  final c = currencyOf(code);
  final div = math.pow(10, c.decimals).toInt();
  final whole = minor ~/ div;
  final frac = minor % div;
  var body = _group(whole.toString(), l == AppLang.fa ? '٬' : ',');
  if (c.decimals > 0 && frac != 0) {
    body += (l == AppLang.fa ? '٫' : '.') + frac.toString().padLeft(c.decimals, '0');
  }
  if (l == AppLang.fa) return '${_toFaDigits(body)} ${c.fa}';
  if (c.code == 'IRT') return '$body ${l == AppLang.zh ? "土曼" : "Toman"}';
  return _prefixCodes.contains(c.code) ? '${c.symbol}$body' : '$body ${c.symbol}';
}

/// متنی که کاربر تایپ کرده را به کوچک‌ترین واحد ارز تبدیل می‌کند (null = نامعتبر).
int? parseMoney(String text, String code) {
  var t = text.trim();
  const ar = '٠١٢٣٤٥٦٧٨٩';
  final b = StringBuffer();
  for (final ch in t.split('')) {
    final i = _faDigits.indexOf(ch);
    final j = ar.indexOf(ch);
    if (i >= 0) {
      b.write(i);
    } else if (j >= 0) {
      b.write(j);
    } else if (ch == '٫') {
      b.write('.');
    } else if (ch == ',' || ch == '٬' || ch == ' ') {
      continue;
    } else {
      b.write(ch);
    }
  }
  t = b.toString();
  final v = double.tryParse(t);
  if (v == null || v < 0) return null;
  final c = currencyOf(code);
  return (v * math.pow(10, c.decimals)).round();
}

/// مبلغ را برای نمایش در فیلد ویرایش برمی‌گرداند (بدون جداکننده).
String moneyToInput(int minor, String code) {
  final c = currencyOf(code);
  if (c.decimals == 0) return minor.toString();
  final div = math.pow(10, c.decimals).toInt();
  final frac = minor % div;
  if (frac == 0) return (minor ~/ div).toString();
  return '${minor ~/ div}.${frac.toString().padLeft(c.decimals, '0')}';
}
