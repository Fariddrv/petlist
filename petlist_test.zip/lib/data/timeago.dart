import '../l10n.dart';
import '../i18n2.dart';
import 'jalali.dart';

const _faMonthsShort = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];
const _enMonths = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

/// زمان نسبی پست: دقیقه/ساعت پیش، دیروز، چند روز/هفته/ماه پیش، سپس «روز و ماه».
String timeAgo(int ms, AppLang l) {
  if (ms <= 0) return '';
  final t = DateTime.fromMillisecondsSinceEpoch(ms);
  final diff = DateTime.now().difference(t);
  String n(String key, int v) => tr(l, key).replaceAll('{n}', '$v');
  if (diff.inSeconds < 60) return tr(l, 'tNow');
  if (diff.inMinutes < 60) return n('tMin', diff.inMinutes);
  if (diff.inHours < 24) return n('tHour', diff.inHours);
  if (diff.inHours < 48) return tr(l, 'tYesterday');
  if (diff.inDays < 7) return n('tDays', diff.inDays);
  if (diff.inDays < 14) return tr(l, 'tWeek1');
  if (diff.inDays < 21) return tr(l, 'tWeek2');
  if (diff.inDays < 28) return tr(l, 'tWeek3');
  if (diff.inDays < 60) return tr(l, 'tMonth1');
  // قدیمی‌تر: روز و ماه (اگر سال فرق دارد، سال هم)
  final now = DateTime.now();
  switch (l) {
    case AppLang.fa:
      final j = toJalali(t.year, t.month, t.day);
      final jn = toJalali(now.year, now.month, now.day);
      final base = '${j[2]} ${_faMonthsShort[j[1] - 1]}';
      return j[0] == jn[0] ? base : '$base ${j[0]}';
    case AppLang.en:
      final base = '${_enMonths[t.month - 1]} ${t.day}';
      return t.year == now.year ? base : '$base, ${t.year}';
    case AppLang.zh:
      final base = '${t.month}月${t.day}日';
      return t.year == now.year ? base : '${t.year}年$base';
  }
}
