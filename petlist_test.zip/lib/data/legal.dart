import '../l10n.dart';

/// متن قوانین و حریم خصوصی. kind: 'terms' | 'privacy'
String legalText(String kind, AppLang l) {
  if (kind == 'vendor') {
    return switch (l) {
      AppLang.fa => _vendorFa,
      AppLang.en => _vendorEn,
      AppLang.zh => _vendorZh,
    };
  }
  if (kind == 'subscription') {
    return switch (l) {
      AppLang.fa => _subFa,
      AppLang.en => _subEn,
      AppLang.zh => _subZh,
    };
  }
  if (kind == 'terms') {
    return switch (l) {
      AppLang.fa => _termsFa,
      AppLang.en => _termsEn,
      AppLang.zh => _termsZh,
    };
  }
  return switch (l) {
    AppLang.fa => _privacyFa,
    AppLang.en => _privacyEn,
    AppLang.zh => _privacyZh,
  };
}

const String _termsFa = '''قوانین و مقررات اپلیکیشن «pawpet»
آخرین بروزرسانی: ۱۴۰۵

مقدمه
pawpet یک پلتفرم آنلاین برای اشتراک‌گذاری محتوا میان صاحبان حیوانات خانگی، معرفی رویدادها و (در آینده) معرفی محصولات و خدمات مرتبط با حیوانات است. استفاده از اپلیکیشن به معنای پذیرش کامل قوانین زیر است.

۱. تعاریف
• کاربر: هر شخصی که در اپلیکیشن ثبت‌نام کرده و از آن استفاده می‌کند.
• فروشنده: دامپزشک، پت‌شاپ یا ارائه‌دهنده‌ی خدماتی که محصولات یا خدمات خود را عرضه می‌کند.
• پلتفرم: اپلیکیشن pawpet که نقش واسط میان کاربران و فروشندگان را دارد.
• محتوا: هر تصویر، متن، ویدئو، پروفایل یا اطلاعات منتشرشده توسط کاربران.

۲. شرایط عضویت
• حداقل سن برای عضویت ۱۳ سال است.
• اطلاعات واردشده باید صحیح باشد؛ ایجاد حساب با اطلاعات جعلی یا متعلق به دیگران ممنوع است.
• مسئولیت امنیت حساب و رمز عبور بر عهده‌ی کاربر است.

۳. قوانین محتوا
انتشار موارد زیر ممنوع است:
• محتوای غیرقانونی، توهین‌آمیز، خشونت‌آمیز یا آزار حیوانات
• تبلیغات غیرمجاز، داروهای دامپزشکی و خدمات درمانی آنلاین
• محتوای جنسی، سیاسی، نژادپرستانه یا نفرت‌پراکن
• انتشار اطلاعات خصوصی دیگران

۴. مالکیت و استفاده از محتوا
محتوای شما متعلق به خودتان می‌ماند. با انتشار آن، به pawpet اجازه می‌دهید آن را در اپلیکیشن نمایش دهد و برای اجرای خدمات (مثل نمایش در فید و پروفایل) ذخیره کند.

۵. مسئولیت کاربران
• مسئولیت کامل محتوا بر عهده‌ی کاربر است.
• سوءاستفاده از حیوانات در تصاویر ممنوع است.
• تخلف می‌تواند به حذف محتوا، محدودیت یا حذف حساب منجر شود.

۶. گزارش تخلف
کاربران می‌توانند محتوای مغایر با قوانین را از طریق بخش پشتیبانی گزارش دهند. پلتفرم حق دارد محتوای مغایر را بدون اطلاع قبلی حذف کند.

۷. اختلالات فنی
پلتفرم مسئولیتی در قبال قطعی اینترنت، مشکلات سرور یا از دست رفتن اطلاعات ندارد.

۸. محدودیت مسئولیت
pawpet واسط است و مسئولیتی در قبال اختلاف میان کاربران یا میان کاربر و فروشنده ندارد.

۹. تغییر قوانین
پلتفرم می‌تواند قوانین را تغییر دهد. ادامه‌ی استفاده به معنای پذیرش نسخه‌ی جدید است.

۱۰. قانون حاکم
این قوانین تابع قوانین کشوری است که سازنده‌ی پلتفرم در آن فعالیت می‌کند.

تماس: پشتیبانی داخل اپلیکیشن
پایان قوانین و مقررات اپلیکیشن pawpet''';

const String _termsEn = '''pawpet Terms & Conditions
Last updated: 2026

Introduction
pawpet is an online platform where pet owners share content, discover events and (in the future) find pet-related products and services. By using the app you accept these terms in full.

1. Definitions
• User: anyone who registers and uses the app.
• Vendor: a veterinarian, pet shop or service provider who offers products or services.
• Platform: the pawpet app, which acts as an intermediary between users and vendors.
• Content: any image, text, video, profile or information published by users.

2. Membership
• You must be at least 13 years old.
• The information you provide must be accurate. Creating accounts with false information or on behalf of others is prohibited.
• You are responsible for the security of your account and password.

3. Content rules
It is forbidden to publish:
• illegal, abusive or violent content, or animal cruelty
• unauthorized advertising, veterinary medicines or online medical services
• sexual, political, racist or hateful content
• other people's private information

4. Ownership and use of content
Your content stays yours. By publishing it you allow pawpet to display it in the app and store it to run the service (for example in feeds and profiles).

5. User responsibility
• You are fully responsible for the content you publish.
• Abuse of animals in images is prohibited.
• Violations may lead to content removal, restrictions or account deletion.

6. Reporting
You can report content that breaks these rules through the Support section. The platform may remove such content without prior notice.

7. Technical issues
The platform is not responsible for internet outages, server problems or data loss.

8. Limitation of liability
pawpet is an intermediary and is not responsible for disputes between users, or between a user and a vendor.

9. Changes
The platform may change these terms. Continued use means you accept the new version.

10. Governing law
These terms are governed by the laws of the country where the platform's creator operates.

Contact: via the Support section of the app
End of pawpet Terms & Conditions''';

const String _termsZh = '''pawpet 服务条款
最后更新：2026年

简介
pawpet 是一个供宠物主人分享内容、发现活动，并（未来）查找宠物相关商品和服务的在线平台。使用本应用即表示您完全接受以下条款。

1. 定义
• 用户：注册并使用本应用的任何人。
• 商家：提供商品或服务的兽医、宠物店或服务提供者。
• 平台：pawpet 应用，作为用户与商家之间的中介。
• 内容：用户发布的任何图片、文字、视频、资料或信息。

2. 会员条件
• 年满13周岁方可注册。
• 所填信息必须真实；禁止使用虚假信息或冒用他人身份创建账号。
• 用户自行负责账号和密码的安全。

3. 内容规范
禁止发布：
• 违法、侮辱、暴力内容或虐待动物的内容
• 未经许可的广告、兽药及线上医疗服务
• 色情、政治、种族主义或仇恨内容
• 他人的隐私信息

4. 内容的所有权与使用
您发布的内容仍归您所有。发布即表示您允许 pawpet 在应用内展示并存储该内容，以提供服务（例如动态和个人主页）。

5. 用户责任
• 用户对其发布的内容负全部责任。
• 禁止在图片中虐待动物。
• 违规可能导致内容被删除、账号受限或被删除。

6. 举报
您可以通过“客服支持”举报违规内容。平台有权在不事先通知的情况下删除违规内容。

7. 技术问题
对于网络中断、服务器故障或数据丢失，平台不承担责任。

8. 责任限制
pawpet 仅为中介，对用户之间或用户与商家之间的纠纷不承担责任。

9. 条款变更
平台可修改本条款。继续使用即表示接受新版本。

10. 适用法律
本条款适用平台创建者所在国家的法律。

联系方式：应用内“客服支持”
pawpet 服务条款结束''';

const String _privacyFa = '''سیاست حریم خصوصی اپلیکیشن «pawpet»
آخرین بروزرسانی: ۱۴۰۵

مقدمه
این سیاست توضیح می‌دهد pawpet چه اطلاعاتی را جمع‌آوری می‌کند، چگونه از آن استفاده می‌کند و چگونه از آن محافظت می‌کند.

۱. اطلاعات جمع‌آوری‌شده
• اطلاعات ثبت‌نام: نام، نام خانوادگی، تاریخ تولد، جنسیت، ایمیل، شماره‌ی موبایل
• موقعیت: کشور و شهری که شما انتخاب می‌کنید (این اطلاعات برای دیگران نمایش داده نمی‌شود)
• اطلاعات پروفایل: نام کاربری، تصویر، بیوگرافی، لینک‌ها، اطلاعات حیوانات
• محتوا: پست‌ها، دیدگاه‌ها، پیام‌ها
• اطلاعات فنی: مدل دستگاه و داده‌های لازم برای اتصال به سرور

۲. نمایش اطلاعات
نام، تاریخ تولد، جنسیت، ایمیل، موبایل، کشور و شهر شما فقط برای خودِ شما و مدیر سیستم قابل مشاهده است و به کاربران دیگر نشان داده نمی‌شود. نام کاربری، تصویر، بیوگرافی، لینک‌ها و پست‌های شما بسته به تنظیم حساب (عمومی یا خصوصی) برای دیگران نمایش داده می‌شود.

۳. نحوه‌ی استفاده از اطلاعات
• ارائه‌ی خدمات اپلیکیشن
• نمایش محتوای مرتبط با منطقه‌ی شما (مثل رویدادها و فروشگاه)
• جلوگیری از تخلف و سوءاستفاده
• بهبود عملکرد اپلیکیشن

۴. اشتراک‌گذاری اطلاعات
اطلاعات شما فروخته نمی‌شود. فقط در این موارد به اشتراک گذاشته می‌شود:
• با ارائه‌دهندگان زیرساخت (مثل سرویس میزبانی داده) برای اجرای اپلیکیشن
• با مراجع قانونی در صورت الزام قانونی

۵. امنیت
ارتباط اپلیکیشن با سرور رمزگذاری‌شده است و رمزهای عبور به‌صورت امن نگهداری می‌شوند. با این حال هیچ سیستمی صددرصد ایمن نیست.

۶. نگهداری و حذف اطلاعات
اطلاعات تا زمانی که حساب شما فعال است نگهداری می‌شود. می‌توانید از طریق بخش پشتیبانی درخواست حذف حساب و اطلاعات خود را بدهید. بخشی از اطلاعات ممکن است طبق قوانین مربوطه برای مدتی نگهداری شود.

۷. کودکان
استفاده از اپلیکیشن برای افراد زیر ۱۳ سال مجاز نیست.

۸. تغییر سیاست
این سیاست ممکن است بروزرسانی شود. ادامه‌ی استفاده به معنای پذیرش نسخه‌ی جدید است.

تماس: بخش پشتیبانی داخل اپلیکیشن
پایان سیاست حریم خصوصی اپلیکیشن pawpet''';

const String _privacyEn = '''pawpet Privacy Policy
Last updated: 2026

Introduction
This policy explains what information pawpet collects, how it is used and how it is protected.

1. Information we collect
• Registration data: first name, last name, date of birth, gender, email, mobile number
• Location: the country and city you choose (not shown to other users)
• Profile data: username, picture, bio, links, pet information
• Content: posts, comments, messages
• Technical data: device model and data needed to connect to the server

2. What others can see
Your name, date of birth, gender, email, mobile number, country and city are visible only to you and the system administrator. They are not shown to other users. Your username, picture, bio, links and posts are shown to others depending on your account setting (public or private).

3. How we use information
• To provide the app's services
• To show content relevant to your region (such as events and the shop)
• To prevent abuse and violations
• To improve the app

4. Sharing
We do not sell your information. It is shared only:
• with infrastructure providers (such as data hosting) that run the app
• with legal authorities when required by law

5. Security
The connection between the app and the server is encrypted and passwords are stored securely. However, no system is 100% secure.

6. Retention and deletion
Your information is kept while your account is active. You can ask to delete your account and data through the Support section. Some data may be retained for a period where the law requires it.

7. Children
The app is not intended for people under 13.

8. Changes
This policy may be updated. Continued use means you accept the new version.

Contact: via the Support section of the app
End of pawpet Privacy Policy''';

const String _privacyZh = '''pawpet 隐私政策
最后更新：2026年

简介
本政策说明 pawpet 收集哪些信息、如何使用以及如何保护这些信息。

1. 收集的信息
• 注册信息：名、姓、出生日期、性别、邮箱、手机号
• 位置：您选择的国家和城市（不向其他用户显示）
• 资料信息：用户名、头像、简介、链接、宠物信息
• 内容：帖子、评论、私信
• 技术信息：设备型号及连接服务器所需的数据

2. 他人可见的内容
您的姓名、出生日期、性别、邮箱、手机号、国家和城市仅您本人和系统管理员可见，不会向其他用户显示。您的用户名、头像、简介、链接和帖子将根据账号设置（公开或私密）向他人显示。

3. 信息的使用
• 提供应用服务
• 展示与您所在地区相关的内容（如活动和商店）
• 防止滥用和违规
• 改进应用

4. 信息共享
我们不会出售您的信息。仅在以下情况共享：
• 与运行应用所需的基础设施服务商（如数据托管）共享
• 依法需要时向法律机关提供

5. 安全
应用与服务器之间的连接已加密，密码经安全存储。但没有任何系统能保证绝对安全。

6. 保存与删除
账号有效期间，您的信息会被保存。您可通过“客服支持”申请删除账号和数据。部分数据可能依法保留一段时间。

7. 儿童
本应用不面向13岁以下人群。

8. 政策变更
本政策可能更新。继续使用即表示接受新版本。

联系方式：应用内“客服支持”
pawpet 隐私政策结束''';


const String _vendorFa = '''قرارداد همکاری فروشندگان اپلیکیشن «pawpet»
آخرین بروزرسانی: ۱۴۰۵

مقدمه
این قرارداد میان فروشنده (دارنده‌ی فروشگاه) و پلتفرم pawpet منعقد می‌شود. با ارسال درخواست ساخت فروشگاه، این قرارداد را می‌پذیرید.

۱. شرایط فعالیت فروشنده
• اطلاعات هویتی، تماس و مجوزهای واردشده باید صحیح و متعلق به خود فروشنده باشد.
• اطلاعات محصولات و خدمات (نام، قیمت، موجودی، تصویر، توضیحات) باید دقیق و واقعی باشد.
• دامپزشکان باید شماره و کارت معتبر نظام دامپزشکی داشته باشند. پانسیون‌ها و مربیان باید مجوز نگهداری حیوان از مراجع مربوطه داشته باشند. فروشندگان کالا ترجیحاً پروانه کسب مرتبط داشته باشند. پلتفرم می‌تواند مدارک را بررسی، استعلام یا درخواست تکمیل کند.
• فروش حیوان زنده فقط با رعایت کامل قوانین محلی و اصول رفاه حیوانات و فقط در دسته‌ی «حیوان خانگی (پت‌شاپ)» مجاز است.
• دامپزشکان فقط خدمات حضوری ارائه می‌کنند؛ درمان و تجویز آنلاین ممنوع است.

۲. کالا و خدمات ممنوع
• داروهای دامپزشکی، کالاهای قاچاق، تاریخ‌گذشته، تقلبی یا غیرقانونی
• هر کالا یا خدمتی که به حیوان آسیب برساند یا مغایر قوانین کشور محل فعالیت باشد

۳. مسئولیت‌ها
• مسئولیت اصالت، سلامت، تاریخ انقضای معتبر و قانونی بودن کالا و کیفیت خدمات ۱۰۰٪ بر عهده‌ی فروشنده است.
• pawpet فقط واسط میان فروشنده و مشتری است. اختلاف میان آن‌ها در وهله‌ی اول با خود طرفین است.
• فروشنده مسئول پرداخت مالیات و عوارض قانونی فعالیت خود است.

۴. ارسال، مرجوعی و لغو
• فروشنده باید زمان ارسال یا انجام خدمت و شرایط مرجوعی و لغو را شفاف اعلام کند و به آن عمل کند.
• در صورت اختلاف، پلتفرم می‌تواند مستندات دو طرف (عکس، پیام، گواهی) را بررسی و تصمیم بگیرد.

۵. پرداخت و تسویه (هنگام فعال شدن پرداخت آنلاین)
• پرداخت‌های آنلاین تا تایید دریافت کالا یا انجام خدمت به‌صورت امانی نگهداری می‌شود و سپس پس از کسر کمیسیون به فروشنده تسویه می‌شود.
• فروشنده باید اطلاعات بانکی صحیح و متعلق به خودش ارائه دهد.
• کمیسیون و اشتراک طبق «سیاست اشتراک و کمیسیون» است.

۶. تخلفات و پایان همکاری
• پلتفرم می‌تواند در صورت تخلف، فروشگاه را محدود، تعلیق یا حذف کند.
• فروشنده هر زمان می‌تواند همکاری را پایان دهد؛ تعهدات مربوط به سفارش‌های باز تا تکمیل آن‌ها باقی است.

پایان قرارداد همکاری فروشندگان اپلیکیشن pawpet''';

const String _vendorEn = '''pawpet Vendor Agreement
Last updated: 2026

Introduction
This agreement is between the vendor (shop owner) and the pawpet platform. By submitting a shop request you accept it.

1. Vendor requirements
• Identity, contact details and permits you provide must be accurate and belong to you.
• Product and service information (name, price, stock, images, description) must be accurate and truthful.
• Veterinarians must hold a valid veterinary council registration. Boarding facilities and trainers must hold the animal-keeping permits required by the competent authorities. Product sellers should hold a relevant trade licence. The platform may review, verify or request additional documents.
• Selling live animals is allowed only in full compliance with local law and animal-welfare rules, and only in the "Pets for sale (pet shops)" category.
• Veterinarians offer in-person services only; online treatment or prescriptions are prohibited.

2. Prohibited goods and services
• Veterinary medicines, smuggled, expired, counterfeit or illegal goods
• Anything that harms animals or breaks the laws of the country where you operate

3. Responsibilities
• You are fully responsible for the authenticity, safety, valid expiry dates and legality of goods and for the quality of services.
• pawpet is only an intermediary between vendor and customer. Disputes are in the first place between the two parties.
• You are responsible for your own taxes and legal duties.

4. Delivery, returns and cancellation
• You must state delivery or service times and your return and cancellation terms clearly, and follow them.
• In a dispute the platform may review both sides' evidence (photos, messages, certificates) and decide.

5. Payment and settlement (when online payments are enabled)
• Online payments are held in escrow until the customer confirms receipt or completion of the service, then settled to you after the commission is deducted.
• You must provide correct bank details that belong to you.
• Commission and subscription follow the "Subscription & Commission Policy".

6. Violations and termination
• The platform may restrict, suspend or remove a shop for violations.
• You may end the cooperation at any time; obligations for open orders remain until they are completed.

End of pawpet Vendor Agreement''';

const String _vendorZh = '''pawpet 商家合作协议
最后更新：2026年

简介
本协议由商家（店主）与 pawpet 平台订立。提交开店申请即表示您接受本协议。

1. 商家要求
• 您提供的身份、联系方式和证照必须真实，并属于您本人。
• 商品和服务信息（名称、价格、库存、图片、描述）必须准确真实。
• 兽医须持有有效的兽医协会注册证；寄养机构和训练师须持有主管部门要求的动物饲养许可；商品卖家宜持有相应营业执照。平台可审核、核实或要求补充材料。
• 仅在完全遵守当地法律和动物福利规定的前提下，才可在“宠物销售（宠物店）”类别中销售活体动物。
• 兽医仅提供线下服务；禁止线上诊疗或开处方。

2. 禁止的商品与服务
• 兽药、走私、过期、假冒或违法商品
• 伤害动物或违反经营所在国家法律的任何商品或服务

3. 责任
• 商品的真实性、安全性、有效期和合法性以及服务质量由商家完全负责。
• pawpet 仅为商家与顾客之间的中介，纠纷首先由双方自行解决。
• 商家自行负责税费及法定义务。

4. 发货、退货与取消
• 商家须清楚说明发货或服务时间以及退换和取消条款，并遵守。
• 发生纠纷时，平台可审查双方证据（照片、消息、证明）并作出决定。

5. 支付与结算（在线支付启用后）
• 在线付款将托管至顾客确认收货或服务完成，扣除佣金后向商家结算。
• 商家须提供属于本人的正确银行信息。
• 佣金和订阅按《订阅与佣金政策》执行。

6. 违规与终止
• 平台可因违规限制、暂停或删除店铺。
• 商家可随时终止合作；未完成订单的义务在订单完成前继续有效。

pawpet 商家合作协议结束''';

const String _subFa = '''سیاست اشتراک و کمیسیون فروشندگان pawpet
آخرین بروزرسانی: ۱۴۰۵

مقدمه
برای استفاده از فروشگاه، فروشندگان باید اشتراک فعال داشته باشند و پلتفرم درصدی از هر فروش را به‌عنوان کمیسیون دریافت می‌کند. دریافت اشتراک و کمیسیون هنگامی آغاز می‌شود که پرداخت آنلاین فعال شود و پیش از آن به شما اطلاع داده می‌شود.

۱. بسته‌های اشتراک
• یک‌ماهه: ۱٬۰۰۰٬۰۰۰ تومان
• سه‌ماهه: ۲٬۵۰۰٬۰۰۰ تومان
• یک‌ساله: ۸٬۰۰۰٬۰۰۰ تومان

۲. امکانات اشتراک
• ساخت پروفایل فروشنده و ثبت محصولات و خدمات
• رزرو و نوبت‌دهی حضوری
• مدیریت سفارش‌ها و داشبورد فروش
• پشتیبانی فروشندگان

۳. کمیسیون
• درصدی از هر فروش به‌عنوان کمیسیون کسر می‌شود. نرخ فعلی در صفحه‌ی ثبت‌نام فروشنده اعلام می‌شود.
• نرخ هر سفارش در لحظه‌ی ثبت آن ثبت می‌شود و تغییر بعدی نرخ روی سفارش‌های قبلی اثر ندارد.
• کمیسیون شامل هزینه‌های زیرساخت، امنیت و پشتیبانی است و پس از هر فروش خودکار کسر می‌شود.

۴. پرداخت، تمدید و لغو
• مبلغ اشتراک بجز مواردی که قانون الزام کند قابل استرداد نیست.
• در صورت تمدید نشدن، فروشگاه غیرفعال می‌شود و محصولات و خدمات از دید کاربران پنهان می‌شود.
• لغو اشتراک باعث غیرفعال شدن فروشگاه می‌شود.

۵. تخلفات
پلتفرم می‌تواند در صورت تخلف، اشتراک فروشنده را لغو کند.

پایان سیاست اشتراک و کمیسیون فروشندگان pawpet''';

const String _subEn = '''pawpet Subscription & Commission Policy
Last updated: 2026

Introduction
To use the shop, vendors need an active subscription, and the platform takes a commission from each sale. Subscriptions and commission start only when online payments are enabled, and you will be notified before that.

1. Subscription plans
• 1 month: 20 USD
• 3 months: 45 USD
• 1 year: 160 USD

2. What a subscription includes
• Vendor profile and product / service listings
• Booking and appointments
• Order management and sales dashboard
• Vendor support

3. Commission
• A percentage of each sale is deducted as commission. The current rate is shown on the vendor sign-up page.
• The rate is recorded when an order is placed; later changes do not affect earlier orders.
• Commission covers infrastructure, security and support, and is deducted automatically after each sale.

4. Payment, renewal and cancellation
• Subscription fees are non-refundable, except where the law requires otherwise.
• If not renewed, the shop is deactivated and its listings are hidden from users.
• Cancelling a subscription deactivates the shop.

5. Violations
The platform may cancel a vendor's subscription for violations.

End of pawpet Subscription & Commission Policy''';

const String _subZh = '''pawpet 订阅与佣金政策
最后更新：2026年

简介
使用商店功能的商家需要有效订阅，平台会从每笔销售中收取佣金。订阅费和佣金仅在在线支付启用后开始收取，启用前会通知您。

1. 订阅套餐
• 1个月：20美元
• 3个月：45美元
• 1年：160美元

2. 订阅包含
• 商家主页及商品/服务发布
• 预约与线下服务
• 订单管理与销售看板
• 商家支持

3. 佣金
• 每笔销售按一定比例扣除佣金，当前费率显示在商家注册页面。
• 费率在下单时记录，之后的调整不影响已有订单。
• 佣金用于基础设施、安全和支持，每笔销售后自动扣除。

4. 付款、续订与取消
• 订阅费不予退还，法律另有规定的除外。
• 未续订时店铺将停用，商品和服务对用户隐藏。
• 取消订阅将导致店铺停用。

5. 违规
平台可因违规取消商家订阅。

pawpet 订阅与佣金政策结束''';
