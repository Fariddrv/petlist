import '../l10n.dart';

/// متن قوانین و حریم خصوصی. kind: 'terms' | 'privacy'
String legalText(String kind, AppLang l) {
  if (kind == 'terms') {
    return switch (l) {
      AppLang.fa => _termsFa,
      AppLang.en => _termsEn,
      AppLang.zh => _termsZh,
    };
  }
  return switch (l) {
    AppLang.fa => _privacyFa,
    AppLang.en => _privacyEn,
    AppLang.zh => _privacyZh,
  };
}

const String _termsFa = '''قوانین و مقررات اپلیکیشن «pawpet»
آخرین بروزرسانی: ۱۴۰۵

مقدمه
pawpet یک پلتفرم آنلاین برای اشتراک‌گذاری محتوا میان صاحبان حیوانات خانگی، معرفی رویدادها و (در آینده) معرفی محصولات و خدمات مرتبط با حیوانات است. استفاده از اپلیکیشن به معنای پذیرش کامل قوانین زیر است.

۱. تعاریف
• کاربر: هر شخصی که در اپلیکیشن ثبت‌نام کرده و از آن استفاده می‌کند.
• فروشنده: دامپزشک، پت‌شاپ یا ارائه‌دهنده‌ی خدماتی که محصولات یا خدمات خود را عرضه می‌کند.
• پلتفرم: اپلیکیشن pawpet که نقش واسط میان کاربران و فروشندگان را دارد.
• محتوا: هر تصویر، متن، ویدئو، پروفایل یا اطلاعات منتشرشده توسط کاربران.

۲. شرایط عضویت
• حداقل سن برای عضویت ۱۳ سال است.
• اطلاعات واردشده باید صحیح باشد؛ ایجاد حساب با اطلاعات جعلی یا متعلق به دیگران ممنوع است.
• مسئولیت امنیت حساب و رمز عبور بر عهده‌ی کاربر است.

۳. قوانین محتوا
انتشار موارد زیر ممنوع است:
• محتوای غیرقانونی، توهین‌آمیز، خشونت‌آمیز یا آزار حیوانات
• تبلیغات غیرمجاز، داروهای دامپزشکی و خدمات درمانی آنلاین
• محتوای جنسی، سیاسی، نژادپرستانه یا نفرت‌پراکن
• انتشار اطلاعات خصوصی دیگران

۴. مالکیت و استفاده از محتوا
محتوای شما متعلق به خودتان می‌ماند. با انتشار آن، به pawpet اجازه می‌دهید آن را در اپلیکیشن نمایش دهد و برای اجرای خدمات (مثل نمایش در فید و پروفایل) ذخیره کند.

۵. مسئولیت کاربران
• مسئولیت کامل محتوا بر عهده‌ی کاربر است.
• سوءاستفاده از حیوانات در تصاویر ممنوع است.
• تخلف می‌تواند به حذف محتوا، محدودیت یا حذف حساب منجر شود.

۶. گزارش تخلف
کاربران می‌توانند محتوای مغایر با قوانین را از طریق بخش پشتیبانی گزارش دهند. پلتفرم حق دارد محتوای مغایر را بدون اطلاع قبلی حذف کند.

۷. اختلالات فنی
پلتفرم مسئولیتی در قبال قطعی اینترنت، مشکلات سرور یا از دست رفتن اطلاعات ندارد.

۸. محدودیت مسئولیت
pawpet واسط است و مسئولیتی در قبال اختلاف میان کاربران یا میان کاربر و فروشنده ندارد.

۹. تغییر قوانین
پلتفرم می‌تواند قوانین را تغییر دهد. ادامه‌ی استفاده به معنای پذیرش نسخه‌ی جدید است.

۱۰. قانون حاکم
این قوانین تابع قوانین کشوری است که سازنده‌ی پلتفرم در آن فعالیت می‌کند.

تماس: پشتیبانی داخل اپلیکیشن
پایان قوانین و مقررات اپلیکیشن pawpet''';

const String _termsEn = '''pawpet Terms & Conditions
Last updated: 2026

Introduction
pawpet is an online platform where pet owners share content, discover events and (in the future) find pet-related products and services. By using the app you accept these terms in full.

1. Definitions
• User: anyone who registers and uses the app.
• Vendor: a veterinarian, pet shop or service provider who offers products or services.
• Platform: the pawpet app, which acts as an intermediary between users and vendors.
• Content: any image, text, video, profile or information published by users.

2. Membership
• You must be at least 13 years old.
• The information you provide must be accurate. Creating accounts with false information or on behalf of others is prohibited.
• You are responsible for the security of your account and password.

3. Content rules
It is forbidden to publish:
• illegal, abusive or violent content, or animal cruelty
• unauthorized advertising, veterinary medicines or online medical services
• sexual, political, racist or hateful content
• other people's private information

4. Ownership and use of content
Your content stays yours. By publishing it you allow pawpet to display it in the app and store it to run the service (for example in feeds and profiles).

5. User responsibility
• You are fully responsible for the content you publish.
• Abuse of animals in images is prohibited.
• Violations may lead to content removal, restrictions or account deletion.

6. Reporting
You can report content that breaks these rules through the Support section. The platform may remove such content without prior notice.

7. Technical issues
The platform is not responsible for internet outages, server problems or data loss.

8. Limitation of liability
pawpet is an intermediary and is not responsible for disputes between users, or between a user and a vendor.

9. Changes
The platform may change these terms. Continued use means you accept the new version.

10. Governing law
These terms are governed by the laws of the country where the platform's creator operates.

Contact: via the Support section of the app
End of pawpet Terms & Conditions''';

const String _termsZh = '''pawpet 服务条款
最后更新：2026年

简介
pawpet 是一个供宠物主人分享内容、发现活动，并（未来）查找宠物相关商品和服务的在线平台。使用本应用即表示您完全接受以下条款。

1. 定义
• 用户：注册并使用本应用的任何人。
• 商家：提供商品或服务的兽医、宠物店或服务提供者。
• 平台：pawpet 应用，作为用户与商家之间的中介。
• 内容：用户发布的任何图片、文字、视频、资料或信息。

2. 会员条件
• 年满13周岁方可注册。
• 所填信息必须真实；禁止使用虚假信息或冒用他人身份创建账号。
• 用户自行负责账号和密码的安全。

3. 内容规范
禁止发布：
• 违法、侮辱、暴力内容或虐待动物的内容
• 未经许可的广告、兽药及线上医疗服务
• 色情、政治、种族主义或仇恨内容
• 他人的隐私信息

4. 内容的所有权与使用
您发布的内容仍归您所有。发布即表示您允许 pawpet 在应用内展示并存储该内容，以提供服务（例如动态和个人主页）。

5. 用户责任
• 用户对其发布的内容负全部责任。
• 禁止在图片中虐待动物。
• 违规可能导致内容被删除、账号受限或被删除。

6. 举报
您可以通过“客服支持”举报违规内容。平台有权在不事先通知的情况下删除违规内容。

7. 技术问题
对于网络中断、服务器故障或数据丢失，平台不承担责任。

8. 责任限制
pawpet 仅为中介，对用户之间或用户与商家之间的纠纷不承担责任。

9. 条款变更
平台可修改本条款。继续使用即表示接受新版本。

10. 适用法律
本条款适用平台创建者所在国家的法律。

联系方式：应用内“客服支持”
pawpet 服务条款结束''';

const String _privacyFa = '''سیاست حریم خصوصی اپلیکیشن «pawpet»
آخرین بروزرسانی: ۱۴۰۵

مقدمه
این سیاست توضیح می‌دهد pawpet چه اطلاعاتی را جمع‌آوری می‌کند، چگونه از آن استفاده می‌کند و چگونه از آن محافظت می‌کند.

۱. اطلاعات جمع‌آوری‌شده
• اطلاعات ثبت‌نام: نام، نام خانوادگی، تاریخ تولد، جنسیت، ایمیل، شماره‌ی موبایل
• موقعیت: کشور و شهری که شما انتخاب می‌کنید (این اطلاعات برای دیگران نمایش داده نمی‌شود)
• اطلاعات پروفایل: نام کاربری، تصویر، بیوگرافی، لینک‌ها، اطلاعات حیوانات
• محتوا: پست‌ها، دیدگاه‌ها، پیام‌ها
• اطلاعات فنی: مدل دستگاه و داده‌های لازم برای اتصال به سرور

۲. نمایش اطلاعات
نام، تاریخ تولد، جنسیت، ایمیل، موبایل، کشور و شهر شما فقط برای خودِ شما و مدیر سیستم قابل مشاهده است و به کاربران دیگر نشان داده نمی‌شود. نام کاربری، تصویر، بیوگرافی، لینک‌ها و پست‌های شما بسته به تنظیم حساب (عمومی یا خصوصی) برای دیگران نمایش داده می‌شود.

۳. نحوه‌ی استفاده از اطلاعات
• ارائه‌ی خدمات اپلیکیشن
• نمایش محتوای مرتبط با منطقه‌ی شما (مثل رویدادها و فروشگاه)
• جلوگیری از تخلف و سوءاستفاده
• بهبود عملکرد اپلیکیشن

۴. اشتراک‌گذاری اطلاعات
اطلاعات شما فروخته نمی‌شود. فقط در این موارد به اشتراک گذاشته می‌شود:
• با ارائه‌دهندگان زیرساخت (مثل سرویس میزبانی داده) برای اجرای اپلیکیشن
• با مراجع قانونی در صورت الزام قانونی

۵. امنیت
ارتباط اپلیکیشن با سرور رمزگذاری‌شده است و رمزهای عبور به‌صورت امن نگهداری می‌شوند. با این حال هیچ سیستمی صددرصد ایمن نیست.

۶. نگهداری و حذف اطلاعات
اطلاعات تا زمانی که حساب شما فعال است نگهداری می‌شود. می‌توانید از طریق بخش پشتیبانی درخواست حذف حساب و اطلاعات خود را بدهید. بخشی از اطلاعات ممکن است طبق قوانین مربوطه برای مدتی نگهداری شود.

۷. کودکان
استفاده از اپلیکیشن برای افراد زیر ۱۳ سال مجاز نیست.

۸. تغییر سیاست
این سیاست ممکن است بروزرسانی شود. ادامه‌ی استفاده به معنای پذیرش نسخه‌ی جدید است.

تماس: بخش پشتیبانی داخل اپلیکیشن
پایان سیاست حریم خصوصی اپلیکیشن pawpet''';

const String _privacyEn = '''pawpet Privacy Policy
Last updated: 2026

Introduction
This policy explains what information pawpet collects, how it is used and how it is protected.

1. Information we collect
• Registration data: first name, last name, date of birth, gender, email, mobile number
• Location: the country and city you choose (not shown to other users)
• Profile data: username, picture, bio, links, pet information
• Content: posts, comments, messages
• Technical data: device model and data needed to connect to the server

2. What others can see
Your name, date of birth, gender, email, mobile number, country and city are visible only to you and the system administrator. They are not shown to other users. Your username, picture, bio, links and posts are shown to others depending on your account setting (public or private).

3. How we use information
• To provide the app's services
• To show content relevant to your region (such as events and the shop)
• To prevent abuse and violations
• To improve the app

4. Sharing
We do not sell your information. It is shared only:
• with infrastructure providers (such as data hosting) that run the app
• with legal authorities when required by law

5. Security
The connection between the app and the server is encrypted and passwords are stored securely. However, no system is 100% secure.

6. Retention and deletion
Your information is kept while your account is active. You can ask to delete your account and data through the Support section. Some data may be retained for a period where the law requires it.

7. Children
The app is not intended for people under 13.

8. Changes
This policy may be updated. Continued use means you accept the new version.

Contact: via the Support section of the app
End of pawpet Privacy Policy''';

const String _privacyZh = '''pawpet 隐私政策
最后更新：2026年

简介
本政策说明 pawpet 收集哪些信息、如何使用以及如何保护这些信息。

1. 收集的信息
• 注册信息：名、姓、出生日期、性别、邮箱、手机号
• 位置：您选择的国家和城市（不向其他用户显示）
• 资料信息：用户名、头像、简介、链接、宠物信息
• 内容：帖子、评论、私信
• 技术信息：设备型号及连接服务器所需的数据

2. 他人可见的内容
您的姓名、出生日期、性别、邮箱、手机号、国家和城市仅您本人和系统管理员可见，不会向其他用户显示。您的用户名、头像、简介、链接和帖子将根据账号设置（公开或私密）向他人显示。

3. 信息的使用
• 提供应用服务
• 展示与您所在地区相关的内容（如活动和商店）
• 防止滥用和违规
• 改进应用

4. 信息共享
我们不会出售您的信息。仅在以下情况共享：
• 与运行应用所需的基础设施服务商（如数据托管）共享
• 依法需要时向法律机关提供

5. 安全
应用与服务器之间的连接已加密，密码经安全存储。但没有任何系统能保证绝对安全。

6. 保存与删除
账号有效期间，您的信息会被保存。您可通过“客服支持”申请删除账号和数据。部分数据可能依法保留一段时间。

7. 儿童
本应用不面向13岁以下人群。

8. 政策变更
本政策可能更新。继续使用即表示接受新版本。

联系方式：应用内“客服支持”
pawpet 隐私政策结束''';
