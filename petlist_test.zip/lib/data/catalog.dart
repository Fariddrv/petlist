import '../l10n.dart';

class Species {
  final String id, emoji, fa, en, zh;
  const Species(this.id, this.emoji, this.fa, this.en, this.zh);
  String name(AppLang l) => switch (l) {
        AppLang.fa => fa,
        AppLang.en => en,
        AppLang.zh => zh,
      };
}

const List<Species> speciesList = [
  Species('dog', '🐕', 'سگ', 'Dog', '狗'),
  Species('cat', '🐈', 'گربه', 'Cat', '猫'),
  Species('parrot', '🦜', 'طوطی', 'Parrot', '鹦鹉'),
  Species('rabbit', '🐇', 'خرگوش', 'Rabbit', '兔子'),
  Species('hamster', '🐹', 'همستر', 'Hamster', '仓鼠'),
  Species('guinea_pig', '🐹', 'خوکچه‌هندی', 'Guinea pig', '豚鼠'),
  Species('fish', '🐟', 'ماهی', 'Fish', '鱼'),
  Species('goldfish', '🐠', 'ماهی قرمز', 'Goldfish', '金鱼'),
  Species('betta', '🐡', 'ماهی جنگجو', 'Betta fish', '斗鱼'),
  Species('turtle', '🐢', 'لاک‌پشت', 'Turtle', '乌龟'),
  Species('tortoise', '🐢', 'لاک‌پشت خشکی', 'Tortoise', '陆龟'),
  Species('canary', '🐤', 'قناری', 'Canary', '金丝雀'),
  Species('budgie', '🦜', 'مرغ عشق', 'Budgie', '虎皮鹦鹉'),
  Species('lovebird', '🦜', 'برزیلی', 'Lovebird', '爱情鸟'),
  Species('cockatiel', '🦜', 'کاکادو کوچک', 'Cockatiel', '玄凤鹦鹉'),
  Species('cockatoo', '🦜', 'کاکادو', 'Cockatoo', '凤头鹦鹉'),
  Species('macaw', '🦜', 'ماکائو', 'Macaw', '金刚鹦鹉'),
  Species('finch', '🐦', 'فنچ', 'Finch', '雀'),
  Species('pigeon', '🕊️', 'کبوتر', 'Pigeon', '鸽子'),
  Species('chicken', '🐔', 'مرغ', 'Chicken', '鸡'),
  Species('duck', '🦆', 'اردک', 'Duck', '鸭'),
  Species('goose', '🪿', 'غاز', 'Goose', '鹅'),
  Species('quail', '🐦', 'بلدرچین', 'Quail', '鹌鹑'),
  Species('horse', '🐎', 'اسب', 'Horse', '马'),
  Species('pony', '🐴', 'پونی', 'Pony', '矮种马'),
  Species('donkey', '🫏', 'الاغ', 'Donkey', '驴'),
  Species('goat', '🐐', 'بز', 'Goat', '山羊'),
  Species('sheep', '🐑', 'گوسفند', 'Sheep', '绵羊'),
  Species('cow', '🐄', 'گاو', 'Cow', '牛'),
  Species('pig', '🐖', 'خوک', 'Pig', '猪'),
  Species('ferret', '🦦', 'راسو خانگی', 'Ferret', '雪貂'),
  Species('chinchilla', '🐭', 'چین‌چیلا', 'Chinchilla', '毛丝鼠'),
  Species('hedgehog', '🦔', 'جوجه‌تیغی', 'Hedgehog', '刺猬'),
  Species('gerbil', '🐭', 'جربیل', 'Gerbil', '沙鼠'),
  Species('mouse', '🐁', 'موش', 'Mouse', '老鼠'),
  Species('rat', '🐀', 'رت', 'Rat', '大鼠'),
  Species('sugar_glider', '🐿️', 'سنجاب پرنده', 'Sugar glider', '蜜袋鼯'),
  Species('squirrel', '🐿️', 'سنجاب', 'Squirrel', '松鼠'),
  Species('snake', '🐍', 'مار', 'Snake', '蛇'),
  Species('lizard', '🦎', 'مارمولک', 'Lizard', '蜥蜴'),
  Species('gecko', '🦎', 'گکو', 'Gecko', '壁虎'),
  Species('iguana', '🦎', 'ایگوانا', 'Iguana', '鬣蜥'),
  Species('chameleon', '🦎', 'آفتاب‌پرست', 'Chameleon', '变色龙'),
  Species('frog', '🐸', 'قورباغه', 'Frog', '青蛙'),
  Species('axolotl', '🦎', 'آکسولوتل', 'Axolotl', '美西螈'),
  Species('tarantula', '🕷️', 'رتیل', 'Tarantula', '狼蛛'),
  Species('hermit_crab', '🦀', 'خرچنگ ندانم‌کار', 'Hermit crab', '寄居蟹'),
  Species('other', '🐾', 'سایر', 'Other', '其他'),
];

Species speciesOf(String id) => speciesList.firstWhere(
      (s) => s.id == id,
      orElse: () => speciesList.last,
    );
