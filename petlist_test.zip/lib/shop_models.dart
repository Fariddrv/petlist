/// فروشگاه یک فروشنده.
class Shop {
  final String id;
  final String ownerId;
  final String name;
  final String description;
  final String? logoUrl;
  final String phone;
  final String email;
  final String address;
  final String country;
  final String city;
  final List<String> types;
  final String contactFirst;
  final String contactLast;
  final String status; // pending | approved | rejected | suspended
  final bool verified;
  final String? rejectionReason;
  final String plan;

  const Shop({
    required this.id,
    required this.ownerId,
    required this.name,
    this.description = '',
    this.logoUrl,
    this.phone = '',
    this.email = '',
    this.address = '',
    this.country = '',
    this.city = '',
    this.types = const [],
    this.contactFirst = '',
    this.contactLast = '',
    this.status = 'pending',
    this.verified = false,
    this.rejectionReason,
    this.plan = 'trial',
  });

  bool get approved => status == 'approved';

  factory Shop.fromRow(Map<String, dynamic> j) => Shop(
        id: j['id'].toString(),
        ownerId: j['owner_id'].toString(),
        name: (j['name'] ?? '').toString(),
        description: (j['description'] ?? '').toString(),
        logoUrl: j['logo_url'] as String?,
        phone: (j['phone'] ?? '').toString(),
        email: (j['email'] ?? '').toString(),
        address: (j['address'] ?? '').toString(),
        country: (j['country'] ?? '').toString(),
        city: (j['city'] ?? '').toString(),
        types: j['service_keys'] is List
            ? (j['service_keys'] as List).map((e) => e.toString()).toList()
            : <String>[],
        contactFirst: (j['contact_first'] ?? '').toString(),
        contactLast: (j['contact_last'] ?? '').toString(),
        status: (j['status'] ?? 'pending').toString(),
        verified: (j['verified'] ?? false) as bool,
        rejectionReason: j['rejection_reason'] as String?,
        plan: (j['plan'] ?? 'trial').toString(),
      );
}

/// یک محصول یا خدمت.
class Listing {
  final String id;
  final String shopId;
  final String kind; // product | service
  final String categoryKey;
  final String title;
  final String description;
  final int priceMinor;
  final String currency;
  final int? stock;
  final int? durationMin;
  final List<String> images;
  final String country;
  final String city;
  final bool active;
  // اطلاعات فروشگاه (برای نمایش در کارت)
  final String shopName;
  final String? shopLogo;
  final bool shopVerified;
  final String shopOwnerId;

  const Listing({
    required this.id,
    required this.shopId,
    required this.kind,
    required this.categoryKey,
    required this.title,
    this.description = '',
    required this.priceMinor,
    required this.currency,
    this.stock,
    this.durationMin,
    this.images = const [],
    this.country = '',
    this.city = '',
    this.active = true,
    this.shopName = '',
    this.shopLogo,
    this.shopVerified = false,
    this.shopOwnerId = '',
  });

  bool get isService => kind == 'service';
  bool get soldOut => !isService && stock != null && stock! <= 0;

  factory Listing.fromRow(Map<String, dynamic> j) {
    final sh = j['shops'] is Map ? j['shops'] as Map : const {};
    return Listing(
      id: j['id'].toString(),
      shopId: j['shop_id'].toString(),
      kind: (j['kind'] ?? 'product').toString(),
      categoryKey: (j['category_key'] ?? '').toString(),
      title: (j['title'] ?? '').toString(),
      description: (j['description'] ?? '').toString(),
      priceMinor: (j['price_minor'] as num?)?.toInt() ?? 0,
      currency: (j['currency'] ?? 'USD').toString(),
      stock: (j['stock'] as num?)?.toInt(),
      durationMin: (j['duration_min'] as num?)?.toInt(),
      images: j['images'] is List
          ? (j['images'] as List).map((e) => e.toString()).toList()
          : <String>[],
      country: (j['country'] ?? '').toString(),
      city: (j['city'] ?? '').toString(),
      active: (j['active'] ?? true) as bool,
      shopName: (sh['name'] ?? '').toString(),
      shopLogo: sh['logo_url'] as String?,
      shopVerified: (sh['verified'] ?? false) as bool,
      shopOwnerId: (sh['owner_id'] ?? '').toString(),
    );
  }
}
