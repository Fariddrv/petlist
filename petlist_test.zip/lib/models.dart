import 'l10n.dart';

/// متنی که برای هر سه زبان ترجمه دارد.
class LocalizedText {
  final String fa, en, zh;
  const LocalizedText(this.fa, this.en, this.zh);
  String of(AppLang l) => switch (l) {
        AppLang.fa => fa,
        AppLang.en => en,
        AppLang.zh => zh,
      };
}

/// یک واکسن ثبت‌شده برای حیوان (تاریخ به‌صورت میلادی yyyy-MM-dd ذخیره می‌شود).
class PetVaccine {
  final String name;
  final String date;
  const PetVaccine(this.name, this.date);

  Map<String, dynamic> toJson() => {'name': name, 'date': date};

  factory PetVaccine.fromJson(Map<String, dynamic> j) =>
      PetVaccine((j['name'] ?? '').toString(), (j['date'] ?? '').toString());

  DateTime? get dateTime => DateTime.tryParse(date);
}

/// شناسنامه‌ی یک حیوان خانگی.
class Pet {
  final String id;
  final String name;
  final String species; // شناسه‌ی نوع حیوان از data/catalog.dart
  final int age;
  final String gender; // m | f | ''
  final String birth; // تاریخ تولد میلادی yyyy-MM-dd یا ''
  final String notes;
  final List<PetVaccine> vaccines;
  final String? photoPath; // آدرس عکس (سرور) یا مسیر فایل محلی هنگام ویرایش
  final String ownerId;

  const Pet({
    required this.id,
    required this.name,
    required this.species,
    required this.age,
    this.gender = '',
    this.birth = '',
    this.notes = '',
    this.vaccines = const [],
    this.photoPath,
    this.ownerId = '',
  });

  /// تصویر پیش‌فرض بر اساس نوع حیوان.
  String get image => switch (species) {
        'dog' => 'assets/pets/pet_dog.jpg',
        'cat' => 'assets/pets/pet_cat.jpg',
        _ => 'assets/pets/pet_other.jpg',
      };

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'species': species,
        'age': age,
        'gender': gender,
        'birth': birth,
        'notes': notes,
        'vaccines': vaccines.map((v) => v.toJson()).toList(),
        'photoPath': photoPath,
        'ownerId': ownerId,
      };

  factory Pet.fromJson(Map<String, dynamic> j) => Pet(
        id: (j['id'] ?? '').toString(),
        name: (j['name'] ?? '') as String,
        species: (j['species'] ?? j['kind'] ?? 'other').toString(),
        age: (j['age'] as num?)?.toInt() ?? 0,
        gender: (j['gender'] ?? '').toString(),
        birth: (j['birth'] ?? '').toString(),
        notes: (j['notes'] ?? '').toString(),
        vaccines: ((j['vaccines'] as List?) ?? const [])
            .map((e) => PetVaccine.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
        photoPath: j['photoPath'] as String?,
        ownerId: (j['ownerId'] ?? '') as String,
      );
}

class Post {
  final LocalizedText title;
  final String author;
  final String avatar; // تصویر آواتار
  final String image;  // تصویر اصلی پست
  final int likes;
  const Post(this.title, this.author, this.avatar, this.image, this.likes);
}

class EventItem {
  final LocalizedText title;
  final LocalizedText date;
  final String image;
  const EventItem(this.title, this.date, this.image);
}

class Product {
  final LocalizedText title;
  final int price;
  final String image;
  const Product(this.title, this.price, this.image);
}

/// داده‌های نمونه برای فید (بعداً با داده‌ی واقعی کاربران جایگزین می‌شود).
const List<Post> samplePosts = [
  Post(
    LocalizedText(
      'بسی امروز اولین بار پارک رفت!',
      'Basie went to the park for the first time today!',
      '巴塞今天第一次去公园！',
    ),
    'Sara',
    'assets/avatars/avatar_sara.jpg',
    'assets/posts/post_park.jpg',
    24,
  ),
  Post(
    LocalizedText(
      'گربه‌ام عاشق این جعبه شد 📦',
      'My cat fell in love with this box 📦',
      '我的猫爱上了这个盒子 📦',
    ),
    'Ali',
    'assets/avatars/avatar_ali.jpg',
    'assets/posts/post_box.jpg',
    41,
  ),
  Post(
    LocalizedText(
      'طوطی کیان یک حرف جدید یاد گرفت!',
      'Kian the parrot learned a new word!',
      '鹦鹉基安学会了新词！',
    ),
    'Mina',
    'assets/avatars/avatar_mina.jpg',
    'assets/posts/post_parrot.jpg',
    17,
  ),
];

/// ایونت‌های نمونه (فاز بعدی: ساخت ایونت توسط کاربران).
const List<EventItem> sampleEvents = [
  EventItem(
    LocalizedText('پیاده‌روی جمعه پارک لاله', 'Friday walk at Laleh Park', '周五拉莱公园散步'),
    LocalizedText('جمعه ۱۰ مهر', 'Fri, Oct 2', '10月2日 周五'),
    'assets/events/event_park.jpg',
  ),
  EventItem(
    LocalizedText('کارگاه نگهداری از گربه', 'Cat care workshop', '猫咪护理工作坊'),
    LocalizedText('شنبه ۱۸ مهر', 'Sat, Oct 10', '10月10日 周六'),
    'assets/events/event_care.jpg',
  ),
  EventItem(
    LocalizedText('جشنواره‌ی پت‌های تهران', 'Tehran pets festival', '德黑兰宠物节'),
    LocalizedText('پنجشنبه ۳۰ مهر', 'Thu, Oct 22', '10月22日 周四'),
    'assets/events/event_festival.jpg',
  ),
];

/// محصولات نمونه‌ی فروشگاه (فاز بعدی: فروشندگان واقعی).
const List<Product> sampleProducts = [
  Product(LocalizedText('غذای خشک سگ ۲ کیلویی', 'Dry dog food 2kg', '狗粮 2公斤'),
      450000, 'assets/products/product_dogfood.jpg'),
  Product(LocalizedText('خاک گربه ۵ لیتری', 'Cat litter 5L', '猫砂 5升'),
      180000, 'assets/products/product_litter.jpg'),
  Product(LocalizedText('اسباب‌بازی جویدنی', 'Chew toy', '咀嚼玩具'),
      95000, 'assets/products/product_toy.jpg'),
  Product(LocalizedText('قلاده‌ی چراغ‌دار', 'LED collar', '发光项圈'),
      220000, 'assets/products/product_collar.jpg'),
];


/// پستی که خود کاربر می‌سازد (متن + عکس اختیاری از گالری).
class UserPost {
  final String id;
  final String author;
  final String text;
  final String? imagePath; // مسیر عکس انتخاب‌شده روی گوشی
  final int likes;
  final String ownerId;
  final String? authorAvatar;
  final int createdAt; // میلی‌ثانیه (۰ یعنی نامشخص)
  final String mediaType; // image | video

  const UserPost({
    required this.id,
    required this.author,
    required this.text,
    this.imagePath,
    this.likes = 0,
    this.ownerId = '',
    this.authorAvatar,
    this.createdAt = 0,
    this.mediaType = 'image',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'author': author,
        'text': text,
        'imagePath': imagePath,
        'likes': likes,
        'ownerId': ownerId,
      };

  factory UserPost.fromJson(Map<String, dynamic> j) => UserPost(
        id: (j['id'] ?? '') as String,
        author: (j['author'] ?? '') as String,
        text: (j['text'] ?? '') as String,
        imagePath: j['imagePath'] as String?,
        likes: (j['likes'] as num?)?.toInt() ?? 0,
        ownerId: (j['ownerId'] ?? '') as String,
      );
}


/// یک نظر روی پست.
class Comment {
  final String id;
  final String author;
  final String text;
  final int createdAt; // میلی‌ثانیه
  final String? parentId; // اگر پاسخ به نظر دیگری باشد
  final String userId;
  final int likes;
  final bool liked;

  const Comment({
    required this.id,
    required this.author,
    required this.text,
    required this.createdAt,
    this.parentId,
    this.userId = '',
    this.likes = 0,
    this.liked = false,
  });

  Comment copyWith({int? likes, bool? liked}) => Comment(
        id: id,
        author: author,
        text: text,
        createdAt: createdAt,
        parentId: parentId,
        userId: userId,
        likes: likes ?? this.likes,
        liked: liked ?? this.liked,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'author': author,
        'text': text,
        'createdAt': createdAt,
        'parentId': parentId,
      };

  factory Comment.fromJson(Map<String, dynamic> j) => Comment(
        id: (j['id'] ?? '') as String,
        author: (j['author'] ?? '') as String,
        text: (j['text'] ?? '') as String,
        createdAt: (j['createdAt'] as num?)?.toInt() ?? 0,
        parentId: j['parentId'] as String?,
      );
}


/// وضعیت تعامل کاربر با یک پست (لایک/ذخیره/نظرات).
class PostInter {
  final bool liked;
  final bool saved;
  final List<Comment> comments;

  const PostInter({
    this.liked = false,
    this.saved = false,
    this.comments = const [],
  });

  PostInter copyWith({bool? liked, bool? saved, List<Comment>? comments}) =>
      PostInter(
        liked: liked ?? this.liked,
        saved: saved ?? this.saved,
        comments: comments ?? this.comments,
      );

  Map<String, dynamic> toJson() => {
        'liked': liked,
        'saved': saved,
        'comments': comments.map((c) => c.toJson()).toList(),
      };

  factory PostInter.fromJson(Map<String, dynamic> j) => PostInter(
        liked: (j['liked'] ?? false) as bool,
        saved: (j['saved'] ?? false) as bool,
        comments: ((j['comments'] as List?) ?? [])
            .map((e) => Comment.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );
}


/// رویدادی که یک کاربر ثبت کرده است.
class AppEvent {
  final String id;
  final String ownerId;
  final String title;
  final String description;
  final String? imageUrl;
  final DateTime date;
  final String country;
  final String city;
  final int createdAt;
  final int participants;
  final bool joined;
  final int likes; // کل لایک‌ها (شامل لایک خودم)
  final bool liked;

  const AppEvent({
    required this.id,
    required this.ownerId,
    required this.title,
    required this.description,
    required this.date,
    this.imageUrl,
    this.country = '',
    this.city = '',
    this.createdAt = 0,
    this.participants = 0,
    this.joined = false,
    this.likes = 0,
    this.liked = false,
  });

  AppEvent copyWith({int? participants, bool? joined, int? likes, bool? liked}) =>
      AppEvent(
        id: id,
        ownerId: ownerId,
        title: title,
        description: description,
        date: date,
        imageUrl: imageUrl,
        country: country,
        city: city,
        createdAt: createdAt,
        participants: participants ?? this.participants,
        joined: joined ?? this.joined,
        likes: likes ?? this.likes,
        liked: liked ?? this.liked,
      );
}
