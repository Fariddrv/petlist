import 'l10n.dart';

/// متنی که برای هر سه زبان ترجمه دارد.
class LocalizedText {
  final String fa, en, zh;
  const LocalizedText(this.fa, this.en, this.zh);
  String of(AppLang l) => switch (l) {
        AppLang.fa => fa,
        AppLang.en => en,
        AppLang.zh => zh,
      };
}

enum PetKind { cat, dog, other }

extension PetKindInfo on PetKind {
  String get emoji => switch (this) {
        PetKind.cat => '🐈',
        PetKind.dog => '🐕',
        PetKind.other => '🐾',
      };

  /// تصویر باکیفیت مربوط به هر نوع پت.
  String get image => switch (this) {
        PetKind.cat => 'assets/pets/pet_cat.jpg',
        PetKind.dog => 'assets/pets/pet_dog.jpg',
        PetKind.other => 'assets/pets/pet_other.jpg',
      };
}

/// یک پت ثبت‌شده توسط کاربر.
class Pet {
  final String name;
  final PetKind kind;
  final int age;
  const Pet({required this.name, required this.kind, required this.age});

  /// برای ذخیره‌ی دائمی روی گوشی.
  Map<String, dynamic> toJson() =>
      {'name': name, 'kind': kind.name, 'age': age};

  factory Pet.fromJson(Map<String, dynamic> j) => Pet(
        name: (j['name'] ?? '') as String,
        kind: PetKind.values.firstWhere(
          (k) => k.name == j['kind'],
          orElse: () => PetKind.other,
        ),
        age: (j['age'] as num?)?.toInt() ?? 0,
      );
}

class Post {
  final LocalizedText title;
  final String author;
  final String avatar; // تصویر آواتار
  final String image;  // تصویر اصلی پست
  final int likes;
  const Post(this.title, this.author, this.avatar, this.image, this.likes);
}

class EventItem {
  final LocalizedText title;
  final LocalizedText date;
  final String image;
  const EventItem(this.title, this.date, this.image);
}

class Product {
  final LocalizedText title;
  final int price;
  final String image;
  const Product(this.title, this.price, this.image);
}

/// داده‌های نمونه برای فید (بعداً با داده‌ی واقعی کاربران جایگزین می‌شود).
const List<Post> samplePosts = [
  Post(
    LocalizedText(
      'بسی امروز اولین بار پارک رفت!',
      'Basie went to the park for the first time today!',
      '巴塞今天第一次去公园！',
    ),
    'Sara',
    'assets/avatars/avatar_sara.jpg',
    'assets/posts/post_park.jpg',
    24,
  ),
  Post(
    LocalizedText(
      'گربه‌ام عاشق این جعبه شد 📦',
      'My cat fell in love with this box 📦',
      '我的猫爱上了这个盒子 📦',
    ),
    'Ali',
    'assets/avatars/avatar_ali.jpg',
    'assets/posts/post_box.jpg',
    41,
  ),
  Post(
    LocalizedText(
      'طوطی کیان یک حرف جدید یاد گرفت!',
      'Kian the parrot learned a new word!',
      '鹦鹉基安学会了新词！',
    ),
    'Mina',
    'assets/avatars/avatar_mina.jpg',
    'assets/posts/post_parrot.jpg',
    17,
  ),
];

/// ایونت‌های نمونه (فاز بعدی: ساخت ایونت توسط کاربران).
const List<EventItem> sampleEvents = [
  EventItem(
    LocalizedText('پیاده‌روی جمعه پارک لاله', 'Friday walk at Laleh Park', '周五拉莱公园散步'),
    LocalizedText('جمعه ۱۰ مهر', 'Fri, Oct 2', '10月2日 周五'),
    'assets/events/event_park.jpg',
  ),
  EventItem(
    LocalizedText('کارگاه نگهداری از گربه', 'Cat care workshop', '猫咪护理工作坊'),
    LocalizedText('شنبه ۱۸ مهر', 'Sat, Oct 10', '10月10日 周六'),
    'assets/events/event_care.jpg',
  ),
  EventItem(
    LocalizedText('جشنواره‌ی پت‌های تهران', 'Tehran pets festival', '德黑兰宠物节'),
    LocalizedText('پنجشنبه ۳۰ مهر', 'Thu, Oct 22', '10月22日 周四'),
    'assets/events/event_festival.jpg',
  ),
];

/// محصولات نمونه‌ی فروشگاه (فاز بعدی: فروشندگان واقعی).
const List<Product> sampleProducts = [
  Product(LocalizedText('غذای خشک سگ ۲ کیلویی', 'Dry dog food 2kg', '狗粮 2公斤'),
      450000, 'assets/products/product_dogfood.jpg'),
  Product(LocalizedText('خاک گربه ۵ لیتری', 'Cat litter 5L', '猫砂 5升'),
      180000, 'assets/products/product_litter.jpg'),
  Product(LocalizedText('اسباب‌بازی جویدنی', 'Chew toy', '咀嚼玩具'),
      95000, 'assets/products/product_toy.jpg'),
  Product(LocalizedText('قلاده‌ی چراغ‌دار', 'LED collar', '发光项圈'),
      220000, 'assets/products/product_collar.jpg'),
];
