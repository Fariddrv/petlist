import 'package:flutter/material.dart';

/// سه رنگ اصلی برند «پت‌لیست» (همین‌ها در لوگو هم استفاده می‌شوند).
///   ۱) بنفش   ۲) زرد   ۳) خاکستری (رنگ بی‌طرف/خنثی)
class BrandColors {
  static const Color purple = Color(0xFF7C5CFF); // رنگ اصلی
  static const Color yellow = Color(0xFFFFC12E); // رنگ مکمل
  static const Color gray   = Color(0xFF6B7280); // رنگ خنثی
}

/// پالت رنگی و استایل‌های مشترک اپلیکیشن پت‌لیست.
class AppPal {
  // پس‌زمینه‌های خنثی (خانواده‌ی خاکستری)
  static const Color bg = Color(0xFFF5F6FA);
  static const Color surface = Colors.white;
  static const Color graySoft = Color(0xFF9CA3AF);

  // سه رنگ اصلی
  static const Color purple = BrandColors.purple;
  static const Color purpleDark = Color(0xFF6244E0);
  static const Color yellow = BrandColors.yellow;
  static const Color yellowDark = Color(0xFF9A6B00);
  static const Color gray = BrandColors.gray;
  static const Color grayDark = Color(0xFF4B5563);

  static const Color ink = Color(0xFF2B2B33);
  static const Color inkSoft = Color(0xFF6B7280);

  // گرادیان‌ها فقط از سه رنگ اصلی ساخته شده‌اند.
  static const LinearGradient purpleGradient = LinearGradient(
    colors: [BrandColors.purple, Color(0xFF9E86FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient yellowGradient = LinearGradient(
    colors: [BrandColors.yellow, Color(0xFFFFD976)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient grayGradient = LinearGradient(
    colors: [BrandColors.gray, Color(0xFF9CA3AF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  /// گرادیان کامل برند: هر سه رنگ در یک نگاه.
  static const LinearGradient brandGradient = LinearGradient(
    colors: [BrandColors.purple, BrandColors.yellow, BrandColors.gray],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const List<LinearGradient> avatarGradients = [
    purpleGradient,
    yellowGradient,
    grayGradient,
  ];

  /// کارت سفید گرد با سایه‌ی نرم.
  static BoxDecoration softCard() => BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0x14000000)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F000000),
            blurRadius: 16,
            offset: Offset(0, 6),
          ),
        ],
      );

  /// دایره‌ی گرادیانی برای آواتار/ایموجی.
  static Widget gradientCircle({
    required LinearGradient gradient,
    required Widget child,
    double size = 48,
  }) =>
      Container(
        width: size,
        height: size,
        decoration: BoxDecoration(gradient: gradient, shape: BoxShape.circle),
        alignment: Alignment.center,
        child: child,
      );

  /// بنر گرادیانی بالای هر صفحه.
  static Widget gradientBanner({
    required LinearGradient gradient,
    required List<Widget> children,
    Color shadow = const Color(0x337C5CFF),
  }) =>
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(color: shadow, blurRadius: 18, offset: const Offset(0, 8)),
          ],
        ),
        child: Column(children: children),
      );
}
