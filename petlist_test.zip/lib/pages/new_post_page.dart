import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';
import '../data/media.dart';
import 'package:video_compress/video_compress.dart';

import '../i18n2.dart';

/// صفحه‌ی ساخت پست جدید: متن + عکس از گالری.
class NewPostPage extends StatefulWidget {
  final AppLang lang;
  final String defaultAuthor;
  const NewPostPage({
    super.key,
    required this.lang,
    required this.defaultAuthor,
  });

  @override
  State<NewPostPage> createState() => _NewPostPageState();
}

class _NewPostPageState extends State<NewPostPage> {
  final TextEditingController _text = TextEditingController();
  final TextEditingController _author = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  String? _imagePath;
  String? _thumbPath;
  bool _isVideo = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _author.text = widget.defaultAuthor;
  }

  @override
  void dispose() {
    _text.dispose();
    _author.dispose();
    super.dispose();
  }

  void _chooseMedia() {
    final l = widget.lang;
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Text(tr(l, 'pickMedia'),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          for (final o in [
            ('photoGallery', Icons.photo_library_outlined, false, ImageSource.gallery),
            ('photoCamera', Icons.photo_camera_outlined, false, ImageSource.camera),
            ('videoGallery', Icons.video_library_outlined, true, ImageSource.gallery),
            ('videoCamera', Icons.videocam_outlined, true, ImageSource.camera),
          ])
            ListTile(
              leading: Icon(o.$2, color: AppPal.purple),
              title: Text(tr(l, o.$1)),
              onTap: () {
                Navigator.pop(ctx);
                _pick(o.$3, o.$4);
              },
            ),
        ]),
      ),
    );
  }

  void _snack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg)));

  /// ویدئو را بررسی (حداکثر ۱:۳۰)، فشرده و برایش کاور می‌سازد.
  Future<void> _prepareVideo(String path) async {
    final l = widget.lang;
    final info = await VideoCompress.getMediaInfo(path);
    final ms = info.duration ?? 0;
    if (ms > 90 * 1000 + 500) {
      if (mounted) _snack(tr(l, 'videoTooLong'));
      return;
    }
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        content: Row(children: [
          const SizedBox(
              width: 26,
              height: 26,
              child: CircularProgressIndicator(strokeWidth: 3)),
          const SizedBox(width: 16),
          Expanded(child: Text(tr(l, 'compressing'))),
        ]),
      ),
    );
    String finalPath = path;
    String? thumb;
    try {
      final out = await VideoCompress.compressVideo(
        path,
        quality: VideoQuality.MediumQuality,
        deleteOrigin: false,
        includeAudio: true,
      );
      final f = out?.file;
      if (f != null) finalPath = f.path;
      try {
        final th = await VideoCompress.getFileThumbnail(finalPath,
            quality: 60, position: -1);
        thumb = th.path;
      } catch (_) {}
    } catch (_) {
      // اگر فشرده‌سازی شکست خورد، با فایل اصلی ادامه می‌دهیم
    }
    if (mounted) Navigator.of(context, rootNavigator: true).pop();
    final size = await File(finalPath).length();
    if (size > 48 * 1024 * 1024) {
      if (mounted) _snack(tr(l, 'videoStillBig'));
      return;
    }
    if (!mounted) return;
    setState(() {
      _imagePath = finalPath;
      _thumbPath = thumb;
      _isVideo = true;
    });
  }

  Future<void> _pick(bool video, ImageSource src) async {
    final t = L10n.of(widget.lang);
    try {
      final XFile? file = video
          ? await _picker.pickVideo(
              source: src, maxDuration: const Duration(seconds: 90))
          : await _picker.pickImage(
              source: src, imageQuality: 85, maxWidth: 1600);
      if (file == null) return;
      if (video) {
        await _prepareVideo(file.path);
        return;
      }
      final saved = await persistImage(file.path);
      if (!mounted) return;
      setState(() {
        _imagePath = saved;
        _thumbPath = null;
        _isVideo = false;
      });
    } catch (e) {
      if (!mounted) return;
      final msg = e.toString().replaceAll('PlatformException(', '').replaceAll(')', '');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.pickFailed} [$msg]')),
      );
    }
  }

  void _publish() {
    final t = L10n.of(widget.lang);
    final text = _text.text.trim();
    if (text.isEmpty && _imagePath == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(t.writeSomething)));
      return;
    }
    final post = UserPost(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      author: _author.text.trim().isEmpty ? 'Me' : _author.text.trim(),
      text: text,
      imagePath: _imagePath,
      mediaType: _isVideo ? 'video' : 'image',
      thumbUrl: _isVideo ? _thumbPath : null,
    );
    Navigator.pop(context, post);
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return Scaffold(
      appBar: AppBar(
        title: Text(t.newPostTitle),
        backgroundColor: AppPal.purple,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // پیش‌نمایش عکس انتخاب‌شده
          GestureDetector(
            onTap: _chooseMedia,
            child: Container(
              height: 220,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14000000)),
                boxShadow: const [
                  BoxShadow(
                      color: Color(0x0F000000),
                      blurRadius: 16,
                      offset: Offset(0, 6)),
                ],
              ),
              clipBehavior: Clip.antiAlias,
              child: _imagePath == null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.add_photo_alternate_outlined,
                            size: 46, color: AppPal.purple),
                        const SizedBox(height: 10),
                        Text(
                          t.addPhoto,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              color: AppPal.inkSoft),
                        ),
                      ],
                    )
                  : Stack(
                      fit: StackFit.expand,
                      children: [
                        _isVideo
                            ? Stack(fit: StackFit.expand, children: [
                                if (_thumbPath != null)
                                  Image.file(File(_thumbPath!),
                                      fit: BoxFit.cover)
                                else
                                  Container(color: const Color(0xFF1B1B26)),
                                const Center(
                                  child: Icon(Icons.play_circle_fill,
                                      size: 64, color: Colors.white70),
                                ),
                              ])
                            : Image.file(File(_imagePath!), fit: BoxFit.cover),
                        Positioned(
                          bottom: 8,
                          left: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.edit,
                                    size: 15, color: Colors.white),
                                const SizedBox(width: 5),
                                Text(
                                  t.changePhoto,
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _author,
            decoration: InputDecoration(
              labelText: t.yourName,
              hintText: t.yourNameHint,
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _text,
            minLines: 4,
            maxLines: 8,
            decoration: InputDecoration(
              hintText: t.postTextHint,
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _busy ? null : _publish,
              style: FilledButton.styleFrom(
                backgroundColor: AppPal.purple,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              icon: const Icon(Icons.send),
              label: Text(
                t.publish,
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w800),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
