import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';

/// صفحه‌ی ساخت پست جدید: متن + عکس از گالری.
class NewPostPage extends StatefulWidget {
  final AppLang lang;
  final String defaultAuthor;
  const NewPostPage({
    super.key,
    required this.lang,
    required this.defaultAuthor,
  });

  @override
  State<NewPostPage> createState() => _NewPostPageState();
}

class _NewPostPageState extends State<NewPostPage> {
  final TextEditingController _text = TextEditingController();
  final TextEditingController _author = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  String? _imagePath;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _author.text = widget.defaultAuthor;
  }

  @override
  void dispose() {
    _text.dispose();
    _author.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final t = L10n.of(widget.lang);
    try {
      final XFile? file = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
        maxWidth: 1600,
      );
      if (file == null) return;
      setState(() => _imagePath = file.path);
    } catch (e) {
      if (!mounted) return;
      final msg = e.toString().replaceAll('PlatformException(', '').replaceAll(')', '');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.pickFailed} [$msg]')),
      );
    }
  }

  void _publish() {
    final t = L10n.of(widget.lang);
    final text = _text.text.trim();
    if (text.isEmpty && _imagePath == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(t.writeSomething)));
      return;
    }
    final post = UserPost(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      author: _author.text.trim().isEmpty ? 'Me' : _author.text.trim(),
      text: text,
      imagePath: _imagePath,
    );
    Navigator.pop(context, post);
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return Scaffold(
      appBar: AppBar(
        title: Text(t.newPostTitle),
        backgroundColor: AppPal.purple,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // پیش‌نمایش عکس انتخاب‌شده
          GestureDetector(
            onTap: _pickImage,
            child: Container(
              height: 220,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14000000)),
                boxShadow: const [
                  BoxShadow(
                      color: Color(0x0F000000),
                      blurRadius: 16,
                      offset: Offset(0, 6)),
                ],
              ),
              clipBehavior: Clip.antiAlias,
              child: _imagePath == null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.add_photo_alternate_outlined,
                            size: 46, color: AppPal.purple),
                        const SizedBox(height: 10),
                        Text(
                          t.addPhoto,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              color: AppPal.inkSoft),
                        ),
                      ],
                    )
                  : Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.file(File(_imagePath!), fit: BoxFit.cover),
                        Positioned(
                          bottom: 8,
                          left: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.edit,
                                    size: 15, color: Colors.white),
                                const SizedBox(width: 5),
                                Text(
                                  t.changePhoto,
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _author,
            decoration: InputDecoration(
              labelText: t.yourName,
              hintText: t.yourNameHint,
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _text,
            minLines: 4,
            maxLines: 8,
            decoration: InputDecoration(
              hintText: t.postTextHint,
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _busy ? null : _publish,
              style: FilledButton.styleFrom(
                backgroundColor: AppPal.purple,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              icon: const Icon(Icons.send),
              label: Text(
                t.publish,
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w800),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
