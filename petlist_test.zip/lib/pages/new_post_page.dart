import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';
import '../data/media.dart';
import '../i18n2.dart';

/// صفحه‌ی ساخت پست جدید: متن + عکس از گالری.
class NewPostPage extends StatefulWidget {
  final AppLang lang;
  final String defaultAuthor;
  const NewPostPage({
    super.key,
    required this.lang,
    required this.defaultAuthor,
  });

  @override
  State<NewPostPage> createState() => _NewPostPageState();
}

class _NewPostPageState extends State<NewPostPage> {
  final TextEditingController _text = TextEditingController();
  final TextEditingController _author = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  String? _imagePath;
  bool _isVideo = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _author.text = widget.defaultAuthor;
  }

  @override
  void dispose() {
    _text.dispose();
    _author.dispose();
    super.dispose();
  }

  void _chooseMedia() {
    final l = widget.lang;
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Text(tr(l, 'pickMedia'),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          for (final o in [
            ('photoGallery', Icons.photo_library_outlined, false, ImageSource.gallery),
            ('photoCamera', Icons.photo_camera_outlined, false, ImageSource.camera),
            ('videoGallery', Icons.video_library_outlined, true, ImageSource.gallery),
            ('videoCamera', Icons.videocam_outlined, true, ImageSource.camera),
          ])
            ListTile(
              leading: Icon(o.$2, color: AppPal.purple),
              title: Text(tr(l, o.$1)),
              onTap: () {
                Navigator.pop(ctx);
                _pick(o.$3, o.$4);
              },
            ),
        ]),
      ),
    );
  }

  Future<void> _pick(bool video, ImageSource src) async {
    final t = L10n.of(widget.lang);
    try {
      final XFile? file = video
          ? await _picker.pickVideo(
              source: src, maxDuration: const Duration(minutes: 2))
          : await _picker.pickImage(
              source: src, imageQuality: 85, maxWidth: 1600);
      if (file == null) return;
      if (video) {
        final size = await File(file.path).length();
        if (size > 48 * 1024 * 1024) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(tr(widget.lang, 'videoTooBig'))));
          return;
        }
      }
      final saved = await persistImage(file.path);
      if (!mounted) return;
      setState(() {
        _imagePath = saved;
        _isVideo = video;
      });
    } catch (e) {
      if (!mounted) return;
      final msg = e.toString().replaceAll('PlatformException(', '').replaceAll(')', '');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${t.pickFailed} [$msg]')),
      );
    }
  }

  void _publish() {
    final t = L10n.of(widget.lang);
    final text = _text.text.trim();
    if (text.isEmpty && _imagePath == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(t.writeSomething)));
      return;
    }
    final post = UserPost(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      author: _author.text.trim().isEmpty ? 'Me' : _author.text.trim(),
      text: text,
      imagePath: _imagePath,
      mediaType: _isVideo ? 'video' : 'image',
    );
    Navigator.pop(context, post);
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return Scaffold(
      appBar: AppBar(
        title: Text(t.newPostTitle),
        backgroundColor: AppPal.purple,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // پیش‌نمایش عکس انتخاب‌شده
          GestureDetector(
            onTap: _chooseMedia,
            child: Container(
              height: 220,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14000000)),
                boxShadow: const [
                  BoxShadow(
                      color: Color(0x0F000000),
                      blurRadius: 16,
                      offset: Offset(0, 6)),
                ],
              ),
              clipBehavior: Clip.antiAlias,
              child: _imagePath == null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.add_photo_alternate_outlined,
                            size: 46, color: AppPal.purple),
                        const SizedBox(height: 10),
                        Text(
                          t.addPhoto,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              color: AppPal.inkSoft),
                        ),
                      ],
                    )
                  : Stack(
                      fit: StackFit.expand,
                      children: [
                        _isVideo
                            ? Container(
                                color: const Color(0xFF1B1B26),
                                child: const Center(
                                  child: Icon(Icons.play_circle_fill,
                                      size: 64, color: Colors.white70),
                                ),
                              )
                            : Image.file(File(_imagePath!), fit: BoxFit.cover),
                        Positioned(
                          bottom: 8,
                          left: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.edit,
                                    size: 15, color: Colors.white),
                                const SizedBox(width: 5),
                                Text(
                                  t.changePhoto,
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _author,
            decoration: InputDecoration(
              labelText: t.yourName,
              hintText: t.yourNameHint,
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _text,
            minLines: 4,
            maxLines: 8,
            decoration: InputDecoration(
              hintText: t.postTextHint,
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _busy ? null : _publish,
              style: FilledButton.styleFrom(
                backgroundColor: AppPal.purple,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              icon: const Icon(Icons.send),
              label: Text(
                t.publish,
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w800),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
