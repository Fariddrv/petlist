import 'package:flutter/material.dart';

import '../i18n2.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import 'profile_page.dart';

/// فهرست شرکت‌کنندگان یک رویداد
class ParticipantsPage extends StatelessWidget {
  final AppState s;
  final String eventId;
  const ParticipantsPage({super.key, required this.s, required this.eventId});

  @override
  Widget build(BuildContext context) {
    final l = s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'participantsTitle'))),
      body: FutureBuilder<List<AppUser>>(
        future: s.loadParticipants(eventId),
        builder: (c, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final list = snap.data!;
          if (list.isEmpty) {
            return Center(
                child: Text(tr(l, 'noParticipants'),
                    style: const TextStyle(color: AppPal.inkSoft)));
          }
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (c, i) => const Divider(height: 1, indent: 72),
            itemBuilder: (c, i) {
              final u = list[i];
              return ListTile(
                leading: UserAvatar(user: u, size: 44),
                title: Text(u.username,
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                onTap: u.id == s.meId
                    ? null
                    : () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => ProfilePage(
                                s: s, userId: u.id, standalone: true))),
              );
            },
          );
        },
      ),
    );
  }
}
