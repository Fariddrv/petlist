import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';

/// تب خانه: فید اشتراک پست‌ها (فعلاً نمونه).
class HomePage extends StatefulWidget {
  final AppLang lang;
  const HomePage({super.key, required this.lang});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Set<int> _liked = {};

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppPal.gradientBanner(
          gradient: AppPal.brandGradient,
          children: [
            const Text('🐾', style: TextStyle(fontSize: 34)),
            const SizedBox(height: 8),
            Text(
              t.homeWelcome,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              t.homeWelcomeSub,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.94),
                  fontSize: 13,
                  height: 1.6),
            ),
          ],
        ),
        const SizedBox(height: 16),
        for (var i = 0; i < samplePosts.length; i++)
          _postCard(i, samplePosts[i]),
      ],
    );
  }

  Widget _postCard(int i, Post p) {
    final liked = _liked.contains(i);
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      clipBehavior: Clip.antiAlias,
      decoration: AppPal.softCard(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // تصویر اصلی پست
          AspectRatio(
            aspectRatio: 4 / 3,
            child: Image.asset(p.image, fit: BoxFit.cover),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: Row(
              children: [
                ClipOval(
                  child: Image.asset(p.avatar,
                      width: 44, height: 44, fit: BoxFit.cover),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        p.author,
                        style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 15,
                            color: AppPal.ink),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        p.title.of(widget.lang),
                        style: const TextStyle(
                            color: AppPal.inkSoft, height: 1.5),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 6, bottom: 6),
            child: Row(
              children: [
                IconButton(
                  onPressed: () =>
                      setState(() => liked ? _liked.remove(i) : _liked.add(i)),
                  icon: Icon(
                    liked ? Icons.favorite : Icons.favorite_border,
                    color: liked ? AppPal.purple : AppPal.inkSoft,
                  ),
                ),
                Text(
                  '${p.likes + (liked ? 1 : 0)}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, color: AppPal.inkSoft),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
