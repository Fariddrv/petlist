import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../l10n.dart';
import '../models.dart';
import '../state.dart';
import '../widgets/avatar.dart';
import '../widgets/comments.dart';
import 'post_detail.dart';
import 'profile_page.dart';

/// پخش ویدئو به سبک اینستاگرام: با کشیدن انگشت به بالا/پایین، ویدئوی بعدی/قبلی.
/// در پروفایل فقط ویدئوهای همان شخص، در خانه ویدئوهای فید.
class ReelsPage extends StatefulWidget {
  final AppState s;
  final List<UserPost> posts;
  final String initialId;
  const ReelsPage(
      {super.key, required this.s, required this.posts, required this.initialId});

  @override
  State<ReelsPage> createState() => _ReelsPageState();
}

class _ReelsPageState extends State<ReelsPage> {
  late final PageController _pc;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    final i = widget.posts.indexWhere((p) => p.id == widget.initialId);
    _index = i < 0 ? 0 : i;
    _pc = PageController(initialPage: _index);
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
      ),
      body: PageView.builder(
        scrollDirection: Axis.vertical,
        controller: _pc,
        itemCount: widget.posts.length,
        onPageChanged: (i) => setState(() => _index = i),
        itemBuilder: (c, i) => _ReelItem(
          key: ValueKey(widget.posts[i].id),
          s: widget.s,
          post: widget.posts[i],
          active: i == _index,
        ),
      ),
    );
  }
}

class _ReelItem extends StatefulWidget {
  final AppState s;
  final UserPost post;
  final bool active;
  const _ReelItem(
      {super.key, required this.s, required this.post, required this.active});

  @override
  State<_ReelItem> createState() => _ReelItemState();
}

class _ReelItemState extends State<_ReelItem> {
  VideoPlayerController? _c;
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    final url = widget.post.imagePath;
    if (url == null || url.isEmpty) {
      _failed = true;
      return;
    }
    final c = VideoPlayerController.networkUrl(Uri.parse(url));
    _c = c;
    c.initialize().then((_) {
      if (!mounted) return;
      c.setLooping(true);
      setState(() => _ready = true);
      if (widget.active) c.play();
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
    c.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void didUpdateWidget(covariant _ReelItem old) {
    super.didUpdateWidget(old);
    final c = _c;
    if (c == null || !_ready) return;
    if (widget.active && !old.active) {
      c.play();
    } else if (!widget.active && old.active) {
      c.pause();
    }
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  Widget _action(IconData icon, String label, VoidCallback onTap,
      {Color color = Colors.white}) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Column(children: [
          Icon(icon, color: color, size: 32),
          if (label.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(label,
                  style: const TextStyle(color: Colors.white, fontSize: 12.5)),
            ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final p = widget.post;
    final c = _c;
    final t = L10n.of(s.lang);
    return ListenableBuilder(
      listenable: s,
      builder: (ctx, _) {
        final st = s.inter[p.id];
        final liked = st?.liked ?? false;
        final saved = st?.saved ?? false;
        final likes = p.likes + (liked ? 1 : 0);
        final comments = st?.comments.length ?? 0;
        final owner = s.userById(p.ownerId);
        return Stack(
          fit: StackFit.expand,
          children: [
            // ویدئو
            GestureDetector(
              onTap: () {
                if (c == null || !_ready) return;
                c.value.isPlaying ? c.pause() : c.play();
              },
              child: Container(
                color: Colors.black,
                alignment: Alignment.center,
                child: _failed
                    ? const Icon(Icons.error_outline,
                        color: Colors.white70, size: 48)
                    : !_ready
                        ? const CircularProgressIndicator()
                        : AspectRatio(
                            aspectRatio: c!.value.aspectRatio == 0
                                ? 9 / 16
                                : c.value.aspectRatio,
                            child: VideoPlayer(c),
                          ),
              ),
            ),
            if (_ready && c != null && !c.value.isPlaying)
              const IgnorePointer(
                child: Center(
                  child: Icon(Icons.play_circle_fill,
                      size: 72, color: Colors.white54),
                ),
              ),
            // دکمه‌های کناری
            PositionedDirectional(
              end: 10,
              bottom: 110,
              child: Column(children: [
                _action(liked ? Icons.favorite : Icons.favorite_border,
                    t.num(likes), () => s.toggleLike(p.id),
                    color: liked ? const Color(0xFFFF4D6D) : Colors.white),
                _action(Icons.chat_bubble_outline, t.num(comments),
                    () => showCommentsSheet(context, s, p.id)),
                _action(Icons.send_outlined, '',
                    () => showShareSheet(context, s, p.id)),
                _action(saved ? Icons.bookmark : Icons.bookmark_border, '',
                    () => s.toggleSave(p.id)),
              ]),
            ),
            // نام و توضیح
            PositionedDirectional(
              start: 14,
              end: 80,
              bottom: 58,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  GestureDetector(
                    onTap: () {
                      if (p.ownerId.isEmpty) return;
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProfilePage(
                              s: s, userId: p.ownerId, standalone: true),
                        ),
                      );
                    },
                    child: Row(children: [
                      AvatarCircle(
                          url: owner?.avatarUrl ?? p.authorAvatar,
                          name: p.author,
                          size: 36),
                      const SizedBox(width: 10),
                      Flexible(
                        child: Text(p.author,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                fontSize: 15)),
                      ),
                    ]),
                  ),
                  if (p.text.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(p.text,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white, height: 1.4)),
                    ),
                ],
              ),
            ),
            // نوار پیشرفت (قابل کشیدن برای جلو و عقب بردن)
            if (_ready && c != null)
              PositionedDirectional(
                start: 8,
                end: 8,
                bottom: 14,
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(children: [
                    Text(_fmt(c.value.position),
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 11.5)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: VideoProgressIndicator(
                        c,
                        allowScrubbing: true,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        colors: const VideoProgressColors(
                          playedColor: Colors.white,
                          bufferedColor: Colors.white30,
                          backgroundColor: Colors.white12,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(_fmt(c.value.duration),
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 11.5)),
                  ]),
                ),
              ),
          ],
        );
      },
    );
  }
}
