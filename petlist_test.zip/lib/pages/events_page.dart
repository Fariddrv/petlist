import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';

/// تب ایونت‌ها: لیست نمونه + دکمه‌ی شرکت (فاز بعد: ساخت ایونت توسط کاربران).
class EventsPage extends StatefulWidget {
  final AppLang lang;
  const EventsPage({super.key, required this.lang});

  @override
  State<EventsPage> createState() => _EventsPageState();
}

class _EventsPageState extends State<EventsPage> {
  final Set<int> _joined = {};

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppPal.gradientBanner(
          gradient: AppPal.yellowGradient,
          shadow: const Color(0x33FFC12E),
          children: [
            const Text('🎪', style: TextStyle(fontSize: 32)),
            const SizedBox(height: 8),
            Text(
              t.tabEvents,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 19,
                  fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              t.eventsBanner,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.95),
                  fontSize: 13,
                  height: 1.6),
            ),
          ],
        ),
        const SizedBox(height: 16),
        for (var i = 0; i < sampleEvents.length; i++)
          _eventCard(i, sampleEvents[i]),
      ],
    );
  }

  Widget _eventCard(int i, EventItem e) {
    final t = L10n.of(widget.lang);
    final joined = _joined.contains(i);
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      clipBehavior: Clip.antiAlias,
      decoration: AppPal.softCard(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              AspectRatio(
                aspectRatio: 16 / 9,
                child: Image.asset(e.image, fit: BoxFit.cover),
              ),
              Positioned(
                left: 12,
                top: 12,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.95),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    e.date.of(widget.lang),
                    style: const TextStyle(
                        color: AppPal.purpleDark,
                        fontSize: 12,
                        fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    e.title.of(widget.lang),
                    style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        color: AppPal.ink),
                  ),
                ),
                const SizedBox(width: 8),
                joined
                    ? ElevatedButton(
                        onPressed: () => setState(() => _joined.remove(i)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppPal.purple,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        child: Text(t.eventJoined),
                      )
                    : OutlinedButton(
                        onPressed: () => setState(() => _joined.add(i)),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppPal.purpleDark,
                          side: const BorderSide(color: AppPal.purple),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        child: Text(t.eventJoin),
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
