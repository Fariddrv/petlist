import 'package:flutter/material.dart';

import '../i18n2.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/post_extras.dart';

/// ویرایش پست: متن، موقعیت و تگ دوستان (عکس/ویدئو عوض نمی‌شود).
class EditPostPage extends StatefulWidget {
  final AppState s;
  final UserPost post;
  const EditPostPage({super.key, required this.s, required this.post});

  @override
  State<EditPostPage> createState() => _EditPostPageState();
}

class _EditPostPageState extends State<EditPostPage> {
  late final TextEditingController _text =
      TextEditingController(text: widget.post.text);
  late String _loc = widget.post.locationText ?? '';
  late double? _lat = widget.post.lat;
  late double? _lng = widget.post.lng;
  late List<PostTag> _tags = List.of(widget.post.tags);
  bool _busy = false;

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _pickLoc() async {
    final r = await pickPostLocation(context, widget.s, _loc);
    if (r == null) return;
    setState(() {
      _loc = r.text;
      _lat = r.text.isEmpty ? null : r.lat;
      _lng = r.text.isEmpty ? null : r.lng;
    });
  }

  Future<void> _pickTags() async {
    final r = await pickPostTags(context, widget.s, _tags);
    if (r != null) setState(() => _tags = r);
  }

  Future<void> _save() async {
    final l = widget.s.lang;
    final hasMedia = (widget.post.imagePath ?? '').isNotEmpty;
    if (_text.text.trim().isEmpty && !hasMedia) return;
    setState(() => _busy = true);
    final ok = await widget.s.updatePost(
      widget.post.id,
      text: _text.text,
      locationText: _loc,
      lat: _lat,
      lng: _lng,
      tagIds: _tags.map((t) => t.id).toList(),
    );
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(tr(l, ok ? 'postSaved' : 'errNet'))));
    if (ok) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'editPost'))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        TextField(
          controller: _text,
          minLines: 4,
          maxLines: 10,
          decoration: InputDecoration(labelText: tr(l, 'caption')),
        ),
        const SizedBox(height: 14),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.location_on_outlined, color: AppPal.purple),
          title: Text(_loc.isEmpty ? tr(l, 'addLocation') : _loc),
          trailing: const Icon(Icons.chevron_right),
          onTap: _pickLoc,
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.person_add_alt_1_outlined, color: AppPal.purple),
          title: Text(_tags.isEmpty
              ? tr(l, 'tagFriends')
              : _tags.map((t) => t.name).join('، ')),
          trailing: const Icon(Icons.chevron_right),
          onTap: _pickTags,
        ),
        const SizedBox(height: 18),
        FilledButton(
          onPressed: _busy ? null : _save,
          style: FilledButton.styleFrom(
            backgroundColor: AppPal.purple,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: Text(tr(l, 'save'),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
      ]),
    );
  }
}
