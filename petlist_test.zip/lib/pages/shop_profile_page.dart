import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/places.dart';
import '../data/shop_catalog.dart';
import '../i18n2.dart';
import '../shop_models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/shop_widgets.dart';
import 'listing_detail_page.dart';
import 'messages_page.dart';

/// صفحه‌ی عمومی یک فروشگاه.
class ShopProfilePage extends StatefulWidget {
  final AppState s;
  final String shopId;
  const ShopProfilePage({super.key, required this.s, required this.shopId});

  @override
  State<ShopProfilePage> createState() => _ShopProfilePageState();
}

class _ShopProfilePageState extends State<ShopProfilePage> {
  Shop? _shop;
  List<Listing> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sh = await widget.s.shop.loadShop(widget.shopId);
    final it = await widget.s.shop.shopListings(widget.shopId);
    if (!mounted) return;
    setState(() {
      _shop = sh;
      _items = it;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final l = s.lang;
    final sh = _shop;
    return Scaffold(
      appBar: AppBar(title: Text(sh?.name ?? '')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : sh == null
              ? Center(child: Text(tr(l, 'unavailable')))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Row(children: [
                      ShopLogo(url: sh.logoUrl, name: sh.name, size: 72),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              Flexible(
                                child: Text(sh.name,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w900, fontSize: 18)),
                              ),
                              if (sh.verified) ...[
                                const SizedBox(width: 5),
                                const VerifiedBadge(size: 18),
                              ],
                            ]),
                            const SizedBox(height: 4),
                            Text(
                              [
                                if (sh.city.isNotEmpty) cityName(sh.country, sh.city, l),
                                if (sh.country.isNotEmpty) countryName(sh.country, l),
                              ].join('، '),
                              style: const TextStyle(color: AppPal.inkSoft),
                            ),
                          ],
                        ),
                      ),
                    ]),
                    const SizedBox(height: 10),
                    Wrap(spacing: 6, runSpacing: 6, children: [
                      for (final k in sh.types)
                        if (shopTypeOf(k) != null)
                          Chip(label: Text('${shopTypeOf(k)!.emoji} ${shopTypeOf(k)!.name(l)}')),
                    ]),
                    if (sh.description.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(sh.description, style: const TextStyle(height: 1.7)),
                    ],
                    if (sh.address.isNotEmpty)
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.place_outlined, color: AppPal.purple),
                        title: Text(sh.address),
                      ),
                    const SizedBox(height: 8),
                    Row(children: [
                      if (sh.ownerId != s.meId)
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => ChatPage(s: s, otherId: sh.ownerId)),
                            ),
                            icon: const Icon(Icons.chat_bubble_outline, size: 18),
                            label: Text(tr(l, 'shMessageSeller')),
                            style: FilledButton.styleFrom(backgroundColor: AppPal.purple),
                          ),
                        ),
                      if (sh.phone.isNotEmpty) ...[
                        const SizedBox(width: 10),
                        OutlinedButton.icon(
                          onPressed: () async {
                            try {
                              await launchUrl(Uri(scheme: 'tel', path: sh.phone));
                            } catch (_) {}
                          },
                          icon: const Icon(Icons.call_outlined, size: 18),
                          label: Text(tr(l, 'shCall')),
                        ),
                      ],
                    ]),
                    const SizedBox(height: 16),
                    Text(tr(l, 'shAllProducts'),
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 10),
                    if (_items.isEmpty)
                      Padding(
                        padding: const EdgeInsets.all(30),
                        child: Center(
                            child: Text(tr(l, 'shNoListings'),
                                style: const TextStyle(color: AppPal.inkSoft))),
                      )
                    else
                      GridView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: .72,
                        ),
                        itemCount: _items.length,
                        itemBuilder: (c, i) => ListingCard(
                          item: _items[i],
                          lang: l,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ListingDetailPage(s: s, item: _items[i]),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }
}
