import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../i18n2.dart';
import '../l10n.dart';
import '../state.dart';
import '../theme.dart';
import '../data/jalali.dart';
import '../data/places.dart';
import '../widgets/avatar.dart';
import '../widgets/location_fields.dart';
import 'invite_support.dart';
import 'legal_pages.dart';
import 'notifications_page.dart';

const String appVersion = '2.4.1';

/// منوی کشویی (سه خط افقی).
class AppDrawer extends StatelessWidget {
  final AppState s;
  const AppDrawer({super.key, required this.s});

  void _go(BuildContext context, Widget page) {
    Navigator.pop(context); // بستن منو
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  void _langDialog(BuildContext context) {
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: Text(tr(s.lang, 'language')),
        children: [
          for (final l in AppLang.values)
            ListTile(
              leading: Icon(
                  l == s.lang ? Icons.radio_button_checked : Icons.radio_button_off,
                  color: AppPal.purple),
              title: Text(l.label),
              onTap: () {
                s.setLang(l);
                Navigator.pop(ctx);
              },
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = s.lang;
    final me = s.me;

    Widget item(IconData icon, String key, VoidCallback onTap) => ListTile(
          leading: Icon(icon, color: AppPal.purple),
          title: Text(tr(l, key), style: const TextStyle(fontWeight: FontWeight.w700)),
          onTap: onTap,
        );

    return Drawer(
      child: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: const BoxDecoration(gradient: AppPal.purpleGradient),
              child: Row(children: [
                UserAvatar(user: me, size: 54),
                const SizedBox(width: 12),
                Expanded(
                  child: Text('@${me?.username ?? ''}',
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 17)),
                ),
              ]),
            ),
            item(Icons.manage_accounts_outlined, 'account',
                () => _go(context, AccountPage(s: s))),
            item(Icons.translate, 'language', () => _langDialog(context)),
            item(Icons.account_balance_wallet_outlined, 'wallet',
                () => _go(context, ComingSoonPage(s: s, titleKey: 'wallet'))),
            item(Icons.system_update_outlined, 'update', () {
              Navigator.pop(context);
              showDialog(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: Text(tr(l, 'update')),
                  content: Text('${tr(l, 'currentVersion')}: $appVersion'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: Text(tr(l, 'ok'))),
                  ],
                ),
              );
            }),
            item(Icons.group_add_outlined, 'invite',
                () => _go(context, InvitePage(s: s))),
            item(Icons.shield_outlined, 'privacySecurity',
                () => _go(context, PrivacyPage(s: s))),
            item(Icons.notifications_none, 'notifications',
                () => _go(context, NotificationsPage(s: s))),
            item(Icons.support_agent_outlined, 'support',
                () => _go(context, SupportPage(s: s))),
            item(Icons.gavel_outlined, 'terms',
                () => _go(context, LegalListPage(s: s))),
          ],
        ),
      ),
    );
  }
}

class ComingSoonPage extends StatelessWidget {
  final AppState s;
  final String titleKey;
  const ComingSoonPage({super.key, required this.s, required this.titleKey});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(tr(s.lang, titleKey))),
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.construction_outlined, size: 54, color: AppPal.inkSoft),
            const SizedBox(height: 10),
            Text(tr(s.lang, 'soon'), style: const TextStyle(color: AppPal.inkSoft)),
          ]),
        ),
      );
}

// ======================= حساب کاربری =======================
class AccountPage extends StatelessWidget {
  final AppState s;
  const AccountPage({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final me = s.me;
        if (me == null) return const SizedBox();

        Widget info(IconData i, String key, String value) => ListTile(
              leading: Icon(i, color: AppPal.purple),
              title: Text(tr(l, key)),
              subtitle: Text(value, textDirection: TextDirection.ltr,
                  textAlign: l == AppLang.fa ? TextAlign.right : TextAlign.left),
            );

        return Scaffold(
          appBar: AppBar(title: Text(tr(l, 'account'))),
          body: ListView(children: [
            info(Icons.alternate_email, 'username', me.username),
            info(Icons.email_outlined, 'email', me.email),
            info(Icons.phone_iphone, 'mobile', me.mobile),
            ListTile(
              leading: const Icon(Icons.cake_outlined, color: AppPal.purple),
              title: Text(tr(l, 'birthDate')),
              subtitle: Text(me.birth == null ? '—' : formatDate(me.birth!, l)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                final d = await pickDate(context, l,
                    initial: me.birth, lastYear: DateTime.now().year);
                if (d != null) await s.updateBirth(d);
              },
            ),
            ListTile(
              leading: const Icon(Icons.location_on_outlined, color: AppPal.purple),
              title: Text(tr(l, 'location')),
              subtitle: Text(
                me.country.isEmpty
                    ? '—'
                    : '${cityName(me.country, me.city, l)}، ${countryName(me.country, l)}',
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => LocationPage(s: s))),
            ),
            ListTile(
              leading: const Icon(Icons.qr_code_2, color: AppPal.purple),
              title: Text(tr(l, 'qrCode')),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => showDialog(
                context: context,
                builder: (ctx) => Dialog(
                  child: Padding(
                    padding: const EdgeInsets.all(22),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Text('@${me.username}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 17)),
                      const SizedBox(height: 14),
                      SizedBox(
                        width: 220,
                        height: 220,
                        child: QrImageView(
                          data: 'petlist://user/${me.username}',
                          backgroundColor: Colors.white,
                        ),
                      ),
                    ]),
                  ),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.password, color: AppPal.purple),
              title: Text(tr(l, 'changePass')),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => ChangePasswordPage(s: s))),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout, color: Color(0xFFB3261E)),
              title: Text(tr(l, 'logout'),
                  style: const TextStyle(
                      color: Color(0xFFB3261E), fontWeight: FontWeight.w800)),
              onTap: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    content: Text(tr(l, 'logoutConfirm')),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(ctx, false),
                          child: Text(tr(l, 'no'))),
                      TextButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          child: Text(tr(l, 'yes'))),
                    ],
                  ),
                );
                if (ok != true) return;
                await s.logout();
                if (context.mounted) {
                  Navigator.of(context).popUntil((r) => r.isFirst);
                }
              },
            ),
          ]),
        );
      },
    );
  }
}

class ChangePasswordPage extends StatefulWidget {
  final AppState s;
  const ChangePasswordPage({super.key, required this.s});

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final _old = TextEditingController();
  final _new = TextEditingController();
  final _new2 = TextEditingController();
  String? _err;

  @override
  void dispose() {
    _old.dispose();
    _new.dispose();
    _new2.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_new.text.length < 6) {
      setState(() => _err = 'errPassShort');
      return;
    }
    if (_new.text != _new2.text) {
      setState(() => _err = 'errPassMatch');
      return;
    }
    final e = await widget.s.changePassword(_old.text, _new.text);
    if (!mounted) return;
    if (e != null) {
      setState(() => _err = e);
      return;
    }
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(tr(widget.s.lang, 'passChanged'))));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'changePass'))),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        TextField(
            controller: _old,
            obscureText: true,
            decoration: InputDecoration(labelText: tr(l, 'oldPass'))),
        const SizedBox(height: 12),
        TextField(
            controller: _new,
            obscureText: true,
            decoration: InputDecoration(labelText: tr(l, 'newPass'))),
        const SizedBox(height: 12),
        TextField(
            controller: _new2,
            obscureText: true,
            decoration: InputDecoration(labelText: tr(l, 'repeatPass'))),
        if (_err != null)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(tr(l, _err!),
                style: const TextStyle(color: Color(0xFFB3261E), fontSize: 13)),
          ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: _save,
          style: FilledButton.styleFrom(
            backgroundColor: AppPal.purple,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: Text(tr(l, 'save'),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
      ]),
    );
  }
}

// ======================= حریم خصوصی و امنیت =======================
class PrivacyPage extends StatelessWidget {
  final AppState s;
  const PrivacyPage({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final me = s.me;
        if (me == null) return const SizedBox();
        return Scaffold(
          appBar: AppBar(title: Text(tr(l, 'privacySecurity'))),
          body: ListView(children: [
            SwitchListTile(
              activeColor: AppPal.purple,
              secondary: const Icon(Icons.lock_outline, color: AppPal.purple),
              title: Text(tr(l, 'privateAccount')),
              subtitle: Text(tr(l, 'privateAccountSub')),
              value: me.isPrivate,
              onChanged: s.setPrivate,
            ),
            SwitchListTile(
              activeColor: AppPal.purple,
              secondary: const Icon(Icons.verified_user_outlined, color: AppPal.purple),
              title: Text(tr(l, 'twoStep')),
              subtitle: Text(tr(l, 'twoStepSub')),
              value: me.twoFactor,
              onChanged: s.setTwoFactor,
            ),
            const Divider(),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
              child: Text(tr(l, 'blockedUsers'),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
            if (me.blocked.isEmpty)
              Padding(
                padding: const EdgeInsets.all(20),
                child: Text(tr(l, 'noBlocked'),
                    style: const TextStyle(color: AppPal.inkSoft)),
              )
            else
              for (final id in me.blocked)
                ListTile(
                  leading: UserAvatar(user: s.userById(id), size: 40),
                  title: Text(s.userById(id)?.username ?? id),
                  trailing: TextButton(
                      onPressed: () => s.unblock(id),
                      child: Text(tr(l, 'unblock'))),
                ),
          ]),
        );
      },
    );
  }
}

// ======================= موقعیت =======================
class LocationPage extends StatefulWidget {
  final AppState s;
  const LocationPage({super.key, required this.s});

  @override
  State<LocationPage> createState() => _LocationPageState();
}

class _LocationPageState extends State<LocationPage> {
  late String _country = widget.s.me?.country ?? '';
  late String _city = widget.s.me?.city ?? '';
  bool _busy = false;

  Future<void> _save() async {
    final l = widget.s.lang;
    if (_country.isEmpty || _city.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(tr(l, 'errFill'))));
      return;
    }
    setState(() => _busy = true);
    final ok = await widget.s.updateLocation(_country, _city);
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(tr(l, ok ? 'locationSaved' : 'errNet'))));
    if (ok) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'location'))),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Text(tr(l, 'locationHelp'),
            style: const TextStyle(color: AppPal.inkSoft, height: 1.6)),
        const SizedBox(height: 16),
        LocationFields(
          lang: l,
          country: _country,
          city: _city,
          onChanged: (c, ct) {
            _country = c;
            _city = ct;
          },
        ),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: _busy ? null : _save,
          style: FilledButton.styleFrom(
            backgroundColor: AppPal.purple,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: Text(tr(l, 'save'),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
      ]),
    );
  }
}
