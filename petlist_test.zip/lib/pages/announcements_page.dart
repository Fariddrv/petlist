import 'package:flutter/material.dart';

import '../data/timeago.dart';
import '../i18n2.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/smart_image.dart';

/// اخبار و اطلاعیه‌های رسمی pawpet (ادمین منتشر می‌کند).
class AnnouncementsPage extends StatefulWidget {
  final AppState s;
  const AnnouncementsPage({super.key, required this.s});

  @override
  State<AnnouncementsPage> createState() => _AnnouncementsPageState();
}

class _AnnouncementsPageState extends State<AnnouncementsPage> {
  @override
  void initState() {
    super.initState();
    widget.s.loadAnnouncements();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final list = s.announcements;
        return Scaffold(
          appBar: AppBar(title: Text(tr(l, 'announcements'))),
          body: RefreshIndicator(
            onRefresh: s.loadAnnouncements,
            child: list.isEmpty
                ? ListView(children: [
                    const SizedBox(height: 120),
                    const Icon(Icons.campaign_outlined,
                        size: 56, color: AppPal.inkSoft),
                    const SizedBox(height: 10),
                    Center(
                        child: Text(tr(l, 'noAnnouncements'),
                            style: const TextStyle(color: AppPal.inkSoft))),
                  ])
                : ListView.builder(
                    padding: const EdgeInsets.all(14),
                    itemCount: list.length,
                    itemBuilder: (c, i) {
                      final a = list[i];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 14),
                        clipBehavior: Clip.antiAlias,
                        decoration: AppPal.softCard(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if ((a.imageUrl ?? '').isNotEmpty)
                              AspectRatio(
                                aspectRatio: 16 / 9,
                                child: SmartImage(
                                    src: a.imageUrl, fit: BoxFit.cover),
                              ),
                            Padding(
                              padding: const EdgeInsets.all(14),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(a.title,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w900,
                                          fontSize: 16)),
                                  const SizedBox(height: 4),
                                  Text(timeAgo(a.createdAt, l),
                                      style: const TextStyle(
                                          color: AppPal.inkSoft, fontSize: 12)),
                                  if (a.body.isNotEmpty) ...[
                                    const SizedBox(height: 10),
                                    Text(a.body,
                                        style: const TextStyle(height: 1.7)),
                                  ],
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        );
      },
    );
  }
}
