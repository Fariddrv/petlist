import 'package:flutter/material.dart';

import '../data/legal.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../state.dart';

class LegalPage extends StatelessWidget {
  final AppLang lang;
  final String kind; // terms | privacy
  const LegalPage({super.key, required this.lang, required this.kind});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
            title: Text(tr(lang, switch (kind) {
          'terms' => 'termsTitle',
          'vendor' => 'vendorTitle',
          'subscription' => 'subscriptionTitle',
          _ => 'privacyTitle',
        }))),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Text(legalText(kind, lang),
              style: const TextStyle(height: 1.8, fontSize: 14.5)),
        ),
      );
}

/// فهرست قوانین (از منو)
class LegalListPage extends StatelessWidget {
  final AppState s;
  const LegalListPage({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    final l = s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'terms'))),
      body: ListView(children: [
        for (final k in ['terms', 'privacy'])
          ListTile(
            leading: Icon(k == 'terms' ? Icons.gavel_outlined : Icons.privacy_tip_outlined),
            title: Text(tr(l, k == 'terms' ? 'termsTitle' : 'privacyTitle')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => LegalPage(lang: l, kind: k))),
          ),
      ]),
    );
  }
}
