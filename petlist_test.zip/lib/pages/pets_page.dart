import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';

/// تب حیوانات خانگی من: افزودن/حذف پت (فعلاً در حافظه؛ فاز بعد: ذخیره‌ی دائمی).
class PetsPage extends StatefulWidget {
  final AppLang lang;
  final List<Pet> pets;
  final ValueChanged<Pet> onAdd;
  final ValueChanged<Pet> onRemove;

  const PetsPage({
    super.key,
    required this.lang,
    required this.pets,
    required this.onAdd,
    required this.onRemove,
  });

  @override
  State<PetsPage> createState() => _PetsPageState();
}

class _PetsPageState extends State<PetsPage> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _age = TextEditingController();
  PetKind _kind = PetKind.cat;

  @override
  void dispose() {
    _name.dispose();
    _age.dispose();
    super.dispose();
  }

  void _snack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg)));

  void _save() {
    final t = L10n.of(widget.lang);
    final name = _name.text.trim();
    if (name.isEmpty) {
      _snack(t.nameRequired);
      return;
    }
    widget.onAdd(Pet(
      name: name,
      kind: _kind,
      age: int.tryParse(_age.text.trim()) ?? 0,
    ));
    _name.clear();
    _age.clear();
    _snack(t.petSaved);
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppPal.gradientBanner(
          gradient: AppPal.grayGradient,
          shadow: const Color(0x336B7280),
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        t.tabPets,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 19,
                            fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${widget.pets.length} 🐾',
                        style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.92),
                            fontSize: 13),
                      ),
                    ],
                  ),
                ),
                const Text('🐶🐱', style: TextStyle(fontSize: 32)),
              ],
            ),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          decoration: AppPal.softCard(),
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: _name,
                decoration: InputDecoration(labelText: t.petNameHint),
              ),
              const SizedBox(height: 12),
              Text(t.petKindLabel,
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, color: AppPal.ink)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  for (final k in PetKind.values)
                    ChoiceChip(
                      label: Text(switch (k) {
                        PetKind.cat => t.kindCat,
                        PetKind.dog => t.kindDog,
                        PetKind.other => t.kindOther,
                      }),
                      avatar: ClipOval(
                        child: Image.asset(k.image,
                            width: 22, height: 22, fit: BoxFit.cover),
                      ),
                      selected: _kind == k,
                      onSelected: (_) => setState(() => _kind = k),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _age,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: t.petAgeHint),
              ),
              const SizedBox(height: 14),
              ElevatedButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.pets),
                label: Text(t.petSave),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppPal.purple,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  elevation: 0,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        if (widget.pets.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 32),
            child: Column(
              children: [
                const Text('🐾', style: TextStyle(fontSize: 56)),
                const SizedBox(height: 12),
                Text(t.petsEmpty,
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: AppPal.ink)),
                const SizedBox(height: 6),
                Text(t.petsEmptySub,
                    style: const TextStyle(color: AppPal.inkSoft)),
              ],
            ),
          )
        else
          for (final p in widget.pets)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              clipBehavior: Clip.antiAlias,
              decoration: AppPal.softCard(),
              child: Row(
                children: [
                  Image.asset(p.kind.image,
                      width: 64, height: 64, fit: BoxFit.cover),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.name,
                            style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                color: AppPal.ink)),
                        const SizedBox(height: 2),
                        Text('${p.age} ${t.yearsOld}',
                            style: const TextStyle(
                                color: AppPal.inkSoft, fontSize: 13)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: AppPal.purple),
                    onPressed: () {
                      widget.onRemove(p);
                      _snack(t.petDeleted);
                    },
                  ),
                ],
              ),
            ),
      ],
    );
  }
}
