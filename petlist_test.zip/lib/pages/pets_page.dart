import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';

/// تب «حیوانات من»: افزودن پت با عکس (گالری/دوربین) + حذف.
class PetsPage extends StatefulWidget {
  final AppLang lang;
  final List<Pet> pets;
  final ValueChanged<Pet> onAdd;
  final ValueChanged<Pet> onRemove;

  const PetsPage({
    super.key,
    required this.lang,
    required this.pets,
    required this.onAdd,
    required this.onRemove,
  });

  @override
  State<PetsPage> createState() => _PetsPageState();
}

class _PetsPageState extends State<PetsPage> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _age = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  PetKind _kind = PetKind.cat;
  String? _photoPath;

  @override
  void dispose() {
    _name.dispose();
    _age.dispose();
    super.dispose();
  }

  void _snack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _pickPhoto() async {
    final t = L10n.of(widget.lang);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 10),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined,
                  color: AppPal.purple),
              title: Text(t.gallery),
              onTap: () async {
                Navigator.pop(ctx);
                await _take(ImageSource.gallery, t.pickFailed);
              },
            ),
            ListTile(
              leading:
                  const Icon(Icons.photo_camera_outlined, color: AppPal.purple),
              title: Text(t.camera),
              onTap: () async {
                Navigator.pop(ctx);
                await _take(ImageSource.camera, t.pickFailed);
              },
            ),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }

  Future<void> _take(ImageSource src, String failMsg) async {
    try {
      final f = await _picker.pickImage(
        source: src,
        imageQuality: 88,
        maxWidth: 1600,
      );
      if (f == null) return;
      setState(() => _photoPath = f.path);
    } catch (e) {
      final msg = e.toString().replaceAll('PlatformException(', '').replaceAll(')', '');
      _snack('$failMsg [$msg]');
    }
  }

  void _save() {
    final t = L10n.of(widget.lang);
    final name = _name.text.trim();
    if (name.isEmpty) {
      _snack(t.nameRequired);
      return;
    }
    widget.onAdd(Pet(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name,
      kind: _kind,
      age: int.tryParse(_age.text.trim()) ?? 0,
      photoPath: _photoPath,
    ));
    _name.clear();
    _age.clear();
    setState(() => _photoPath = null);
    _snack(t.petSaved);
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppPal.gradientBanner(
          gradient: AppPal.purpleGradient,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        t.tabPets,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 19,
                            fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${t.num(widget.pets.length)} 🐾',
                        style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.94),
                            fontSize: 13),
                      ),
                    ],
                  ),
                ),
                const Text('🐶🐱', style: TextStyle(fontSize: 32)),
              ],
            ),
          ],
        ),
        const SizedBox(height: 16),

        // ---------- فرم افزودن پت ----------
        Container(
          decoration: AppPal.softCard(),
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // حلقه‌ی عکس پت
              Center(
                child: GestureDetector(
                  onTap: _pickPhoto,
                  child: Stack(
                    children: [
                      Container(
                        width: 112,
                        height: 112,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: _photoPath == null
                              ? AppPal.purpleGradient
                              : null,
                          border: Border.all(
                              color: const Color(0x14000000), width: 2),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0x1A7C5CFF),
                                blurRadius: 16,
                                offset: Offset(0, 6)),
                          ],
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: _photoPath == null
                            ? const Icon(Icons.pets,
                                color: Colors.white, size: 46)
                            : Image.file(File(_photoPath!),
                                fit: BoxFit.cover),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          padding: const EdgeInsets.all(7),
                          decoration: const BoxDecoration(
                            color: AppPal.yellow,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.add_a_photo_outlined,
                              size: 17, color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Center(
                child: Text(
                  _photoPath == null ? t.tapToAddPhoto : t.changePhoto,
                  style: const TextStyle(
                      color: AppPal.inkSoft,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 18),
              TextField(
                controller: _name,
                decoration: InputDecoration(labelText: t.petNameHint),
              ),
              const SizedBox(height: 14),
              Text(t.petKindLabel,
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, color: AppPal.ink)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  for (final k in PetKind.values)
                    ChoiceChip(
                      label: Text(switch (k) {
                        PetKind.cat => t.kindCat,
                        PetKind.dog => t.kindDog,
                        PetKind.other => t.kindOther,
                      }),
                      avatar: ClipOval(
                        child: Image.asset(k.image,
                            width: 22, height: 22, fit: BoxFit.cover),
                      ),
                      selected: _kind == k,
                      onSelected: (_) => setState(() => _kind = k),
                    ),
                ],
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _age,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: t.petAgeHint),
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 52,
                child: FilledButton.icon(
                  onPressed: _save,
                  style: FilledButton.styleFrom(
                    backgroundColor: AppPal.purple,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  icon: const Icon(Icons.pets),
                  label: Text(
                    t.petSave,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),

        // ---------- لیست پت‌ها ----------
        if (widget.pets.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 34),
            child: Column(
              children: [
                const Text('🐾', style: TextStyle(fontSize: 54)),
                const SizedBox(height: 12),
                Text(t.petsEmpty,
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: AppPal.ink)),
                const SizedBox(height: 6),
                Text(t.petsEmptySub,
                    style: const TextStyle(color: AppPal.inkSoft)),
              ],
            ),
          )
        else
          for (final p in widget.pets)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              clipBehavior: Clip.antiAlias,
              decoration: AppPal.softCard(),
              child: Row(
                children: [
                  SizedBox(
                    width: 92,
                    height: 92,
                    child: p.photoPath != null
                        ? Image.file(File(p.photoPath!), fit: BoxFit.cover)
                        : Image.asset(p.kind.image, fit: BoxFit.cover),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.name,
                            style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 16,
                                color: AppPal.ink)),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            ClipOval(
                              child: Image.asset(p.kind.image,
                                  width: 18, height: 18, fit: BoxFit.cover),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '${switch (p.kind) {
                                PetKind.cat => t.kindCat,
                                PetKind.dog => t.kindDog,
                                PetKind.other => t.kindOther,
                              }} • ${t.num(p.age)} ${t.yearsOld}',
                              style: const TextStyle(
                                  color: AppPal.inkSoft, fontSize: 13),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: AppPal.inkSoft),
                    onPressed: () {
                      widget.onRemove(p);
                      _snack(t.petDeleted);
                    },
                  ),
                  const SizedBox(width: 4),
                ],
              ),
            ),
      ],
    );
  }
}
