import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';
import '../data/catalog.dart';
import '../data/media.dart';
import '../i18n2.dart';

/// تب «حیوانات من»: افزودن پت با عکس (گالری/دوربین) + حذف.
class PetsPage extends StatefulWidget {
  final AppLang lang;
  final List<Pet> pets;
  final ValueChanged<Pet> onAdd;
  final ValueChanged<Pet> onRemove;

  const PetsPage({
    super.key,
    required this.lang,
    required this.pets,
    required this.onAdd,
    required this.onRemove,
  });

  @override
  State<PetsPage> createState() => _PetsPageState();
}

class _PetsPageState extends State<PetsPage> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _age = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  String _species = 'dog';
  String? _photoPath;

  @override
  void dispose() {
    _name.dispose();
    _age.dispose();
    super.dispose();
  }

  void _snack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _pickPhoto() async {
    final t = L10n.of(widget.lang);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 10),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined,
                  color: AppPal.purple),
              title: Text(t.gallery),
              onTap: () async {
                Navigator.pop(ctx);
                await _take(ImageSource.gallery, t.pickFailed);
              },
            ),
            ListTile(
              leading:
                  const Icon(Icons.photo_camera_outlined, color: AppPal.purple),
              title: Text(t.camera),
              onTap: () async {
                Navigator.pop(ctx);
                await _take(ImageSource.camera, t.pickFailed);
              },
            ),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }

  Future<void> _take(ImageSource src, String failMsg) async {
    try {
      final f = await _picker.pickImage(
        source: src,
        imageQuality: 88,
        maxWidth: 1600,
      );
      if (f == null) return;
      final saved = await persistImage(f.path);
      if (!mounted) return;
      setState(() => _photoPath = saved);
    } catch (e) {
      final msg = e.toString().replaceAll('PlatformException(', '').replaceAll(')', '');
      _snack('$failMsg [$msg]');
    }
  }

  Future<void> _chooseSpecies() async {
    final picked = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (ctx) => SizedBox(
        height: MediaQuery.of(ctx).size.height * .7,
        child: Column(
          children: [
            const SizedBox(height: 14),
            Text(tr(widget.lang, 'chooseSpecies'),
                style: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 10),
            Expanded(
              child: GridView.count(
                crossAxisCount: 3,
                padding: const EdgeInsets.all(14),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.05,
                children: [
                  for (final sp in speciesList)
                    InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () => Navigator.pop(ctx, sp.id),
                      child: Container(
                        decoration: BoxDecoration(
                          color: sp.id == _species
                              ? const Color(0xFFEDE7FF)
                              : const Color(0xFFF3F4F8),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: sp.id == _species
                                ? AppPal.purple
                                : Colors.transparent,
                            width: 1.5,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(sp.emoji, style: const TextStyle(fontSize: 30)),
                            const SizedBox(height: 4),
                            Text(sp.name(widget.lang),
                                textAlign: TextAlign.center,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
    if (picked != null) setState(() => _species = picked);
  }

  void _save() {
    final t = L10n.of(widget.lang);
    final name = _name.text.trim();
    if (name.isEmpty) {
      _snack(t.nameRequired);
      return;
    }
    widget.onAdd(Pet(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name,
      species: _species,
      age: int.tryParse(_age.text.trim()) ?? 0,
      photoPath: _photoPath,
    ));
    _name.clear();
    _age.clear();
    setState(() => _photoPath = null);
    _snack(t.petSaved);
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppPal.gradientBanner(
          gradient: AppPal.purpleGradient,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        t.tabPets,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 19,
                            fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${t.num(widget.pets.length)} 🐾',
                        style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.94),
                            fontSize: 13),
                      ),
                    ],
                  ),
                ),
                const Text('🐶🐱', style: TextStyle(fontSize: 32)),
              ],
            ),
          ],
        ),
        const SizedBox(height: 16),

        // ---------- فرم افزودن پت ----------
        Container(
          decoration: AppPal.softCard(),
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // حلقه‌ی عکس پت
              Center(
                child: GestureDetector(
                  onTap: _pickPhoto,
                  child: Stack(
                    children: [
                      Container(
                        width: 112,
                        height: 112,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: _photoPath == null
                              ? AppPal.purpleGradient
                              : null,
                          border: Border.all(
                              color: const Color(0x14000000), width: 2),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0x1A7C5CFF),
                                blurRadius: 16,
                                offset: Offset(0, 6)),
                          ],
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: _photoPath == null
                            ? const Icon(Icons.pets,
                                color: Colors.white, size: 46)
                            : Image.file(File(_photoPath!),
                                fit: BoxFit.cover),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          padding: const EdgeInsets.all(7),
                          decoration: const BoxDecoration(
                            color: AppPal.yellow,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.add_a_photo_outlined,
                              size: 17, color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Center(
                child: Text(
                  _photoPath == null ? t.tapToAddPhoto : t.changePhoto,
                  style: const TextStyle(
                      color: AppPal.inkSoft,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 18),
              TextField(
                controller: _name,
                decoration: InputDecoration(labelText: t.petNameHint),
              ),
              const SizedBox(height: 14),
              InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: _chooseSpecies,
                child: InputDecorator(
                  decoration: InputDecoration(
                    labelText: tr(widget.lang, 'petSpecies'),
                    suffixIcon: const Icon(Icons.arrow_drop_down),
                  ),
                  child: Row(
                    children: [
                      Text(speciesOf(_species).emoji,
                          style: const TextStyle(fontSize: 20)),
                      const SizedBox(width: 8),
                      Text(speciesOf(_species).name(widget.lang),
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _age,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: t.petAgeHint),
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 52,
                child: FilledButton.icon(
                  onPressed: _save,
                  style: FilledButton.styleFrom(
                    backgroundColor: AppPal.purple,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  icon: const Icon(Icons.pets),
                  label: Text(
                    t.petSave,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),

        // ---------- لیست پت‌ها ----------
        if (widget.pets.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 34),
            child: Column(
              children: [
                const Text('🐾', style: TextStyle(fontSize: 54)),
                const SizedBox(height: 12),
                Text(t.petsEmpty,
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: AppPal.ink)),
                const SizedBox(height: 6),
                Text(t.petsEmptySub,
                    style: const TextStyle(color: AppPal.inkSoft)),
              ],
            ),
          )
        else
          for (final p in widget.pets)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              clipBehavior: Clip.antiAlias,
              decoration: AppPal.softCard(),
              child: Row(
                children: [
                  SizedBox(
                    width: 92,
                    height: 92,
                    child: p.photoPath != null
                        ? Image.file(File(p.photoPath!), fit: BoxFit.cover)
                        : Image.asset(p.image, fit: BoxFit.cover),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.name,
                            style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 16,
                                color: AppPal.ink)),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            Text(speciesOf(p.species).emoji,
                                style: const TextStyle(fontSize: 16)),
                            const SizedBox(width: 6),
                            Flexible(
                              child: Text(
                                '${speciesOf(p.species).name(widget.lang)} • ${t.num(p.age)} ${t.yearsOld}',
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    color: AppPal.inkSoft, fontSize: 13),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: AppPal.inkSoft),
                    onPressed: () {
                      widget.onRemove(p);
                      _snack(t.petDeleted);
                    },
                  ),
                  const SizedBox(width: 4),
                ],
              ),
            ),
      ],
    );
  }
}
