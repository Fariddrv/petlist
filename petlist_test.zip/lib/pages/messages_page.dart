import 'package:flutter/material.dart';
import '../i18n2.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';

/// فهرست گفتگوها.
class MessagesPage extends StatelessWidget {
  final AppState s;
  const MessagesPage({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final partners = s.threadPartners();
        return Scaffold(
          appBar: AppBar(title: Text(tr(l, 'messages'))),
          body: partners.isEmpty
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.mail_outline, size: 54, color: AppPal.inkSoft),
                    const SizedBox(height: 10),
                    Text(tr(l, 'noMessages'),
                        style: const TextStyle(color: AppPal.inkSoft)),
                  ]),
                )
              : ListView.separated(
                  itemCount: partners.length,
                  separatorBuilder: (c, i) => const Divider(height: 1, indent: 72),
                  itemBuilder: (c, i) {
                    final u = s.userById(partners[i]);
                    final last = s.thread(partners[i]).last;
                    return ListTile(
                      leading: UserAvatar(user: u, size: 46),
                      title: Text(u?.username ?? '?',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text(last.text,
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  ChatPage(s: s, otherId: partners[i]))),
                    );
                  },
                ),
        );
      },
    );
  }
}

/// صفحه‌ی گفتگو با یک کاربر.
class ChatPage extends StatefulWidget {
  final AppState s;
  final String otherId;
  const ChatPage({super.key, required this.s, required this.otherId});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _send() {
    final txt = _ctrl.text;
    if (txt.trim().isEmpty) return;
    widget.s.sendMsg(widget.otherId, txt);
    _ctrl.clear();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent + 80,
            duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final other = s.userById(widget.otherId);
        final list = s.thread(widget.otherId);
        return Scaffold(
          appBar: AppBar(
            title: Row(children: [
              UserAvatar(user: other, size: 34),
              const SizedBox(width: 10),
              Text(other?.username ?? '?'),
            ]),
          ),
          body: Column(children: [
            Expanded(
              child: ListView.builder(
                controller: _scroll,
                padding: const EdgeInsets.all(14),
                itemCount: list.length,
                itemBuilder: (c, i) {
                  final m = list[i];
                  final mine = m.from == s.meId;
                  return Align(
                    alignment: mine
                        ? AlignmentDirectional.centerEnd
                        : AlignmentDirectional.centerStart,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 9),
                      constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(c).size.width * .75),
                      decoration: BoxDecoration(
                        color: mine ? AppPal.purple : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: mine
                            ? null
                            : Border.all(color: const Color(0x14000000)),
                      ),
                      child: Text(m.text,
                          style: TextStyle(
                              color: mine ? Colors.white : AppPal.ink,
                              height: 1.4)),
                    ),
                  );
                },
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
                child: Row(children: [
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      onSubmitted: (_) => _send(),
                      decoration: InputDecoration(hintText: tr(l, 'typeMessage')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _send,
                    style: IconButton.styleFrom(backgroundColor: AppPal.purple),
                    icon: const Icon(Icons.send_rounded),
                  ),
                ]),
              ),
            ),
          ]),
        );
      },
    );
  }
}
