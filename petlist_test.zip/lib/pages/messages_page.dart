import 'package:flutter/material.dart';
import '../i18n2.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/emoji_panel.dart';

/// فهرست گفتگوها.
class MessagesPage extends StatelessWidget {
  final AppState s;
  const MessagesPage({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final partners = s.threadPartners();
        return Scaffold(
          appBar: AppBar(title: Text(tr(l, 'messages'))),
          body: partners.isEmpty
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.mail_outline, size: 54, color: AppPal.inkSoft),
                    const SizedBox(height: 10),
                    Text(tr(l, 'noMessages'),
                        style: const TextStyle(color: AppPal.inkSoft)),
                  ]),
                )
              : ListView.separated(
                  itemCount: partners.length,
                  separatorBuilder: (c, i) => const Divider(height: 1, indent: 72),
                  itemBuilder: (c, i) {
                    final u = s.userById(partners[i]);
                    final last = s.thread(partners[i]).last;
                    return ListTile(
                      leading: UserAvatar(user: u, size: 46),
                      title: Text(u?.username ?? '?',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text(last.text,
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  ChatPage(s: s, otherId: partners[i]))),
                    );
                  },
                ),
        );
      },
    );
  }
}

/// صفحه‌ی گفتگو با یک کاربر (مثل اینستاگرام: جدیدترین پیام پایین صفحه).
class ChatPage extends StatefulWidget {
  final AppState s;
  final String otherId;
  const ChatPage({super.key, required this.s, required this.otherId});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final _focus = FocusNode();
  bool _showEmoji = false;

  @override
  void initState() {
    super.initState();
    _focus.addListener(() {
      if (_focus.hasFocus && _showEmoji) setState(() => _showEmoji = false);
    });
    widget.s.loadMessages();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _send() {
    final txt = _ctrl.text;
    if (txt.trim().isEmpty) return;
    widget.s.sendMsg(widget.otherId, txt);
    _ctrl.clear();
    if (_scroll.hasClients) {
      _scroll.animateTo(0,
          duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
    }
  }

  void _toggleEmoji() {
    if (_showEmoji) {
      setState(() => _showEmoji = false);
      _focus.requestFocus();
    } else {
      _focus.unfocus();
      setState(() => _showEmoji = true);
    }
  }

  void _insert(String e) {
    final v = _ctrl.value;
    final start = v.selection.start < 0 ? v.text.length : v.selection.start;
    final end = v.selection.end < 0 ? v.text.length : v.selection.end;
    final t = v.text.replaceRange(start, end, e);
    _ctrl.value = TextEditingValue(
      text: t,
      selection: TextSelection.collapsed(offset: start + e.length),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final other = s.userById(widget.otherId);
        // reverse: true → اولین آیتم پایین صفحه است؛ پس جدیدترین را اول می‌گذاریم
        final list = s.thread(widget.otherId).reversed.toList();
        return Scaffold(
          appBar: AppBar(
            title: Row(children: [
              UserAvatar(user: other, size: 34),
              const SizedBox(width: 10),
              Text(other?.username ?? '?'),
            ]),
          ),
          body: Column(children: [
            Expanded(
              child: ListView.builder(
                reverse: true,
                controller: _scroll,
                padding: const EdgeInsets.all(14),
                itemCount: list.length,
                itemBuilder: (c, i) {
                  final m = list[i];
                  final mine = m.from == s.meId;
                  return Align(
                    alignment: mine
                        ? AlignmentDirectional.centerEnd
                        : AlignmentDirectional.centerStart,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 9),
                      constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(c).size.width * .75),
                      decoration: BoxDecoration(
                        color: mine ? AppPal.purple : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: mine
                            ? null
                            : Border.all(color: const Color(0x14000000)),
                      ),
                      child: Text(m.text,
                          style: TextStyle(
                              color: mine ? Colors.white : AppPal.ink,
                              fontSize: 15,
                              height: 1.4)),
                    ),
                  );
                },
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
                child: Row(children: [
                  IconButton(
                    onPressed: _toggleEmoji,
                    icon: Icon(
                      _showEmoji
                          ? Icons.keyboard_alt_outlined
                          : Icons.emoji_emotions_outlined,
                      color: AppPal.purple,
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      focusNode: _focus,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.newline,
                      decoration: InputDecoration(hintText: tr(l, 'typeMessage')),
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton.filled(
                    onPressed: _send,
                    style: IconButton.styleFrom(backgroundColor: AppPal.purple),
                    icon: const Icon(Icons.send_rounded),
                  ),
                ]),
              ),
            ),
            if (_showEmoji) EmojiPanel(onPick: _insert),
          ]),
        );
      },
    );
  }
}
