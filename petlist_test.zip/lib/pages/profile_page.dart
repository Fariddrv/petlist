import 'dart:io';
import 'package:flutter/material.dart';

import '../i18n2.dart';
import '../l10n.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/pigeon.dart';
import 'auth_pages.dart';
import 'messages_page.dart';

class _Tile {
  final String id;
  final String? file, asset;
  final String text;
  _Tile(this.id, {this.file, this.asset, this.text = ''});
}

/// پروفایل به سبک اینستاگرام. برای پروفایل خودِ کاربر (کبوتر پیام‌ها، ویرایش،
/// تب ذخیره‌شده‌ها) و برای پروفایل دیگران (Follow / Message) استفاده می‌شود.
class ProfilePage extends StatefulWidget {
  final AppState s;
  final String userId;
  final bool standalone; // true: با نوار بالا، به‌صورت صفحه‌ی جدا
  const ProfilePage(
      {super.key, required this.s, required this.userId, this.standalone = false});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  int _tab = 0; // 0 پست‌ها، 1 ذخیره‌شده‌ها

  AppState get s => widget.s;

  List<_Tile> _postsOf(AppUser u) {
    final out = <_Tile>[];
    for (final p in s.posts.reversed) {
      if (p.ownerId == u.id) {
        out.add(_Tile(p.id, file: p.imagePath, text: p.text));
      }
    }
    if (u.demo) {
      for (var i = 0; i < samplePosts.length; i++) {
        if ('demo_${samplePosts[i].author.toLowerCase()}' == u.id) {
          out.add(_Tile('sample_$i',
              asset: samplePosts[i].image,
              text: samplePosts[i].title.of(s.lang)));
        }
      }
    }
    return out;
  }

  List<_Tile> _savedTiles() {
    final out = <_Tile>[];
    for (final p in s.visiblePosts().reversed) {
      if (s.inter[p.id]?.saved == true) {
        out.add(_Tile(p.id, file: p.imagePath, text: p.text));
      }
    }
    final hidden = s.hiddenDemoOwners();
    for (var i = 0; i < samplePosts.length; i++) {
      final owner = 'demo_${samplePosts[i].author.toLowerCase()}';
      if (s.inter['sample_$i']?.saved == true && !hidden.contains(owner)) {
        out.add(_Tile('sample_$i',
            asset: samplePosts[i].image, text: samplePosts[i].title.of(s.lang)));
      }
    }
    return out;
  }

  void _open(_Tile t) {
    Widget img;
    if (t.file != null && File(t.file!).existsSync()) {
      img = Image.file(File(t.file!), fit: BoxFit.contain);
    } else if (t.asset != null) {
      img = Image.asset(t.asset!, fit: BoxFit.contain);
    } else {
      img = Container(
        padding: const EdgeInsets.all(24),
        alignment: Alignment.center,
        child: Text(t.text, style: const TextStyle(fontSize: 16)),
      );
    }
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        clipBehavior: Clip.antiAlias,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Flexible(child: img),
          if (t.text.isNotEmpty && (t.file != null || t.asset != null))
            Padding(padding: const EdgeInsets.all(12), child: Text(t.text)),
        ]),
      ),
    );
  }

  Widget _stat(String num, String label) => Column(children: [
        Text(num,
            style: const TextStyle(
                fontSize: 18, fontWeight: FontWeight.w900, color: AppPal.ink)),
        const SizedBox(height: 2),
        Text(label,
            style: const TextStyle(fontSize: 12.5, color: AppPal.inkSoft)),
      ]);

  Widget _grid(List<_Tile> tiles, String emptyKey) {
    final l = s.lang;
    if (tiles.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 44),
        child: Column(children: [
          Icon(_tab == 1 ? Icons.bookmark_border : Icons.photo_camera_outlined,
              size: 48, color: AppPal.inkSoft),
          const SizedBox(height: 10),
          Text(tr(l, emptyKey), style: const TextStyle(color: AppPal.inkSoft)),
        ]),
      );
    }
    return GridView.count(
      crossAxisCount: 3,
      mainAxisSpacing: 3,
      crossAxisSpacing: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: [
        for (final t in tiles)
          GestureDetector(
            onTap: () => _open(t),
            child: () {
              if (t.file != null && File(t.file!).existsSync()) {
                return Image.file(File(t.file!), fit: BoxFit.cover);
              }
              if (t.asset != null) return Image.asset(t.asset!, fit: BoxFit.cover);
              return Container(
                color: const Color(0xFFEDE7FF),
                padding: const EdgeInsets.all(8),
                alignment: Alignment.center,
                child: Text(t.text,
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 12)),
              );
            }(),
          ),
      ],
    );
  }

  void _requestsSheet(AppUser me) {
    final l = s.lang;
    showModalBottomSheet(
      context: context,
      builder: (ctx) => ListenableBuilder(
        listenable: s,
        builder: (c, _) => SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Text(tr(l, 'requestsTitle'),
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            ),
            for (final id in List<String>.from(me.requests))
              ListTile(
                leading: UserAvatar(user: s.userById(id), size: 40),
                title: Text(s.userById(id)?.username ?? id),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  TextButton(
                      onPressed: () => s.approve(id), child: Text(tr(l, 'accept'))),
                  TextButton(
                      onPressed: () => s.decline(id), child: Text(tr(l, 'decline'))),
                ]),
              ),
            const SizedBox(height: 8),
          ]),
        ),
      ),
    );
  }

  Widget _actions(AppUser u, bool own) {
    final l = s.lang;
    if (own) {
      return Column(children: [
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => ProfileSetupPage(s: s, editing: true))),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: AppPal.purple),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: Text(tr(l, 'editProfile'),
                style: const TextStyle(
                    color: AppPal.purple, fontWeight: FontWeight.w800)),
          ),
        ),
        if (u.requests.isNotEmpty)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.person_add_alt_1_outlined,
                color: AppPal.purple),
            title: Text(
                '${tr(l, 'requestsTitle')} (${L10n.of(l).num(u.requests.length)})'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _requestsSheet(u),
          ),
      ]);
    }
    final rel = s.relation(u);
    final String label = switch (rel) {
      'following' => tr(l, 'following'),
      'requested' => tr(l, 'requested'),
      _ => u.isPrivate ? tr(l, 'sendRequest') : tr(l, 'follow'),
    };
    final primary = rel == 'none';
    return Row(children: [
      Expanded(
        child: FilledButton(
          onPressed: () => primary ? s.follow(u) : s.unfollow(u),
          style: FilledButton.styleFrom(
            backgroundColor: primary ? AppPal.purple : const Color(0xFFE5E7EB),
            foregroundColor: primary ? Colors.white : AppPal.ink,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      ),
      const SizedBox(width: 10),
      Expanded(
        child: OutlinedButton(
          onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => ChatPage(s: s, otherId: u.id))),
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: AppPal.purple),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          child: Text(tr(l, 'message'),
              style: const TextStyle(
                  color: AppPal.purple, fontWeight: FontWeight.w800)),
        ),
      ),
    ]);
  }

  Widget _body(AppUser u) {
    final l = s.lang;
    final t = L10n.of(l);
    final own = u.id == s.meId;
    final canSee = s.canSee(u);
    final tiles = canSee ? _postsOf(u) : <_Tile>[];

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
      children: [
        if (own)
          Align(
            alignment: Alignment.topRight, // گوشه‌ی بالا-راست صفحه
            child: IconButton(
              tooltip: tr(l, 'messages'),
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => MessagesPage(s: s))),
              icon: const PigeonIcon(size: 36),
            ),
          ),
        Row(children: [
          UserAvatar(user: u, size: 84),
          const SizedBox(width: 18),
          Expanded(
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              _stat(t.num(tiles.length), tr(l, 'posts')),
              _stat(t.num(u.followers.length), tr(l, 'followers')),
              _stat(t.num(u.following.length), tr(l, 'following')),
            ]),
          ),
        ]),
        const SizedBox(height: 12),
        Text('@${u.username}',
            style: const TextStyle(
                fontWeight: FontWeight.w900, fontSize: 16, color: AppPal.ink)),
        if (u.bio.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(u.bio, style: const TextStyle(height: 1.5)),
          ),
        const SizedBox(height: 14),
        _actions(u, own),
        const SizedBox(height: 14),
        if (own)
          Row(children: [
            for (final i in [0, 1])
              Expanded(
                child: InkWell(
                  onTap: () => setState(() => _tab = i),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: _tab == i ? AppPal.purple : Colors.transparent,
                          width: 2.5,
                        ),
                      ),
                    ),
                    child: Icon(
                      i == 0 ? Icons.grid_on : Icons.bookmark_border,
                      color: _tab == i ? AppPal.purple : AppPal.inkSoft,
                    ),
                  ),
                ),
              ),
          ]),
        const SizedBox(height: 4),
        if (!canSee)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 44),
            child: Column(children: [
              const Icon(Icons.lock_outline, size: 46, color: AppPal.inkSoft),
              const SizedBox(height: 10),
              Text(tr(l, 'privateAcc'),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(tr(l, 'privateAccSub'),
                  style: const TextStyle(color: AppPal.inkSoft)),
            ]),
          )
        else if (own && _tab == 1)
          _grid(_savedTiles(), 'noSaved')
        else
          _grid(tiles, 'noPosts'),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final u = s.userById(widget.userId);
        final me = s.me;
        if (u == null || me == null) return const SizedBox();
        final blockedMe = u.blocked.contains(me.id);
        final Widget body = blockedMe
            ? Center(child: Text(tr(s.lang, 'unavailable')))
            : _body(u);
        if (!widget.standalone) return body;
        return Scaffold(
          appBar: AppBar(
            title: Text('@${u.username}'),
            actions: [
              if (u.id != me.id)
                PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'block') {
                      s.block(u);
                      Navigator.pop(context);
                    }
                  },
                  itemBuilder: (ctx) => [
                    PopupMenuItem(
                        value: 'block', child: Text(tr(s.lang, 'block'))),
                  ],
                ),
            ],
          ),
          body: body,
        );
      },
    );
  }
}
