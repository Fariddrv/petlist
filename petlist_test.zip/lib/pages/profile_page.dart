import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../i18n2.dart';
import '../l10n.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/pigeon.dart';
import '../widgets/smart_image.dart';
import '../widgets/post_media.dart';
import 'reels_page.dart';
import 'auth_pages.dart';
import 'messages_page.dart';
import 'follow_list_page.dart';
import 'notifications_page.dart';
import 'post_detail.dart';

class _Tile {
  final String id;
  final String? url;
  final String text;
  final bool video;
  final String? thumb;
  _Tile(this.id,
      {this.url, this.text = '', this.video = false, this.thumb});
}

/// پروفایل به سبک اینستاگرام. برای پروفایل خودِ کاربر (کبوتر پیام‌ها، ویرایش،
/// تب ذخیره‌شده‌ها) و برای پروفایل دیگران (Follow / Message) استفاده می‌شود.
class ProfilePage extends StatefulWidget {
  final AppState s;
  final String userId;
  final bool standalone; // true: با نوار بالا، به‌صورت صفحه‌ی جدا
  const ProfilePage(
      {super.key, required this.s, required this.userId, this.standalone = false});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  int _tab = 0; // 0 پست‌ها، 1 ذخیره‌شده‌ها

  AppState get s => widget.s;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await s.fetchUser(widget.userId, force: true);
    await s.loadUserPosts(widget.userId);
    if (widget.userId == s.meId) await s.loadSaved();
  }

  List<_Tile> _postsOf(AppUser u) => [
        for (final p in (s.userPosts[u.id] ?? const <UserPost>[]))
          _Tile(p.id,
              url: p.imagePath,
              text: p.text,
              video: p.mediaType == 'video',
              thumb: p.thumbUrl)
      ];

  List<_Tile> _savedTiles() => [
        for (final p in s.savedPosts)
          _Tile(p.id,
              url: p.imagePath,
              text: p.text,
              video: p.mediaType == 'video',
              thumb: p.thumbUrl)
      ];

  void _open(_Tile t) {
    if (t.video) {
      // فقط ویدئوهای همین فهرست (پست‌های این شخص یا ذخیره‌شده‌ها)
      final own = widget.userId == s.meId;
      final source = (own && _tab == 1)
          ? s.savedPosts
          : (s.userPosts[widget.userId] ?? const <UserPost>[]);
      final vids = source.where((p) => p.mediaType == 'video').toList();
      if (vids.any((p) => p.id == t.id)) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ReelsPage(s: s, posts: vids, initialId: t.id),
          ),
        );
        return;
      }
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PostDetailPage(s: s, postId: t.id),
      ),
    );
  }

  Widget _stat(String num, String label, {VoidCallback? onTap}) => InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        child: Column(children: [
        Text(num,
            style: const TextStyle(
                fontSize: 18, fontWeight: FontWeight.w900, color: AppPal.ink)),
        const SizedBox(height: 2),
        Text(label,
            style: const TextStyle(fontSize: 12.5, color: AppPal.inkSoft)),
      ])));

  Widget _grid(List<_Tile> tiles, String emptyKey) {
    final l = s.lang;
    if (tiles.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 44),
        child: Column(children: [
          Icon(_tab == 1 ? Icons.bookmark_border : Icons.photo_camera_outlined,
              size: 48, color: AppPal.inkSoft),
          const SizedBox(height: 10),
          Text(tr(l, emptyKey), style: const TextStyle(color: AppPal.inkSoft)),
        ]),
      );
    }
    return GridView.count(
      crossAxisCount: 3,
      mainAxisSpacing: 3,
      crossAxisSpacing: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: [
        for (final t in tiles)
          GestureDetector(
            onTap: () => _open(t),
            child: (t.url != null && t.url!.isNotEmpty)
                ? (t.video
                    ? VideoThumb(thumbUrl: t.thumb, iconSize: 36)
                    : SmartImage(src: t.url, fit: BoxFit.cover))
                : Container(
                    color: const Color(0xFFEDE7FF),
                    padding: const EdgeInsets.all(8),
                    alignment: Alignment.center,
                    child: Text(t.text,
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 12)),
                  ),
          ),
      ],
    );
  }

  void _requestsSheet() {
    final l = s.lang;
    showModalBottomSheet(
      context: context,
      builder: (ctx) => ListenableBuilder(
        listenable: s,
        builder: (c, _) {
          final ids = List<String>.from(s.me?.requests ?? const <String>[]);
          return SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(
                padding: const EdgeInsets.all(14),
                child: Text(tr(l, 'requestsTitle'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 16)),
              ),
              for (final id in ids)
                ListTile(
                  leading: UserAvatar(user: s.userById(id), size: 40),
                  title: Text(s.userById(id)?.username ?? id),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    TextButton(
                        onPressed: () => s.approve(id),
                        child: Text(tr(l, 'accept'))),
                    TextButton(
                        onPressed: () => s.decline(id),
                        child: Text(tr(l, 'decline'))),
                  ]),
                ),
              const SizedBox(height: 8),
            ]),
          );
        },
      ),
    );
  }

  Widget _actions(AppUser u, bool own) {
    final l = s.lang;
    if (own) {
      return Column(children: [
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => ProfileSetupPage(s: s, editing: true))),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: AppPal.purple),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: Text(tr(l, 'editProfile'),
                style: const TextStyle(
                    color: AppPal.purple, fontWeight: FontWeight.w800)),
          ),
        ),
        if (u.requests.isNotEmpty)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading:
                const Icon(Icons.person_add_alt_1_outlined, color: AppPal.purple),
            title: Text(
                '${tr(l, 'requestsTitle')} (${L10n.of(l).num(u.requests.length)})'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _requestsSheet,
          ),
      ]);
    }
    final rel = s.relation(u);
    final String label = switch (rel) {
      'following' => tr(l, 'following'),
      'requested' => tr(l, 'requested'),
      _ => u.isPrivate ? tr(l, 'sendRequest') : tr(l, 'follow'),
    };
    final primary = rel == 'none';
    return Row(children: [
      Expanded(
        child: FilledButton(
          onPressed: () => primary ? s.follow(u) : s.unfollow(u),
          style: FilledButton.styleFrom(
            backgroundColor: primary ? AppPal.purple : const Color(0xFFE5E7EB),
            foregroundColor: primary ? Colors.white : AppPal.ink,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      ),
      const SizedBox(width: 10),
      Expanded(
        child: OutlinedButton(
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => ChatPage(s: s, otherId: u.id))),
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: AppPal.purple),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          child: Text(tr(l, 'message'),
              style: const TextStyle(
                  color: AppPal.purple, fontWeight: FontWeight.w800)),
        ),
      ),
    ]);
  }

  Widget _body(AppUser u) {
    final l = s.lang;
    final t = L10n.of(l);
    final own = u.id == s.meId;
    final canSee = s.canSee(u);
    final tiles = canSee ? _postsOf(u) : <_Tile>[];
    final postsCount = canSee ? tiles.length : u.postsCount;

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
        children: [
          if (own)
            Row(children: [
              IconButton(
                tooltip: tr(l, 'notifications'),
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => NotificationsPage(s: s))),
                icon: s.hasUnreadNotifications
                    ? const Icon(Icons.favorite,
                        size: 32, color: Color(0xFFE0245E))
                    : const Icon(Icons.favorite_border,
                        size: 32, color: AppPal.inkSoft),
              ),
              const Spacer(),
              IconButton(
                tooltip: tr(l, 'messages'),
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => MessagesPage(s: s))),
                icon: Stack(clipBehavior: Clip.none, children: [
                  PigeonIcon(
                      size: 36,
                      color: s.hasUnreadMessages
                          ? const Color(0xFFE0245E)
                          : const Color(0xFF7C5CFF)),
                  if (s.hasUnreadMessages)
                    Positioned(
                      right: -2,
                      top: -2,
                      child: Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          color: const Color(0xFFE0245E),
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                      ),
                    ),
                ]),
              ),
            ]),
          Row(children: [
            UserAvatar(user: u, size: 84),
            const SizedBox(width: 18),
            Expanded(
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                _stat(t.num(postsCount), tr(l, 'posts')),
                _stat(t.num(u.followersCount), tr(l, 'followers'),
                    onTap: canSee
                        ? () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => FollowListPage(
                                    s: s, userId: u.id, followers: true)))
                        : null),
                _stat(t.num(u.followingCount), tr(l, 'following'),
                    onTap: canSee
                        ? () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => FollowListPage(
                                    s: s, userId: u.id, followers: false)))
                        : null),
              ]),
            ),
          ]),
          const SizedBox(height: 12),
          Text('@${u.username}',
              style: const TextStyle(
                  fontWeight: FontWeight.w900, fontSize: 16, color: AppPal.ink)),
          if (u.bio.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(u.bio, style: const TextStyle(height: 1.5)),
            ),
          if (u.links.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Wrap(spacing: 8, runSpacing: 4, children: [
                for (final link in u.links)
                  ActionChip(
                    avatar: const Icon(Icons.link, size: 16, color: AppPal.purple),
                    label: Text(
                      Uri.tryParse(link)?.host.replaceFirst('www.', '') ?? link,
                      textDirection: TextDirection.ltr,
                    ),
                    onPressed: () async {
                      final uri = Uri.tryParse(link);
                      if (uri == null) return;
                      try {
                        await launchUrl(uri, mode: LaunchMode.externalApplication);
                      } catch (_) {}
                    },
                  ),
              ]),
            ),
          const SizedBox(height: 14),
          _actions(u, own),
          const SizedBox(height: 14),
          if (own)
            Row(children: [
              for (final i in [0, 1])
                Expanded(
                  child: InkWell(
                    onTap: () => setState(() => _tab = i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: _tab == i ? AppPal.purple : Colors.transparent,
                            width: 2.5,
                          ),
                        ),
                      ),
                      child: Icon(
                        i == 0 ? Icons.grid_on : Icons.bookmark_border,
                        color: _tab == i ? AppPal.purple : AppPal.inkSoft,
                      ),
                    ),
                  ),
                ),
            ]),
          const SizedBox(height: 4),
          if (!canSee)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 44),
              child: Column(children: [
                const Icon(Icons.lock_outline, size: 46, color: AppPal.inkSoft),
                const SizedBox(height: 10),
                Text(tr(l, 'privateAcc'),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(tr(l, 'privateAccSub'),
                    style: const TextStyle(color: AppPal.inkSoft)),
              ]),
            )
          else if (own && _tab == 1)
            _grid(_savedTiles(), 'noSaved')
          else
            _grid(tiles, 'noPosts'),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final u = s.userById(widget.userId);
        final me = s.me;
        if (u == null || me == null) {
          return widget.standalone
              ? Scaffold(
                  appBar: AppBar(),
                  body: const Center(child: CircularProgressIndicator()))
              : const Center(child: CircularProgressIndicator());
        }
        final body = _body(u);
        if (!widget.standalone) return body;
        return Scaffold(
          appBar: AppBar(
            title: Text(u.username),
            actions: [
              if (u.id != me.id)
                PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (v == 'block') {
                      await s.block(u);
                      if (context.mounted) Navigator.pop(context);
                    }
                    if (v == 'report' && context.mounted) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => ReportPage(
                                  s: s, type: 'account', targetId: u.id)));
                    }
                  },
                  itemBuilder: (ctx) => [
                    PopupMenuItem(
                        value: 'block', child: Text(tr(s.lang, 'block'))),
                    PopupMenuItem(
                        value: 'report', child: Text(tr(s.lang, 'report'))),
                  ],
                ),
            ],
          ),
          body: body,
        );
      },
    );
  }
}
