import 'dart:async';
import 'package:flutter/material.dart';

import '../i18n2.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import 'profile_page.dart';

/// جستجوی کاربران با آیدی (نام کاربری)؛ کشور و شهر مهم نیست.
class SearchPage extends StatefulWidget {
  final AppState s;
  const SearchPage({super.key, required this.s});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _ctrl = TextEditingController();
  Timer? _debounce;
  List<AppUser> _results = [];
  bool _loading = false;
  bool _searched = false;

  @override
  void dispose() {
    _debounce?.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  void _onChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () async {
      final q = v.trim().replaceFirst('@', '');
      if (q.length < 2) {
        if (mounted) setState(() => _results = []);
        return;
      }
      setState(() => _loading = true);
      final r = await widget.s.searchUsers(q);
      if (!mounted) return;
      setState(() {
        _results = r;
        _loading = false;
        _searched = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _ctrl,
          autofocus: true,
          autocorrect: false,
          onChanged: _onChanged,
          decoration: InputDecoration(
            hintText: tr(l, 'searchHint'),
            prefixIcon: const Icon(Icons.search),
            border: InputBorder.none,
            filled: false,
          ),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _results.isEmpty
              ? Center(
                  child: Text(
                    _searched ? tr(l, 'noResults') : tr(l, 'searchHelp'),
                    style: const TextStyle(color: AppPal.inkSoft),
                  ),
                )
              : ListView.separated(
                  itemCount: _results.length,
                  separatorBuilder: (c, i) =>
                      const Divider(height: 1, indent: 72),
                  itemBuilder: (c, i) {
                    final u = _results[i];
                    return ListTile(
                      leading: UserAvatar(user: u, size: 46),
                      title: Text('@${u.username}',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: u.bio.isEmpty
                          ? null
                          : Text(u.bio,
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProfilePage(
                              s: widget.s, userId: u.id, standalone: true),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
