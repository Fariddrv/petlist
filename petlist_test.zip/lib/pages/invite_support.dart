import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../i18n2.dart';
import '../state.dart';
import '../theme.dart';

// ======================= دعوت از دوستان =======================
class InvitePage extends StatelessWidget {
  final AppState s;
  const InvitePage({super.key, required this.s});

  String get _text => '${tr(s.lang, 'inviteText')}\n$kInviteLink';

  Future<void> _open(BuildContext context, Uri uri) async {
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok && context.mounted) _toast(context, tr(s.lang, 'errNet'));
    } catch (_) {
      if (context.mounted) _toast(context, tr(s.lang, 'errNet'));
    }
  }

  void _toast(BuildContext context, String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  @override
  Widget build(BuildContext context) {
    final l = s.lang;
    Widget tile(IconData i, String key, VoidCallback onTap) => ListTile(
          leading: Icon(i, color: AppPal.purple),
          title: Text(tr(l, key),
              style: const TextStyle(fontWeight: FontWeight.w700)),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        );
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'invite'))),
      body: ListView(children: [
        Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFFEDE7FF),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(_text, style: const TextStyle(height: 1.6)),
        ),
        tile(Icons.share_outlined, 'shareApp',
            () => Share.share(_text)),
        tile(Icons.email_outlined, 'byEmail', () {
          _open(
              context,
              Uri(
                scheme: 'mailto',
                queryParameters: {'subject': 'pawpet', 'body': _text},
              ));
        }),
        tile(Icons.sms_outlined, 'bySms', () {
          _open(context, Uri(scheme: 'sms', queryParameters: {'body': _text}));
        }),
        tile(Icons.link, 'copyLink', () {
          Clipboard.setData(ClipboardData(text: kInviteLink));
          _toast(context, tr(l, 'linkCopied'));
        }),
      ]),
    );
  }
}

// ======================= پشتیبانی =======================
class SupportPage extends StatefulWidget {
  final AppState s;
  const SupportPage({super.key, required this.s});

  @override
  State<SupportPage> createState() => _SupportPageState();
}

class _SupportPageState extends State<SupportPage> {
  final _name = TextEditingController();
  final _subject = TextEditingController();
  final _message = TextEditingController();
  final _captcha = TextEditingController();
  bool _human = false;
  bool _busy = false;
  String _code = '';
  String? _err;

  @override
  void initState() {
    super.initState();
    _name.text = widget.s.me?.username ?? '';
    _newCode();
  }

  @override
  void dispose() {
    for (final c in [_name, _subject, _message, _captcha]) {
      c.dispose();
    }
    super.dispose();
  }

  void _newCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = Random.secure();
    setState(() {
      _code = List.generate(5, (_) => chars[r.nextInt(chars.length)]).join();
      _captcha.clear();
    });
  }

  Future<void> _send() async {
    final l = widget.s.lang;
    if (_name.text.trim().isEmpty ||
        _subject.text.trim().isEmpty ||
        _message.text.trim().isEmpty) {
      setState(() => _err = 'errFill');
      return;
    }
    if (_captcha.text.trim().toUpperCase() != _code) {
      setState(() => _err = 'errCaptcha');
      _newCode();
      return;
    }
    if (!_human) {
      setState(() => _err = 'errRobot');
      return;
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    final ok = await widget.s
        .submitSupport(_name.text, _subject.text, _message.text);
    if (!mounted) return;
    if (!ok) {
      setState(() {
        _busy = false;
        _err = 'errNet';
      });
      return;
    }
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(tr(l, 'supportSent'))));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'support'))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.email_outlined, color: AppPal.purple),
          title: Text(tr(l, 'supportEmail')),
          subtitle: Text(kSupportEmail, textDirection: TextDirection.ltr,
              textAlign: l.name == 'fa' ? TextAlign.right : TextAlign.left),
        ),
        const Divider(),
        const SizedBox(height: 8),
        TextField(
            controller: _name,
            decoration: InputDecoration(labelText: tr(l, 'yourName'))),
        const SizedBox(height: 12),
        TextField(
            controller: _subject,
            decoration: InputDecoration(labelText: tr(l, 'subject'))),
        const SizedBox(height: 12),
        TextField(
          controller: _message,
          minLines: 5,
          maxLines: 10,
          decoration: InputDecoration(labelText: tr(l, 'messageBody')),
        ),
        const SizedBox(height: 16),
        Row(children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xFFEDE7FF),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(_code,
                textDirection: TextDirection.ltr,
                style: const TextStyle(
                    fontSize: 22,
                    letterSpacing: 6,
                    fontWeight: FontWeight.w900,
                    color: AppPal.purpleDark)),
          ),
          IconButton(onPressed: _newCode, icon: const Icon(Icons.refresh)),
          Expanded(
            child: TextField(
              controller: _captcha,
              textCapitalization: TextCapitalization.characters,
              autocorrect: false,
              decoration: InputDecoration(hintText: tr(l, 'captchaHint')),
            ),
          ),
        ]),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          value: _human,
          activeColor: AppPal.purple,
          onChanged: (v) => setState(() => _human = v ?? false),
          title: Text(tr(l, 'notRobot')),
        ),
        if (_err != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(tr(l, _err!),
                style: const TextStyle(color: Color(0xFFB3261E), fontSize: 13)),
          ),
        FilledButton(
          onPressed: _busy ? null : _send,
          style: FilledButton.styleFrom(
            backgroundColor: AppPal.purple,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: Text(tr(l, 'send'),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
      ]),
    );
  }
}

