import 'dart:async';

import 'package:flutter/material.dart';

import '../data/shop_catalog.dart';
import '../i18n2.dart';
import '../shop_models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/ad_slider.dart';
import '../widgets/shop_widgets.dart';
import 'listing_detail_page.dart';
import 'shop_dashboard_page.dart';

/// تب فروشگاه: مارکت‌پلیس محصولات و خدمات حیوانات خانگی.
class ShopPage extends StatefulWidget {
  final AppState s;
  const ShopPage({super.key, required this.s});

  @override
  State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {
  final _q = TextEditingController();
  Timer? _debounce;
  String? _category;
  late bool _local = (widget.s.me?.country ?? '').isNotEmpty;
  List<Listing> _items = [];
  bool _loading = true;

  AppState get s => widget.s;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _q.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final r = await s.shop.browse(
      query: _q.text,
      category: _category,
      localOnly: _local,
    );
    if (!mounted) return;
    setState(() {
      _items = r;
      _loading = false;
    });
  }

  void _onSearch(String _) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 450), _load);
  }

  Widget _sellerCard() {
    final l = s.lang;
    final shop = s.shop.myShop;
    return GestureDetector(
      onTap: () => openMyShop(context, s),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: AppPal.purpleGradient,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(children: [
          const Icon(Icons.storefront, color: Colors.white, size: 30),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              shop == null ? tr(l, 'shSellerBanner') : '${tr(l, 'shMyShop')}: ${shop.name}',
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14.5),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppPal.yellow,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              shop == null ? tr(l, 'shCreateShop') : tr(l, 'shDashboard'),
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.5),
            ),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([s, s.shop]),
      builder: (c, _) {
        final l = s.lang;
        final hasLoc = (s.me?.country ?? '').isNotEmpty;
        return RefreshIndicator(
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              AdSlider(lang: l, placement: 'shop'),
              const SizedBox(height: 14),
              _sellerCard(),
              const SizedBox(height: 14),
              TextField(
                controller: _q,
                onChanged: _onSearch,
                decoration: InputDecoration(
                  hintText: tr(l, 'shSearch'),
                  prefixIcon: const Icon(Icons.search),
                ),
              ),
              if (hasLoc)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Wrap(spacing: 8, children: [
                    ChoiceChip(
                      label: Text(tr(l, 'shMyArea')),
                      selected: _local,
                      onSelected: (_) {
                        setState(() => _local = true);
                        _load();
                      },
                    ),
                    ChoiceChip(
                      label: Text(tr(l, 'shEverywhere')),
                      selected: !_local,
                      onSelected: (_) {
                        setState(() => _local = false);
                        _load();
                      },
                    ),
                  ]),
                ),
              const SizedBox(height: 10),
              SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: ChoiceChip(
                        label: Text(tr(l, 'shAll')),
                        selected: _category == null,
                        onSelected: (_) {
                          setState(() => _category = null);
                          _load();
                        },
                      ),
                    ),
                    for (final cat in shopCategories)
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 8),
                        child: ChoiceChip(
                          label: Text('${cat.emoji} ${cat.name(l)}'),
                          selected: _category == cat.key,
                          onSelected: (_) {
                            setState(() => _category = cat.key);
                            _load();
                          },
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              if (_loading)
                const Padding(
                  padding: EdgeInsets.all(40),
                  child: Center(child: CircularProgressIndicator()),
                )
              else if (_items.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 50),
                  child: Column(children: [
                    const Text('🛍️', style: TextStyle(fontSize: 46)),
                    const SizedBox(height: 8),
                    Text(tr(l, 'shNoResults'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: AppPal.inkSoft, height: 1.6)),
                  ]),
                )
              else
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: .72,
                  ),
                  itemCount: _items.length,
                  itemBuilder: (c, i) => ListingCard(
                    item: _items[i],
                    lang: l,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ListingDetailPage(s: s, item: _items[i]),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
