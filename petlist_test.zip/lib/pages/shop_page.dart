import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets/ad_slider.dart';

/// تب فروشگاه: ویترین نمونه (فاز بعد: فروشندگان واقعی + پرداخت).
class ShopPage extends StatelessWidget {
  final AppLang lang;
  const ShopPage({super.key, required this.lang});

  void _snack(BuildContext context, String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AdSlider(lang: lang),
        const SizedBox(height: 16),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.70,
          children: [
            for (final p in sampleProducts)
              Container(
                clipBehavior: Clip.antiAlias,
                decoration: AppPal.softCard(),
                child: InkWell(
                  onTap: () => _snack(context, t.shopTapHint),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      AspectRatio(
                        aspectRatio: 1,
                        child: Image.asset(p.image, fit: BoxFit.cover),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
                        child: Text(
                          p.title.of(lang),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 13,
                              color: AppPal.ink,
                              height: 1.4),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            gradient: AppPal.purpleGradient,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            t.price(p.price),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                fontSize: 12),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}
