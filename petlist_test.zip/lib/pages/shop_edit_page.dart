import 'dart:io';

import 'package:flutter/material.dart';

import '../i18n2.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/location_fields.dart';
import '../widgets/shop_widgets.dart';

/// ویرایش مشخصات فروشگاه.
class ShopEditPage extends StatefulWidget {
  final AppState s;
  const ShopEditPage({super.key, required this.s});

  @override
  State<ShopEditPage> createState() => _ShopEditPageState();
}

class _ShopEditPageState extends State<ShopEditPage> {
  late final _sh = widget.s.shop.myShop!;
  late final _name = TextEditingController(text: _sh.name);
  late final _desc = TextEditingController(text: _sh.description);
  late final _phone = TextEditingController(text: _sh.phone);
  late final _email = TextEditingController(text: _sh.email);
  late final _address = TextEditingController(text: _sh.address);
  late String _country = _sh.country;
  late String _city = _sh.city;
  String? _logo;
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_name, _desc, _phone, _email, _address]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    final l = widget.s.lang;
    if (_name.text.trim().isEmpty) return;
    setState(() => _busy = true);
    final e = await widget.s.shop.updateShop(
      name: _name.text,
      description: _desc.text,
      phone: _phone.text,
      email: _email.text,
      address: _address.text,
      country: _country,
      city: _city,
      logoPath: _logo,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(tr(l, e == null ? 'shSaved' : e))));
    if (e == null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'shEditShop'))),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Center(
          child: GestureDetector(
            onTap: () async {
              final p = await pickImagePath(context, l);
              if (p != null) setState(() => _logo = p);
            },
            child: _logo != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(27),
                    child: Image.file(File(_logo!), width: 96, height: 96, fit: BoxFit.cover))
                : ShopLogo(url: _sh.logoUrl, name: _sh.name, size: 96),
          ),
        ),
        const SizedBox(height: 16),
        TextField(controller: _name, decoration: InputDecoration(labelText: tr(l, 'shShopName'))),
        const SizedBox(height: 12),
        LocationFields(
          lang: l,
          country: _country,
          city: _city,
          onChanged: (c, ct) {
            _country = c;
            _city = ct;
          },
        ),
        const SizedBox(height: 12),
        TextField(controller: _address, maxLines: 2, decoration: InputDecoration(labelText: tr(l, 'shAddress'))),
        const SizedBox(height: 12),
        TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: tr(l, 'shPhone'))),
        const SizedBox(height: 12),
        TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: InputDecoration(labelText: tr(l, 'email'))),
        const SizedBox(height: 12),
        TextField(controller: _desc, minLines: 3, maxLines: 6, decoration: InputDecoration(labelText: tr(l, 'shDescription'))),
        const SizedBox(height: 18),
        FilledButton(
          onPressed: _busy ? null : _save,
          style: FilledButton.styleFrom(
            backgroundColor: AppPal.purple,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: Text(tr(l, 'save'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
      ]),
    );
  }
}
