import 'package:flutter/material.dart';

import '../data/timeago.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import '../widgets/comments.dart';
import '../widgets/image_viewer.dart';
import '../widgets/post_media.dart';
import '../widgets/smart_image.dart';
import 'edit_post_page.dart';
import 'profile_page.dart';

// ======================= ارسال پست برای دوستان =======================
void showShareSheet(BuildContext context, AppState s, String postId) {
  final l = s.lang;
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
    ),
    builder: (ctx) => SizedBox(
      height: MediaQuery.of(ctx).size.height * .6,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text(tr(l, 'sendTo'),
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        ),
        const Divider(height: 1),
        Expanded(
          child: FutureBuilder<List<AppUser>>(
            future: s.shareTargets(),
            builder: (c, snap) {
              if (!snap.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final list = snap.data!;
              if (list.isEmpty) {
                return Center(
                    child: Text(tr(l, 'noFriends'),
                        style: const TextStyle(color: AppPal.inkSoft)));
              }
              return ListView.builder(
                itemCount: list.length,
                itemBuilder: (c, i) {
                  final u = list[i];
                  return ListTile(
                    leading: UserAvatar(user: u, size: 42),
                    title: Text(u.username,
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    trailing: const Icon(Icons.send, color: AppPal.purple),
                    onTap: () {
                      s.sendMsg(u.id, '', postId: postId);
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text(tr(l, 'sentOk'))));
                    },
                  );
                },
              );
            },
          ),
        ),
      ]),
    ),
  );
}

// ======================= گزارش پست یا حساب =======================
class ReportPage extends StatefulWidget {
  final AppState s;
  final String type; // post | account
  final String targetId;
  const ReportPage(
      {super.key, required this.s, required this.type, required this.targetId});

  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage> {
  static const _reasons = [
    'rSpam', 'rAbuse', 'rViolence', 'rSexual', 'rFake', 'rIllegal', 'rOther'
  ];
  String? _picked;
  bool _busy = false;

  Future<void> _submit() async {
    final l = widget.s.lang;
    if (_picked == null) return;
    setState(() => _busy = true);
    final ok = await widget.s.submitReport(widget.type, widget.targetId, _picked!);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr(l, ok ? 'reportSent' : 'errNet'))));
    if (ok) Navigator.pop(context);
    setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    final isPost = widget.type == 'post';
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, isPost ? 'reportPost' : 'reportAccount'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(tr(l, isPost ? 'reportWhyPost' : 'reportWhyAccount'),
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 8),
        for (final r in _reasons)
          RadioListTile<String>(
            value: r,
            groupValue: _picked,
            activeColor: AppPal.purple,
            title: Text(tr(l, r)),
            onChanged: (v) => setState(() => _picked = v),
          ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: (_picked == null || _busy) ? null : _submit,
          style: FilledButton.styleFrom(
            backgroundColor: AppPal.purple,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: Text(tr(l, 'reportSubmit'),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
      ]),
    );
  }
}

// ======================= صفحه‌ی کامل پست =======================
class PostDetailPage extends StatefulWidget {
  final AppState s;
  final String postId;
  const PostDetailPage({super.key, required this.s, required this.postId});

  @override
  State<PostDetailPage> createState() => _PostDetailPageState();
}

class _PostDetailPageState extends State<PostDetailPage> {
  ReplyTarget? _reply;
  bool _loading = false;

  AppState get s => widget.s;

  @override
  void initState() {
    super.initState();
    if (s.findPost(widget.postId) == null) {
      _loading = true;
      s.fetchPost(widget.postId).then((_) {
        if (mounted) setState(() => _loading = false);
      });
    }
  }

  Future<void> _delete(UserPost p) async {
    final t = L10n.of(s.lang);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(t.deleteConfirm),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false), child: Text(t.cancel)),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(t.delete,
                  style: const TextStyle(color: Color(0xFFB3261E)))),
        ],
      ),
    );
    if (ok == true) {
      await s.removePost(p);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final p = s.findPost(widget.postId);
        if (p == null) {
          return Scaffold(
            appBar: AppBar(),
            body: Center(
                child: _loading
                    ? const CircularProgressIndicator()
                    : Text(tr(l, 'unavailable'))),
          );
        }
        final st = s.inter[p.id] ?? const PostInter(comments: []);
        final own = p.ownerId == s.meId;
        final hasImg = p.imagePath != null && p.imagePath!.isNotEmpty;
        final likes = p.likes + (st.liked ? 1 : 0);
        return Scaffold(
          appBar: AppBar(
            actions: [
              PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'delete') _delete(p);
                  if (v == 'edit') {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => EditPostPage(s: s, post: p)));
                  }
                  if (v == 'report') {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => ReportPage(
                                s: s, type: 'post', targetId: p.id)));
                  }
                },
                itemBuilder: (ctx) => [
                  if (own) ...[
                    PopupMenuItem(
                        value: 'edit', child: Text(tr(l, 'editPost'))),
                    PopupMenuItem(
                        value: 'delete', child: Text(tr(l, 'removePost'))),
                  ] else
                    PopupMenuItem(
                        value: 'report', child: Text(tr(l, 'reportPost'))),
                ],
              ),
            ],
          ),
          body: Column(children: [
            Expanded(
              child: ListView(children: [
                ListTile(
                  leading: AvatarCircle(
                      url: p.authorAvatar, name: p.author, size: 42),
                  title: Text(p.author,
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(timeAgo(p.createdAt, l)),
                  onTap: own
                      ? null
                      : () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => ProfilePage(
                                  s: s, userId: p.ownerId, standalone: true))),
                ),
                if (hasImg)
                  MediaOverlay(
                    location: p.locationText,
                    tags: p.tags,
                    onTagTap: (id) => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => ProfilePage(
                                s: s, userId: id, standalone: true))),
                    child: p.mediaType == 'video'
                        ? PostVideo(url: p.imagePath!)
                        : GestureDetector(
                            onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) =>
                                        ImageViewerPage(src: p.imagePath!))),
                            child: SmartImage(
                                src: p.imagePath, fit: BoxFit.fitWidth),
                          ),
                  ),
                if (p.text.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
                    child: Text(p.text, style: const TextStyle(height: 1.6)),
                  ),
                Row(children: [
                  IconButton(
                    onPressed: () => s.toggleLike(p.id),
                    icon: Icon(
                        st.liked ? Icons.favorite : Icons.favorite_border,
                        color: st.liked ? const Color(0xFFE0245E) : AppPal.ink),
                  ),
                  Text('$likes',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(width: 10),
                  const Icon(Icons.chat_bubble_outline, size: 22),
                  const SizedBox(width: 4),
                  Text('${st.comments.length}',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  const Spacer(),
                  IconButton(
                    onPressed: () => s.toggleSave(p.id),
                    icon: Icon(
                        st.saved ? Icons.bookmark : Icons.bookmark_border,
                        color: st.saved ? AppPal.purple : AppPal.ink),
                  ),
                  IconButton(
                    onPressed: () => showShareSheet(context, s, p.id),
                    icon: const Icon(Icons.send_outlined),
                  ),
                ]),
                const Divider(height: 1),
                CommentsList(
                  s: s,
                  postId: p.id,
                  onReply: (r) => setState(() => _reply = r),
                ),
                const SizedBox(height: 20),
              ]),
            ),
            CommentInputBar(
              s: s,
              postId: p.id,
              reply: _reply,
              onClearReply: () => setState(() => _reply = null),
            ),
          ]),
        );
      },
    );
  }
}
