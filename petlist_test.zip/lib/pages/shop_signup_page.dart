import 'dart:io';

import 'package:flutter/material.dart';

import '../data/shop_catalog.dart';
import '../i18n2.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/location_fields.dart';
import '../widgets/shop_widgets.dart';
import 'legal_pages.dart';

const String kVendorTermsVersion = 'vendor-2026-10';

/// ساخت فروشگاه: مرحله‌ی ۱ قرارداد، مرحله‌ی ۲ مشخصات و مدارک.
class ShopSignupPage extends StatefulWidget {
  final AppState s;
  const ShopSignupPage({super.key, required this.s});

  @override
  State<ShopSignupPage> createState() => _ShopSignupPageState();
}

class _ShopSignupPageState extends State<ShopSignupPage> {
  int _step = 0;
  bool _accepted = false;

  final _name = TextEditingController();
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _address = TextEditingController();
  final _desc = TextEditingController();
  late String _country = widget.s.me?.country ?? '';
  late String _city = widget.s.me?.city ?? '';
  final Set<String> _types = {};
  String? _logo;
  final Map<String, String> _docs = {}; // kind -> path
  String? _err;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _email.text = widget.s.me?.email ?? '';
  }

  @override
  void dispose() {
    for (final c in [_name, _first, _last, _phone, _email, _address, _desc]) {
      c.dispose();
    }
    super.dispose();
  }

  /// مدارک لازم بر اساس نوع فعالیت: kind -> الزامی بودن
  Map<String, bool> get _docSlots {
    final m = <String, bool>{'national_id': true};
    for (final k in _types) {
      final t = shopTypeOf(k);
      if (t?.extraDoc != null) {
        m[t!.extraDoc!] = (m[t.extraDoc!] ?? false) || t.extraRequired;
      }
    }
    return m;
  }

  String _docLabel(String kind) => tr(widget.s.lang, switch (kind) {
        'national_id' => 'shDocNational',
        'vet_council' => 'shDocVet',
        'animal_permit' => 'shDocPermit',
        _ => 'shDocLicense',
      });

  Future<void> _submit() async {
    final l = widget.s.lang;
    if (_name.text.trim().isEmpty ||
        _first.text.trim().isEmpty ||
        _last.text.trim().isEmpty ||
        _phone.text.trim().isEmpty ||
        _address.text.trim().isEmpty ||
        _country.isEmpty ||
        _city.isEmpty ||
        _types.isEmpty) {
      setState(() => _err = 'errFill');
      return;
    }
    for (final e in _docSlots.entries) {
      if (e.value && !_docs.containsKey(e.key)) {
        setState(() => _err = 'shErrDoc');
        return;
      }
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    final e = await widget.s.shop.createShop(
      name: _name.text,
      description: _desc.text,
      phone: _phone.text,
      email: _email.text,
      address: _address.text,
      country: _country,
      city: _city,
      types: _types.toList(),
      contactFirst: _first.text,
      contactLast: _last.text,
      termsVersion: kVendorTermsVersion,
      logoPath: _logo,
      docs: Map.of(_docs)..removeWhere((k, v) => !_docSlots.containsKey(k)),
    );
    if (!mounted) return;
    if (e != null) {
      setState(() {
        _busy = false;
        _err = e;
      });
      return;
    }
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(tr(l, 'shSubmitted'))));
    Navigator.pop(context);
  }

  Widget _step1() {
    final s = widget.s;
    final l = s.lang;
    return ListView(padding: const EdgeInsets.all(20), children: [
      Text(tr(l, 'shAgreementTitle'),
          style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
      const SizedBox(height: 10),
      Text(tr(l, 'shAgreementIntro'), style: const TextStyle(height: 1.7)),
      const SizedBox(height: 14),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFEDE7FF),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(
          tr(l, 'shCommissionIs').replaceAll('{x}', '${s.shop.commissionPercent}'),
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      const SizedBox(height: 8),
      for (final k in ['vendor', 'subscription'])
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.description_outlined, color: AppPal.purple),
          title: Text(tr(l, k == 'vendor' ? 'vendorTitle' : 'subscriptionTitle')),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => LegalPage(lang: l, kind: k))),
        ),
      CheckboxListTile(
        contentPadding: EdgeInsets.zero,
        controlAffinity: ListTileControlAffinity.leading,
        value: _accepted,
        activeColor: AppPal.purple,
        onChanged: (v) => setState(() => _accepted = v ?? false),
        title: Text(tr(l, 'shReadAccept'), style: const TextStyle(fontSize: 13.5)),
      ),
      const SizedBox(height: 10),
      FilledButton(
        onPressed: _accepted ? () => setState(() => _step = 1) : null,
        style: FilledButton.styleFrom(
          backgroundColor: AppPal.purple,
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        child: Text(tr(l, 'shNext'),
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      ),
    ]);
  }

  Widget _docTile(String kind, bool required) {
    final l = widget.s.lang;
    final path = _docs[kind];
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0x22000000)),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: SizedBox(
            width: 54,
            height: 54,
            child: path == null
                ? Container(
                    color: AppPal.bg,
                    child: const Icon(Icons.badge_outlined, color: AppPal.inkSoft))
                : Image.file(File(path), fit: BoxFit.cover),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text('${_docLabel(kind)}${required ? ' *' : ''}',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
        ),
        TextButton(
          onPressed: () async {
            final p = await pickImagePath(context, l);
            if (p != null) setState(() => _docs[kind] = p);
          },
          child: Text(tr(l, path == null ? 'shUpload' : 'shChange')),
        ),
      ]),
    );
  }

  Widget _step2() {
    final s = widget.s;
    final l = s.lang;
    final slots = _docSlots;
    return ListView(padding: const EdgeInsets.all(20), children: [
      Center(
        child: GestureDetector(
          onTap: () async {
            final p = await pickImagePath(context, l);
            if (p != null) setState(() => _logo = p);
          },
          child: Stack(children: [
            _logo == null
                ? const ShopLogo(name: '+', size: 96)
                : ClipRRect(
                    borderRadius: BorderRadius.circular(27),
                    child: Image.file(File(_logo!), width: 96, height: 96, fit: BoxFit.cover)),
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.all(7),
                decoration: const BoxDecoration(
                    color: AppPal.yellow, shape: BoxShape.circle),
                child: const Icon(Icons.add_a_photo_outlined,
                    size: 16, color: Colors.white),
              ),
            ),
          ]),
        ),
      ),
      const SizedBox(height: 4),
      Center(
          child: Text(tr(l, 'shLogo'),
              style: const TextStyle(color: AppPal.inkSoft, fontSize: 12))),
      const SizedBox(height: 14),
      TextField(
          controller: _name,
          decoration: InputDecoration(labelText: tr(l, 'shShopName'))),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: TextField(
              controller: _first,
              decoration: InputDecoration(labelText: tr(l, 'firstName'))),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: TextField(
              controller: _last,
              decoration: InputDecoration(labelText: tr(l, 'lastName'))),
        ),
      ]),
      const SizedBox(height: 14),
      Text(tr(l, 'shShopType'), style: const TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      Wrap(spacing: 8, runSpacing: 6, children: [
        for (final t in shopTypes)
          FilterChip(
            label: Text('${t.emoji} ${t.name(l)}'),
            selected: _types.contains(t.key),
            onSelected: (v) => setState(() {
              v ? _types.add(t.key) : _types.remove(t.key);
            }),
          ),
      ]),
      const SizedBox(height: 14),
      LocationFields(
        lang: l,
        country: _country,
        city: _city,
        onChanged: (c, ct) {
          _country = c;
          _city = ct;
        },
      ),
      const SizedBox(height: 12),
      TextField(
          controller: _address,
          maxLines: 2,
          decoration: InputDecoration(labelText: tr(l, 'shAddress'))),
      const SizedBox(height: 12),
      TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: InputDecoration(labelText: tr(l, 'shPhone'))),
      const SizedBox(height: 12),
      TextField(
          controller: _email,
          keyboardType: TextInputType.emailAddress,
          decoration: InputDecoration(labelText: tr(l, 'email'))),
      const SizedBox(height: 12),
      TextField(
          controller: _desc,
          minLines: 3,
          maxLines: 6,
          decoration: InputDecoration(labelText: tr(l, 'shDescription'))),
      const SizedBox(height: 16),
      Text(tr(l, 'shDocs'), style: const TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 4),
      Text(tr(l, 'shDocsPrivate'),
          style: const TextStyle(color: AppPal.inkSoft, fontSize: 12.5, height: 1.5)),
      const SizedBox(height: 10),
      for (final e in slots.entries) _docTile(e.key, e.value),
      if (_err != null)
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(
            tr(l, _err!) +
                ((_err == 'errNet' && s.shop.lastError.isNotEmpty)
                    ? '\n[${s.shop.lastError}]'
                    : ''),
            style: const TextStyle(color: Color(0xFFB3261E), fontSize: 13),
          ),
        ),
      const SizedBox(height: 14),
      FilledButton(
        onPressed: _busy ? null : _submit,
        style: FilledButton.styleFrom(
          backgroundColor: AppPal.purple,
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        child: _busy
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
            : Text(tr(l, 'shSubmit'),
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      ),
      const SizedBox(height: 20),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'shCreateShop'))),
      body: _step == 0 ? _step1() : _step2(),
    );
  }
}
