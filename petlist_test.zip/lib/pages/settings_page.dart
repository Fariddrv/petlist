import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../l10n.dart';
import '../theme.dart';

/// صفحه‌ی تنظیمات و پشتیبان‌گیری: گرفتن پشتیبان از همه‌ی داده‌ها و بازگردانی آن.
class SettingsPage extends StatefulWidget {
  final AppLang lang;
  /// کل داده‌های اپ به‌صورت JSON.
  final String exportJson;
  /// بازگردانی از متن پشتیبان؛ true اگر موفق باشد.
  final bool Function(String raw) onRestore;

  const SettingsPage({
    super.key,
    required this.lang,
    required this.exportJson,
    required this.onRestore,
  });

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final TextEditingController _importCtrl = TextEditingController();
  bool _showExport = false;

  @override
  void dispose() {
    _importCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg, {bool ok = true}) =>
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(msg),
          backgroundColor: ok ? AppPal.ink : const Color(0xFFB3261E),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return Scaffold(
      appBar: AppBar(
        title: Text(t.backupTitle),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
        titleTextStyle: const TextStyle(
            color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800),
        flexibleSpace: Container(
          decoration: const BoxDecoration(gradient: AppPal.purpleGradient),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ---------- گرفتن پشتیبان ----------
          Container(
            decoration: AppPal.softCard(),
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    const Icon(Icons.cloud_upload_outlined,
                        color: AppPal.purple),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        t.exportData,
                        style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                            color: AppPal.ink),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  t.exportHint,
                  style: const TextStyle(
                      color: AppPal.inkSoft, fontSize: 12.5, height: 1.6),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 46,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: AppPal.purple,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: () => setState(() => _showExport = !_showExport),
                    icon: const Icon(Icons.description_outlined, size: 20),
                    label: Text(
                      t.exportData,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
                if (_showExport) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    constraints: const BoxConstraints(maxHeight: 220),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF3F4F8),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: SingleChildScrollView(
                      child: SelectableText(
                        widget.exportJson,
                        style: const TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 11,
                            height: 1.4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppPal.purple,
                      side: const BorderSide(color: AppPal.purple),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: () {
                      Clipboard.setData(
                          ClipboardData(text: widget.exportJson));
                      _snack(t.copied);
                    },
                    icon: const Icon(Icons.copy_all, size: 20),
                    label: Text(
                      t.copyAll,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),

          // ---------- بازگردانی ----------
          Container(
            decoration: AppPal.softCard(),
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    const Icon(Icons.settings_backup_restore,
                        color: AppPal.purple),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        t.importData,
                        style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                            color: AppPal.ink),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  t.importHint,
                  style: const TextStyle(
                      color: AppPal.inkSoft, fontSize: 12.5, height: 1.6),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _importCtrl,
                  minLines: 4,
                  maxLines: 8,
                  decoration: const InputDecoration(hintText: '{ ... }'),
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 48,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: AppPal.yellow,
                      foregroundColor: AppPal.ink,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: () {
                      final ok = widget.onRestore(_importCtrl.text.trim());
                      if (ok) {
                        _snack(t.restoredOk);
                      } else {
                        _snack(t.restoreFailed, ok: false);
                      }
                    },
                    icon: const Icon(Icons.restore, size: 20),
                    label: Text(
                      t.restore,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
