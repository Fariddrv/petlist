import 'package:flutter/material.dart';

import '../i18n2.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import 'profile_page.dart';

/// فهرست فالوورها یا دنبال‌شده‌های یک کاربر
class FollowListPage extends StatefulWidget {
  final AppState s;
  final String userId;
  final bool followers;
  const FollowListPage(
      {super.key,
      required this.s,
      required this.userId,
      required this.followers});

  @override
  State<FollowListPage> createState() => _FollowListPageState();
}

class _FollowListPageState extends State<FollowListPage> {
  late Future<List<AppUser>> _f =
      widget.s.followList(widget.userId, followers: widget.followers);

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(
          title: Text(tr(l, widget.followers ? 'followers' : 'following'))),
      body: FutureBuilder<List<AppUser>>(
        future: _f,
        builder: (c, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final list = snap.data!;
          if (list.isEmpty) {
            return Center(
                child: Text(tr(l, 'nobodyYet'),
                    style: const TextStyle(color: AppPal.inkSoft)));
          }
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (c, i) => const Divider(height: 1, indent: 72),
            itemBuilder: (c, i) {
              final u = list[i];
              return ListTile(
                leading: UserAvatar(user: u, size: 46),
                title: Text(u.username,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: u.bio.isEmpty
                    ? null
                    : Text(u.bio, maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () {
                  if (u.id == widget.s.meId) return;
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ProfilePage(
                              s: widget.s, userId: u.id, standalone: true)));
                },
              );
            },
          );
        },
      ),
    );
  }
}
