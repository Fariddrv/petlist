import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../data/media.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import 'menu_pages.dart' show appVersion;

Future<String> _probe(String url) async {
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final req = await c.getUrl(Uri.parse(url));
    final res = await req.close().timeout(const Duration(seconds: 10));
    await res.drain<void>();
    return 'OK (${res.statusCode})';
  } on TlsException {
    return 'OK (TLS)';
  } catch (e) {
    final t = e.toString().replaceAll('\n', ' ');
    return 'FAIL: ${t.length > 150 ? t.substring(0, 150) : t}';
  } finally {
    c.close(force: true);
  }
}

void _connectionTest(BuildContext context) {
  final tests = <String, String>{
    'Supabase': 'https://ajvlqvcljplrkfgztljf.supabase.co/rest/v1/',
    'Google': 'https://www.google.com',
    'IP 1.1.1.1': 'https://1.1.1.1',
  };
  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text('v$appVersion'),
      content: FutureBuilder<List<String>>(
        future: Future.wait(tests.values.map(_probe)),
        builder: (c, snap) {
          if (!snap.hasData) {
            return const SizedBox(
                height: 60,
                child: Center(child: CircularProgressIndicator()));
          }
          final names = tests.keys.toList();
          return SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (var i = 0; i < names.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text('${names[i]}: ${snap.data![i]}',
                        textDirection: TextDirection.ltr,
                        style: const TextStyle(fontSize: 12.5)),
                  ),
              ],
            ),
          );
        },
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))
      ],
    ),
  );
}

String _errText(AppState s, AppLang l, String key) {
  final base = tr(l, key);
  if (key == 'errNet' && s.lastError.isNotEmpty) {
    return '$base\n[${s.lastError}]';
  }
  return base;
}

Widget _langButton(AppState s) => PopupMenuButton<AppLang>(
      icon: const Icon(Icons.translate, color: AppPal.inkSoft),
      onSelected: s.setLang,
      itemBuilder: (ctx) => [
        for (final l in AppLang.values)
          PopupMenuItem(
            value: l,
            child: Row(children: [
              Icon(l == s.lang ? Icons.check : Icons.circle_outlined, size: 18),
              const SizedBox(width: 8),
              Text(l.label),
            ]),
          ),
      ],
    );

Widget _logoHeader(String title) => Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Image.asset('assets/logo/app_logo.png',
              width: 96, height: 96, fit: BoxFit.cover),
        ),
        const SizedBox(height: 12),
        Text(title,
            style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w900,
                color: AppPal.purpleDark)),
      ],
    );

ButtonStyle get _bigBtn => FilledButton.styleFrom(
      backgroundColor: AppPal.purple,
      minimumSize: const Size.fromHeight(52),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    );

// ======================= ورود =======================
class LoginPage extends StatefulWidget {
  final AppState s;
  const LoginPage({super.key, required this.s});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _id = TextEditingController();
  final _pw = TextEditingController();
  bool _busy = false, _hide = true;
  String? _err;

  @override
  void dispose() {
    _id.dispose();
    _pw.dispose();
    super.dispose();
  }

  Future<void> _go() async {
    if (_id.text.trim().isEmpty || _pw.text.isEmpty) {
      setState(() => _err = 'errFill');
      return;
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    final e = await widget.s.login(_id.text, _pw.text);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _err = e;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final t = L10n.of(s.lang);
    final l = s.lang;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(alignment: AlignmentDirectional.centerEnd, child: _langButton(s)),
            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 26),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(child: _logoHeader(t.appTitle)),
                      const SizedBox(height: 30),
                      TextField(
                        controller: _id,
                        keyboardType: TextInputType.emailAddress,
                        autocorrect: false,
                        decoration: InputDecoration(
                            labelText: tr(l, 'userOrEmail'),
                            prefixIcon: const Icon(Icons.person_outline)),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _pw,
                        obscureText: _hide,
                        onSubmitted: (_) => _go(),
                        decoration: InputDecoration(
                          labelText: tr(l, 'password'),
                          prefixIcon: const Icon(Icons.lock_outline),
                          suffixIcon: IconButton(
                            icon: Icon(_hide
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined),
                            onPressed: () => setState(() => _hide = !_hide),
                          ),
                        ),
                      ),
                      if (_err != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Text(_errText(widget.s, l, _err!),
                              style: const TextStyle(
                                  color: Color(0xFFB3261E), fontSize: 13)),
                        ),
                      const SizedBox(height: 16),
                      FilledButton(
                        onPressed: _busy ? null : _go,
                        style: _bigBtn,
                        child: Text(tr(l, 'login'),
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w800)),
                      ),
                      Align(
                        child: TextButton(
                          onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => ForgotPage(s: s))),
                          child: Text(tr(l, 'forgot')),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(children: [
                        const Expanded(child: Divider()),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Text(tr(l, 'newHere'),
                              style: const TextStyle(
                                  color: AppPal.inkSoft, fontSize: 13)),
                        ),
                        const Expanded(child: Divider()),
                      ]),
                      const SizedBox(height: 12),
                      OutlinedButton(
                        onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => SignUpPage(s: s))),
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size.fromHeight(52),
                          side: const BorderSide(color: AppPal.purple),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16)),
                        ),
                        child: Text(tr(l, 'signup'),
                            style: const TextStyle(
                                color: AppPal.purple,
                                fontSize: 16,
                                fontWeight: FontWeight.w800)),
                      ),
                      const SizedBox(height: 14),
                      TextButton.icon(
                        onPressed: () => _connectionTest(context),
                        icon: const Icon(Icons.network_check, size: 18),
                        label: Text(tr(l, 'connTest')),
                      ),
                      Center(
                        child: Text('v$appVersion',
                            style: const TextStyle(
                                color: AppPal.inkSoft, fontSize: 12)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ======================= فراموشی رمز =======================
class ForgotPage extends StatelessWidget {
  final AppState s;
  const ForgotPage({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    final l = s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'forgot'))),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              decoration: InputDecoration(
                  labelText: tr(l, 'email'),
                  prefixIcon: const Icon(Icons.email_outlined)),
            ),
            const SizedBox(height: 16),
            FilledButton(
              style: _bigBtn,
              onPressed: () => showDialog(
                context: context,
                builder: (ctx) => AlertDialog(
                  content: Text(tr(l, 'forgotBody')),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: Text(tr(l, 'ok')))
                  ],
                ),
              ),
              child: Text(tr(l, 'continue')),
            ),
          ],
        ),
      ),
    );
  }
}

// ======================= ثبت‌نام =======================
class SignUpPage extends StatefulWidget {
  final AppState s;
  const SignUpPage({super.key, required this.s});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _email = TextEditingController();
  final _mobile = TextEditingController();
  final _pw = TextEditingController();
  final _pw2 = TextEditingController();
  DateTime? _birth;
  String _gender = '';
  String? _err;
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_first, _last, _email, _mobile, _pw, _pw2]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _birth ?? DateTime(2000, 1, 1),
      firstDate: DateTime(1920),
      lastDate: DateTime.now(),
    );
    if (d != null) setState(() => _birth = d);
  }

  String? _validate() {
    if (_first.text.trim().isEmpty ||
        _last.text.trim().isEmpty ||
        _birth == null ||
        _gender.isEmpty ||
        _email.text.trim().isEmpty ||
        _mobile.text.trim().isEmpty ||
        _pw.text.isEmpty) {
      return 'errFill';
    }
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(_email.text.trim())) {
      return 'errEmail';
    }
    if (!RegExp(r'^\+?[0-9]{10,14}$').hasMatch(_mobile.text.trim())) {
      return 'errMobile';
    }
    final now = DateTime.now();
    var age = now.year - _birth!.year;
    if (now.month < _birth!.month ||
        (now.month == _birth!.month && now.day < _birth!.day)) {
      age--;
    }
    if (age < 13) return 'errAge';
    if (_pw.text.length < 6) return 'errPassShort';
    if (_pw.text != _pw2.text) return 'errPassMatch';
    return null;
  }

  Future<void> _submit() async {
    final v = _validate();
    if (v != null) {
      setState(() => _err = v);
      return;
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    final e = await widget.s.signUp(
      first: _first.text,
      last: _last.text,
      gender: _gender,
      email: _email.text,
      mobile: _mobile.text,
      pass: _pw.text,
      birth: _birth!.millisecondsSinceEpoch,
    );
    if (!mounted) return;
    if (e != null) {
      setState(() {
        _busy = false;
        _err = e;
      });
      return;
    }
    Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    String d2(int n) => n.toString().padLeft(2, '0');
    return Scaffold(
      appBar: AppBar(title: Text(tr(l, 'signup'))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Row(children: [
            Expanded(
              child: TextField(
                controller: _first,
                decoration: InputDecoration(labelText: tr(l, 'firstName')),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _last,
                decoration: InputDecoration(labelText: tr(l, 'lastName')),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: _pickDate,
            child: InputDecorator(
              decoration: InputDecoration(
                labelText: tr(l, 'birthDate'),
                suffixIcon: const Icon(Icons.calendar_month_outlined),
              ),
              child: Text(
                _birth == null
                    ? tr(l, 'pickDate')
                    : '${_birth!.year}/${d2(_birth!.month)}/${d2(_birth!.day)}',
                style: TextStyle(
                    color: _birth == null ? AppPal.inkSoft : AppPal.ink),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(tr(l, 'gender'),
              style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Wrap(spacing: 10, children: [
            ChoiceChip(
              label: Text(tr(l, 'female')),
              selected: _gender == 'f',
              onSelected: (_) => setState(() => _gender = 'f'),
            ),
            ChoiceChip(
              label: Text(tr(l, 'male')),
              selected: _gender == 'm',
              onSelected: (_) => setState(() => _gender = 'm'),
            ),
          ]),
          const SizedBox(height: 12),
          TextField(
            controller: _email,
            keyboardType: TextInputType.emailAddress,
            autocorrect: false,
            decoration: InputDecoration(labelText: tr(l, 'email')),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _mobile,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(labelText: tr(l, 'mobile')),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _pw,
            obscureText: true,
            decoration: InputDecoration(labelText: tr(l, 'password')),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _pw2,
            obscureText: true,
            decoration: InputDecoration(labelText: tr(l, 'repeatPass')),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFEDE7FF),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(children: [
              const Icon(Icons.lock_outline, size: 20, color: AppPal.purpleDark),
              const SizedBox(width: 8),
              Expanded(
                child: Text(tr(l, 'privacyNote'),
                    style: const TextStyle(fontSize: 12.5, height: 1.5)),
              ),
            ]),
          ),
          if (_err != null)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(_errText(widget.s, l, _err!),
                  style: const TextStyle(color: Color(0xFFB3261E), fontSize: 13)),
            ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _busy ? null : _submit,
            style: _bigBtn,
            child: Text(tr(l, 'continue'),
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }
}

// ============ ساخت / ویرایش پروفایل (عکس، نام کاربری، بیو) ============
class ProfileSetupPage extends StatefulWidget {
  final AppState s;
  final bool editing;
  const ProfileSetupPage({super.key, required this.s, this.editing = false});

  @override
  State<ProfileSetupPage> createState() => _ProfileSetupPageState();
}

class _ProfileSetupPageState extends State<ProfileSetupPage> {
  late final TextEditingController _name;
  late final TextEditingController _bio;
  String? _photo;
  String? _err;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final m = widget.s.me!;
    _name = TextEditingController(text: m.username);
    _bio = TextEditingController(text: m.bio);
  }

  @override
  void dispose() {
    _name.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _pick(ImageSource src) async {
    try {
      final f = await ImagePicker()
          .pickImage(source: src, imageQuality: 85, maxWidth: 900);
      if (f == null) return;
      final saved = await persistImage(f.path);
      if (mounted) setState(() => _photo = saved);
    } catch (_) {}
  }

  void _sheet() {
    final t = L10n.of(widget.s.lang);
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_library_outlined, color: AppPal.purple),
            title: Text(t.gallery),
            onTap: () {
              Navigator.pop(ctx);
              _pick(ImageSource.gallery);
            },
          ),
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined, color: AppPal.purple),
            title: Text(t.camera),
            onTap: () {
              Navigator.pop(ctx);
              _pick(ImageSource.camera);
            },
          ),
        ]),
      ),
    );
  }

  Future<void> _save() async {
    setState(() {
      _busy = true;
      _err = null;
    });
    final e = await widget.s.saveProfile(
        username: _name.text, bio: _bio.text, avatarPath: _photo);
    if (!mounted) return;
    if (e != null) {
      setState(() {
        _busy = false;
        _err = e;
      });
      return;
    }
    if (widget.editing) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    final m = widget.s.me!;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: widget.editing,
        title: Text(tr(l, widget.editing ? 'editProfile' : 'profileSetup')),
      ),
      body: ListView(
        padding: const EdgeInsets.all(22),
        children: [
          Center(
            child: GestureDetector(
              onTap: _sheet,
              child: Stack(children: [
                UserAvatar(user: m, filePath: _photo, size: 116),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: const BoxDecoration(
                        color: AppPal.yellow, shape: BoxShape.circle),
                    child: const Icon(Icons.add_a_photo_outlined,
                        size: 18, color: Colors.white),
                  ),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 24),
          TextField(
            controller: _name,
            autocorrect: false,
            decoration: InputDecoration(
                labelText: tr(l, 'username'), prefixText: '@'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _bio,
            maxLines: 4,
            maxLength: 150,
            decoration: InputDecoration(labelText: tr(l, 'bio')),
          ),
          if (_err != null)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(_errText(widget.s, l, _err!),
                  style: const TextStyle(color: Color(0xFFB3261E), fontSize: 13)),
            ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _busy ? null : _save,
            style: _bigBtn,
            child: Text(tr(l, widget.editing ? 'save' : 'finish'),
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }
}
