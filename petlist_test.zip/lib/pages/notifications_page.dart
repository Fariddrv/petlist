import 'package:flutter/material.dart';

import '../data/timeago.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/avatar.dart';
import 'follow_list_page.dart';
import 'post_detail.dart';
import 'profile_page.dart';

/// اعلان‌ها: درخواست‌های فالو + لایک/نظر/پاسخ/تگ (مثل اینستاگرام)
class NotificationsPage extends StatefulWidget {
  final AppState s;
  const NotificationsPage({super.key, required this.s});

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  AppState get s => widget.s;

  @override
  void initState() {
    super.initState();
    s.loadNotifications().then((_) => s.markNotificationsSeen());
    s.refreshRequests();
  }

  String _text(NotifItem n) {
    final key = switch (n.kind) {
      'like' => 'nLike',
      'comment' => 'nComment',
      'reply' => 'nReply',
      'tag' => 'nTag',
      _ => 'nCommentLike',
    };
    final who = s.userById(n.userId)?.username ?? '?';
    return tr(s.lang, key).replaceAll('{x}', '@$who');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (c, _) {
        final l = s.lang;
        final t = L10n.of(l);
        final reqs = s.me?.requests ?? const <String>[];
        return Scaffold(
          appBar: AppBar(title: Text(tr(l, 'notifications'))),
          body: ListView(children: [
            if (reqs.isNotEmpty) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
                child: Text('${tr(l, 'requestsTitle')} (${t.num(reqs.length)})',
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 15)),
              ),
              for (final id in reqs)
                ListTile(
                  leading: UserAvatar(user: s.userById(id), size: 44),
                  title: Text('@${s.userById(id)?.username ?? id}',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ProfilePage(
                              s: s, userId: id, standalone: true))),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    FilledButton(
                      onPressed: () => s.approve(id),
                      style: FilledButton.styleFrom(
                          backgroundColor: AppPal.purple,
                          padding: const EdgeInsets.symmetric(horizontal: 12)),
                      child: Text(tr(l, 'accept')),
                    ),
                    const SizedBox(width: 6),
                    OutlinedButton(
                      onPressed: () => s.decline(id),
                      style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 12)),
                      child: Text(tr(l, 'decline')),
                    ),
                  ]),
                ),
              const Divider(),
            ],
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
              child: Text(tr(l, 'activity'),
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 15)),
            ),
            if (s.notifs.isEmpty)
              Padding(
                padding: const EdgeInsets.all(40),
                child: Column(children: [
                  const Icon(Icons.favorite_border,
                      size: 44, color: AppPal.inkSoft),
                  const SizedBox(height: 10),
                  Text(tr(l, 'noNotifs'),
                      style: const TextStyle(color: AppPal.inkSoft)),
                ]),
              )
            else
              for (final n in s.notifs)
                ListTile(
                  leading: UserAvatar(user: s.userById(n.userId), size: 44),
                  title: Text(_text(n), style: const TextStyle(fontSize: 14)),
                  subtitle: Text(
                      n.text.isNotEmpty
                          ? '${n.text}\n${timeAgo(n.at, l)}'
                          : timeAgo(n.at, l),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis),
                  isThreeLine: n.text.isNotEmpty,
                  tileColor: n.at > s.notifSeenAt
                      ? const Color(0xFFF3EEFF)
                      : null,
                  onTap: () {
                    if (n.postId != null) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  PostDetailPage(s: s, postId: n.postId!)));
                    } else {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => ProfilePage(
                                  s: s, userId: n.userId, standalone: true)));
                    }
                  },
                ),
          ]),
        );
      },
    );
  }
}
