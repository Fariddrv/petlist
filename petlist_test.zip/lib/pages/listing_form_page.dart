import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../data/media.dart';
import '../data/shop_catalog.dart';
import '../i18n2.dart';
import '../shop_models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/smart_image.dart';

/// افزودن یا ویرایش یک محصول / خدمت.
class ListingFormPage extends StatefulWidget {
  final AppState s;
  final Listing? item;
  const ListingFormPage({super.key, required this.s, this.item});

  @override
  State<ListingFormPage> createState() => _ListingFormPageState();
}

class _ListingFormPageState extends State<ListingFormPage> {
  late String _kind = widget.item?.kind ?? 'product';
  late String? _cat = widget.item?.categoryKey;
  late String _currency = widget.item?.currency ?? _defaultCurrency();
  late final _title = TextEditingController(text: widget.item?.title ?? '');
  late final _desc = TextEditingController(text: widget.item?.description ?? '');
  late final _price = TextEditingController(
      text: widget.item == null
          ? ''
          : moneyToInput(widget.item!.priceMinor, widget.item!.currency));
  late final _stock =
      TextEditingController(text: widget.item?.stock?.toString() ?? '');
  late final _duration =
      TextEditingController(text: widget.item?.durationMin?.toString() ?? '');
  late List<String> _kept = List.of(widget.item?.images ?? const []);
  final List<String> _newImages = [];
  late bool _active = widget.item?.active ?? true;
  String? _err;
  bool _busy = false;

  String _defaultCurrency() => widget.s.lang.name == 'fa' ? 'IRT' : 'USD';

  @override
  void dispose() {
    for (final c in [_title, _desc, _price, _stock, _duration]) {
      c.dispose();
    }
    super.dispose();
  }

  int get _count => _kept.length + _newImages.length;

  Future<void> _pickImages() async {
    if (_count >= 5) return;
    try {
      final files = await ImagePicker()
          .pickMultiImage(imageQuality: 85, maxWidth: 1600);
      for (final f in files) {
        if (_count >= 5) break;
        final saved = await persistImage(f.path);
        _newImages.add(saved);
      }
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Future<void> _pickCurrency() async {
    final l = widget.s.lang;
    final v = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Text(tr(l, 'shCurrency'),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          for (final c in currencies)
            ListTile(
              leading: Text(c.code,
                  style: const TextStyle(fontWeight: FontWeight.w800, color: AppPal.purple)),
              title: Text(c.name(l)),
              trailing: c.code == _currency ? const Icon(Icons.check, color: AppPal.purple) : null,
              onTap: () => Navigator.pop(ctx, c.code),
            ),
        ]),
      ),
    );
    if (v != null) setState(() => _currency = v);
  }

  Future<void> _save() async {
    final price = parseMoney(_price.text, _currency);
    if (_title.text.trim().isEmpty || _cat == null || price == null) {
      setState(() => _err = 'errFill');
      return;
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    final e = await widget.s.shop.saveListing(
      id: widget.item?.id,
      kind: _kind,
      categoryKey: _cat!,
      title: _title.text,
      description: _desc.text,
      priceMinor: price,
      currency: _currency,
      stock: int.tryParse(_stock.text.trim()),
      durationMin: int.tryParse(_duration.text.trim()),
      keptImages: _kept,
      localImages: _newImages,
      active: _active,
    );
    if (!mounted) return;
    if (e != null) {
      setState(() {
        _busy = false;
        _err = e;
      });
      return;
    }
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(tr(widget.s.lang, 'shSaved'))));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    final cats = shopCategories.where((c) => c.kind == _kind).toList();
    if (_cat != null && !cats.any((c) => c.key == _cat)) _cat = null;
    return Scaffold(
      appBar: AppBar(
        title: Text(tr(l, widget.item == null ? 'shAddListing' : 'shEdit')),
      ),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        SegmentedButton<String>(
          segments: [
            ButtonSegment(value: 'product', label: Text(tr(l, 'shProduct'))),
            ButtonSegment(value: 'service', label: Text(tr(l, 'shService'))),
          ],
          selected: {_kind},
          onSelectionChanged: (v) => setState(() => _kind = v.first),
        ),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(
          value: _cat,
          isExpanded: true,
          decoration: InputDecoration(labelText: tr(l, 'shCategory')),
          items: [
            for (final c in cats)
              DropdownMenuItem(value: c.key, child: Text('${c.emoji} ${c.name(l)}')),
          ],
          onChanged: (v) => setState(() => _cat = v),
        ),
        const SizedBox(height: 12),
        TextField(controller: _title, decoration: InputDecoration(labelText: tr(l, 'shTitle'))),
        const SizedBox(height: 12),
        TextField(
            controller: _desc,
            minLines: 3,
            maxLines: 8,
            decoration: InputDecoration(labelText: tr(l, 'shDescription'))),
        const SizedBox(height: 12),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            flex: 3,
            child: TextField(
              controller: _price,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: tr(l, 'shPrice')),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 2,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: _pickCurrency,
              child: InputDecorator(
                decoration: InputDecoration(
                    labelText: tr(l, 'shCurrency'),
                    suffixIcon: const Icon(Icons.arrow_drop_down)),
                child: Text(_currency, style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        if (_kind == 'product')
          TextField(
            controller: _stock,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
                labelText: tr(l, 'shStock'), helperText: tr(l, 'shStockHint')),
          )
        else
          TextField(
            controller: _duration,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: tr(l, 'shDuration')),
          ),
        const SizedBox(height: 16),
        Text('${tr(l, 'shImages')} ($_count/5)',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        SizedBox(
          height: 84,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            for (final u in _kept)
              _thumb(SmartImage(src: u, fit: BoxFit.cover), () => setState(() => _kept.remove(u))),
            for (final p in _newImages)
              _thumb(Image.file(File(p), fit: BoxFit.cover),
                  () => setState(() => _newImages.remove(p))),
            if (_count < 5)
              GestureDetector(
                onTap: _pickImages,
                child: Container(
                  width: 84,
                  decoration: BoxDecoration(
                    color: const Color(0xFFEDE7FF),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.add_photo_alternate_outlined,
                      color: AppPal.purple, size: 30),
                ),
              ),
          ]),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          activeColor: AppPal.purple,
          value: _active,
          onChanged: (v) => setState(() => _active = v),
          title: Text(tr(l, 'shListingActive')),
        ),
        if (_err != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              tr(l, _err!) +
                  ((_err == 'errNet' && widget.s.shop.lastError.isNotEmpty)
                      ? '\n[${widget.s.shop.lastError}]'
                      : ''),
              style: const TextStyle(color: Color(0xFFB3261E), fontSize: 13),
            ),
          ),
        FilledButton(
          onPressed: _busy ? null : _save,
          style: FilledButton.styleFrom(
            backgroundColor: AppPal.purple,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: _busy
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
              : Text(tr(l, 'save'),
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
        const SizedBox(height: 20),
      ]),
    );
  }

  Widget _thumb(Widget img, VoidCallback onRemove) => Container(
        width: 84,
        margin: const EdgeInsetsDirectional.only(end: 8),
        child: Stack(fit: StackFit.expand, children: [
          ClipRRect(borderRadius: BorderRadius.circular(14), child: img),
          PositionedDirectional(
            top: 2,
            end: 2,
            child: GestureDetector(
              onTap: onRemove,
              child: Container(
                padding: const EdgeInsets.all(3),
                decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                child: const Icon(Icons.close, size: 14, color: Colors.white),
              ),
            ),
          ),
        ]),
      );
}
