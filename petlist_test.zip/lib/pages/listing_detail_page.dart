import 'package:flutter/material.dart';

import '../data/shop_catalog.dart';
import '../i18n2.dart';
import '../shop_models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/image_viewer.dart';
import '../widgets/shop_widgets.dart';
import '../widgets/smart_image.dart';
import 'messages_page.dart';
import 'shop_profile_page.dart';

/// صفحه‌ی یک محصول یا خدمت.
class ListingDetailPage extends StatefulWidget {
  final AppState s;
  final Listing item;
  const ListingDetailPage({super.key, required this.s, required this.item});

  @override
  State<ListingDetailPage> createState() => _ListingDetailPageState();
}

class _ListingDetailPageState extends State<ListingDetailPage> {
  final _pc = PageController();
  int _page = 0;

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final it = widget.item;
    final l = s.lang;
    final own = it.shopOwnerId == s.meId;
    final cat = categoryOf(it.categoryKey);
    return Scaffold(
      appBar: AppBar(title: Text(it.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: ListView(
        children: [
          AspectRatio(
            aspectRatio: 1.2,
            child: it.images.isEmpty
                ? Container(
                    color: AppPal.bg,
                    alignment: Alignment.center,
                    child: Text(cat?.emoji ?? '🐾', style: const TextStyle(fontSize: 70)),
                  )
                : Stack(children: [
                    PageView.builder(
                      controller: _pc,
                      itemCount: it.images.length,
                      onPageChanged: (i) => setState(() => _page = i),
                      itemBuilder: (c, i) => GestureDetector(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => ImageViewerPage(src: it.images[i])),
                        ),
                        child: SmartImage(src: it.images[i], fit: BoxFit.cover),
                      ),
                    ),
                    if (it.images.length > 1)
                      Positioned(
                        bottom: 10,
                        left: 0,
                        right: 0,
                        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          for (var i = 0; i < it.images.length; i++)
                            Container(
                              margin: const EdgeInsets.symmetric(horizontal: 3),
                              width: i == _page ? 16 : 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: i == _page ? Colors.white : Colors.white54,
                                borderRadius: BorderRadius.circular(999),
                              ),
                            ),
                        ]),
                      ),
                  ]),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(it.title,
                    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                const SizedBox(height: 6),
                Text(formatMoney(it.priceMinor, it.currency, l),
                    style: const TextStyle(
                        color: AppPal.purpleDark,
                        fontWeight: FontWeight.w900,
                        fontSize: 20)),
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 6, children: [
                  if (cat != null)
                    Chip(label: Text('${cat.emoji} ${cat.name(l)}')),
                  if (it.isService && it.durationMin != null)
                    Chip(label: Text('${it.durationMin} ${tr(l, 'shMinutes')}')),
                  if (it.soldOut) Chip(label: Text(tr(l, 'shSoldOut'))),
                  if (it.city.isNotEmpty)
                    Chip(
                      avatar: const Icon(Icons.location_on_outlined, size: 16),
                      label: Text(it.city),
                    ),
                ]),
                if (it.description.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  Text(it.description, style: const TextStyle(height: 1.8)),
                ],
                const SizedBox(height: 18),
                InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => ShopProfilePage(s: s, shopId: it.shopId)),
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: AppPal.softCard(),
                    child: Row(children: [
                      ShopLogo(url: it.shopLogo, name: it.shopName, size: 46),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Row(children: [
                          Flexible(
                            child: Text(it.shopName,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800, fontSize: 15)),
                          ),
                          if (it.shopVerified) ...[
                            const SizedBox(width: 4),
                            const VerifiedBadge(),
                          ],
                        ]),
                      ),
                      const Icon(Icons.chevron_right),
                    ]),
                  ),
                ),
                const SizedBox(height: 18),
                if (!own && it.shopOwnerId.isNotEmpty)
                  FilledButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ChatPage(s: s, otherId: it.shopOwnerId)),
                    ),
                    icon: const Icon(Icons.chat_bubble_outline),
                    label: Text(tr(l, 'shMessageSeller')),
                    style: FilledButton.styleFrom(
                      backgroundColor: AppPal.purple,
                      minimumSize: const Size.fromHeight(52),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
