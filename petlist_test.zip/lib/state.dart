import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart'
    show
        Supabase,
        SupabaseClient,
        AuthException,
        PostgrestException,
        FileOptions,
        UserAttributes;

import 'config.dart';
import 'l10n.dart';
import 'models.dart';

/// پروفایل یک کاربر (برای خود کاربر فیلدهای خصوصی هم پر می‌شود).
class AppUser {
  final String id;
  String username, bio;
  String? avatarUrl;
  bool isPrivate, setupDone;
  int followersCount, followingCount, postsCount;
  // فقط برای کاربر فعلی
  String email, mobile;
  bool twoFactor;
  List<String> requests, blocked;

  AppUser({
    required this.id,
    this.username = '',
    this.bio = '',
    this.avatarUrl,
    this.isPrivate = false,
    this.setupDone = false,
    this.followersCount = 0,
    this.followingCount = 0,
    this.postsCount = 0,
    this.email = '',
    this.mobile = '',
    this.twoFactor = false,
    List<String>? requests,
    List<String>? blocked,
  })  : requests = requests ?? [],
        blocked = blocked ?? [];

  factory AppUser.fromRow(Map<String, dynamic> j) => AppUser(
        id: j['id'].toString(),
        username: (j['username'] ?? '').toString(),
        bio: (j['bio'] ?? '').toString(),
        avatarUrl: j['avatar_url'] as String?,
        isPrivate: (j['is_private'] ?? false) as bool,
        setupDone: (j['setup_done'] ?? false) as bool,
      );
}

class Msg {
  final String id, from, to, text;
  final int at;
  const Msg(this.id, this.from, this.to, this.text, this.at);

  factory Msg.fromRow(Map<String, dynamic> j) => Msg(
        j['id'].toString(),
        j['sender_id'].toString(),
        j['receiver_id'].toString(),
        (j['text'] ?? '').toString(),
        DateTime.tryParse((j['created_at'] ?? '').toString())
                ?.millisecondsSinceEpoch ??
            0,
      );
}

List<Map<String, dynamic>> _rows(dynamic r) =>
    (r as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();

int _ms(dynamic v) =>
    DateTime.tryParse((v ?? '').toString())?.millisecondsSinceEpoch ?? 0;

class AppState extends ChangeNotifier {
  final SupabaseClient _sb = Supabase.instance.client;

  AppLang lang = AppLang.fa;
  bool ready = false;
  String? meId;

  final Map<String, AppUser> _users = {};
  Map<String, String> myFollows = {}; // شناسه‌ی هدف -> pending | accepted
  List<UserPost> posts = []; // فید
  Map<String, List<UserPost>> userPosts = {};
  List<UserPost> savedPosts = [];
  Map<String, PostInter> inter = {};
  List<Pet> pets = [];
  List<Msg> msgs = [];

  Timer? _timer;
  bool _polling = false;
  int _tick = 0;

  AppUser? get me => userById(meId);
  AppUser? userById(String? id) => id == null ? null : _users[id];
  List<Pet> get myPets => pets;

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // ---------- شروع ----------
  Future<void> load() async {
    try {
      final sp = await SharedPreferences.getInstance();
      lang = AppLang.values.firstWhere(
        (l) => l.name == sp.getString('lang_v1'),
        orElse: () => AppLang.fa,
      );
      final cu = _sb.auth.currentUser;
      if (cu != null) {
        meId = cu.id;
        await _bootstrap();
      }
    } catch (_) {}
    ready = true;
    notifyListeners();
  }

  Future<void> _bootstrap() async {
    await refreshMe();
    await Future.wait([loadFollows(), loadFeed(), loadPets(), loadMessages()]);
    _startTimer();
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 8), (_) async {
      if (meId == null || _polling) return;
      _polling = true;
      try {
        await loadMessages();
        await refreshMe();
        if (++_tick % 3 == 0) await loadFeed();
      } finally {
        _polling = false;
      }
    });
  }

  void _clear() {
    _timer?.cancel();
    meId = null;
    _users.clear();
    myFollows = {};
    posts = [];
    userPosts = {};
    savedPosts = [];
    inter = {};
    pets = [];
    msgs = [];
  }

  // ---------- زبان ----------
  void setLang(AppLang l) {
    lang = l;
    notifyListeners();
    SharedPreferences.getInstance().then((sp) => sp.setString('lang_v1', l.name));
  }

  // ---------- ورود / ثبت‌نام ----------
  Future<String?> signUp({
    required String first,
    required String last,
    required String gender,
    required String email,
    required String mobile,
    required String pass,
    required int birth,
  }) async {
    try {
      final d = DateTime.fromMillisecondsSinceEpoch(birth);
      String p2(int n) => n.toString().padLeft(2, '0');
      final res = await _sb.auth.signUp(
        email: email.trim().toLowerCase(),
        password: pass,
        data: {
          'first_name': first.trim(),
          'last_name': last.trim(),
          'gender': gender,
          'mobile': mobile.trim(),
          'birth_date': '${d.year}-${p2(d.month)}-${p2(d.day)}',
          'region': kRegion,
        },
      );
      if (res.session == null || res.user == null) return 'errConfirmEmail';
      meId = res.user!.id;
      await _bootstrap();
      notifyListeners();
      return null;
    } on AuthException catch (e) {
      final m = e.message.toLowerCase();
      if (m.contains('already')) return 'errEmailUsed';
      if (m.contains('password')) return 'errPassShort';
      if (m.contains('email')) return 'errEmail';
      return 'errNet';
    } catch (_) {
      return 'errNet';
    }
  }

  Future<String?> login(String idOrEmail, String pass) async {
    final k = idOrEmail.trim().toLowerCase();
    if (!k.contains('@')) return 'errUseEmail';
    try {
      final res = await _sb.auth.signInWithPassword(email: k, password: pass);
      if (res.user == null) return 'errLogin';
      meId = res.user!.id;
      await _bootstrap();
      notifyListeners();
      return null;
    } on AuthException {
      return 'errLogin';
    } catch (_) {
      return 'errNet';
    }
  }

  Future<void> logout() async {
    try {
      await _sb.auth.signOut();
    } catch (_) {}
    _clear();
    notifyListeners();
  }

  Future<String?> changePassword(String oldPass, String newPass) async {
    final m = me;
    if (m == null) return 'errLogin';
    try {
      await _sb.auth.signInWithPassword(email: m.email, password: oldPass);
    } on AuthException {
      return 'errOldPass';
    } catch (_) {
      return 'errNet';
    }
    try {
      await _sb.auth.updateUser(UserAttributes(password: newPass));
      return null;
    } on AuthException {
      return 'errPassShort';
    } catch (_) {
      return 'errNet';
    }
  }

  // ---------- آپلود عکس ----------
  Future<String?> _upload(String? path, String folder) async {
    if (path == null || path.isEmpty) return null;
    if (path.startsWith('http')) return path;
    final uid = meId;
    if (uid == null) return null;
    try {
      final ext = path.contains('.') ? path.split('.').last.toLowerCase() : 'jpg';
      final name = '$uid/$folder-${DateTime.now().microsecondsSinceEpoch}.$ext';
      await _sb.storage.from('media').upload(
            name,
            File(path),
            fileOptions: FileOptions(
                contentType: ext == 'png' ? 'image/png' : 'image/jpeg'),
          );
      return _sb.storage.from('media').getPublicUrl(name);
    } catch (_) {
      return null;
    }
  }

  // ---------- پروفایل ----------
  Future<AppUser?> fetchUser(String id, {bool force = false}) async {
    if (!force && _users.containsKey(id)) return _users[id];
    try {
      final row = await _sb.from('profiles').select().eq('id', id).maybeSingle();
      if (row == null) return _users[id];
      final u = AppUser.fromRow(Map<String, dynamic>.from(row));
      final old = _users[id];
      if (old != null) {
        u.email = old.email;
        u.mobile = old.mobile;
        u.twoFactor = old.twoFactor;
        u.requests = old.requests;
        u.blocked = old.blocked;
      }
      try {
        final st = await _sb.rpc('profile_stats', params: {'uid': id});
        if (st is Map) {
          u.followersCount = (st['followers'] as num?)?.toInt() ?? 0;
          u.followingCount = (st['following'] as num?)?.toInt() ?? 0;
          u.postsCount = (st['posts'] as num?)?.toInt() ?? 0;
        }
      } catch (_) {}
      _users[id] = u;
      notifyListeners();
      return u;
    } catch (_) {
      return _users[id];
    }
  }

  Future<void> _cacheProfiles(Iterable<String> ids) async {
    final need = ids.where((i) => !_users.containsKey(i)).toSet().toList();
    if (need.isEmpty) return;
    try {
      final rows = _rows(await _sb.from('profiles').select().inFilter('id', need));
      for (final r in rows) {
        _users[r['id'].toString()] = AppUser.fromRow(r);
      }
    } catch (_) {}
  }

  Future<void> refreshMe() async {
    final id = meId;
    if (id == null) return;
    final u = await fetchUser(id, force: true);
    if (u == null) return;
    try {
      final pi =
          await _sb.from('private_info').select().eq('id', id).maybeSingle();
      if (pi != null) {
        u.mobile = (pi['mobile'] ?? '').toString();
        u.twoFactor = (pi['two_factor'] ?? false) as bool;
      }
    } catch (_) {}
    u.email = _sb.auth.currentUser?.email ?? u.email;
    try {
      final req = _rows(await _sb
          .from('follows')
          .select('follower_id')
          .eq('followee_id', id)
          .eq('status', 'pending'));
      u.requests = req.map((e) => e['follower_id'].toString()).toList();
      final bl = _rows(
          await _sb.from('blocks').select('blocked_id').eq('blocker_id', id));
      u.blocked = bl.map((e) => e['blocked_id'].toString()).toList();
      await _cacheProfiles([...u.requests, ...u.blocked]);
    } catch (_) {}
    notifyListeners();
  }

  Future<String?> saveProfile({
    required String username,
    required String bio,
    String? avatarPath,
  }) async {
    final m = me;
    if (m == null) return 'errLogin';
    final n = username.trim();
    if (!RegExp(r'^[A-Za-z0-9_.]{3,20}$').hasMatch(n)) return 'errUsername';
    try {
      final data = <String, dynamic>{
        'username': n,
        'bio': bio.trim(),
        'setup_done': true,
      };
      if (avatarPath != null) {
        final url = await _upload(avatarPath, 'avatar');
        if (url != null) data['avatar_url'] = url;
      }
      await _sb.from('profiles').update(data).eq('id', m.id);
      await fetchUser(m.id, force: true);
      await refreshMe();
      return null;
    } on PostgrestException catch (e) {
      if (e.code == '23505') return 'errUsernameUsed';
      return 'errNet';
    } catch (_) {
      return 'errNet';
    }
  }

  Future<void> setPrivate(bool v) async {
    final m = me;
    if (m == null) return;
    m.isPrivate = v;
    notifyListeners();
    try {
      await _sb.from('profiles').update({'is_private': v}).eq('id', m.id);
      if (!v) {
        await _sb
            .from('follows')
            .update({'status': 'accepted'})
            .eq('followee_id', m.id)
            .eq('status', 'pending');
      }
    } catch (_) {}
    await refreshMe();
  }

  Future<void> setTwoFactor(bool v) async {
    final m = me;
    if (m == null) return;
    m.twoFactor = v;
    notifyListeners();
    try {
      await _sb.from('private_info').update({'two_factor': v}).eq('id', m.id);
    } catch (_) {}
  }

  // ---------- دنبال‌کردن و مسدودسازی ----------
  Future<void> loadFollows() async {
    final id = meId;
    if (id == null) return;
    try {
      final rows = _rows(await _sb
          .from('follows')
          .select('followee_id,status')
          .eq('follower_id', id));
      myFollows = {
        for (final r in rows) r['followee_id'].toString(): r['status'].toString()
      };
      notifyListeners();
    } catch (_) {}
  }

  /// none | requested | following
  String relation(AppUser t) => switch (myFollows[t.id]) {
        'accepted' => 'following',
        'pending' => 'requested',
        _ => 'none',
      };

  Future<void> follow(AppUser t) async {
    try {
      final st = await _sb.rpc('follow_user', params: {'target': t.id});
      myFollows[t.id] = st.toString();
      notifyListeners();
    } catch (_) {}
    await fetchUser(t.id, force: true);
    await loadUserPosts(t.id);
    await loadFeed();
  }

  Future<void> unfollow(AppUser t) async {
    final id = meId;
    if (id == null) return;
    try {
      await _sb
          .from('follows')
          .delete()
          .eq('follower_id', id)
          .eq('followee_id', t.id);
    } catch (_) {}
    myFollows.remove(t.id);
    notifyListeners();
    await fetchUser(t.id, force: true);
    await loadUserPosts(t.id);
    await loadFeed();
  }

  Future<void> approve(String uid) async {
    final id = meId;
    if (id == null) return;
    try {
      await _sb
          .from('follows')
          .update({'status': 'accepted'})
          .eq('follower_id', uid)
          .eq('followee_id', id);
    } catch (_) {}
    await refreshMe();
  }

  Future<void> decline(String uid) async {
    final id = meId;
    if (id == null) return;
    try {
      await _sb
          .from('follows')
          .delete()
          .eq('follower_id', uid)
          .eq('followee_id', id);
    } catch (_) {}
    await refreshMe();
  }

  Future<void> block(AppUser t) async {
    try {
      await _sb.rpc('block_user', params: {'target': t.id});
    } catch (_) {}
    myFollows.remove(t.id);
    await refreshMe();
    await loadFeed();
  }

  Future<void> unblock(String id) async {
    final m = meId;
    if (m == null) return;
    try {
      await _sb.from('blocks').delete().eq('blocker_id', m).eq('blocked_id', id);
    } catch (_) {}
    await refreshMe();
    await loadFeed();
  }

  bool canSee(AppUser t) {
    final m = me;
    if (m == null) return false;
    if (t.id == m.id) return true;
    if (m.blocked.contains(t.id)) return false;
    return !t.isPrivate || myFollows[t.id] == 'accepted';
  }

  // ---------- پست‌ها ----------
  Future<List<UserPost>> _hydrate(List<Map<String, dynamic>> rows) async {
    if (rows.isEmpty) return [];
    final me0 = meId;
    final ids = rows.map((r) => r['id'].toString()).toList();
    final likes = _rows(await _sb
        .from('post_likes')
        .select('post_id,user_id')
        .inFilter('post_id', ids));
    final coms = _rows(await _sb
        .from('comments')
        .select('id,post_id,text,created_at,profiles(username)')
        .inFilter('post_id', ids)
        .order('created_at'));
    final saves = _rows(await _sb
        .from('post_saves')
        .select('post_id')
        .eq('user_id', me0 ?? '')
        .inFilter('post_id', ids));

    final likeCount = <String, int>{};
    final myLikes = <String>{};
    for (final l in likes) {
      final p = l['post_id'].toString();
      likeCount[p] = (likeCount[p] ?? 0) + 1;
      if (l['user_id'].toString() == me0) myLikes.add(p);
    }
    final mySaves = saves.map((e) => e['post_id'].toString()).toSet();
    final cmap = <String, List<Comment>>{};
    for (final c in coms) {
      final pid = c['post_id'].toString();
      final prof = c['profiles'] is Map ? c['profiles'] as Map : const {};
      (cmap[pid] ??= []).add(Comment(
        id: c['id'].toString(),
        author: (prof['username'] ?? '?').toString(),
        text: (c['text'] ?? '').toString(),
        createdAt: _ms(c['created_at']),
      ));
    }

    final out = <UserPost>[];
    for (final r in rows) {
      final id = r['id'].toString();
      final prof = r['profiles'] is Map ? r['profiles'] as Map : const {};
      final liked = myLikes.contains(id);
      inter[id] = PostInter(
        liked: liked,
        saved: mySaves.contains(id),
        comments: cmap[id] ?? <Comment>[],
      );
      out.add(UserPost(
        id: id,
        author: (prof['username'] ?? '?').toString(),
        text: (r['text'] ?? '').toString(),
        imagePath: r['image_url'] as String?,
        likes: (likeCount[id] ?? 0) - (liked ? 1 : 0),
        ownerId: r['owner_id'].toString(),
        authorAvatar: prof['avatar_url'] as String?,
      ));
    }
    return out;
  }

  static const _postCols =
      'id,owner_id,text,image_url,created_at,profiles(username,avatar_url)';

  Future<void> loadFeed() async {
    if (meId == null) return;
    try {
      final rows = _rows(await _sb
          .from('posts')
          .select(_postCols)
          .order('created_at', ascending: false)
          .limit(60));
      posts = await _hydrate(rows);
      notifyListeners();
    } catch (_) {}
  }

  List<UserPost> visiblePosts() => posts;

  Future<void> loadUserPosts(String uid) async {
    if (meId == null) return;
    try {
      final rows = _rows(await _sb
          .from('posts')
          .select(_postCols)
          .eq('owner_id', uid)
          .order('created_at', ascending: false)
          .limit(100));
      userPosts[uid] = await _hydrate(rows);
      notifyListeners();
    } catch (_) {}
  }

  Future<void> loadSaved() async {
    final id = meId;
    if (id == null) return;
    try {
      final r = _rows(await _sb
          .from('post_saves')
          .select('created_at,posts($_postCols)')
          .eq('user_id', id)
          .order('created_at', ascending: false));
      final rows = <Map<String, dynamic>>[];
      for (final e in r) {
        if (e['posts'] is Map) {
          rows.add(Map<String, dynamic>.from(e['posts'] as Map));
        }
      }
      savedPosts = await _hydrate(rows);
      notifyListeners();
    } catch (_) {}
  }

  /// null یعنی موفق؛ در غیر این‌صورت کلید پیام خطا.
  Future<String?> addPost(UserPost p) async {
    final id = meId;
    if (id == null) return 'errLogin';
    String? url;
    if (p.imagePath != null && p.imagePath!.isNotEmpty) {
      url = await _upload(p.imagePath, 'post');
      if (url == null) return 'errNet';
    }
    try {
      await _sb
          .from('posts')
          .insert({'owner_id': id, 'text': p.text, 'image_url': url});
    } catch (_) {
      return 'errNet';
    }
    await loadFeed();
    await loadUserPosts(id);
    await fetchUser(id, force: true);
    return null;
  }

  Future<void> removePost(UserPost p) async {
    posts = posts.where((x) => x.id != p.id).toList();
    userPosts[p.ownerId] =
        (userPosts[p.ownerId] ?? []).where((x) => x.id != p.id).toList();
    inter.remove(p.id);
    notifyListeners();
    try {
      await _sb.from('posts').delete().eq('id', p.id);
    } catch (_) {}
    final id = meId;
    if (id != null) await fetchUser(id, force: true);
  }

  void toggleLike(String id) {
    final m = meId;
    if (m == null) return;
    final cur = inter[id] ?? const PostInter(comments: []);
    final now = !cur.liked;
    inter[id] = cur.copyWith(liked: now);
    notifyListeners();
    () async {
      try {
        if (now) {
          await _sb.from('post_likes').insert({'post_id': id, 'user_id': m});
        } else {
          await _sb
              .from('post_likes')
              .delete()
              .eq('post_id', id)
              .eq('user_id', m);
        }
      } catch (_) {}
    }();
  }

  void toggleSave(String id) {
    final m = meId;
    if (m == null) return;
    final cur = inter[id] ?? const PostInter(comments: []);
    final now = !cur.saved;
    inter[id] = cur.copyWith(saved: now);
    notifyListeners();
    () async {
      try {
        if (now) {
          await _sb.from('post_saves').insert({'post_id': id, 'user_id': m});
        } else {
          await _sb
              .from('post_saves')
              .delete()
              .eq('post_id', id)
              .eq('user_id', m);
        }
      } catch (_) {}
      await loadSaved();
    }();
  }

  void addComment(String postId, String text) {
    final m = meId;
    if (m == null) return;
    final cur = inter[postId] ?? const PostInter(comments: []);
    final cm = Comment(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      author: me?.username ?? 'Me',
      text: text,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
    inter[postId] = cur.copyWith(comments: [...cur.comments, cm]);
    notifyListeners();
    () async {
      try {
        await _sb
            .from('comments')
            .insert({'post_id': postId, 'user_id': m, 'text': text});
      } catch (_) {}
    }();
  }

  // ---------- حیوانات ----------
  Future<void> loadPets() async {
    final id = meId;
    if (id == null) return;
    try {
      final rows = _rows(await _sb
          .from('pets')
          .select()
          .eq('owner_id', id)
          .order('created_at'));
      pets = rows
          .map((r) => Pet(
                id: r['id'].toString(),
                name: (r['name'] ?? '').toString(),
                species: (r['species'] ?? 'other').toString(),
                age: (r['age'] as num?)?.toInt() ?? 0,
                photoPath: r['photo_url'] as String?,
                ownerId: id,
              ))
          .toList();
      notifyListeners();
    } catch (_) {}
  }

  Future<void> addPet(Pet p) async {
    final id = meId;
    if (id == null) return;
    final url = await _upload(p.photoPath, 'pet');
    try {
      await _sb.from('pets').insert({
        'owner_id': id,
        'name': p.name,
        'species': p.species,
        'age': p.age,
        'photo_url': url,
      });
    } catch (_) {}
    await loadPets();
  }

  Future<void> removePet(Pet p) async {
    pets = pets.where((x) => x.id != p.id).toList();
    notifyListeners();
    try {
      await _sb.from('pets').delete().eq('id', p.id);
    } catch (_) {}
  }

  // ---------- پیام‌ها ----------
  Future<void> loadMessages() async {
    final id = meId;
    if (id == null) return;
    try {
      final rows = _rows(await _sb
          .from('messages')
          .select()
          .or('sender_id.eq.$id,receiver_id.eq.$id')
          .order('created_at')
          .limit(500));
      msgs = rows.map(Msg.fromRow).toList();
      await _cacheProfiles(threadPartners());
      notifyListeners();
    } catch (_) {}
  }

  List<Msg> thread(String other) {
    final m = meId;
    return msgs
        .where((x) =>
            (x.from == m && x.to == other) || (x.from == other && x.to == m))
        .toList();
  }

  List<String> threadPartners() {
    final m = meId;
    final seen = <String>[];
    for (final x in msgs.reversed) {
      final other = x.from == m ? x.to : x.from;
      if (!seen.contains(other)) seen.add(other);
    }
    return seen;
  }

  Future<void> sendMsg(String to, String text) async {
    final m = meId;
    final t = text.trim();
    if (m == null || t.isEmpty) return;
    final tmp = Msg('tmp${DateTime.now().microsecondsSinceEpoch}', m, to, t,
        DateTime.now().millisecondsSinceEpoch);
    msgs = [...msgs, tmp];
    notifyListeners();
    try {
      await _sb
          .from('messages')
          .insert({'sender_id': m, 'receiver_id': to, 'text': t});
    } catch (_) {
      msgs = msgs.where((x) => x.id != tmp.id).toList();
      notifyListeners();
      return;
    }
    await loadMessages();
  }
}
