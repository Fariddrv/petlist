import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'l10n.dart';
import 'models.dart';

/// کاربر اپ. فعلاً همه‌چیز روی همین گوشی ذخیره می‌شود؛
/// با اتصال به سرور، همین مدل به بک‌اند منتقل می‌شود.
class AppUser {
  final String id;
  String firstName, lastName, gender, email, mobile;
  String salt, passHash;
  String username, bio;
  int birth;
  String? avatarPath;
  String? avatarAsset;
  bool isPrivate, twoFactor, setupDone, demo;
  List<String> followers, following, requests, blocked;

  AppUser({
    required this.id,
    this.firstName = '',
    this.lastName = '',
    this.gender = '',
    this.email = '',
    this.mobile = '',
    this.salt = '',
    this.passHash = '',
    this.username = '',
    this.bio = '',
    this.birth = 0,
    this.avatarPath,
    this.avatarAsset,
    this.isPrivate = false,
    this.twoFactor = false,
    this.setupDone = false,
    this.demo = false,
    List<String>? followers,
    List<String>? following,
    List<String>? requests,
    List<String>? blocked,
  })  : followers = followers ?? [],
        following = following ?? [],
        requests = requests ?? [],
        blocked = blocked ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'firstName': firstName,
        'lastName': lastName,
        'gender': gender,
        'email': email,
        'mobile': mobile,
        'salt': salt,
        'passHash': passHash,
        'username': username,
        'bio': bio,
        'birth': birth,
        'avatarPath': avatarPath,
        'avatarAsset': avatarAsset,
        'isPrivate': isPrivate,
        'twoFactor': twoFactor,
        'setupDone': setupDone,
        'demo': demo,
        'followers': followers,
        'following': following,
        'requests': requests,
        'blocked': blocked,
      };

  static List<String> _ls(dynamic v) =>
      ((v as List?) ?? const []).map((e) => e.toString()).toList();

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        id: (j['id'] ?? '').toString(),
        firstName: (j['firstName'] ?? '') as String,
        lastName: (j['lastName'] ?? '') as String,
        gender: (j['gender'] ?? '') as String,
        email: (j['email'] ?? '') as String,
        mobile: (j['mobile'] ?? '') as String,
        salt: (j['salt'] ?? '') as String,
        passHash: (j['passHash'] ?? '') as String,
        username: (j['username'] ?? '') as String,
        bio: (j['bio'] ?? '') as String,
        birth: (j['birth'] as num?)?.toInt() ?? 0,
        avatarPath: j['avatarPath'] as String?,
        avatarAsset: j['avatarAsset'] as String?,
        isPrivate: (j['isPrivate'] ?? false) as bool,
        twoFactor: (j['twoFactor'] ?? false) as bool,
        setupDone: (j['setupDone'] ?? false) as bool,
        demo: (j['demo'] ?? false) as bool,
        followers: _ls(j['followers']),
        following: _ls(j['following']),
        requests: _ls(j['requests']),
        blocked: _ls(j['blocked']),
      );
}

class Msg {
  final String id, from, to, text;
  final int at;
  const Msg(this.id, this.from, this.to, this.text, this.at);

  Map<String, dynamic> toJson() =>
      {'id': id, 'from': from, 'to': to, 'text': text, 'at': at};

  factory Msg.fromJson(Map<String, dynamic> j) => Msg(
        (j['id'] ?? '').toString(),
        (j['from'] ?? '').toString(),
        (j['to'] ?? '').toString(),
        (j['text'] ?? '').toString(),
        (j['at'] as num?)?.toInt() ?? 0,
      );
}

AppUser _demo(String id, String name, String avatar,
        {bool priv = false, int fo = 0, int fg = 0, String bio = ''}) =>
    AppUser(
      id: id,
      username: name.toLowerCase(),
      bio: bio,
      avatarAsset: avatar,
      isPrivate: priv,
      demo: true,
      setupDone: true,
      followers: List.generate(fo, (i) => 'f$i'),
      following: List.generate(fg, (i) => 'g$i'),
    );

class AppState extends ChangeNotifier {
  AppLang lang = AppLang.fa;
  bool ready = false;
  List<AppUser> users = [];
  String? meId;
  List<UserPost> posts = [];
  List<Pet> pets = [];
  Map<String, PostInter> inter = {}; // تعامل‌های کاربر فعلی
  List<Msg> msgs = [];

  AppUser? get me => userById(meId);

  AppUser? userById(String? id) {
    if (id == null) return null;
    for (final u in users) {
      if (u.id == id) return u;
    }
    return null;
  }

  List<Pet> get myPets => pets.where((p) => p.ownerId == meId).toList();

  // ---------- بارگذاری ----------
  Future<void> load() async {
    try {
      final sp = await SharedPreferences.getInstance();
      List<dynamic> lst(String k) {
        final r = sp.getString(k);
        return (r == null || r.isEmpty) ? [] : (jsonDecode(r) as List);
      }

      Map<String, dynamic> mp(dynamic e) =>
          Map<String, dynamic>.from(e as Map);

      users = lst('users_v1').map((e) => AppUser.fromJson(mp(e))).toList();
      posts = lst('posts_v2').map((e) => UserPost.fromJson(mp(e))).toList();
      pets = lst('pets_v2').map((e) => Pet.fromJson(mp(e))).toList();
      msgs = lst('msgs_v1').map((e) => Msg.fromJson(mp(e))).toList();
      lang = AppLang.values.firstWhere(
        (l) => l.name == sp.getString('lang_v1'),
        orElse: () => AppLang.fa,
      );
      _ensureDemos();
      meId = sp.getString('me_v1');
      if (userById(meId) == null) meId = null;
      await _loadInter(sp);
    } catch (_) {}
    ready = true;
    notifyListeners();
  }

  void _ensureDemos() {
    final demos = [
      _demo('demo_sara', 'Sara', 'assets/avatars/avatar_sara.jpg',
          fo: 128, fg: 64, bio: 'Basie و من 🐶🌳'),
      _demo('demo_ali', 'Ali', 'assets/avatars/avatar_ali.jpg',
          fo: 86, fg: 40, bio: 'Cat dad 🐈📦'),
      _demo('demo_mina', 'Mina', 'assets/avatars/avatar_mina.jpg',
          priv: true, fo: 52, fg: 31, bio: 'Kian the parrot 🦜'),
    ];
    for (final d in demos) {
      if (userById(d.id) == null) users.add(d);
    }
  }

  Future<void> _loadInter(SharedPreferences sp) async {
    inter = {};
    if (meId == null) return;
    final raw = sp.getString('inter_v2_$meId');
    if (raw == null || raw.isEmpty) return;
    final map = Map<String, dynamic>.from(jsonDecode(raw) as Map);
    map.forEach((k, v) {
      inter[k] = PostInter.fromJson(Map<String, dynamic>.from(v as Map));
    });
  }

  // ---------- ذخیره ----------
  Future<void> _put(String key, Object o) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(key, jsonEncode(o));
  }

  Future<void> _saveUsers() => _put('users_v1', users.map((u) => u.toJson()).toList());
  Future<void> _savePosts() => _put('posts_v2', posts.map((p) => p.toJson()).toList());
  Future<void> _savePets() => _put('pets_v2', pets.map((p) => p.toJson()).toList());
  Future<void> _saveMsgs() => _put('msgs_v1', msgs.map((m) => m.toJson()).toList());
  Future<void> _saveInter() async {
    if (meId == null) return;
    await _put('inter_v2_$meId', inter.map((k, v) => MapEntry(k, v.toJson())));
  }

  // ---------- زبان ----------
  void setLang(AppLang l) {
    lang = l;
    notifyListeners();
    SharedPreferences.getInstance().then((sp) => sp.setString('lang_v1', l.name));
  }

  // ---------- حساب کاربری ----------
  static String _hash(String salt, String pass) =>
      sha256.convert(utf8.encode('$salt:$pass')).toString();

  static String _newSalt() {
    final r = Random.secure();
    return base64Url.encode(List<int>.generate(16, (_) => r.nextInt(256)));
  }

  /// null یعنی موفق؛ در غیر این‌صورت کلید پیام خطا.
  Future<String?> signUp({
    required String first,
    required String last,
    required String gender,
    required String email,
    required String mobile,
    required String pass,
    required int birth,
  }) async {
    final mail = email.trim().toLowerCase();
    for (final u in users) {
      if (!u.demo && u.email == mail) return 'errEmailUsed';
    }
    var base = mail.split('@').first.replaceAll(RegExp(r'[^a-z0-9_.]'), '');
    if (base.length < 3) base = 'user$base';
    if (base.length > 16) base = base.substring(0, 16);
    var name = base;
    var i = 1;
    while (users.any((u) => u.username.toLowerCase() == name)) {
      name = '$base${i++}';
    }
    final salt = _newSalt();
    final u = AppUser(
      id: 'u${DateTime.now().microsecondsSinceEpoch}',
      firstName: first.trim(),
      lastName: last.trim(),
      gender: gender,
      email: mail,
      mobile: mobile.trim(),
      salt: salt,
      passHash: _hash(salt, pass),
      username: name,
      birth: birth,
    );
    users.add(u);
    await _saveUsers();
    await _setMe(u.id);
    return null;
  }

  Future<String?> login(String idOrEmail, String pass) async {
    final k = idOrEmail.trim().toLowerCase();
    AppUser? found;
    for (final u in users) {
      if (!u.demo && (u.email == k || u.username.toLowerCase() == k)) found = u;
    }
    if (found == null || _hash(found.salt, pass) != found.passHash) {
      return 'errLogin';
    }
    await _setMe(found.id);
    return null;
  }

  Future<void> logout() => _setMe(null);

  Future<void> _setMe(String? id) async {
    meId = id;
    final sp = await SharedPreferences.getInstance();
    if (id == null) {
      await sp.remove('me_v1');
    } else {
      await sp.setString('me_v1', id);
    }
    await _loadInter(sp);
    notifyListeners();
  }

  Future<String?> saveProfile({
    required String username,
    required String bio,
    String? avatarPath,
  }) async {
    final m = me;
    if (m == null) return 'errLogin';
    final n = username.trim();
    if (!RegExp(r'^[A-Za-z0-9_.]{3,20}$').hasMatch(n)) return 'errUsername';
    for (final u in users) {
      if (u.id != m.id && u.username.toLowerCase() == n.toLowerCase()) {
        return 'errUsernameUsed';
      }
    }
    m.username = n;
    m.bio = bio.trim();
    if (avatarPath != null) m.avatarPath = avatarPath;
    m.setupDone = true;
    await _saveUsers();
    notifyListeners();
    return null;
  }

  Future<String?> changePassword(String oldPass, String newPass) async {
    final m = me;
    if (m == null) return 'errLogin';
    if (_hash(m.salt, oldPass) != m.passHash) return 'errOldPass';
    m.salt = _newSalt();
    m.passHash = _hash(m.salt, newPass);
    await _saveUsers();
    return null;
  }

  void setPrivate(bool v) {
    final m = me;
    if (m == null) return;
    m.isPrivate = v;
    if (!v) {
      for (final id in List<String>.from(m.requests)) {
        approve(id);
      }
    }
    _saveUsers();
    notifyListeners();
  }

  void setTwoFactor(bool v) {
    final m = me;
    if (m == null) return;
    m.twoFactor = v;
    _saveUsers();
    notifyListeners();
  }

  // ---------- دنبال‌کردن و مسدودسازی ----------
  /// none | requested | following
  String relation(AppUser t) {
    final m = me;
    if (m == null) return 'none';
    if (t.followers.contains(m.id)) return 'following';
    if (t.requests.contains(m.id)) return 'requested';
    return 'none';
  }

  void follow(AppUser t) {
    final m = me;
    if (m == null || t.id == m.id) return;
    if (t.blocked.contains(m.id) || m.blocked.contains(t.id)) return;
    if (t.isPrivate) {
      if (!t.requests.contains(m.id)) t.requests.add(m.id);
      // نسخه‌ی نمایشی: حساب‌های نمونه بعد از چند ثانیه درخواست را تایید می‌کنند.
      // با اتصال به سرور حذف می‌شود.
      if (t.demo) {
        Future.delayed(const Duration(seconds: 3), () {
          if (t.requests.remove(m.id)) {
            t.followers.add(m.id);
            m.following.add(t.id);
            _saveUsers();
            notifyListeners();
          }
        });
      }
    } else {
      if (!t.followers.contains(m.id)) t.followers.add(m.id);
      if (!m.following.contains(t.id)) m.following.add(t.id);
    }
    _saveUsers();
    notifyListeners();
  }

  void unfollow(AppUser t) {
    final m = me;
    if (m == null) return;
    t.followers.remove(m.id);
    t.requests.remove(m.id);
    m.following.remove(t.id);
    _saveUsers();
    notifyListeners();
  }

  void approve(String uid) {
    final m = me;
    if (m == null) return;
    m.requests.remove(uid);
    if (!m.followers.contains(uid)) m.followers.add(uid);
    final o = userById(uid);
    if (o != null && !o.following.contains(m.id)) o.following.add(m.id);
    _saveUsers();
    notifyListeners();
  }

  void decline(String uid) {
    me?.requests.remove(uid);
    _saveUsers();
    notifyListeners();
  }

  void block(AppUser t) {
    final m = me;
    if (m == null) return;
    if (!m.blocked.contains(t.id)) m.blocked.add(t.id);
    t.followers.remove(m.id);
    t.following.remove(m.id);
    t.requests.remove(m.id);
    m.followers.remove(t.id);
    m.following.remove(t.id);
    m.requests.remove(t.id);
    _saveUsers();
    notifyListeners();
  }

  void unblock(String id) {
    me?.blocked.remove(id);
    _saveUsers();
    notifyListeners();
  }

  bool canSee(AppUser t) {
    final m = me;
    if (m == null) return false;
    if (t.id == m.id) return true;
    if (m.blocked.contains(t.id) || t.blocked.contains(m.id)) return false;
    return !t.isPrivate || t.followers.contains(m.id);
  }

  /// پست‌هایی که کاربر فعلی اجازه‌ی دیدنشان را دارد.
  List<UserPost> visiblePosts() => posts.where((p) {
        final o = userById(p.ownerId);
        return o == null ? true : canSee(o);
      }).toList();

  /// شناسه‌ی حساب‌های نمونه‌ای که پست‌هایشان نباید نمایش داده شود.
  Set<String> hiddenDemoOwners() => {
        for (final u in users)
          if (u.demo && !canSee(u)) u.id,
      };

  // ---------- پست، پت، تعامل ----------
  void addPost(UserPost p) {
    posts.add(p);
    _savePosts();
    notifyListeners();
  }

  void removePost(UserPost p) {
    posts.remove(p);
    inter.remove(p.id);
    _savePosts();
    _saveInter();
    notifyListeners();
  }

  void addPet(Pet p) {
    pets.add(Pet(
      id: p.id,
      name: p.name,
      species: p.species,
      age: p.age,
      photoPath: p.photoPath,
      ownerId: meId ?? '',
    ));
    _savePets();
    notifyListeners();
  }

  void removePet(Pet p) {
    pets.removeWhere((x) => x.id == p.id);
    _savePets();
    notifyListeners();
  }

  void toggleLike(String id) {
    final cur = inter[id] ?? const PostInter(comments: []);
    inter[id] = cur.copyWith(liked: !cur.liked);
    _saveInter();
    notifyListeners();
  }

  void toggleSave(String id) {
    final cur = inter[id] ?? const PostInter(comments: []);
    inter[id] = cur.copyWith(saved: !cur.saved);
    _saveInter();
    notifyListeners();
  }

  void addComment(String postId, String text) {
    final cur = inter[postId] ?? const PostInter(comments: []);
    final cm = Comment(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      author: me?.username ?? 'Me',
      text: text,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
    inter[postId] = cur.copyWith(comments: [...cur.comments, cm]);
    _saveInter();
    notifyListeners();
  }

  // ---------- پیام‌ها ----------
  List<Msg> thread(String other) {
    final m = meId;
    final l = msgs
        .where((x) =>
            (x.from == m && x.to == other) || (x.from == other && x.to == m))
        .toList();
    l.sort((a, b) => a.at.compareTo(b.at));
    return l;
  }

  List<String> threadPartners() {
    final m = meId;
    final seen = <String>[];
    for (final x in msgs.reversed) {
      if (x.from != m && x.to != m) continue;
      final other = x.from == m ? x.to : x.from;
      if (!seen.contains(other)) seen.add(other);
    }
    return seen;
  }

  void sendMsg(String to, String text) {
    final m = meId;
    if (m == null || text.trim().isEmpty) return;
    final now = DateTime.now().microsecondsSinceEpoch;
    msgs.add(Msg('$now', m, to, text.trim(), DateTime.now().millisecondsSinceEpoch));
    _saveMsgs();
    notifyListeners();
  }

  // ---------- پشتیبان ----------
  String exportJson() => const JsonEncoder.withIndent('  ').convert({
        'app': 'petlist',
        'version': 2,
        'lang': lang.name,
        'pets': myPets.map((p) => p.toJson()).toList(),
        'posts': posts.where((p) => p.ownerId == meId).map((p) => p.toJson()).toList(),
        'inter': inter.map((k, v) => MapEntry(k, v.toJson())),
      });

  bool restoreFrom(String raw) {
    Map<String, dynamic> data;
    try {
      data = Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return false;
    }
    if (data['app'] != 'petlist') return false;
    try {
      final mine = meId ?? '';
      final np = <Pet>[];
      for (final it in (data['pets'] as List? ?? [])) {
        final p = Pet.fromJson(Map<String, dynamic>.from(it as Map));
        np.add(Pet(
            id: p.id, name: p.name, species: p.species, age: p.age,
            photoPath: p.photoPath, ownerId: mine));
      }
      final nq = <UserPost>[];
      for (final it in (data['posts'] as List? ?? [])) {
        final p = UserPost.fromJson(Map<String, dynamic>.from(it as Map));
        nq.add(UserPost(
            id: p.id, author: p.author, text: p.text,
            imagePath: p.imagePath, likes: p.likes, ownerId: mine));
      }
      final ni = <String, PostInter>{};
      Map<String, dynamic>.from(data['inter'] as Map? ?? {}).forEach((k, v) {
        ni[k] = PostInter.fromJson(Map<String, dynamic>.from(v as Map));
      });
      pets = [...pets.where((p) => p.ownerId != mine), ...np];
      posts = [...posts.where((p) => p.ownerId != mine), ...nq];
      inter = ni;
    } catch (_) {
      return false;
    }
    _savePets();
    _savePosts();
    _saveInter();
    notifyListeners();
    return true;
  }
}
