import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show Supabase, SupabaseClient, FileOptions;

import 'shop_models.dart';
import 'state.dart';

List<Map<String, dynamic>> _rows(dynamic r) =>
    (r as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();

/// وضعیت و عملیات مارکت‌پلیس: فروشگاه من، محصولات و خدمات، جستجو.
class ShopStore extends ChangeNotifier {
  final AppState app;
  ShopStore(this.app);

  SupabaseClient get _sb => Supabase.instance.client;

  Shop? myShop;
  bool myShopLoaded = false;
  List<Listing> myListings = [];
  String lastError = '';
  int commissionPercent = 10;

  void reset() {
    myShop = null;
    myShopLoaded = false;
    myListings = [];
    notifyListeners();
  }

  // ---------- فروشگاه من ----------
  Future<void> loadMyShop() async {
    final id = app.meId;
    if (id == null) return;
    try {
      final row =
          await _sb.from('shops').select().eq('owner_id', id).maybeSingle();
      myShop = row == null ? null : Shop.fromRow(Map<String, dynamic>.from(row));
      myShopLoaded = true;
      if (myShop != null) await loadMyListings();
    } catch (e) {
      lastError = 'myShop: $e';
      myShopLoaded = true;
    }
    notifyListeners();
  }

  Future<void> loadCommission() async {
    try {
      final r = await _sb
          .from('app_settings')
          .select('value')
          .eq('key', 'commission_percent')
          .maybeSingle();
      final v = r?['value'];
      if (v is num) commissionPercent = v.toInt();
    } catch (_) {}
  }

  /// نوع مدرک → مسیر فایل در فضای خصوصی. null = موفق، وگرنه کلید خطا.
  Future<String?> createShop({
    required String name,
    required String description,
    required String phone,
    required String email,
    required String address,
    required String country,
    required String city,
    required List<String> types,
    required String contactFirst,
    required String contactLast,
    required String termsVersion,
    String? logoPath,
    required Map<String, String> docs, // kind -> local path
  }) async {
    final uid = app.meId;
    if (uid == null) return 'errLogin';
    lastError = '';
    try {
      String? logo;
      if (logoPath != null) logo = await app.uploadMedia(logoPath, 'shoplogo');
      final row = await _sb
          .from('shops')
          .insert({
            'owner_id': uid,
            'name': name.trim(),
            'description': description.trim(),
            'logo_url': logo,
            'phone': phone.trim(),
            'email': email.trim(),
            'address': address.trim(),
            'country': country,
            'city': city,
            'service_keys': types,
            'contact_first': contactFirst.trim(),
            'contact_last': contactLast.trim(),
            'terms_version': termsVersion,
            'terms_accepted_at': DateTime.now().toUtc().toIso8601String(),
          })
          .select('id')
          .single();
      final shopId = row['id'].toString();
      for (final e in docs.entries) {
        final path = await _uploadPrivate(e.value, e.key);
        if (path == null) {
          lastError = 'doc upload failed (${e.key})';
          continue;
        }
        await _sb.from('shop_documents').insert({
          'shop_id': shopId,
          'kind': e.key,
          'file_path': path,
        });
      }
      await loadMyShop();
      return null;
    } catch (e) {
      lastError = 'createShop: $e';
      return 'errNet';
    }
  }

  Future<String?> _uploadPrivate(String localPath, String kind) async {
    final uid = app.meId;
    if (uid == null) return null;
    try {
      final ext = localPath.contains('.') ? localPath.split('.').last.toLowerCase() : 'jpg';
      final name = '$uid/$kind-${DateTime.now().microsecondsSinceEpoch}.$ext';
      await _sb.storage.from('kyc').upload(
            name,
            File(localPath),
            fileOptions: FileOptions(
                contentType: ext == 'png' ? 'image/png' : 'image/jpeg'),
          );
      return name;
    } catch (e) {
      lastError = 'kyc upload: $e';
      return null;
    }
  }

  Future<String?> updateShop({
    required String name,
    required String description,
    required String phone,
    required String email,
    required String address,
    required String country,
    required String city,
    String? logoPath,
  }) async {
    final sh = myShop;
    if (sh == null) return 'errLogin';
    try {
      final data = <String, dynamic>{
        'name': name.trim(),
        'description': description.trim(),
        'phone': phone.trim(),
        'email': email.trim(),
        'address': address.trim(),
        'country': country,
        'city': city,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      };
      if (logoPath != null) {
        final u = await app.uploadMedia(logoPath, 'shoplogo');
        if (u != null) data['logo_url'] = u;
      }
      await _sb.from('shops').update(data).eq('id', sh.id);
      await loadMyShop();
      return null;
    } catch (e) {
      lastError = 'updateShop: $e';
      return 'errNet';
    }
  }

  Future<void> resubmit() async {
    try {
      await _sb.rpc('shop_resubmit');
    } catch (e) {
      lastError = 'resubmit: $e';
    }
    await loadMyShop();
  }

  // ---------- محصولات و خدمات من ----------
  Future<void> loadMyListings() async {
    final sh = myShop;
    if (sh == null) return;
    try {
      final rows = _rows(await _sb
          .from('listings')
          .select()
          .eq('shop_id', sh.id)
          .order('created_at', ascending: false));
      myListings = rows.map(Listing.fromRow).toList();
    } catch (e) {
      lastError = 'myListings: $e';
    }
    notifyListeners();
  }

  /// ذخیره‌ی آگهی (جدید یا ویرایش). [localImages] مسیر عکس‌های تازه است.
  Future<String?> saveListing({
    String? id,
    required String kind,
    required String categoryKey,
    required String title,
    required String description,
    required int priceMinor,
    required String currency,
    int? stock,
    int? durationMin,
    required List<String> keptImages,
    required List<String> localImages,
    required bool active,
  }) async {
    final sh = myShop;
    if (sh == null) return 'errLogin';
    try {
      final images = [...keptImages];
      for (final p in localImages) {
        final u = await app.uploadMedia(p, 'listing');
        if (u != null) images.add(u);
      }
      final data = <String, dynamic>{
        'kind': kind,
        'category_key': categoryKey,
        'title': title.trim(),
        'description': description.trim(),
        'price_minor': priceMinor,
        'currency': currency,
        'stock': kind == 'product' ? stock : null,
        'duration_min': kind == 'service' ? durationMin : null,
        'images': images,
        'active': active,
      };
      if (id == null) {
        await _sb.from('listings').insert({'shop_id': sh.id, ...data});
      } else {
        await _sb.from('listings').update(data).eq('id', id);
      }
      await loadMyListings();
      return null;
    } catch (e) {
      lastError = 'saveListing: $e';
      return 'errNet';
    }
  }

  Future<void> setActive(Listing l, bool v) async {
    try {
      await _sb.from('listings').update({'active': v}).eq('id', l.id);
    } catch (e) {
      lastError = 'setActive: $e';
    }
    await loadMyListings();
  }

  Future<void> deleteListing(Listing l) async {
    myListings = myListings.where((x) => x.id != l.id).toList();
    notifyListeners();
    try {
      await _sb.from('listings').delete().eq('id', l.id);
    } catch (e) {
      lastError = 'deleteListing: $e';
    }
  }

  // ---------- مرور و جستجو ----------
  static const _listCols =
      '*, shops(id,name,logo_url,verified,owner_id)';

  /// [localOnly] فقط کشور و شهر خود کاربر.
  Future<List<Listing>> browse({
    String query = '',
    String? category,
    String? kind,
    bool localOnly = false,
    int limit = 60,
  }) async {
    try {
      var q = _sb.from('listings').select(_listCols).eq('active', true);
      if (category != null) q = q.eq('category_key', category);
      if (kind != null) q = q.eq('kind', kind);
      final m = app.me;
      if (localOnly && m != null && m.country.isNotEmpty) {
        q = q.eq('country', m.country);
        if (m.city.isNotEmpty) q = q.eq('city', m.city);
      }
      final t = query.trim().replaceAll(RegExp(r'[%,()]'), '');
      if (t.isNotEmpty) {
        q = q.or('title.ilike.%$t%,description.ilike.%$t%');
      }
      final rows = _rows(await q.order('created_at', ascending: false).limit(limit));
      return rows.map(Listing.fromRow).toList();
    } catch (e) {
      lastError = 'browse: $e';
      return [];
    }
  }

  Future<Shop?> loadShop(String id) async {
    try {
      final row = await _sb.from('shops').select().eq('id', id).maybeSingle();
      return row == null ? null : Shop.fromRow(Map<String, dynamic>.from(row));
    } catch (e) {
      lastError = 'loadShop: $e';
      return null;
    }
  }

  Future<List<Listing>> shopListings(String shopId) async {
    try {
      final rows = _rows(await _sb
          .from('listings')
          .select(_listCols)
          .eq('shop_id', shopId)
          .eq('active', true)
          .order('created_at', ascending: false));
      return rows.map(Listing.fromRow).toList();
    } catch (e) {
      lastError = 'shopListings: $e';
      return [];
    }
  }
}
