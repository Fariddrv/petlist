import 'package:flutter/material.dart';

/// زبان‌های پشتیبانی‌شده‌ی اپلیکیشن.
enum AppLang { fa, en, zh }

extension AppLangInfo on AppLang {
  TextDirection get direction =>
      this == AppLang.fa ? TextDirection.rtl : TextDirection.ltr;

  String get label => switch (this) {
        AppLang.fa => 'فارسی',
        AppLang.en => 'English',
        AppLang.zh => '中文',
      };
}

/// متن‌های سه‌زبانه‌ی اپ. برای افزودن متن جدید فقط همین‌جا را کامل کن.
class L10n {
  final AppLang lang;
  final String appTitle;
  final String tabHome, tabPets, tabEvents, tabShop;
  final String changeLang;
  final String homeWelcome, homeWelcomeSub;
  final String petsEmpty, petsEmptySub;
  final String petNameHint, petKindLabel, kindCat, kindDog, kindOther;
  final String petAgeHint, petSave, petSaved, petDeleted, nameRequired;
  final String eventsBanner, eventJoin, eventJoined;
  final String shopBanner, shopTapHint;
  final String yearsOld;

  const L10n({
    required this.lang,
    required this.appTitle,
    required this.tabHome,
    required this.tabPets,
    required this.tabEvents,
    required this.tabShop,
    required this.changeLang,
    required this.homeWelcome,
    required this.homeWelcomeSub,
    required this.petsEmpty,
    required this.petsEmptySub,
    required this.petNameHint,
    required this.petKindLabel,
    required this.kindCat,
    required this.kindDog,
    required this.kindOther,
    required this.petAgeHint,
    required this.petSave,
    required this.petSaved,
    required this.petDeleted,
    required this.nameRequired,
    required this.eventsBanner,
    required this.eventJoin,
    required this.eventJoined,
    required this.shopBanner,
    required this.shopTapHint,
    required this.yearsOld,
  });

  static const Map<AppLang, L10n> all = {
    AppLang.fa: L10n(
      lang: AppLang.fa,
      appTitle: 'پت‌لیست',
      tabHome: 'خانه',
      tabPets: 'حیوانات خانگی من',
      tabEvents: 'ایونت‌ها',
      tabShop: 'فروشگاه',
      changeLang: 'تغییر زبان',
      homeWelcome: 'به پت‌لیست خوش آمدی! 🐾',
      homeWelcomeSub: 'اینجا فید نمونه است؛ به‌زودی پست‌های واقعی کاربران اینجاست.',
      petsEmpty: 'هنوز پتی ثبت نکرده‌ای',
      petsEmptySub: 'با فرم زیر اولین پتت را اضافه کن.',
      petNameHint: 'نام پت',
      petKindLabel: 'نوع پت',
      kindCat: 'گربه',
      kindDog: 'سگ',
      kindOther: 'سایر',
      petAgeHint: 'سن (سال)',
      petSave: 'افزودن پت',
      petSaved: 'پت اضافه شد! 🎉',
      petDeleted: 'پت حذف شد.',
      nameRequired: 'اول نام پت را بنویس.',
      eventsBanner: 'ایونت‌ها نمونه هستند؛ به‌زودی کاربران خودشان ایونت می‌سازند.',
      eventJoin: 'شرکت می‌کنم',
      eventJoined: 'ثبت شد ✅',
      shopBanner: 'فروشگاه در فاز بعدی فعال می‌شود؛ این‌ها نمونه‌اند.',
      shopTapHint: 'به‌زودی قابل خرید است!',
      yearsOld: 'سال',
    ),
    AppLang.en: L10n(
      lang: AppLang.en,
      appTitle: 'PetList',
      tabHome: 'Home',
      tabPets: 'My Pets',
      tabEvents: 'Events',
      tabShop: 'Shop',
      changeLang: 'Change language',
      homeWelcome: 'Welcome to PetList! 🐾',
      homeWelcomeSub: 'This is a sample feed; real user posts coming soon.',
      petsEmpty: 'No pets yet',
      petsEmptySub: 'Add your first pet with the form below.',
      petNameHint: 'Pet name',
      petKindLabel: 'Pet type',
      kindCat: 'Cat',
      kindDog: 'Dog',
      kindOther: 'Other',
      petAgeHint: 'Age (years)',
      petSave: 'Add pet',
      petSaved: 'Pet added! 🎉',
      petDeleted: 'Pet removed.',
      nameRequired: 'Write the pet name first.',
      eventsBanner: 'Sample events; users will create their own soon.',
      eventJoin: 'Join',
      eventJoined: 'Joined ✅',
      shopBanner: 'Shop launches in a later phase; these are samples.',
      shopTapHint: 'Purchasing coming soon!',
      yearsOld: 'years',
    ),
    AppLang.zh: L10n(
      lang: AppLang.zh,
      appTitle: '宠物社区',
      tabHome: '首页',
      tabPets: '我的宠物',
      tabEvents: '活动',
      tabShop: '商店',
      changeLang: '切换语言',
      homeWelcome: '欢迎来到宠物社区！🐾',
      homeWelcomeSub: '这是示例动态；用户真实帖子即将上线。',
      petsEmpty: '还没有宠物',
      petsEmptySub: '用下面的表单添加你的第一只宠物。',
      petNameHint: '宠物名字',
      petKindLabel: '宠物类型',
      kindCat: '猫',
      kindDog: '狗',
      kindOther: '其他',
      petAgeHint: '年龄（岁）',
      petSave: '添加宠物',
      petSaved: '宠物已添加！🎉',
      petDeleted: '宠物已删除。',
      nameRequired: '请先填写宠物名字。',
      eventsBanner: '示例活动；用户很快可以自建活动。',
      eventJoin: '参加',
      eventJoined: '已报名 ✅',
      shopBanner: '商店将在后续阶段上线；这些是示例。',
      shopTapHint: '即将可以购买！',
      yearsOld: '岁',
    ),
  };

  static L10n of(AppLang l) => all[l]!;

  static String _faDigits(String s) => s.replaceAllMapped(
      RegExp(r'\d'), (m) => '۰۱۲۳۴۵۶۷۸۹'[int.parse(m.group(0)!)]);

  /// نمایش قیمت بر اساس زبان.
  String price(int toman) => switch (lang) {
        AppLang.fa => '${_faDigits(toman.toString())} تومان',
        AppLang.en => '$toman Toman',
        AppLang.zh => '$toman 土曼',
      };
}
