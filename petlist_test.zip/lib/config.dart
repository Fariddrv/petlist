/// تنظیمات اتصال به سرور (Supabase).
/// این دو مقدار «عمومی» هستند و طراحی شده‌اند که داخل اپ باشند؛
/// امنیت واقعی را قوانین دیتابیس (RLS) تامین می‌کنند.
const String kSupabaseUrl = 'https://ajvlqvcljplrkfgztljf.supabase.co';
const String kSupabaseKey = 'sb_publishable_G8Z-Z_pJYCsvddAHTJyoCQ_xHxqyzqT';

/// منطقه‌ی این نسخه‌ی اپ: intl (بین‌المللی) | ir (ایران) | cn (چین).
/// موقع بیلد با --dart-define=REGION=ir عوض می‌شود.
const String kRegion = String.fromEnvironment('REGION', defaultValue: 'intl');

/// آدرس دانلود اپ برای دعوت دوستان (فعلاً نمونه؛ بعد از داشتن سایت/فروشگاه عوض شود).
const String kInviteLink = 'https://pawpet.app';

/// ایمیل پشتیبانی (فعلاً نمونه؛ بعد از ساخت ایمیل واقعی عوض شود).
const String kSupportEmail = 'support@pawpet.app';

/// حداکثر مدت ویدئوی پست (ثانیه) — بعداً می‌شود بیشتر کرد.
const int kMaxVideoSeconds = 90;

/// حداکثر حجم فایل ویدئو بعد از فشرده‌سازی (سقف آپلود پلن رایگان Supabase ۵۰ مگابایت است).
const int kMaxVideoBytes = 48 * 1024 * 1024;
