/// تنظیمات اتصال به سرور (Supabase).
/// این دو مقدار «عمومی» هستند و طراحی شده‌اند که داخل اپ باشند؛
/// امنیت واقعی را قوانین دیتابیس (RLS) تامین می‌کنند.
const String kSupabaseUrl = 'https://ajvlqvcljplrkfgztljf.supabase.co';
const String kSupabaseKey = 'sb_publishable_G8Z-Z_pJYCsvddAHTJyoCQ_xHxqyzqT';

/// منطقه‌ی این نسخه‌ی اپ: intl (بین‌المللی) | ir (ایران) | cn (چین).
/// موقع بیلد با --dart-define=REGION=ir عوض می‌شود.
const String kRegion = String.fromEnvironment('REGION', defaultValue: 'intl');
