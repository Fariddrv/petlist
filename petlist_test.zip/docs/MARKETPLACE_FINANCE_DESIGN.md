# طراحی مالی مارکت‌پلیس pawpet (مرحله‌ی B به بعد)

## اصول
1. **دفتر کل دوطرفه (ledger):** هر جابه‌جایی پول یک رکورد تغییرناپذیر؛ موجودی = جمع رکوردها.
2. **فقط سرور می‌نویسد:** کاربر/اپ مستقیم در جدول‌های مالی نمی‌نویسد؛ فقط توابع
   (RPC/Edge Function) داخل تراکنش دیتابیس.
3. **مبلغ = عدد صحیح + ارز.** موجودی هر ارز جداست. (در مرحله‌ی A همین الان
   `price_minor` + `currency` روی هر آگهی هست.)
4. **مستقل از درگاه:** هر منطقه یک آداپتور (ایران: پرداخت‌یار تسهیم‌دار؛ بین‌الملل: مثلاً
   Stripe Connect). دفتر کل ما می‌گوید چه کسی چقدر طلب دارد.

## حساب‌ها (ledger_accounts)
`user_wallet`، `vendor_pending` (در انتظار آزادسازی)، `vendor_available`،
`platform_escrow`، `platform_revenue`، `gateway_clearing`.

## چرخه‌ی سفارش کالا
`pending_payment → paid_held → shipped → delivered → released`
(یا `disputed → refunded / partial / released`)
- آزادسازی خودکار چند روز بعد از تحویل (زمان‌بندی با pg_cron)
- کمیسیون در لحظه‌ی سفارش ذخیره می‌شود (`commission_percent` snapshot)

## چرخه‌ی رزرو خدمت
`requested → confirmed → paid_held → in_service → completed (QR یا کد تایید) → released`

## جدول‌های پیشنهادی مرحله‌ی B
`ledger_accounts`، `ledger_entries` (مبلغ، ارز، حساب بدهکار/بستانکار، ارجاع، idempotency_key)،
`orders`، `order_items`، `bookings`، `availability_slots`، `payments`، `payouts`،
`disputes`، `dispute_evidence`، `reviews`.

## تبلیغات و اشتراک
روی همان دفتر کل: پرداخت تبلیغ و اشتراک مستقیم به `platform_revenue` می‌رود
(بدون اسکرو).

## داشبورد مالی فروشنده
فروش کل، در انتظار، قابل برداشت، فهرست سفارش‌ها، درخواست برداشت (تایید ادمین)،
گزارش ماهانه — همه از ledger خوانده می‌شوند.
