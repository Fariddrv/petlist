-- ===== pawpet: به‌روزرسانی ۴ (فقط یک بار اجرا شود) =====

-- زمان تایید درخواست دنبال‌کردن (برای اعلان‌ها) + اجازه‌ی نوشتن آن
alter table public.follows add column if not exists accepted_at timestamptz;
update public.follows set accepted_at = created_at where status = 'accepted' and accepted_at is null;
revoke update on public.follows from authenticated;
grant update (status, accepted_at) on public.follows to authenticated;

-- تصویر کاور ویدئو
alter table public.posts add column if not exists thumb_url text;

-- حذف گفتگو (فقط برای خودِ کاربر)
create table if not exists public.chat_clears (
  user_id uuid not null references public.profiles(id) on delete cascade,
  partner_id uuid not null references public.profiles(id) on delete cascade,
  cleared_at timestamptz not null default now(),
  primary key (user_id, partner_id)
);
alter table public.chat_clears enable row level security;
drop policy if exists chat_clears_own on public.chat_clears;
create policy chat_clears_own on public.chat_clears for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
grant select, insert, update, delete on public.chat_clears to authenticated;
