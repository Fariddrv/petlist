-- ===== pawpet: به‌روزرسانی ۳ (فقط یک بار اجرا شود) =====

-- پاسخ به پیام در چت
alter table public.messages add column if not exists reply_to uuid references public.messages(id) on delete set null;

-- حذف پیام‌های خودِ فرستنده (برای «بریدن» و حذف)
drop policy if exists messages_delete_own on public.messages;
create policy messages_delete_own on public.messages for delete to authenticated
  using (sender_id = auth.uid());

-- تاریخ ثبت لایک‌ها (برای اعلان‌ها)
alter table public.post_likes add column if not exists created_at timestamptz not null default now();
alter table public.comment_likes add column if not exists created_at timestamptz not null default now();

-- تاریخ تولد حیوان
alter table public.pets add column if not exists birth_date date;

-- گزارش پست یا حساب (فقط ادمین می‌خواند؛ کاربر فقط می‌فرستد)
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('post','account')),
  target_id uuid not null,
  reason text not null,
  status text not null default 'new',
  created_at timestamptz not null default now()
);
alter table public.reports enable row level security;
drop policy if exists reports_insert_own on public.reports;
create policy reports_insert_own on public.reports for insert to authenticated
  with check (reporter_id = auth.uid());
grant select, insert on public.reports to authenticated;

-- فهرست فالوورها / دنبال‌شده‌ها (فقط اگر اجازه‌ی دیدن آن پروفایل را داشته باشیم)
create or replace function public.follow_list(uid uuid, want_followers boolean)
returns setof uuid language sql stable security definer set search_path = public as $$
  select case when want_followers then f.follower_id else f.followee_id end
  from public.follows f
  where f.status = 'accepted'
    and ((want_followers and f.followee_id = uid) or (not want_followers and f.follower_id = uid))
    and public.can_see_owner(uid)
  limit 500;
$$;
revoke execute on function public.follow_list(uuid, boolean) from public, anon;
grant execute on function public.follow_list(uuid, boolean) to authenticated;

-- ===== رویدادها =====
create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text not null default '',
  image_url text,
  event_date date not null,
  country text,
  city text,
  created_at timestamptz not null default now()
);
create index if not exists events_loc_idx on public.events (country, city, event_date);

create table if not exists public.event_participants (
  event_id uuid not null references public.events(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (event_id, user_id)
);
create table if not exists public.event_likes (
  event_id uuid not null references public.events(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (event_id, user_id)
);
create table if not exists public.event_comments (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  text text not null,
  parent_id uuid references public.event_comments(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.event_comment_likes (
  comment_id uuid not null references public.event_comments(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (comment_id, user_id)
);

alter table public.events enable row level security;
alter table public.event_participants enable row level security;
alter table public.event_likes enable row level security;
alter table public.event_comments enable row level security;
alter table public.event_comment_likes enable row level security;

drop policy if exists events_read on public.events;
drop policy if exists events_insert on public.events;
drop policy if exists events_delete on public.events;
create policy events_read on public.events for select to authenticated using (true);
create policy events_insert on public.events for insert to authenticated with check (owner_id = auth.uid());
create policy events_delete on public.events for delete to authenticated using (owner_id = auth.uid());

drop policy if exists ep_read on public.event_participants;
drop policy if exists ep_insert on public.event_participants;
drop policy if exists ep_delete on public.event_participants;
create policy ep_read on public.event_participants for select to authenticated using (true);
create policy ep_insert on public.event_participants for insert to authenticated with check (user_id = auth.uid());
create policy ep_delete on public.event_participants for delete to authenticated using (user_id = auth.uid());

drop policy if exists el_read on public.event_likes;
drop policy if exists el_insert on public.event_likes;
drop policy if exists el_delete on public.event_likes;
create policy el_read on public.event_likes for select to authenticated using (true);
create policy el_insert on public.event_likes for insert to authenticated with check (user_id = auth.uid());
create policy el_delete on public.event_likes for delete to authenticated using (user_id = auth.uid());

drop policy if exists ec_read on public.event_comments;
drop policy if exists ec_insert on public.event_comments;
drop policy if exists ec_delete on public.event_comments;
create policy ec_read on public.event_comments for select to authenticated using (true);
create policy ec_insert on public.event_comments for insert to authenticated with check (user_id = auth.uid());
create policy ec_delete on public.event_comments for delete to authenticated
  using (user_id = auth.uid() or exists (select 1 from public.events e where e.id = event_id and e.owner_id = auth.uid()));

drop policy if exists ecl_read on public.event_comment_likes;
drop policy if exists ecl_insert on public.event_comment_likes;
drop policy if exists ecl_delete on public.event_comment_likes;
create policy ecl_read on public.event_comment_likes for select to authenticated using (true);
create policy ecl_insert on public.event_comment_likes for insert to authenticated with check (user_id = auth.uid());
create policy ecl_delete on public.event_comment_likes for delete to authenticated using (user_id = auth.uid());

grant select, insert, update, delete on public.events, public.event_participants, public.event_likes,
  public.event_comments, public.event_comment_likes to authenticated;

-- ویدئوی پست
alter table public.posts add column if not exists media_type text not null default 'image';
