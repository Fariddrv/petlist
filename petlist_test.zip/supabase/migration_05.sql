-- ===== pawpet: به‌روزرسانی ۵ (فقط یک بار اجرا شود) =====
-- بخش ۱: ویرایش پست، موقعیت و تگ دوستان
-- بخش ۲: زیرساخت پنل مدیریت (ادمین‌ها، اطلاعیه‌ها، بنرها، تنظیمات، ثبت اقدامات)

-- ---------- ۱) پست‌ها ----------
alter table public.posts add column if not exists location_text text;
alter table public.posts add column if not exists lat double precision;
alter table public.posts add column if not exists lng double precision;
alter table public.posts add column if not exists edited_at timestamptz;

-- صاحب پست فقط این ستون‌ها را می‌تواند ویرایش کند (عکس/ویدئو ثابت می‌ماند)
drop policy if exists posts_update_own on public.posts;
create policy posts_update_own on public.posts for update to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());
revoke update on public.posts from authenticated;
grant update (text, location_text, lat, lng, edited_at) on public.posts to authenticated;

create table if not exists public.post_tags (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);
alter table public.post_tags enable row level security;
drop policy if exists post_tags_read on public.post_tags;
drop policy if exists post_tags_insert on public.post_tags;
drop policy if exists post_tags_delete on public.post_tags;
create policy post_tags_read on public.post_tags for select to authenticated
  using (exists (select 1 from public.posts p where p.id = post_id));
create policy post_tags_insert on public.post_tags for insert to authenticated
  with check (exists (select 1 from public.posts p where p.id = post_id and p.owner_id = auth.uid()));
create policy post_tags_delete on public.post_tags for delete to authenticated
  using (exists (select 1 from public.posts p where p.id = post_id and p.owner_id = auth.uid()));
grant select, insert, delete on public.post_tags to authenticated;

-- ---------- ۲) زیرساخت پنل مدیریت ----------

-- ادمین‌ها. نقش‌ها: owner (شما) | admin | moderator
create table if not exists public.admins (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  role text not null default 'moderator' check (role in ('owner','admin','moderator')),
  created_at timestamptz not null default now()
);
alter table public.admins enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

create or replace function public.admin_role()
returns text language sql stable security definer set search_path = public as $$
  select role from public.admins where user_id = auth.uid();
$$;

drop policy if exists admins_read on public.admins;
drop policy if exists admins_write on public.admins;
create policy admins_read on public.admins for select to authenticated
  using (user_id = auth.uid() or public.is_admin());
-- فقط owner می‌تواند ادمین اضافه/حذف کند
create policy admins_write on public.admins for all to authenticated
  using (public.admin_role() = 'owner') with check (public.admin_role() = 'owner');
grant select, insert, update, delete on public.admins to authenticated;

-- اطلاعیه‌های رسمی اپ (در منوی کشویی نمایش داده می‌شود)
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null default '',
  image_url text,
  published boolean not null default true,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table public.announcements enable row level security;
drop policy if exists announcements_read on public.announcements;
drop policy if exists announcements_admin on public.announcements;
create policy announcements_read on public.announcements for select to authenticated
  using (published or public.is_admin());
create policy announcements_admin on public.announcements for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.announcements to authenticated;

-- بنرهای تبلیغاتی (خانه / رویدادها / فروشگاه)
create table if not exists public.banners (
  id uuid primary key default gen_random_uuid(),
  placement text not null default 'home' check (placement in ('home','events','shop')),
  image_url text not null,
  title text,
  link_url text,
  country text,                     -- خالی = همه‌ی کشورها
  sort_order int not null default 0,
  active boolean not null default true,
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.banners enable row level security;
drop policy if exists banners_read on public.banners;
drop policy if exists banners_admin on public.banners;
create policy banners_read on public.banners for select to authenticated
  using (active or public.is_admin());
create policy banners_admin on public.banners for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.banners to authenticated;

-- تنظیمات اپ (مثلاً درصد کمیسیون، قیمت اشتراک، حداکثر مدت ویدئو)
create table if not exists public.app_settings (
  key text primary key,
  value jsonb not null,
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);
alter table public.app_settings enable row level security;
drop policy if exists settings_read on public.app_settings;
drop policy if exists settings_admin on public.app_settings;
create policy settings_read on public.app_settings for select to authenticated using (true);
create policy settings_admin on public.app_settings for all to authenticated
  using (public.admin_role() in ('owner','admin')) with check (public.admin_role() in ('owner','admin'));
grant select, insert, update, delete on public.app_settings to authenticated;

insert into public.app_settings (key, value) values
  ('commission_percent', '10'::jsonb),
  ('max_video_seconds', '90'::jsonb)
on conflict (key) do nothing;

-- گزارش‌های کاربران: ادمین‌ها می‌بینند و وضعیت را عوض می‌کنند
alter table public.reports add column if not exists handled_by uuid references public.profiles(id) on delete set null;
alter table public.reports add column if not exists handled_at timestamptz;
drop policy if exists reports_admin_read on public.reports;
drop policy if exists reports_admin_update on public.reports;
create policy reports_admin_read on public.reports for select to authenticated using (public.is_admin());
create policy reports_admin_update on public.reports for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant update on public.reports to authenticated;

-- پیام‌های پشتیبانی
alter table public.support_messages add column if not exists status text not null default 'new';
drop policy if exists support_admin_read on public.support_messages;
drop policy if exists support_admin_update on public.support_messages;
create policy support_admin_read on public.support_messages for select to authenticated using (public.is_admin());
create policy support_admin_update on public.support_messages for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant update on public.support_messages to authenticated;

-- مدیریت محتوا: ادمین‌ها می‌توانند پست، کامنت و رویداد نامناسب را حذف کنند
drop policy if exists posts_admin_delete on public.posts;
drop policy if exists comments_admin_delete on public.comments;
drop policy if exists events_admin_delete on public.events;
drop policy if exists event_comments_admin_delete on public.event_comments;
create policy posts_admin_delete on public.posts for delete to authenticated using (public.is_admin());
create policy comments_admin_delete on public.comments for delete to authenticated using (public.is_admin());
create policy events_admin_delete on public.events for delete to authenticated using (public.is_admin());
create policy event_comments_admin_delete on public.event_comments for delete to authenticated using (public.is_admin());
-- ادمین‌ها همه‌ی پست‌ها را (حتی حساب خصوصی) برای بررسی گزارش می‌بینند
drop policy if exists posts_admin_read on public.posts;
create policy posts_admin_read on public.posts for select to authenticated using (public.is_admin());

-- ثبت اقدامات مدیریتی (چه کسی، چه کاری، روی چه چیزی)
create table if not exists public.audit_log (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_type text,
  target_id text,
  details jsonb,
  created_at timestamptz not null default now()
);
alter table public.audit_log enable row level security;
drop policy if exists audit_read on public.audit_log;
drop policy if exists audit_insert on public.audit_log;
create policy audit_read on public.audit_log for select to authenticated using (public.is_admin());
create policy audit_insert on public.audit_log for insert to authenticated
  with check (public.is_admin() and admin_id = auth.uid());
grant select, insert on public.audit_log to authenticated;

-- ===== ساخت اولین ادمین (owner) =====
-- بعد از اجرای بالا، این دستور را جداگانه اجرا کنید و ایمیل خودتان را بنویسید:
--
-- insert into public.admins (user_id, role)
-- select id, 'owner' from auth.users where email = 'YOUR_EMAIL@example.com'
-- on conflict (user_id) do update set role = 'owner';
