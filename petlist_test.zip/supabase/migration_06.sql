-- ===== pawpet: به‌روزرسانی ۶ — مرحله‌ی A مارکت‌پلیس (فقط یک بار اجرا شود) =====
-- فروشگاه‌ها، مدارک هویتی (خصوصی)، محصولات و خدمات

-- ---------- ابزارهای ادمین (اگر قبلاً ساخته شده باشند، بدون تغییر می‌مانند) ----------
create table if not exists public.admins (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  role text not null default 'moderator' check (role in ('owner','admin','moderator')),
  created_at timestamptz not null default now()
);
alter table public.admins enable row level security;
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;
create or replace function public.admin_role()
returns text language sql stable security definer set search_path = public as $$
  select role from public.admins where user_id = auth.uid();
$$;
create table if not exists public.audit_log (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_type text,
  target_id text,
  details jsonb,
  created_at timestamptz not null default now()
);
alter table public.audit_log enable row level security;

-- ---------- فروشگاه‌ها ----------
create table if not exists public.shops (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references public.profiles(id) on delete cascade,
  name text not null,
  description text not null default '',
  logo_url text,
  cover_url text,
  phone text,
  email text,
  address text,
  country text,
  city text,
  service_keys text[] not null default '{}',   -- نوع فعالیت: vet, petshop, groomer, ...
  contact_first text,
  contact_last text,
  status text not null default 'pending'
    check (status in ('pending','approved','rejected','suspended')),
  verified boolean not null default false,
  rejection_reason text,
  terms_version text,
  terms_accepted_at timestamptz,
  plan text not null default 'trial',
  subscription_until timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.shops enable row level security;

drop policy if exists shops_read on public.shops;
drop policy if exists shops_insert_own on public.shops;
drop policy if exists shops_update_own on public.shops;
create policy shops_read on public.shops for select to authenticated
  using (status = 'approved' or owner_id = auth.uid() or public.is_admin());
create policy shops_insert_own on public.shops for insert to authenticated
  with check (owner_id = auth.uid() and status = 'pending' and verified = false);
create policy shops_update_own on public.shops for update to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- صاحب فروشگاه فقط این ستون‌ها را می‌نویسد؛ وضعیت، تایید و اشتراک فقط با تابع‌های ادمین
revoke insert, update on public.shops from authenticated;
grant select on public.shops to authenticated;
grant insert (owner_id, name, description, logo_url, cover_url, phone, email, address,
              country, city, service_keys, contact_first, contact_last,
              terms_version, terms_accepted_at) on public.shops to authenticated;
grant update (name, description, logo_url, cover_url, phone, email, address,
              country, city, service_keys, contact_first, contact_last, updated_at)
  on public.shops to authenticated;

-- ارسال دوباره‌ی درخواست بعد از رد شدن
create or replace function public.shop_resubmit()
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.shops set status = 'pending', rejection_reason = null, updated_at = now()
  where owner_id = auth.uid() and status = 'rejected';
end $$;
revoke execute on function public.shop_resubmit() from public, anon;
grant execute on function public.shop_resubmit() to authenticated;

-- تغییر وضعیت فروشگاه توسط ادمین (پنل مدیریت از همین تابع استفاده می‌کند)
create or replace function public.admin_set_shop_status(
  p_shop uuid, p_status text, p_reason text default null, p_verified boolean default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  if p_status not in ('pending','approved','rejected','suspended') then
    raise exception 'bad status';
  end if;
  update public.shops
     set status = p_status,
         rejection_reason = case when p_status in ('rejected','suspended') then p_reason else null end,
         verified = coalesce(p_verified, verified),
         updated_at = now()
   where id = p_shop;
  insert into public.audit_log (admin_id, action, target_type, target_id, details)
  values (auth.uid(), 'shop_status', 'shop', p_shop::text,
          jsonb_build_object('status', p_status, 'reason', p_reason, 'verified', p_verified));
end $$;
revoke execute on function public.admin_set_shop_status(uuid, text, text, boolean) from public, anon;
grant execute on function public.admin_set_shop_status(uuid, text, text, boolean) to authenticated;

-- ---------- مدارک هویتی و مجوزها (خصوصی؛ فقط صاحب فروشگاه و ادمین) ----------
create table if not exists public.shop_documents (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  kind text not null check (kind in ('national_id','business_license','vet_council','animal_permit','other')),
  file_path text not null,
  created_at timestamptz not null default now()
);
alter table public.shop_documents enable row level security;
drop policy if exists shop_docs_read on public.shop_documents;
drop policy if exists shop_docs_insert on public.shop_documents;
drop policy if exists shop_docs_delete on public.shop_documents;
create policy shop_docs_read on public.shop_documents for select to authenticated
  using (public.is_admin() or exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()));
create policy shop_docs_insert on public.shop_documents for insert to authenticated
  with check (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()));
create policy shop_docs_delete on public.shop_documents for delete to authenticated
  using (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()));
grant select, insert, delete on public.shop_documents to authenticated;

-- فضای ذخیره‌ی خصوصی برای مدارک (عمومی نیست)
insert into storage.buckets (id, name, public) values ('kyc', 'kyc', false)
on conflict (id) do nothing;
drop policy if exists kyc_owner_insert on storage.objects;
drop policy if exists kyc_owner_read on storage.objects;
drop policy if exists kyc_admin_read on storage.objects;
create policy kyc_owner_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'kyc' and (storage.foldername(name))[1] = auth.uid()::text);
create policy kyc_owner_read on storage.objects for select to authenticated
  using (bucket_id = 'kyc' and (storage.foldername(name))[1] = auth.uid()::text);
create policy kyc_admin_read on storage.objects for select to authenticated
  using (bucket_id = 'kyc' and public.is_admin());

-- ---------- محصولات و خدمات ----------
create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  kind text not null check (kind in ('product','service')),
  category_key text not null,
  title text not null,
  description text not null default '',
  price_minor bigint not null check (price_minor >= 0),   -- کوچک‌ترین واحد ارز (سنت، تومان و ...)
  currency text not null check (char_length(currency) = 3),
  stock int,                    -- فقط محصول؛ خالی = نامحدود
  duration_min int,             -- فقط خدمت (دقیقه)
  images text[] not null default '{}',
  country text,                 -- از فروشگاه کپی می‌شود (برای فیلتر منطقه)
  city text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists listings_browse_idx on public.listings (active, country, city, category_key);
create index if not exists listings_shop_idx on public.listings (shop_id);
alter table public.listings enable row level security;

create or replace function public.listings_before_write()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  select s.country, s.city into new.country, new.city from public.shops s where s.id = new.shop_id;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists listings_before_write_trg on public.listings;
create trigger listings_before_write_trg before insert or update on public.listings
  for each row execute function public.listings_before_write();

drop policy if exists listings_read on public.listings;
drop policy if exists listings_insert on public.listings;
drop policy if exists listings_update on public.listings;
drop policy if exists listings_delete on public.listings;
create policy listings_read on public.listings for select to authenticated
  using (
    (active and exists (select 1 from public.shops s where s.id = shop_id and s.status = 'approved'))
    or exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid())
    or public.is_admin()
  );
create policy listings_insert on public.listings for insert to authenticated
  with check (exists (select 1 from public.shops s
                      where s.id = shop_id and s.owner_id = auth.uid() and s.status = 'approved'));
create policy listings_update on public.listings for update to authenticated
  using (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()))
  with check (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()));
create policy listings_delete on public.listings for delete to authenticated
  using (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid())
         or public.is_admin());
revoke update on public.listings from authenticated;
grant select, insert, delete on public.listings to authenticated;
grant update (kind, category_key, title, description, price_minor, currency, stock,
              duration_min, images, active) on public.listings to authenticated;

-- ===== تایید فروشگاه خودتان برای تست =====
-- بعد از ساخت فروشگاه در اپ، این را (با ایمیل خودتان) اجرا کنید:
--
-- update public.shops set status = 'approved', verified = true
-- where owner_id = (select id from auth.users where email = 'YOUR_EMAIL@example.com');
