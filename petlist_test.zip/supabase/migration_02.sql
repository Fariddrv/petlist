-- ===== PetList / pawpet: به‌روزرسانی ۲ (فقط یک بار اجرا شود) =====

-- لینک‌های بیو
alter table public.profiles add column if not exists links jsonb not null default '[]'::jsonb;

-- موقعیت کاربر (فقط خودِ کاربر می‌بیند)
alter table public.private_info add column if not exists country text;
alter table public.private_info add column if not exists city text;

-- پاسخ به کامنت و لایک کامنت
alter table public.comments add column if not exists parent_id uuid references public.comments(id) on delete cascade;

create table if not exists public.comment_likes (
  comment_id uuid not null references public.comments(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  primary key (comment_id, user_id)
);
alter table public.comment_likes enable row level security;
drop policy if exists comment_likes_read on public.comment_likes;
drop policy if exists comment_likes_insert on public.comment_likes;
drop policy if exists comment_likes_delete on public.comment_likes;
create policy comment_likes_read on public.comment_likes for select to authenticated
  using (exists (select 1 from public.comments c where c.id = comment_id));
create policy comment_likes_insert on public.comment_likes for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.comments c where c.id = comment_id));
create policy comment_likes_delete on public.comment_likes for delete to authenticated
  using (user_id = auth.uid());

-- ارسال پست برای دوست
alter table public.messages add column if not exists post_id uuid references public.posts(id) on delete set null;

-- پاسپورت حیوان
alter table public.pets add column if not exists gender text;
alter table public.pets add column if not exists vaccines jsonb not null default '[]'::jsonb;
alter table public.pets add column if not exists notes text;

-- پیام‌های پشتیبانی
create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text,
  subject text,
  message text not null,
  created_at timestamptz not null default now()
);
alter table public.support_messages enable row level security;
drop policy if exists support_insert_own on public.support_messages;
create policy support_insert_own on public.support_messages for insert to authenticated
  with check (user_id = auth.uid());

grant select, insert, update, delete on public.comment_likes to authenticated;
grant select, insert on public.support_messages to authenticated;

-- ساخت خودکار پروفایل هنگام ثبت‌نام (نسخه‌ی جدید با کشور و شهر)
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  base text;
  uname text;
begin
  base := regexp_replace(lower(split_part(new.email, '@', 1)), '[^a-z0-9_.]', '', 'g');
  if length(base) < 3 then base := 'user' || base; end if;
  base := left(base, 14);
  uname := base;
  while exists (select 1 from public.profiles where lower(username) = uname) loop
    uname := base || floor(random() * 9000 + 1000)::int;
  end loop;

  insert into public.profiles (id, username, region)
  values (new.id, uname, coalesce(new.raw_user_meta_data->>'region', 'intl'));

  insert into public.private_info (id, first_name, last_name, gender, birth_date, mobile, country, city)
  values (
    new.id,
    new.raw_user_meta_data->>'first_name',
    new.raw_user_meta_data->>'last_name',
    new.raw_user_meta_data->>'gender',
    nullif(new.raw_user_meta_data->>'birth_date', '')::date,
    new.raw_user_meta_data->>'mobile',
    new.raw_user_meta_data->>'country',
    new.raw_user_meta_data->>'city'
  );
  return new;
end $$;
