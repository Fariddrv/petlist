-- ===== PetList: جدول‌ها و قوانین امنیتی (فقط یک بار اجرا شود) =====

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  bio text not null default '',
  avatar_url text,
  is_private boolean not null default false,
  setup_done boolean not null default false,
  region text not null default 'intl',
  created_at timestamptz not null default now()
);
create unique index if not exists profiles_username_uq on public.profiles (lower(username));

-- اطلاعات خصوصی ثبت‌نام: فقط خودِ کاربر (و مدیر پروژه) می‌بیند
create table if not exists public.private_info (
  id uuid primary key references auth.users(id) on delete cascade,
  first_name text,
  last_name text,
  gender text,
  birth_date date,
  mobile text,
  two_factor boolean not null default false
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  followee_id uuid not null references public.profiles(id) on delete cascade,
  status text not null check (status in ('pending','accepted')),
  created_at timestamptz not null default now(),
  primary key (follower_id, followee_id),
  check (follower_id <> followee_id)
);
create index if not exists follows_followee_idx on public.follows (followee_id);

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  primary key (blocker_id, blocked_id)
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  text text not null default '',
  image_url text,
  created_at timestamptz not null default now()
);
create index if not exists posts_owner_idx on public.posts (owner_id, created_at desc);

create table if not exists public.post_likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  primary key (post_id, user_id)
);

create table if not exists public.post_saves (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  text text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  text text not null,
  created_at timestamptz not null default now()
);
create index if not exists messages_sender_idx on public.messages (sender_id);
create index if not exists messages_receiver_idx on public.messages (receiver_id);

create table if not exists public.pets (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  species text not null default 'other',
  age int not null default 0,
  photo_url text,
  created_at timestamptz not null default now()
);

-- ===== توابع کمکی =====

create or replace function public.is_blocked_pair(a uuid, b uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.blocks
    where (blocker_id = a and blocked_id = b) or (blocker_id = b and blocked_id = a)
  );
$$;

create or replace function public.can_see_owner(owner uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and (
    owner = auth.uid()
    or (
      not public.is_blocked_pair(auth.uid(), owner)
      and (
        not coalesce((select is_private from public.profiles where id = owner), false)
        or exists (
          select 1 from public.follows f
          where f.follower_id = auth.uid() and f.followee_id = owner and f.status = 'accepted'
        )
      )
    )
  );
$$;

create or replace function public.follow_user(target uuid)
returns text language plpgsql security definer set search_path = public as $$
declare
  me uuid := auth.uid();
  priv boolean;
  st text;
begin
  if me is null or target = me then raise exception 'invalid'; end if;
  if public.is_blocked_pair(me, target) then raise exception 'blocked'; end if;
  select is_private into priv from public.profiles where id = target;
  if priv is null then raise exception 'not found'; end if;
  st := case when priv then 'pending' else 'accepted' end;
  insert into public.follows (follower_id, followee_id, status)
  values (me, target, st)
  on conflict (follower_id, followee_id) do nothing;
  select status into st from public.follows where follower_id = me and followee_id = target;
  return st;
end $$;

create or replace function public.block_user(target uuid)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid();
begin
  if me is null or target = me then raise exception 'invalid'; end if;
  insert into public.blocks (blocker_id, blocked_id) values (me, target)
  on conflict do nothing;
  delete from public.follows
  where (follower_id = me and followee_id = target)
     or (follower_id = target and followee_id = me);
end $$;

create or replace function public.profile_stats(uid uuid)
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'followers', (select count(*) from public.follows where followee_id = uid and status = 'accepted'),
    'following', (select count(*) from public.follows where follower_id = uid and status = 'accepted'),
    'posts',     (select count(*) from public.posts where owner_id = uid)
  );
$$;

revoke execute on function public.follow_user(uuid) from public, anon;
revoke execute on function public.block_user(uuid) from public, anon;
revoke execute on function public.profile_stats(uuid) from public, anon;
grant execute on function public.follow_user(uuid) to authenticated;
grant execute on function public.block_user(uuid) to authenticated;
grant execute on function public.profile_stats(uuid) to authenticated;

-- ===== ساخت خودکار پروفایل هنگام ثبت‌نام =====

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  base text;
  uname text;
begin
  base := regexp_replace(lower(split_part(new.email, '@', 1)), '[^a-z0-9_.]', '', 'g');
  if length(base) < 3 then base := 'user' || base; end if;
  base := left(base, 14);
  uname := base;
  while exists (select 1 from public.profiles where lower(username) = uname) loop
    uname := base || floor(random() * 9000 + 1000)::int;
  end loop;

  insert into public.profiles (id, username, region)
  values (new.id, uname, coalesce(new.raw_user_meta_data->>'region', 'intl'));

  insert into public.private_info (id, first_name, last_name, gender, birth_date, mobile)
  values (
    new.id,
    new.raw_user_meta_data->>'first_name',
    new.raw_user_meta_data->>'last_name',
    new.raw_user_meta_data->>'gender',
    nullif(new.raw_user_meta_data->>'birth_date', '')::date,
    new.raw_user_meta_data->>'mobile'
  );
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ===== قوانین دسترسی (RLS) =====

alter table public.profiles     enable row level security;
alter table public.private_info enable row level security;
alter table public.follows      enable row level security;
alter table public.blocks       enable row level security;
alter table public.posts        enable row level security;
alter table public.post_likes   enable row level security;
alter table public.post_saves   enable row level security;
alter table public.comments     enable row level security;
alter table public.messages     enable row level security;
alter table public.pets         enable row level security;

create policy profiles_read on public.profiles for select to authenticated using (true);
create policy profiles_update_own on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

create policy private_read_own on public.private_info for select to authenticated using (id = auth.uid());
create policy private_update_own on public.private_info for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

create policy follows_read on public.follows for select to authenticated
  using (auth.uid() in (follower_id, followee_id));
create policy follows_update_followee on public.follows for update to authenticated
  using (followee_id = auth.uid()) with check (followee_id = auth.uid());
create policy follows_delete on public.follows for delete to authenticated
  using (auth.uid() in (follower_id, followee_id));
revoke update on public.follows from authenticated;
grant update (status) on public.follows to authenticated;

create policy blocks_read_own on public.blocks for select to authenticated using (blocker_id = auth.uid());
create policy blocks_delete_own on public.blocks for delete to authenticated using (blocker_id = auth.uid());

create policy posts_read on public.posts for select to authenticated using (public.can_see_owner(owner_id));
create policy posts_insert_own on public.posts for insert to authenticated with check (owner_id = auth.uid());
create policy posts_delete_own on public.posts for delete to authenticated using (owner_id = auth.uid());

create policy likes_read on public.post_likes for select to authenticated
  using (exists (select 1 from public.posts p where p.id = post_id));
create policy likes_insert on public.post_likes for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.posts p where p.id = post_id));
create policy likes_delete on public.post_likes for delete to authenticated using (user_id = auth.uid());

create policy saves_read_own on public.post_saves for select to authenticated using (user_id = auth.uid());
create policy saves_insert on public.post_saves for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.posts p where p.id = post_id));
create policy saves_delete on public.post_saves for delete to authenticated using (user_id = auth.uid());

create policy comments_read on public.comments for select to authenticated
  using (exists (select 1 from public.posts p where p.id = post_id));
create policy comments_insert on public.comments for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.posts p where p.id = post_id));
create policy comments_delete on public.comments for delete to authenticated
  using (user_id = auth.uid() or exists (select 1 from public.posts p where p.id = post_id and p.owner_id = auth.uid()));

create policy messages_read on public.messages for select to authenticated
  using (auth.uid() in (sender_id, receiver_id));
create policy messages_insert on public.messages for insert to authenticated
  with check (sender_id = auth.uid() and not public.is_blocked_pair(sender_id, receiver_id));

create policy pets_all_own on public.pets for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- ===== ذخیره‌ی عکس‌ها =====

insert into storage.buckets (id, name, public) values ('media', 'media', true)
on conflict (id) do nothing;

create policy media_read on storage.objects for select using (bucket_id = 'media');
create policy media_upload_own on storage.objects for insert to authenticated
  with check (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy media_delete_own on storage.objects for delete to authenticated
  using (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
