# Decisions — 2026-10-10

- Baseline: pawpet2.7.0_test.zip, version 2.7.0+24, preserved byte-for-byte. New source is 2.8.0+25.
- Monetization pivot: paid advertising inventory managed by owner/admin; no advertiser publishing or self-service editing; ordinary social accounts remain.
- Product label: Services / خدمات / 服务. Paid cards always carry sponsored disclosure.
- New tables: ad_packages, service_ads, ad_requests, ad_events. Migration 07 requires 02..06 and is transactional. All client roles are subject to RLS; new table privileges are revoked from PUBLIC and anon.
- Request submission: one security-definer RPC validates inputs, binds auth.uid(), serializes per-user submissions with advisory lock, enforces rate limits, snapshots server prices, and deduplicates a client token. No financial transaction is executed.
- Management: in-app mobile admin surface first; future web admin can use the same RLS-backed data. Owner/admin only, moderator excluded. Management changes generate audit rows. Audit currently records operation and target, not full content snapshots.
- Contact/payment: external manual contact after review, no automatic outbound messages or payment verification. User-facing prices are country-specific and mutable; initial prices are NULL / quotation required.
- Marketplace: compile-time MARKETPLACE_ENABLED=false plus app_settings.marketplace_enabled=false. Old rows retained. Server write guards stop older clients from continuing to write. Guards are intended for application writes; privileged database maintenance may require temporarily enabling the setting or a manager-authenticated context.
- Ad order: paid tier, priority, stable UUID tie break. Source ratings are optional and must cite their source; they are not PawPet reviews. Local means matching selected city, not GPS distance.
- Location: shared Services/Home ad location, persisted locally, independent of user profile. Country codes and canonical city keys reuse existing place data. Free-form city names require exact matches when no catalog entry exists.
- Links: HTTPS outside destinations; tel numeric calls; UUID normal PawPet profiles. No internal booking/checkout. Opening requires user action and external navigation confirmation.
- Home placement: old top banner removed, sponsored widget inserted after third social post; maximum two sponsored cards per loaded area. No sponsor post is inserted into ordinary posts table.
- Analytics: daily unique authenticated user/ad/kind deduplication. View is recorded when approximately half the card overlaps the viewport. Counts are operational signals, not audited impressions, billing evidence or proof of genuine unique people. No anonymous tracking or advertising profile is collected. Retention/deletion policy must be finalized before public launch.
- Limits in initial UI: up to 500 ads/packages, newest 200 requests, two home sponsor placements. Pagination is a follow-up before these limits are approached.
- CI: pinned Flutter 3.35.7; safe exact ZIP selection; Java 17; database-policy and Dart checks before APK; test signature preserved. Flutter dependencies remain ranged until first successful resolution produces pubspec.lock. Android project still generated during CI.
- Outstanding: live Supabase integration, full Dart analyzer and Flutter tests, APK build/device layout QA, production signing plan, definitive terms/cancellation/refund policy, business jurisdiction, actual tariffs, spam/content moderation policy and sufficient audience.
