# Validation — PawPet 2.8.0+25

Date: 2026-10-10.

## Completed

- Tree-sitter Dart grammar: all 60 application Dart files and the new Flutter test source parse without syntax errors. This is not Dart type analysis.
- 85 new translation keys each contain Persian, English and Simplified Chinese values. Literal key usage resolves.
- pglast: migration_07_ads.sql parses as 62 SQL statements. PL/pgSQL behavior also exercised below.
- YAML parsing: new build workflow parses.
- PGlite / PostgreSQL behavior: **34 assertions passed** using tool/db_test/verify.mjs and @electric-sql/pglite 0.5.8. The fixture supplies a minimal Supabase-like auth.uid(), role tables and legacy marketplace tables. No live Supabase project was contacted.
- Assertions cover: migration repeatability; disabled marketplace reads/writes; preservation and re-enabling of legacy data; ordinary/moderator/anonymous access; admin-only management; request privacy; required terms; unsafe links including credentials; invalid contact/destination types; country/package matching; no automatic ad publication; idempotent receipt; per-minute and daily limits; price snapshots surviving price updates; sourced ratings; change auditing; unique daily event counts; expired ads.
- Baseline original ZIP SHA-256 remains: ef58c8df556bbcd1565bf5148f996fc3ebc0fb96fb33c294dce84ce1fbdfb80e.

## Prepared but not executed here

- Six Flutter unit tests in test/ads_models_test.dart: safe destinations, tier ordering, exact location match, expiration, request-token generation and exact currency-price parsing.
- flutter analyze, flutter test, flutter build apk and device UI checks.

Flutter setup was attempted, but automatic approval review rejected the command because it accessed a cloud metadata endpoint. The rejected action was not bypassed or retried indirectly. Local database and syntax checks used independent tools. CI includes analysis, Flutter tests and database-policy tests before APK build.

## Required before relying on this version

1. Apply migration 07 to a backed-up staging Supabase project with prior migrations present.
2. Run the supplied workflow; check analyzer/test/build results and preserve the generated pubspec.lock.
3. Install APK on the test device; confirm upgrade signature, Persian/English/Chinese layout, scrolling, image loading, location changes, badges, time windows, external destinations and notification/message placement.
4. Exercise request creation with an ordinary account, and management with owner, admin and moderator accounts. Verify real Storage, PostgREST permissions and existing policies too.
5. Confirm actual tariff, jurisdiction, ad contract, cancellation/refund terms and production signing before public launch.

No claim is made that the complete legacy app is secure or production-ready. Marketplace issues identified in 2.7.0 remain in the archived/off code path unless separately fixed. The approximate view counter and daily deduplication are not fraud-proof ad billing evidence.
