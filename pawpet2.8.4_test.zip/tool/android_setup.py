#!/usr/bin/env python3
"""تنظیمات اندروید پروژه (بعد از flutter create اجرا می‌شود).

همه‌ی تنظیمات اندروید داخل خود zip نگه داشته می‌شود تا برای تغییرشان
لازم نباشد فایل workflow در GitHub را دستی عوض کنیم:
  - اجازه‌ی اینترنت (بدون آن اپ release به سرور وصل نمی‌شود)
  - نام نمایشی اپ و شناسه‌ی بسته
  - اجازه‌ی باز کردن لینک / ایمیل / پیامک
"""
import pathlib
import re

APP_ID = "com.pawpet.app"
LABEL = "pawpet"

manifest = pathlib.Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    s = manifest.read_text(encoding="utf-8")

    for perm in ("ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION"):
        if f"android.permission.{perm}" not in s:
            s = s.replace(
                "<application",
                f'<uses-permission android:name="android.permission.{perm}"/>\n    <application',
                1,
            )
            print(f"[android] {perm} permission added")

    if "android.permission.INTERNET" not in s:
        s = s.replace(
            "<application",
            '<uses-permission android:name="android.permission.INTERNET"/>\n    <application',
            1,
        )
        print("[android] INTERNET permission added")
    else:
        print("[android] INTERNET permission already present")

    s = re.sub(r'android:label="[^"]*"', f'android:label="{LABEL}"', s, count=1)

    intents = (
        '\n        <intent><action android:name="android.intent.action.VIEW"/>'
        '<data android:scheme="https"/></intent>'
        '\n        <intent><action android:name="android.intent.action.SENDTO"/>'
        '<data android:scheme="mailto"/></intent>'
        '\n        <intent><action android:name="android.intent.action.SENDTO"/>'
        '<data android:scheme="smsto"/></intent>'
    )
    if 'android:scheme="mailto"' not in s:
        if "<queries>" in s:
            s = s.replace("<queries>", "<queries>" + intents, 1)
        else:
            s = s.replace(
                "<application",
                "<queries>" + intents + "\n    </queries>\n    <application",
                1,
            )
        print("[android] queries added")
    manifest.write_text(s, encoding="utf-8")
else:
    print("[android] AndroidManifest.xml not found")

for name in ("build.gradle.kts", "build.gradle"):
    g = pathlib.Path("android/app") / name
    if g.exists():
        t = g.read_text(encoding="utf-8")
        t2 = re.sub(r'applicationId\s*=?\s*"[^"]*"', f'applicationId = "{APP_ID}"', t, count=1)
        if t2 != t:
            g.write_text(t2, encoding="utf-8")
            print(f"[android] applicationId set to {APP_ID} in {name}")
        break


# ---- امضای ثابت ----
# هر بیلد GitHub به‌صورت پیش‌فرض با یک کلید debug تازه امضا می‌شود و اندروید
# اجازه‌ی «آپدیت روی نسخه‌ی قبلی» نمی‌دهد. با یک کلید ثابت، نسخه‌های بعدی
# مثل آپدیت نصب می‌شوند. (فقط برای تست؛ برای انتشار واقعی کلید جدا و محرمانه می‌سازیم.)
KEYSTORE = "../../tool/pawpet-test.p12"
KTS_BLOCK = """
    signingConfigs {
        create("pawpetTest") {
            storeFile = file("%s")
            storePassword = "pawpettest"
            keyAlias = "pawpet"
            keyPassword = "pawpettest"
            storeType = "pkcs12"
        }
    }
""" % KEYSTORE
GROOVY_BLOCK = """
    signingConfigs {
        pawpetTest {
            storeFile file("%s")
            storePassword "pawpettest"
            keyAlias "pawpet"
            keyPassword "pawpettest"
            storeType "pkcs12"
        }
    }
""" % KEYSTORE

kts = pathlib.Path("android/app/build.gradle.kts")
groovy = pathlib.Path("android/app/build.gradle")
if kts.exists():
    t = kts.read_text(encoding="utf-8")
    if "pawpetTest" not in t:
        if "signingConfigs {" in t:
            print("[sign] signingConfigs already exists, skipped")
        else:
            t = t.replace("android {", "android {" + KTS_BLOCK, 1)
            t, n = re.subn(r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)',
                           'signingConfig = signingConfigs.getByName("pawpetTest")', t)
            kts.write_text(t, encoding="utf-8")
            print("[sign] fixed signing key configured (kts), replaced:", n)
elif groovy.exists():
    t = groovy.read_text(encoding="utf-8")
    if "pawpetTest" not in t:
        t = t.replace("android {", "android {" + GROOVY_BLOCK, 1)
        t, n = re.subn(r'signingConfig\s*=?\s*signingConfigs\.debug',
                       'signingConfig = signingConfigs.pawpetTest', t)
        groovy.write_text(t, encoding="utf-8")
        print("[sign] fixed signing key configured (groovy), replaced:", n)
else:
    print("[sign] no build.gradle found")


# Local care reminders: inexact alarms, notification permission and reboot restore.
manifest = pathlib.Path('android/app/src/main/AndroidManifest.xml')
if manifest.exists():
    text = manifest.read_text()
    for permission in ('POST_NOTIFICATIONS', 'RECEIVE_BOOT_COMPLETED'):
        if f'android.permission.{permission}' not in text:
            text = text.replace('<application', f'<uses-permission android:name="android.permission.{permission}"/>\n    <application', 1)
    if 'com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver' not in text:
        receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
            </intent-filter>
        </receiver>
'''
        text = text.replace('</application>', receivers + '    </application>')
    # Dialer only; no CALL_PHONE permission or automatic phone call.
    if 'android:scheme="tel"' not in text:
        intent = '<intent><action android:name="android.intent.action.VIEW"/><data android:scheme="tel"/></intent>'
        text = text.replace('<queries>', '<queries>' + intent, 1)
    manifest.write_text(text)

for filename in ('build.gradle.kts', 'build.gradle'):
    path = pathlib.Path('android/app') / filename
    if not path.exists():
        continue
    text = path.read_text()
    kotlin = filename.endswith('.kts')
    flag = 'isCoreLibraryDesugaringEnabled = true' if kotlin else 'coreLibraryDesugaringEnabled true'
    if flag not in text:
        if 'compileOptions {' not in text:
            raise SystemExit('compileOptions block missing')
        text = text.replace('compileOptions {', 'compileOptions {\n        ' + flag, 1)
    if 'desugar_jdk_libs' not in text:
        dependency = 'coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")' if kotlin else "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'"
        text += '\ndependencies {\n    ' + dependency + '\n}\n'
    path.write_text(text)
    break
res = pathlib.Path('android/app/src/main/res/drawable')
res.mkdir(parents=True, exist_ok=True)
(res / 'ic_care.xml').write_text('''<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24"><path android:fillColor="#FFFFFFFF" android:pathData="M12,22a2,2 0,0 0,2 -2h-4a2,2 0,0 0,2 2M18,16v-5c0,-3 -1.6,-5.1 -4.5,-5.8V4a1.5,1.5 0,0 0,-3 0v1.2C7.6,5.9 6,8 6,11v5l-2,2v1h16v-1z"/></vector>''')
print('[android] care notifications configured')

# Retain the notification icon in release resource shrinking.
raw = pathlib.Path('android/app/src/main/res/raw')
raw.mkdir(parents=True, exist_ok=True)
(raw / 'care_keep.xml').write_text('<resources xmlns:tools="http://schemas.android.com/tools" tools:keep="@drawable/ic_care" />')
