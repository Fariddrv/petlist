import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.PAWPET_PGLITE_MODULE||'@electric-sql/pglite');const db=new PGlite();
const a='10000000-0000-4000-8000-000000000001',b='10000000-0000-4000-8000-000000000002',admin='10000000-0000-4000-8000-000000000003',mod='10000000-0000-4000-8000-000000000004';let checks=0;
async function login(id){await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[id]);await db.exec('set role authenticated');}
function eq(a,b){assert.deepEqual(a,b);checks++;}async function denied(sql,args=[]){await assert.rejects(db.query(sql,args));checks++;}
await db.exec(`create role authenticated;create role anon;create schema auth;create schema storage;
create function auth.uid()returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
grant usage on schema public,auth,storage to authenticated,anon;
create table profiles(id uuid primary key,is_private boolean default false,username text default 'member',avatar_url text);insert into profiles(id,is_private) values('${a}',false),('${b}',true),('${admin}',false),('${mod}',false);
create table follows(follower_id uuid,followee_id uuid,status text);create table blocks(blocker_id uuid,blocked_id uuid);
create function public.can_see_owner(owner uuid)returns boolean language sql stable security definer set search_path=public as $$select auth.uid() is not null and(owner=auth.uid() or(not exists(select 1 from blocks where (blocker_id=auth.uid() and blocked_id=owner)or(blocker_id=owner and blocked_id=auth.uid())) and(not(select is_private from profiles where id=owner)or exists(select 1 from follows where follower_id=auth.uid() and followee_id=owner and status='accepted'))))$$;
create function public.is_ad_manager()returns boolean language sql stable as $$select auth.uid()='${admin}'::uuid$$;
create function public.audit_ads_change()returns trigger language plpgsql security definer set search_path=public as $$begin if not public.is_ad_manager()then raise exception 'not allowed';end if;new.updated_at:=now();return new;end$$;
create table ad_packages(id uuid primary key default gen_random_uuid(),country text,tier text constraint ad_packages_tier_check check(tier in('basic','premium','featured')),currency text,price_minor bigint,unique(country,tier));
insert into ad_packages(country,tier,currency,price_minor)values('IR','featured','IRT',777);
create table banners(id uuid primary key default gen_random_uuid(),active boolean);alter table banners enable row level security;grant all on banners to authenticated;
create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text,name text);
alter table storage.objects enable row level security;grant select,insert,delete on storage.objects to authenticated;
create function public.is_blocked_pair(a uuid,b uuid)returns boolean language sql stable security definer as $$select exists(select 1 from blocks where(blocker_id=a and blocked_id=b)or(blocker_id=b and blocked_id=a))$$;
create table messages(id uuid primary key default gen_random_uuid(),sender_id uuid references profiles(id),receiver_id uuid references profiles(id),text text,post_id uuid,reply_to uuid,media_path text,media_type text,created_at timestamptz default now());
alter table messages enable row level security;create policy msg_read on messages for select to authenticated using(auth.uid() in(sender_id,receiver_id));create policy msg_insert on messages for insert to authenticated with check(sender_id=auth.uid() and not public.is_blocked_pair(sender_id,receiver_id));grant select,insert on messages to authenticated;
grant select on profiles to authenticated;`);

await db.exec(await readFile(new URL('../../supabase/migration_09_stories_catalog.sql',import.meta.url),'utf8'));
const sql=await readFile(new URL('../../supabase/migration_10_story_interactions.sql',import.meta.url),'utf8');await db.exec(sql);await db.exec(sql);
async function makeStory(owner,n){const path=`${owner}/10000000-0000-4000-8000-${String(n).padStart(12,'0')}.png`;await login(owner);await db.query('insert into storage.objects(bucket_id,name)values($1,$2)',['stories',path]);return(await db.query('insert into stories(owner_id,file_path)values($1,$2)returning id',[owner,path])).rows[0].id;}
const pub=await makeStory(a,11),priv=await makeStory(b,12);
async function act(story,action,text=null,recipient=null){return db.query('select story_interact($1,$2,$3,$4)',[story,action,text,recipient]);}
async function summary(story){return(await db.query('select story_summary($1) as s',[story])).rows[0].s;}
await login(a);await act(pub,'view');eq((await summary(pub)).views,0);await denied('select story_interact($1,$2)',[pub,'like']);
await denied('select * from story_views');await denied('insert into story_views(story_id,user_id)values($1,$2)',[pub,b]);
await denied('insert into messages(sender_id,receiver_id,text,story_ref)values($1,$2,$3,$4)',[a,b,'fake',priv]);
await login(b);await act(pub,'view');await act(pub,'view');await act(pub,'like');await act(pub,'like');await act(pub,'comment','private comment');
eq((await summary(pub)).views,null);eq((await summary(pub)).likes,null);eq((await summary(pub)).liked,true);eq((await summary(pub)).comments,1);
await denied('select * from story_people($1,$2,0)',[pub,'views']);
await login(mod);eq((await db.query('select * from story_comment_list($1,0)',[pub])).rows.length,0);await denied('select * from story_people($1,$2,0)',[pub,'likes']);
await login(a);eq((await summary(pub)).views,1);eq((await summary(pub)).likes,1);eq((await summary(pub)).comments,1);eq((await db.query('select * from story_people($1,$2,0)',[pub,'views'])).rows[0].user_id,b);eq((await db.query('select * from story_people($1,$2,0)',[pub,'likes'])).rows[0].user_id,b);
const comment=(await db.query('select * from story_comment_list($1,0)',[pub])).rows[0].id;
await login(mod);await denied('select story_comment_delete($1)',[comment]);await login(a);await db.query('select story_comment_delete($1)',[comment]);eq((await summary(pub)).comments,0);
await denied('select story_interact($1,$2)',[priv,'view']);await denied('select story_summary($1)',[priv]);
await db.exec('reset role');await db.query("insert into follows values($1,$2,'accepted')",[a,b]);await login(a);await act(priv,'view');eq((await summary(priv)).liked,false);
await login(b);await denied('select story_interact($1,$2,$3,$4)',[priv,'share',null,admin]);
await db.exec('reset role');await db.query("insert into follows values($1,$2,'accepted')",[b,mod]);await login(b);await act(priv,'share',null,mod);await act(priv,'share',null,mod);eq((await db.query('select count(*)::int n from messages where story_ref=$1',[priv])).rows[0].n,1);eq((await summary(priv)).shares,1);
await login(mod);eq((await db.query('select story_ref from messages')).rows[0].story_ref,priv);eq((await db.query('select count(*)::int n from stories where id=$1',[priv])).rows[0].n,0);await denied('select story_interact($1,$2)',[priv,'view']);
await login(b);await act(pub,'unlike');eq((await summary(pub)).liked,false);await denied('select story_interact($1,$2,$3)',[pub,'comment',' ']);await denied('select story_interact($1,$2,$3)',[pub,'comment','x'.repeat(1001)]);
for(let i=0;i<4;i++)await act(pub,'comment','message');await denied('select story_interact($1,$2,$3)',[pub,'comment','too many']);
await db.exec('reset role');await db.query('insert into blocks values($1,$2)',[a,b]);await login(a);eq((await summary(pub)).views,0);eq((await db.query('select * from story_people($1,$2,0)',[pub,'views'])).rows.length,0);
await login(b);await denied('select story_interact($1,$2)',[pub,'view']);await denied('select story_summary($1)',[pub]);
await db.exec('reset role');await db.query("update stories set created_at=now()-interval '25 hours',expires_at=now()-interval '1 hour' where id=$1",[priv]);await login(b);await denied('select story_summary($1)',[priv]);await denied('select story_interact($1,$2)',[priv,'like']);
await db.exec('reset role');await db.exec('set role anon');await denied('select story_interact($1,$2)',[pub,'view']);await denied('select story_summary($1)',[pub]);
console.log(`PASS: ${checks} story interaction assertions (unique viewers, private comments/stats, sharing, expiry, blocking, anti-spam and repeatable SQL).`);await db.close();
