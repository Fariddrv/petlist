import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.PAWPET_PGLITE_MODULE || '@electric-sql/pglite');
const db=new PGlite();
const a='10000000-0000-4000-8000-000000000001',b='10000000-0000-4000-8000-000000000002',c='10000000-0000-4000-8000-000000000003';
const path=`${a}/${b}/10000000-0000-4000-8000-000000000004.gif`;
await db.exec(`create role authenticated; create schema auth; create schema storage;
create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
grant usage on schema auth,public,storage to authenticated;
create table profiles(id uuid primary key); insert into profiles values('${a}'),('${b}'),('${c}'); grant select on profiles to authenticated;
create table messages(id uuid primary key default gen_random_uuid(), sender_id uuid,receiver_id uuid,text text,created_at timestamptz default now());
alter table messages enable row level security;
create policy msg_read on messages for select to authenticated using(auth.uid() in(sender_id,receiver_id));
create policy msg_write on messages for insert to authenticated with check(sender_id=auth.uid()); grant select,insert on messages to authenticated;
create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text,name text);
alter table storage.objects enable row level security; grant select,insert,delete on storage.objects to authenticated;`);
const migration=await readFile(new URL('../../supabase/migration_08_chat_media.sql',import.meta.url),'utf8');
await db.exec(migration); await db.exec(migration);
let checks=0;
async function login(id){await db.exec('reset role'); await db.query("select set_config('request.jwt.claim.sub',$1,false)",[id]);await db.exec('set role authenticated');}
async function count(n){assert.equal((await db.query('select count(*)::int n from storage.objects')).rows[0].n,n);checks++;}
async function deny(sql,args=[]){await assert.rejects(db.query(sql,args));checks++;}
await login(a);await db.query('insert into storage.objects(bucket_id,name) values($1,$2)',['chat-media',path]);await count(1);
await login(b);await count(0); // Recipient cannot see unfinished uploads.
await login(c);await count(0);await deny('insert into storage.objects(bucket_id,name) values($1,$2)',['chat-media',path+'x']);
await login(a);await db.query('insert into messages(sender_id,receiver_id,text,media_path,media_type) values($1,$2,$3,$4,$5)',[a,b,'',path,'gif']);
await deny('insert into messages(sender_id,receiver_id,text,media_path,media_type) values($1,$2,$3,$4,$5)',[a,c,'',path,'gif']);
await deny('insert into messages(sender_id,receiver_id,text,media_path,media_type) values($1,$2,$3,$4,$5)',[a,b,'',path,null]);
await login(b);await count(1);await db.exec('delete from storage.objects');await count(1);
await login(c);await count(0);assert.equal((await db.query('select count(*)::int n from messages')).rows[0].n,0);checks++;
await login(a);await db.exec('delete from storage.objects');await count(0);
await db.exec('reset role');assert.equal((await db.query("select public from storage.buckets where id='chat-media'")).rows[0].public,false);checks++;
console.log(`PASS: ${checks} chat-media policy assertions; migration is repeatable.`);await db.close();
