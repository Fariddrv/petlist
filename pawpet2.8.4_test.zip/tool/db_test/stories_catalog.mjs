import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.PAWPET_PGLITE_MODULE||'@electric-sql/pglite');const db=new PGlite();
const a='10000000-0000-4000-8000-000000000001',b='10000000-0000-4000-8000-000000000002',admin='10000000-0000-4000-8000-000000000003',mod='10000000-0000-4000-8000-000000000004';let checks=0;
async function login(id){await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[id]);await db.exec('set role authenticated');}
function eq(a,b){assert.deepEqual(a,b);checks++;}async function denied(sql,args=[]){await assert.rejects(db.query(sql,args));checks++;}
await db.exec(`create role authenticated;create role anon;create schema auth;create schema storage;
create function auth.uid()returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
grant usage on schema public,auth,storage to authenticated,anon;
create table profiles(id uuid primary key,is_private boolean default false);insert into profiles values('${a}',false),('${b}',true),('${admin}',false),('${mod}',false);
create table follows(follower_id uuid,followee_id uuid,status text);create table blocks(blocker_id uuid,blocked_id uuid);
create function public.can_see_owner(owner uuid)returns boolean language sql stable security definer set search_path=public as $$select auth.uid() is not null and(owner=auth.uid() or(not exists(select 1 from blocks where (blocker_id=auth.uid() and blocked_id=owner)or(blocker_id=owner and blocked_id=auth.uid())) and(not(select is_private from profiles where id=owner)or exists(select 1 from follows where follower_id=auth.uid() and followee_id=owner and status='accepted'))))$$;
create function public.is_ad_manager()returns boolean language sql stable as $$select auth.uid()='${admin}'::uuid$$;
create function public.audit_ads_change()returns trigger language plpgsql security definer set search_path=public as $$begin if not public.is_ad_manager()then raise exception 'not allowed';end if;new.updated_at:=now();return new;end$$;
create table ad_packages(id uuid primary key default gen_random_uuid(),country text,tier text constraint ad_packages_tier_check check(tier in('basic','premium','featured')),currency text,price_minor bigint,unique(country,tier));
insert into ad_packages(country,tier,currency,price_minor)values('IR','featured','IRT',777);
create table banners(id uuid primary key default gen_random_uuid(),active boolean);alter table banners enable row level security;grant all on banners to authenticated;
create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text,name text);
alter table storage.objects enable row level security;grant select,insert,delete on storage.objects to authenticated;
grant select on profiles to authenticated;`);
const sql=await readFile(new URL('../../supabase/migration_09_stories_catalog.sql',import.meta.url),'utf8');await db.exec(sql);await db.exec(sql);
let serial=10;
async function story(owner){const file=`${owner}/10000000-0000-4000-8000-${String(serial++).padStart(12,'0')}.png`;await db.query('insert into storage.objects(bucket_id,name)values($1,$2)',['stories',file]);await db.query('insert into stories(owner_id,file_path)values($1,$2)',[owner,file]);return file;}
await login(a);const pa=await story(a);eq((await db.query('select count(*)::int n from stories')).rows[0].n,1);
await denied('insert into stories(owner_id,file_path)values($1,$2)',[b,`${b}/10000000-0000-4000-8000-000000000099.png`]);
await denied("insert into stories(owner_id,file_path,expires_at)values($1,$2,now()+interval '10 days')",[a,`${a}/10000000-0000-4000-8000-000000000090.png`]);
await denied('insert into stories(owner_id,file_path)values($1,$2)',[a,`${a}/10000000-0000-4000-8000-000000000091.png`]);
await db.exec('update membership_catalog set free_events=100');eq((await db.query("select free_events from membership_catalog where country='IR' and tier='normal'")).rows[0].free_events,1);await denied('select * from story_publish_log');
await login(b);const pb=await story(b);eq((await db.query('select count(*)::int n from stories')).rows[0].n,2);
await login(a);eq((await db.query('select count(*)::int n from stories')).rows[0].n,1);eq((await db.query('select count(*)::int n from storage.objects')).rows[0].n,1);
await denied('insert into story_reports(story_id,reporter_id,reason)select id,$1,$2 from stories where owner_id=$3',[b,'wrong reporter',a]);
await db.exec('reset role');await db.query("insert into follows values($1,$2,'accepted')",[a,b]);await login(a);eq((await db.query('select count(*)::int n from stories')).rows[0].n,2);eq((await db.query('select count(*)::int n from storage.objects')).rows[0].n,2);
await db.query("insert into story_reports(story_id,reporter_id,reason) select id,$1,'inappropriate photo' from stories where file_path=$2",[a,pb]);eq((await db.query('select count(*)::int n from story_reports')).rows[0].n,0);
await db.exec('delete from stories where owner_id=\''+b+'\'');eq((await db.query('select count(*)::int n from stories')).rows[0].n,2);
await db.exec('reset role');await db.query('insert into blocks values($1,$2)',[b,a]);await login(a);eq((await db.query('select count(*)::int n from stories')).rows[0].n,1);eq((await db.query('select count(*)::int n from storage.objects')).rows[0].n,1);
await login(admin);eq((await db.query('select count(*)::int n from story_reports')).rows[0].n,1);eq((await db.query('select count(*)::int n from stories')).rows[0].n,2);await db.exec("update membership_catalog set free_events=7 where tier='gold' and country='IR'");eq((await db.query("select free_events from membership_catalog where tier='gold' and country='IR'")).rows[0].free_events,7);
await login(mod);await db.exec('update membership_catalog set free_events=9');eq((await db.query("select free_events from membership_catalog where country='IR' and tier='gold'")).rows[0].free_events,7);await denied('insert into banners(active)values(true)');
await db.exec('reset role');await db.query("update stories set created_at=now()-interval '25 hours',expires_at=now()-interval '1 hour' where file_path=$1",[pa]);await login(a);eq((await db.query('select count(*)::int n from stories')).rows[0].n,0);eq((await db.query('select count(*)::int n from storage.objects')).rows[0].n,0);
await login(admin);eq((await db.query('select count(*)::int n from stories')).rows[0].n,2);await db.exec('reset role');await db.exec(sql);eq((await db.query("select free_events from membership_catalog where tier='gold' and country='IR'")).rows[0].free_events,7);eq((await db.query("select price_minor from ad_packages where tier='featured'")).rows[0].price_minor,777);eq((await db.query("select count(*)::int n from ad_packages where tier='event_banner'")).rows[0].n,2);
await login(a);for(let i=0;i<19;i++){const path=await story(a);await db.query('delete from stories where file_path=$1',[path]);}
const limited=`${a}/10000000-0000-4000-8000-000000000999.png`;await db.query('insert into storage.objects(bucket_id,name)values($1,$2)',['stories',limited]);await denied('insert into stories(owner_id,file_path)values($1,$2)',[a,limited]);
await db.exec('reset role');eq((await db.query('select expires_at-created_at=interval\'24 hours\' ok from stories where file_path=$1',[pb])).rows[0].ok,true);await db.exec('set role anon');await denied('select * from stories');
console.log(`PASS: ${checks} stories/catalog assertions (privacy, expiry, limits, admin access, repeatable migration).`);await db.close();
