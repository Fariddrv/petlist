-- PawPet 2.8.0. Requires setup.sql and migrations 02..06. Additive migration.
-- Take a database backup before applying. Never drop marketplace tables.
begin;
create or replace function public.is_ad_manager()
returns boolean language sql stable security definer set search_path = public as $$
 select coalesce(public.admin_role() in ('owner','admin'),false);
$$;
revoke all on function public.is_ad_manager() from public, anon;
grant execute on function public.is_ad_manager() to authenticated;

create table if not exists public.ad_packages (
 id uuid primary key default gen_random_uuid(),
 country text not null check(country ~ '^[A-Z]{2}$'),
 tier text not null check(tier in ('basic','premium','featured')),
 price_minor bigint check(price_minor >= 0),
 currency text not null check(currency in ('IRT','USD','EUR','CNY','GBP','AED','TRY','JPY','KRW','CAD','AUD','CHF','SAR','INR','RUB','IQD')),
 duration_days integer not null default 30 check(duration_days between 1 and 366),
 feed_placement boolean not null default false,
 active boolean not null default true,
 updated_at timestamptz not null default now(),
 unique(country,tier)
);
drop trigger if exists ad_packages_audit on public.ad_packages;
-- NULL means quotation required. These are not live prices.
insert into public.ad_packages(country,tier,currency,feed_placement)
select c.country,t.tier,c.currency,t.tier <> 'basic'
from (values ('IR','IRT'),('CN','CNY')) c(country,currency)
cross join (values ('basic'),('premium'),('featured')) t(tier)
on conflict(country,tier) do nothing;

create table if not exists public.service_ads (
 id uuid primary key default gen_random_uuid(),
 brand text not null check(length(trim(brand)) between 1 and 120),
 description jsonb not null default '{}'::jsonb check(jsonb_typeof(description)='object'),
 image_url text not null check(image_url ~ '^https://[^[:space:]]+$'),
 country text not null check(country ~ '^[A-Z]{2}$'),
 city text not null check(length(trim(city)) between 1 and 100),
 category text not null check(category in ('vet','petshop','grooming','training','boarding','transport','other')),
 tier text not null default 'basic' check(tier in ('basic','premium','featured')),
 priority integer not null default 0 check(priority between 0 and 10000),
 badges text[] not null default '{}' check(badges <@ array['local','promotion','top_rated']::text[]),
 rating numeric(2,1) check(rating between 0 and 5),
 rating_source text,
 destination_type text not null default 'website' check(destination_type in ('website','profile','appointment','message','call','whatsapp','instagram','wechat','telegram','tiktok','facebook','other')),
 destination text not null check(length(destination) between 1 and 2000),
 show_in_feed boolean not null default false,
 active boolean not null default false,
 starts_at timestamptz not null default now(),
 ends_at timestamptz not null,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 check(ends_at > starts_at),
 check(not show_in_feed or tier in ('premium','featured')),
 check((rating is null and not ('top_rated'=any(badges))) or (rating is not null and coalesce(length(trim(rating_source)),0) > 0)),
 check(case when destination_type='profile' then destination ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
 when destination_type='call' then destination ~ '^tel:\+?[0-9]{5,20}$'
 else destination ~ '^https://[^[:space:]]+$' and destination !~ '^https://[^/]*@' end)
);
create index if not exists service_ads_location_idx on public.service_ads(country,city,category,active,ends_at);

create table if not exists public.ad_requests (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 client_token uuid not null,
 brand text not null,
 contact_name text not null,
 contact_channel text not null check(contact_channel in ('whatsapp','telegram','wechat','email','phone')),
 contact_value text not null,
 country text not null,
 city text not null,
 category text not null,
 package_id uuid references public.ad_packages(id) on delete set null,
 package_snapshot jsonb not null,
 destination_type text not null,
 destination text not null,
 description text not null,
 terms_version text not null default 'ads-2.8.0',
 terms_accepted_at timestamptz not null default now(),
 status text not null default 'new' check(status in ('new','reviewing','awaiting_payment','paid','published','rejected')),
 admin_notes text not null default '',
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 unique(user_id,client_token)
);
create index if not exists ad_requests_user_time_idx on public.ad_requests(user_id,created_at desc);
-- Do not expose internal notes to requesters. They receive only the submission receipt.
alter table public.ad_packages enable row level security;
alter table public.service_ads enable row level security;
alter table public.ad_requests enable row level security;
drop policy if exists ad_packages_read on public.ad_packages;
create policy ad_packages_read on public.ad_packages for select to authenticated using(active or public.is_ad_manager());
drop policy if exists ad_packages_manage on public.ad_packages;
create policy ad_packages_manage on public.ad_packages for all to authenticated using(public.is_ad_manager()) with check(public.is_ad_manager());
drop policy if exists service_ads_read on public.service_ads;
create policy service_ads_read on public.service_ads for select to authenticated
 using((active and starts_at <= now() and ends_at > now()) or public.is_ad_manager());
drop policy if exists service_ads_manage on public.service_ads;
create policy service_ads_manage on public.service_ads for all to authenticated using(public.is_ad_manager()) with check(public.is_ad_manager());
drop policy if exists ad_requests_manage on public.ad_requests;
create policy ad_requests_manage on public.ad_requests for all to authenticated using(public.is_ad_manager()) with check(public.is_ad_manager());
revoke all on public.ad_packages, public.service_ads, public.ad_requests from public, anon, authenticated;
grant select,insert,update,delete on public.ad_packages,public.service_ads to authenticated;
grant select,update on public.ad_requests to authenticated;

create or replace function public.submit_ad_request(p_data jsonb,p_token uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare
 uid uuid := auth.uid(); result uuid; pkg public.ad_packages%rowtype; last_submit timestamptz;
begin
 if uid is null or p_token is null then raise exception 'authentication required'; end if;
 perform pg_advisory_xact_lock(hashtextextended(uid::text,7280));
 select id into result from public.ad_requests where user_id=uid and client_token=p_token;
 if result is not null then return result; end if;
 if p_data->>'terms_version' is distinct from 'ads-2.8.0' or p_data->>'accepted' is distinct from 'true' then raise exception 'terms required'; end if;
 select max(created_at) into last_submit from public.ad_requests where user_id=uid;
 if last_submit > now()-interval '1 minute' or (select count(*) from public.ad_requests where user_id=uid and created_at > now()-interval '1 day') >= 5 then raise exception 'request limit reached'; end if;
 if coalesce(length(trim(p_data->>'brand')),0) not between 1 and 120
 or coalesce(length(trim(p_data->>'contact_name')),0) not between 1 and 120
 or coalesce(length(trim(p_data->>'contact_value')),0) not between 3 and 200
 or coalesce(length(trim(p_data->>'city')),0) not between 1 and 100
 or coalesce(length(p_data->>'description'),0) not between 1 and 3000
 or coalesce(p_data->>'category','') not in ('vet','petshop','grooming','training','boarding','transport','other')
 or coalesce(p_data->>'contact_channel','') not in ('whatsapp','telegram','wechat','email','phone')
 or coalesce(p_data->>'destination_type','') not in ('website','profile','appointment','message','call','whatsapp','instagram','wechat','telegram','tiktok','facebook','other')
 then raise exception 'invalid request'; end if;
 if (case when p_data->>'destination_type'='profile' then coalesce(p_data->>'destination','') ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
 when p_data->>'destination_type'='call' then coalesce(p_data->>'destination','') ~ '^tel:\+?[0-9]{5,20}$'
 else coalesce(p_data->>'destination','') ~ '^https://[^[:space:]]+$' and coalesce(p_data->>'destination','') !~ '^https://[^/]*@' end) is not true
 or length(p_data->>'destination') > 2000 then raise exception 'invalid destination'; end if;
 select * into pkg from public.ad_packages where id=(p_data->>'package_id')::uuid and active;
 if not found or pkg.country is distinct from p_data->>'country' then raise exception 'package unavailable'; end if;
 insert into public.ad_requests(user_id,client_token,brand,contact_name,contact_channel,contact_value,country,city,category,package_id,package_snapshot,destination_type,destination,description)
 values(uid,p_token,trim(p_data->>'brand'),trim(p_data->>'contact_name'),p_data->>'contact_channel',trim(p_data->>'contact_value'),pkg.country,trim(p_data->>'city'),p_data->>'category',pkg.id,
 jsonb_build_object('tier',pkg.tier,'price_minor',pkg.price_minor,'currency',pkg.currency,'duration_days',pkg.duration_days,'feed_placement',pkg.feed_placement),
 p_data->>'destination_type',p_data->>'destination',p_data->>'description') returning id into result;
 return result;
end $$;
revoke all on function public.submit_ad_request(jsonb,uuid) from public,anon;
grant execute on function public.submit_ad_request(jsonb,uuid) to authenticated;

create or replace function public.audit_ads_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
 if not public.is_ad_manager() then raise exception 'not allowed'; end if;
 if TG_OP <> 'DELETE' then new.updated_at := now(); end if;
 insert into public.audit_log(admin_id,action,target_type,target_id,details)
 values(auth.uid(),'ads_'||lower(TG_OP),TG_TABLE_NAME,coalesce(new.id,old.id)::text,jsonb_build_object('operation',TG_OP));
 if TG_OP='DELETE' then return old; else return new; end if;
end $$;
revoke all on function public.audit_ads_change() from public,anon,authenticated;
drop trigger if exists service_ads_audit on public.service_ads;
create trigger service_ads_audit before insert or update or delete on public.service_ads for each row execute function public.audit_ads_change();
drop trigger if exists ad_packages_audit on public.ad_packages;
create trigger ad_packages_audit before insert or update or delete on public.ad_packages for each row execute function public.audit_ads_change();
drop trigger if exists ad_requests_audit on public.ad_requests;
create trigger ad_requests_audit before update on public.ad_requests for each row execute function public.audit_ads_change();

-- Server kill switch: old APKs cannot continue to write marketplace data.
insert into public.app_settings(key,value) values('marketplace_enabled','false'::jsonb) on conflict(key) do update set value='false'::jsonb;
create or replace function public.marketplace_enabled()
returns boolean language sql stable security definer set search_path = public as $$
 select coalesce((select value='true'::jsonb from public.app_settings where key='marketplace_enabled'),false);
$$;
revoke all on function public.marketplace_enabled() from public,anon;
grant execute on function public.marketplace_enabled() to authenticated;
create or replace function public.guard_marketplace_write()
returns trigger language plpgsql security definer set search_path = public as $$
begin
 if not public.marketplace_enabled() and not public.is_ad_manager() then raise exception 'marketplace disabled'; end if;
 if TG_OP='DELETE' then return old; else return new; end if;
end $$;
revoke all on function public.guard_marketplace_write() from public,anon,authenticated;
drop trigger if exists marketplace_guard on public.shops;
create trigger marketplace_guard before insert or update or delete on public.shops for each row execute function public.guard_marketplace_write();
drop trigger if exists marketplace_guard on public.listings;
create trigger marketplace_guard before insert or update or delete on public.listings for each row execute function public.guard_marketplace_write();
drop trigger if exists marketplace_guard on public.shop_documents;
create trigger marketplace_guard before insert or update or delete on public.shop_documents for each row execute function public.guard_marketplace_write();
alter policy shops_read on public.shops using(public.is_ad_manager() or (public.marketplace_enabled() and (status='approved' or owner_id=auth.uid() or public.is_admin())));
alter policy listings_read on public.listings using(public.is_ad_manager() or (public.marketplace_enabled() and ((active and exists(select 1 from public.shops s where s.id=shop_id and s.status='approved')) or exists(select 1 from public.shops s where s.id=shop_id and s.owner_id=auth.uid()) or public.is_admin())));

-- Analytics: one event per authenticated user / ad / UTC day / kind.
-- Reports are aggregates; requesters cannot read event rows.
create table if not exists public.ad_events (
 ad_id uuid not null references public.service_ads(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 event_day date not null default ((now() at time zone 'UTC')::date),
 kind text not null check(kind in ('view','click')),
 primary key(ad_id,user_id,event_day,kind)
);
alter table public.ad_events enable row level security;
revoke all on public.ad_events from public,anon,authenticated;
create or replace function public.record_ad_event(p_ad uuid,p_kind text)
returns void language plpgsql security definer set search_path = public as $$
begin
 if auth.uid() is null or p_kind is null or p_kind not in ('view','click') then raise exception 'invalid event'; end if;
 if not exists(select 1 from public.service_ads where id=p_ad and active and starts_at<=now() and ends_at>now()) then return; end if;
 insert into public.ad_events(ad_id,user_id,kind) values(p_ad,auth.uid(),p_kind) on conflict do nothing;
end $$;
revoke all on function public.record_ad_event(uuid,text) from public,anon;
grant execute on function public.record_ad_event(uuid,text) to authenticated;
create or replace function public.ad_event_report()
returns table(ad_id uuid,kind text,count bigint) language plpgsql security definer set search_path = public as $$
begin
 if not public.is_ad_manager() then raise exception 'not allowed'; end if;
 return query select e.ad_id,e.kind,count(*) from public.ad_events e group by e.ad_id,e.kind;
end $$;
revoke all on function public.ad_event_report() from public,anon;
grant execute on function public.ad_event_report() to authenticated;

commit;
