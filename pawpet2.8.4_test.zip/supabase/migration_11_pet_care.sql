-- PawPet 2.8.4 phase 1. Additive; existing pet passports remain unchanged.
begin;
create table if not exists public.pet_health (
 pet_id uuid primary key references public.pets(id) on delete cascade,
 allergies text not null default '' check(length(allergies)<=4000),
 conditions text not null default '' check(length(conditions)<=4000),
 medications text not null default '' check(length(medications)<=4000),
 vet_name text not null default '' check(length(vet_name)<=200),
 vet_phone text not null default '' check(length(vet_phone)<=60),
 vet_address text not null default '' check(length(vet_address)<=1000),
 created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create table if not exists public.pet_care (
 id uuid primary key default gen_random_uuid(),pet_id uuid not null references public.pets(id) on delete cascade,
 kind text not null check(kind in('vaccination','deworming','checkup','grooming','other')),
 title text not null check(length(trim(title)) between 1 and 200),
 notes text not null default '' check(length(notes)<=2000),
 due_at timestamptz not null check(due_at between '1900-01-01'::timestamptz and '2100-01-01'::timestamptz),
 notify boolean not null default true,completed boolean not null default false,
 completed_at timestamptz,created_at timestamptz not null default now(),updated_at timestamptz not null default now(),
 check((completed and completed_at is not null)or(not completed and completed_at is null))
);
create index if not exists pet_care_due_idx on public.pet_care(pet_id,completed,due_at,id);
create table if not exists public.pet_weights (
 id uuid primary key default gen_random_uuid(),pet_id uuid not null references public.pets(id) on delete cascade,
 weight_kg numeric(8,3) not null check(weight_kg>0 and weight_kg<=1000),
 measured_on date not null check(measured_on between '1900-01-01'::date and '2100-01-01'::date),
 notes text not null default '' check(length(notes)<=1000),
 created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create index if not exists pet_weights_date_idx on public.pet_weights(pet_id,measured_on desc,id);
alter table public.pet_health enable row level security;
alter table public.pet_care enable row level security;
alter table public.pet_weights enable row level security;
drop policy if exists pet_health_owner on public.pet_health;
create policy pet_health_owner on public.pet_health for all to authenticated
 using(exists(select 1 from public.pets p where p.id=pet_id and p.owner_id=auth.uid()))
 with check(exists(select 1 from public.pets p where p.id=pet_id and p.owner_id=auth.uid()));
drop policy if exists pet_care_owner on public.pet_care;
create policy pet_care_owner on public.pet_care for all to authenticated
 using(exists(select 1 from public.pets p where p.id=pet_id and p.owner_id=auth.uid()))
 with check(exists(select 1 from public.pets p where p.id=pet_id and p.owner_id=auth.uid()));
drop policy if exists pet_weights_owner on public.pet_weights;
create policy pet_weights_owner on public.pet_weights for all to authenticated
 using(exists(select 1 from public.pets p where p.id=pet_id and p.owner_id=auth.uid()))
 with check(exists(select 1 from public.pets p where p.id=pet_id and p.owner_id=auth.uid()));
create or replace function public.pet_care_guard()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null or not exists(select 1 from public.pets where id=new.pet_id and owner_id=auth.uid()) then raise exception 'owner only';end if;
 if tg_op='UPDATE' then
  if new.pet_id is distinct from old.pet_id then raise exception 'pet cannot change';end if;
  new.created_at:=old.created_at;
 else new.created_at:=now();end if;
 new.updated_at:=now();
 if tg_table_name='pet_care' then
  perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,7284));
  if not new.completed and (tg_op='INSERT' or old.completed) and (select count(*) from public.pet_care c join public.pets p on p.id=c.pet_id where p.owner_id=auth.uid() and not c.completed)>=500 then raise exception 'pending care limit';end if;
  if new.completed then
   if tg_op='UPDATE' and old.completed then new.completed_at:=old.completed_at;else new.completed_at:=now();end if;
  else new.completed_at:=null;end if;
 elsif tg_table_name='pet_weights' then
  -- One-day tolerance for users east of the database's UTC clock.
  if new.measured_on>current_date+1 then raise exception 'future weight';end if;
 end if;
 return new;
end $$;
revoke all on function public.pet_care_guard() from public,anon,authenticated;
drop trigger if exists pet_health_guard on public.pet_health;
create trigger pet_health_guard before insert or update on public.pet_health for each row execute function public.pet_care_guard();
drop trigger if exists pet_care_guard on public.pet_care;
create trigger pet_care_guard before insert or update on public.pet_care for each row execute function public.pet_care_guard();
drop trigger if exists pet_weights_guard on public.pet_weights;
create trigger pet_weights_guard before insert or update on public.pet_weights for each row execute function public.pet_care_guard();
revoke all on public.pet_health,public.pet_care,public.pet_weights from public,anon,authenticated;
grant select,delete on public.pet_health,public.pet_care,public.pet_weights to authenticated;
grant insert(pet_id,allergies,conditions,medications,vet_name,vet_phone,vet_address) on public.pet_health to authenticated;
grant update(allergies,conditions,medications,vet_name,vet_phone,vet_address) on public.pet_health to authenticated;
grant insert(pet_id,kind,title,notes,due_at,notify,completed) on public.pet_care to authenticated;
grant update(kind,title,notes,due_at,notify,completed) on public.pet_care to authenticated;
grant insert(pet_id,weight_kg,measured_on,notes) on public.pet_weights to authenticated;
grant update(weight_kg,measured_on,notes) on public.pet_weights to authenticated;
commit;
