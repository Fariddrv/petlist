-- Requires migrations 07 and 08. Additive; payment remains disabled.
begin;
create table if not exists public.stories (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references public.profiles(id) on delete cascade,
 file_path text not null unique,
 created_at timestamptz not null default now(),
 expires_at timestamptz not null default now()+interval '24 hours',
 check(file_path ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}\.png$' and split_part(file_path,'/',1)=owner_id::text),
 check(expires_at>created_at and expires_at<=created_at+interval '24 hours')
);
create index if not exists stories_live_idx on public.stories(expires_at,owner_id,created_at);
alter table public.stories enable row level security;
create table if not exists public.story_publish_log(owner_id uuid not null references public.profiles(id) on delete cascade,created_at timestamptz not null default now());
create index if not exists story_publish_log_idx on public.story_publish_log(owner_id,created_at);
alter table public.story_publish_log enable row level security;
revoke all on public.story_publish_log from public,anon,authenticated;
create or replace function public.guard_story_insert()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null or new.owner_id is distinct from auth.uid() then raise exception 'not allowed'; end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,7282));
 if (select count(*) from public.story_publish_log where owner_id=auth.uid() and created_at>now()-interval '24 hours')>=20 then raise exception 'story limit reached'; end if;
 if not exists(select 1 from storage.objects where bucket_id='stories' and name=new.file_path) then raise exception 'image must be uploaded first'; end if;
 insert into public.story_publish_log(owner_id) values(auth.uid());
 new.created_at:=now(); new.expires_at:=now()+interval '24 hours';
 return new;
end $$;
drop trigger if exists stories_guard on public.stories;
create trigger stories_guard before insert on public.stories for each row execute function public.guard_story_insert();
revoke all on function public.guard_story_insert() from public,anon,authenticated;
drop policy if exists stories_read on public.stories;
create policy stories_read on public.stories for select to authenticated using((expires_at>now() and public.can_see_owner(owner_id)) or public.is_ad_manager());
drop policy if exists stories_insert on public.stories;
create policy stories_insert on public.stories for insert to authenticated with check(owner_id=auth.uid());
drop policy if exists stories_delete on public.stories;
create policy stories_delete on public.stories for delete to authenticated using(owner_id=auth.uid() or public.is_ad_manager());
revoke all on public.stories from public,anon,authenticated;
grant select,delete on public.stories to authenticated;
grant insert(owner_id,file_path) on public.stories to authenticated;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('stories','stories',false,10485760,array['image/png'])
on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists stories_upload on storage.objects;
create policy stories_upload on storage.objects for insert to authenticated with check(bucket_id='stories' and split_part(name,'/',1)=auth.uid()::text and name~'^[0-9a-f-]{36}/[0-9a-f-]{36}\.png$');
drop policy if exists stories_file_read on storage.objects;
create policy stories_file_read on storage.objects for select to authenticated using(bucket_id='stories' and exists(select 1 from public.stories s where s.file_path=name and ((s.expires_at>now() and public.can_see_owner(s.owner_id)) or public.is_ad_manager())));
drop policy if exists stories_file_delete on storage.objects;
create policy stories_file_delete on storage.objects for delete to authenticated using(bucket_id='stories' and (split_part(name,'/',1)=auth.uid()::text or public.is_ad_manager()));
create table if not exists public.story_reports (
 id uuid primary key default gen_random_uuid(),
 story_id uuid not null references public.stories(id) on delete cascade,
 reporter_id uuid not null references public.profiles(id) on delete cascade,
 reason text not null check(length(trim(reason)) between 3 and 1000),
 created_at timestamptz not null default now(),
 unique(story_id,reporter_id)
);
alter table public.story_reports enable row level security;
drop policy if exists story_reports_insert on public.story_reports;
create policy story_reports_insert on public.story_reports for insert to authenticated with check(reporter_id=auth.uid() and exists(select 1 from public.stories s where s.id=story_id));
drop policy if exists story_reports_admin on public.story_reports;
create policy story_reports_admin on public.story_reports for select to authenticated using(public.is_ad_manager());
revoke all on public.story_reports from public,anon,authenticated;
grant select on public.story_reports to authenticated;
grant insert(story_id,reporter_id,reason) on public.story_reports to authenticated;

drop policy if exists banners_admin on public.banners;
create policy banners_admin on public.banners for all to authenticated using(public.is_ad_manager()) with check(public.is_ad_manager());

-- Existing Featured prices now refer to the image-only services slider.
alter table public.ad_packages drop constraint if exists ad_packages_tier_check;
alter table public.ad_packages add constraint ad_packages_tier_check check(tier in ('basic','premium','featured','event_banner'));
drop trigger if exists ad_packages_audit on public.ad_packages;
insert into public.ad_packages(country,tier,currency)
values('IR','event_banner','IRT'),('CN','event_banner','CNY') on conflict(country,tier) do nothing;
create trigger ad_packages_audit before insert or update or delete on public.ad_packages for each row execute function public.audit_ads_change();

create table if not exists public.membership_catalog (
 id uuid primary key default gen_random_uuid(),
 country text not null check(country~'^[A-Z]{2}$'),
 tier text not null check(tier in ('normal','supporter','gold')),
 free_events integer not null check(free_events between 0 and 100),
 monthly_price_minor bigint check(monthly_price_minor between 0 and 999999999999999),
 currency text not null check(currency in ('IRT','USD','CNY','EUR')),
 boost_discount integer not null default 0 check(boost_discount between 0 and 100),
 profile_frame boolean not null default false,
 updated_at timestamptz not null default now(),
 unique(country,tier)
);
create table if not exists public.event_pricing (
 id uuid primary key default gen_random_uuid(),
 country text not null unique check(country~'^[A-Z]{2}$'),
 currency text not null check(currency in ('IRT','USD','CNY','EUR')),
 extra_event_price_minor bigint check(extra_event_price_minor between 0 and 999999999999999),
 boost_price_minor bigint check(boost_price_minor between 0 and 999999999999999),
 boost_hours integer not null default 24 check(boost_hours between 1 and 168),
 updated_at timestamptz not null default now()
);
drop trigger if exists membership_catalog_audit on public.membership_catalog;
drop trigger if exists event_pricing_audit on public.event_pricing;
insert into public.membership_catalog(country,tier,free_events,monthly_price_minor,currency,profile_frame)
select c.country,t.tier,t.quota,case when t.tier='normal' then 0 else null end,c.currency,t.tier='gold'
from (values('IR','IRT'),('CN','CNY')) c(country,currency)
cross join(values('normal',1),('supporter',3),('gold',4)) t(tier,quota)
on conflict(country,tier) do nothing;
insert into public.event_pricing(country,currency,extra_event_price_minor)
values('IR','IRT',100000),('CN','CNY',null) on conflict(country) do nothing;
alter table public.membership_catalog enable row level security;
alter table public.event_pricing enable row level security;
drop policy if exists membership_catalog_read on public.membership_catalog;
create policy membership_catalog_read on public.membership_catalog for select to authenticated using(true);
drop policy if exists membership_catalog_manage on public.membership_catalog;
create policy membership_catalog_manage on public.membership_catalog for all to authenticated using(public.is_ad_manager()) with check(public.is_ad_manager());
drop policy if exists event_pricing_read on public.event_pricing;
create policy event_pricing_read on public.event_pricing for select to authenticated using(true);
drop policy if exists event_pricing_manage on public.event_pricing;
create policy event_pricing_manage on public.event_pricing for all to authenticated using(public.is_ad_manager()) with check(public.is_ad_manager());
revoke all on public.membership_catalog,public.event_pricing from public,anon,authenticated;
grant select,insert,update,delete on public.membership_catalog,public.event_pricing to authenticated;
create trigger membership_catalog_audit before insert or update or delete on public.membership_catalog for each row execute function public.audit_ads_change();
create trigger event_pricing_audit before insert or update or delete on public.event_pricing for each row execute function public.audit_ads_change();
-- Draft rules only. No quota enforcement, fake payment, or entitlement grant.
commit;
