begin;
alter table public.messages add column if not exists media_path text;
alter table public.messages add column if not exists media_type text;
alter table public.messages drop constraint if exists messages_media_valid;
alter table public.messages add constraint messages_media_valid check (
 (media_path is null and media_type is null) or
 (media_path is not null and media_type is not null and media_type in ('image','video','gif') and
  split_part(media_path,'/',1)=sender_id::text and split_part(media_path,'/',2)=receiver_id::text and
  media_path ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}/[0-9a-f-]{36}\.(jpg|png|webp|gif|mp4|mov)$')
);
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('chat-media','chat-media',false,26214400,array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/quicktime'])
on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists chat_media_insert on storage.objects;
create policy chat_media_insert on storage.objects for insert to authenticated with check (
 bucket_id='chat-media' and split_part(name,'/',1)=auth.uid()::text and
 exists(select 1 from public.profiles where id::text=split_part(name,'/',2))
);
drop policy if exists chat_media_read on storage.objects;
create policy chat_media_read on storage.objects for select to authenticated using (
 bucket_id='chat-media' and (
  split_part(name,'/',1)=auth.uid()::text or
  exists(select 1 from public.messages m where m.media_path=name and m.receiver_id=auth.uid())
 )
);
drop policy if exists chat_media_delete on storage.objects;
create policy chat_media_delete on storage.objects for delete to authenticated using (
 bucket_id='chat-media' and split_part(name,'/',1)=auth.uid()::text
);
-- Existing participant policies remain; extra columns do not widen access.
commit;
