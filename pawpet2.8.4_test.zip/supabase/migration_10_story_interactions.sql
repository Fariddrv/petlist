-- PawPet 2.8.3: apply AFTER migration 09. No payments or membership grants.
begin;
create table if not exists public.story_views (
 story_id uuid not null references public.stories(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(story_id,user_id)
);
create table if not exists public.story_likes (
 story_id uuid not null references public.stories(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(story_id,user_id)
);
create table if not exists public.story_comments (
 id uuid primary key default gen_random_uuid(),
 story_id uuid not null references public.stories(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 text text not null check(length(trim(text)) between 1 and 1000),
 created_at timestamptz not null default now()
);
create index if not exists story_comments_story_idx on public.story_comments(story_id,created_at,id);
create index if not exists story_comments_actor_idx on public.story_comments(user_id,created_at);
create table if not exists public.story_shares (
 story_id uuid not null references public.stories(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 recipient_id uuid not null references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(story_id,user_id,recipient_id)
);
create table if not exists public.story_comment_log (
 user_id uuid not null references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now()
);
create index if not exists story_comment_log_actor_idx on public.story_comment_log(user_id,created_at);
alter table public.story_comment_log enable row level security;
revoke all on public.story_comment_log from public,anon,authenticated;
alter table public.story_views enable row level security;
alter table public.story_likes enable row level security;
alter table public.story_comments enable row level security;
alter table public.story_shares enable row level security;
-- RPC-only writes and reads. Clients cannot forge viewers, counts or timestamps.
revoke all on public.story_views,public.story_likes,public.story_comments,public.story_shares from public,anon,authenticated;
alter table public.messages add column if not exists story_ref uuid;
-- Deliberately no FK: expired/deleted story messages retain an unavailable card.
revoke insert,update on public.messages from authenticated;
grant insert(sender_id,receiver_id,text,post_id,reply_to,media_path,media_type) on public.messages to authenticated;

create or replace function public.story_access(p_story uuid)
returns boolean language sql stable security definer set search_path=public as $$
 select auth.uid() is not null and exists(select 1 from public.stories s where s.id=p_story and s.expires_at>now() and public.can_see_owner(s.owner_id));
$$;
revoke all on function public.story_access(uuid) from public,anon,authenticated;

create or replace function public.story_interact(p_story uuid,p_action text,p_text text default null,p_recipient uuid default null)
returns void language plpgsql security definer set search_path=public as $$
declare actor uuid:=auth.uid(); owner uuid; inserted integer;
begin
 if not public.story_access(p_story) then raise exception 'story unavailable'; end if;
 select owner_id into owner from public.stories where id=p_story;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,7283));
 if p_action='view' then
  if actor<>owner then insert into public.story_views(story_id,user_id)values(p_story,actor)on conflict do nothing;end if;
 elsif p_action='like' then
  if actor=owner then raise exception 'cannot like own story';end if;
  insert into public.story_views(story_id,user_id)values(p_story,actor)on conflict do nothing;
  insert into public.story_likes(story_id,user_id)values(p_story,actor)on conflict do nothing;
 elsif p_action='unlike' then
  delete from public.story_likes where story_id=p_story and user_id=actor;
 elsif p_action='comment' then
  if p_text is null or length(trim(p_text)) not between 1 and 1000 then raise exception 'invalid comment';end if;
  if (select count(*) from public.story_comment_log where user_id=actor and created_at>now()-interval '1 minute')>=5 or
     (select count(*) from public.story_comment_log where user_id=actor and created_at>now()-interval '24 hours')>=100 then raise exception 'comment limit';end if;
  insert into public.story_comments(story_id,user_id,text)values(p_story,actor,trim(p_text));
  insert into public.story_comment_log(user_id)values(actor);
 elsif p_action='share' then
  if p_recipient is null or p_recipient=actor or not exists(select 1 from public.profiles where id=p_recipient) or public.is_blocked_pair(actor,p_recipient) then raise exception 'recipient unavailable';end if;
  if not exists(select 1 from public.follows where follower_id=actor and followee_id=p_recipient and status='accepted') and not exists(select 1 from public.messages where (sender_id=actor and receiver_id=p_recipient) or(sender_id=p_recipient and receiver_id=actor)) then raise exception 'choose a followed user or existing conversation';end if;
  if(select count(*) from public.story_shares where user_id=actor and created_at>now()-interval '24 hours')>=100 then raise exception 'share limit';end if;
  insert into public.story_shares(story_id,user_id,recipient_id)values(p_story,actor,p_recipient)on conflict do nothing;
  get diagnostics inserted=row_count;
  if inserted>0 then insert into public.messages(sender_id,receiver_id,text,story_ref)values(actor,p_recipient,'',p_story);end if;
 else raise exception 'invalid action';end if;
end $$;
revoke all on function public.story_interact(uuid,text,text,uuid) from public,anon;
grant execute on function public.story_interact(uuid,text,text,uuid) to authenticated;

create or replace function public.story_summary(p_story uuid)
returns jsonb language plpgsql stable security definer set search_path=public as $$
declare own boolean;
begin
 if not public.story_access(p_story) then raise exception 'story unavailable';end if;
 select owner_id=auth.uid() into own from public.stories where id=p_story;
 return jsonb_build_object('own',own,'liked',exists(select 1 from public.story_likes where story_id=p_story and user_id=auth.uid()),
 'views',case when own then(select count(*) from public.story_views v where v.story_id=p_story and not public.is_blocked_pair(auth.uid(),v.user_id))else null end,
 'likes',case when own then(select count(*) from public.story_likes v where v.story_id=p_story and not public.is_blocked_pair(auth.uid(),v.user_id))else null end,
 'comments',(select count(*) from public.story_comments v where v.story_id=p_story and (own or v.user_id=auth.uid()) and not public.is_blocked_pair(auth.uid(),v.user_id)),
 'shares',case when own then(select count(*) from public.story_shares v where v.story_id=p_story and not public.is_blocked_pair(auth.uid(),v.user_id))else null end);
end $$;
revoke all on function public.story_summary(uuid) from public,anon;
grant execute on function public.story_summary(uuid) to authenticated;

create or replace function public.story_people(p_story uuid,p_kind text,p_offset integer default 0)
returns table(user_id uuid,username text,avatar_url text,created_at timestamptz)
language plpgsql stable security definer set search_path=public as $$
begin
 if not public.story_access(p_story) or not exists(select 1 from public.stories where id=p_story and owner_id=auth.uid()) then raise exception 'owner only';end if;
 if p_offset is null or p_offset<0 or p_offset>1000000 then raise exception 'bad offset';end if;
 if p_kind='views' then return query select v.user_id,p.username,p.avatar_url,v.created_at from public.story_views v join public.profiles p on p.id=v.user_id where v.story_id=p_story and not public.is_blocked_pair(auth.uid(),v.user_id) order by v.created_at desc,v.user_id limit 50 offset p_offset;
 elsif p_kind='likes' then return query select v.user_id,p.username,p.avatar_url,v.created_at from public.story_likes v join public.profiles p on p.id=v.user_id where v.story_id=p_story and not public.is_blocked_pair(auth.uid(),v.user_id) order by v.created_at desc,v.user_id limit 50 offset p_offset;
 else raise exception 'invalid kind';end if;
end $$;
revoke all on function public.story_people(uuid,text,integer) from public,anon;
grant execute on function public.story_people(uuid,text,integer) to authenticated;

create or replace function public.story_comment_list(p_story uuid,p_offset integer default 0)
returns table(id uuid,user_id uuid,username text,avatar_url text,text text,created_at timestamptz)
language plpgsql stable security definer set search_path=public as $$
declare own boolean;
begin
 if not public.story_access(p_story) then raise exception 'story unavailable';end if;
 if p_offset is null or p_offset<0 or p_offset>1000000 then raise exception 'bad offset';end if;
 select owner_id=auth.uid() into own from public.stories where stories.id=p_story;
 return query select v.id,v.user_id,p.username,p.avatar_url,v.text,v.created_at from public.story_comments v join public.profiles p on p.id=v.user_id where v.story_id=p_story and (own or v.user_id=auth.uid()) and not public.is_blocked_pair(auth.uid(),v.user_id) order by v.created_at desc,v.id limit 50 offset p_offset;
end $$;
revoke all on function public.story_comment_list(uuid,integer) from public,anon;
grant execute on function public.story_comment_list(uuid,integer) to authenticated;

create or replace function public.story_comment_delete(p_comment uuid)
returns void language plpgsql security definer set search_path=public as $$
declare sid uuid; author uuid;
begin
 select story_id,user_id into sid,author from public.story_comments where id=p_comment;
 if not public.story_access(sid) or not(author=auth.uid() or exists(select 1 from public.stories where id=sid and owner_id=auth.uid())) then raise exception 'not allowed';end if;
 delete from public.story_comments where id=p_comment;
end $$;
revoke all on function public.story_comment_delete(uuid) from public,anon;
grant execute on function public.story_comment_delete(uuid) to authenticated;
commit;
