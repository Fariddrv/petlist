import 'package:flutter_test/flutter_test.dart';
import 'package:petlist_test/ads/ads_models.dart';

ServiceAd ad(
  String id, {
  String tier = 'basic',
  int priority = 0,
  String country = 'IR',
  String city = 'Tehran',
  bool active = true,
}) => ServiceAd({
  'id': id,
  'tier': tier,
  'priority': priority,
  'country': country,
  'city': city,
  'active': active,
  'starts_at': '2026-10-01T00:00:00Z',
  'ends_at': '2026-11-01T00:00:00Z',
});
void main() {
  test('prices use exact currency units and accept Persian digits', () {
    expect(parseAdPrice('۱٬۲۰۰٬۰۰۰', 'IRT'), 1200000);
    expect(parseAdPrice('۹۹٫۵۰', 'CNY'), 9950);
    expect(parseAdPrice('10.1', 'USD'), 1010);
    expect(parseAdPrice('10.12', 'IRT'), null);
    expect(parseAdPrice('NaN', 'USD'), null);
    expect(parseAdPrice('-10', 'USD'), null);
    expect(parseAdPrice('1.234', 'CNY'), null);
    expect(parseAdPrice('999999999999999999999', 'USD'), null);
  });
  test('rejects executable, local and unauthenticated destination schemes', () {
    for (final u in [
      'javascript:alert(1)',
      'file:///etc/passwd',
      'data:text/html,hello',
      'http://example.com',
      'https://user:pass@example.com',
      'https://example.com bad',
    ]) {
      expect(validAdDestination('website', u), false, reason: u);
    }
    expect(validAdDestination('website', 'https://example.com/path?q=1'), true);
    expect(validAdDestination('call', 'tel:+989121234567'), true);
    expect(validAdDestination('call', 'tel:*123#'), false);
    expect(
      validAdDestination('profile', 'ba1eaa27-4a9d-4d8a-a1d0-1109c89e1ca1'),
      true,
    );
    expect(validAdDestination('profile', 'other-user'), false);
  });
  test('paid tier precedes priority, with stable tie order', () {
    final rows = [
      ad('z', tier: 'basic', priority: 10000),
      ad('b', tier: 'featured'),
      ad('a', tier: 'featured'),
      ad('p', tier: 'premium', priority: 100),
    ];
    rows.sort(compareAds);
    expect(rows.map((a) => a.id), ['a', 'b', 'p', 'z']);
  });
  test('country and city must both match', () {
    final a = ad('a');
    expect(a.matches('IR', 'Tehran'), true);
    expect(a.matches('CN', 'Tehran'), false);
    expect(a.matches('IR', 'Shiraz'), false);
  });
  test('expired, future and inactive advertisements never display', () {
    final a = ad('a');
    expect(a.live(DateTime.parse('2026-10-01T00:00:00Z')), true);
    expect(a.live(DateTime.parse('2026-11-01T00:00:00Z')), false);
    expect(a.live(DateTime.parse('2026-09-30T00:00:00Z')), false);
    expect(
      ad('b', active: false).live(DateTime.parse('2026-10-10T00:00:00Z')),
      false,
    );
  });
  test('request token is a valid unpredictable UUID and changes', () {
    final a = requestToken(), b = requestToken();
    expect(a, isNot(b));
    expect(validAdDestination('profile', a), true);
  });
}
