import 'package:flutter_test/flutter_test.dart';
import 'package:petlist_test/pets/care_models.dart';
void main(){
 test('Persian and Arabic digits and decimal sign normalize',(){expect(normalizeDigits(' ۱۲٫۵ '),'12.5');expect(normalizeDigits('٢٣.٤'),'23.4');});
 test('Pounds display converts consistently and preserves integer zeros',(){expect(weightText(10,false),'10');expect(weightText(4.5,false),'4.5');expect(weightText(1,true),'2.205');expect(double.parse(weightText(1,true))/poundsPerKg,closeTo(1,.001));});
 test('Reminder plan excludes past, completed and muted tasks; schedules nearest 50',(){
  final now=DateTime.utc(2030,1,1);final rows=<CareTask>[];
  CareTask task(String id,DateTime due,{bool notify=true,bool complete=false})=>CareTask({'id':id,'pet_id':'pet','kind':'checkup','title':'test','notes':'','due_at':due.toIso8601String(),'notify':notify,'completed':complete,'completed_at':complete?now.toIso8601String():null});
  rows.add(task('past',now.subtract(const Duration(minutes:1))));rows.add(task('now',now));rows.add(task('muted',now.add(const Duration(minutes:1)),notify:false));rows.add(task('done',now.add(const Duration(minutes:1)),complete:true));
  for(var i=60;i>=1;i--){rows.add(task('$i',now.add(Duration(days:i))));}
  final plan=scheduledCare(rows,now);expect(plan.length,50);expect(plan.first.id,'1');expect(plan.last.id,'50');expect(rows.first.id,'past');
 });
}
