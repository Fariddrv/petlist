import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../state.dart';
import '../models.dart';
import '../l10n.dart';
import '../data/catalog.dart';
import '../data/jalali.dart';
import '../theme.dart';
import '../widgets/smart_image.dart';
import '../pages/pets_page.dart';
import 'care_models.dart';
import 'care_text.dart';
import 'care_forms.dart';

Future<void> editPet(BuildContext context,AppState s,{Pet? pet})async{
 await Navigator.push<Pet>(context,MaterialPageRoute(builder:(_)=>PetFormPage(lang:s.lang,pet:pet,onCommit:pet==null?s.addPet:s.updatePet)));
}
void openPetCare(BuildContext context,AppState s,Pet pet)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PetCarePage(s:s,petId:pet.id)));
Widget petPicture(Pet p,double size)=>ClipRRect(borderRadius:BorderRadius.circular(size*.28),child:SizedBox(width:size,height:size,child:SmartImage(src:p.photoPath,fit:BoxFit.cover,fallbackAsset:p.image)));

class PetsDashboard extends StatelessWidget{
 final AppState s;const PetsDashboard({super.key,required this.s});
 @override Widget build(BuildContext context)=>ListenableBuilder(listenable:Listenable.merge([s,s.care]),builder:(ctx,_){
 final l=s.lang,care=s.care;final overdue=care.upcoming.where((t)=>t.overdue).length;
 return RefreshIndicator(onRefresh:()async{await s.loadPets();await care.load();},child:ListView(physics:const AlwaysScrollableScrollPhysics(),padding:const EdgeInsets.all(16),children:[
  Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:AppPal.purpleGradient,borderRadius:BorderRadius.circular(24)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   Row(children:[const Icon(Icons.pets,color:Colors.white,size:30),const SizedBox(width:10),Expanded(child:Text(petText(l,'دفتر مراقبت حیوانات من','My pet care journal','我的宠物照护日志'),style:const TextStyle(fontWeight:FontWeight.w800,color:Colors.white,fontSize:19)))]),const SizedBox(height:8),
   Text(petText(l,'شناسنامه، سلامت و مراقبت‌های روزمره در یک جا','Passports, health and everyday care in one place','档案、健康与日常照护，一站管理'),style:const TextStyle(color:Colors.white70,fontSize:12)),const SizedBox(height:12),
   Wrap(spacing:10,runSpacing:6,children:[Chip(label:Text('${s.myPets.length} ${petText(l,'حیوان','pets','只宠物')}')),if(overdue>0)Chip(label:Text('$overdue ${petText(l,'مراقبت عقب‌افتاده','overdue tasks','项逾期任务')}'),backgroundColor:const Color(0xFFFFE7DA))]),
  ])),const SizedBox(height:14),
  FilledButton.icon(onPressed:()=>editPet(context,s),icon:const Icon(Icons.add),label:Text(petText(l,'افزودن حیوان','Add a pet','添加宠物'))),
  if(care.loading)const Padding(padding:EdgeInsets.only(top:12),child:LinearProgressIndicator(minHeight:2)),
  if(care.failed)TextButton.icon(onPressed:care.load,icon:const Icon(Icons.refresh),label:Text(petText(l,'مراقبت‌ها بارگذاری نشدند؛ تلاش دوباره','Care tasks unavailable. Retry','无法加载照护任务，重试'))),
  if(care.notificationFailed)Text(petText(l,'زمان‌بندی اعلان کامل نشد؛ مراقبت‌ها در اپ موجودند.','Notification scheduling failed; tasks remain available in the app.','通知安排失败，任务仍可在应用内查看。'),style:const TextStyle(color:Colors.deepOrange,fontSize:12)),
  const SizedBox(height:16),
  if(s.myPets.isEmpty)Padding(padding:const EdgeInsets.all(24),child:Column(children:[const Icon(Icons.pets,size:64,color:AppPal.purple),const SizedBox(height:12),Text(petText(l,'اولین حیوانت را ثبت کن','Add your first pet','添加你的第一只宠物'),style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text(petText(l,'بعد از ثبت، مراقبت‌ها، وزن و اطلاعات دامپزشک را همین‌جا نگه دار.','Then keep care tasks, weight and vet details here.','添加后可在这里管理照护、体重和兽医信息。'),textAlign:TextAlign.center,style:const TextStyle(color:AppPal.inkSoft))])),
  for(final pet in s.myPets)Padding(padding:const EdgeInsets.only(bottom:14),child:Material(color:Colors.white,borderRadius:BorderRadius.circular(22),child:InkWell(borderRadius:BorderRadius.circular(22),onTap:()=>openPetCare(context,s,pet),child:Container(padding:const EdgeInsets.all(14),decoration:AppPal.softCard(),child:Column(children:[
   Row(children:[petPicture(pet,76),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(pet.name,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:19)),const SizedBox(height:5),Text('${speciesOf(pet.species).name(l)} · ${petAgeText(pet,l)}',style:const TextStyle(color:AppPal.inkSoft,fontSize:12))])),const Icon(Icons.chevron_right,color:AppPal.purple)]),
   const SizedBox(height:12),_NextTask(task:care.next(pet.id),s:s),const SizedBox(height:10),Align(alignment:AlignmentDirectional.centerEnd,child:Text(petText(l,'مشاهدهٔ پرونده','View care journal','查看照护档案'),style:const TextStyle(color:AppPal.purple,fontWeight:FontWeight.w700))),
  ]))))),
  Padding(padding:const EdgeInsets.only(top:8),child:Row(children:[const Icon(Icons.lock_outline,size:16,color:AppPal.inkSoft),const SizedBox(width:6),Expanded(child:Text(petText(l,'پروندهٔ مراقبت فقط برای حساب شماست.','Care records are private to your account.','照护记录仅对你的账号可见。'),style:const TextStyle(color:AppPal.inkSoft,fontSize:11)))])),
 ]));
 });
}
class _NextTask extends StatelessWidget{
 final CareTask? task;final AppState s;const _NextTask({required this.task,required this.s});
 @override Widget build(BuildContext context){final l=s.lang;return Container(width:double.infinity,padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:task?.overdue==true?const Color(0xFFFFF1E8):const Color(0xFFF5F1FF),borderRadius:BorderRadius.circular(12)),child:Row(children:[Icon(task?.overdue==true?Icons.schedule:Icons.event_available_outlined,size:18,color:task?.overdue==true?Colors.deepOrange:AppPal.purple),const SizedBox(width:8),Expanded(child:Text(task==null?petText(l,'برای این حیوان مراقبت جدید ثبت کنید.','Add a care task for this pet.','为这只宠物添加照护任务。'):'${task!.title} · ${formatDate(task!.due,l)}${task!.overdue?' · ${petText(l,'عقب‌افتاده','Overdue','已逾期')}':''}',style:const TextStyle(fontSize:12),maxLines:2,overflow:TextOverflow.ellipsis))]));}
}

class PetCarePage extends StatefulWidget{
 final AppState s;final String petId;const PetCarePage({super.key,required this.s,required this.petId});
 @override State<PetCarePage> createState()=>_PetCarePageState();
}
class _PetCarePageState extends State<PetCarePage>{
 int tab=0;bool loading=true,failed=false,busy=false;AppState get s=>widget.s;
 @override void initState(){super.initState();s.care.activePet=widget.petId;_reload();}
 @override void dispose(){if(s.care.activePet==widget.petId)s.care.activePet=null;super.dispose();}
 Future<void> _reload()async{if(mounted)setState(()=>loading=true);try{await s.care.loadPet(widget.petId);if(mounted)setState(()=>failed=false);}catch(_){if(mounted)setState(()=>failed=true);}if(mounted)setState(()=>loading=false);}
 Future<void> _run(Future<void> Function() action)async{if(busy)return;setState(()=>busy=true);try{await action();}catch(_){if(mounted)careError(context,s);}if(mounted)setState(()=>busy=false);}
 Future<bool> _confirm(String message)async=>await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(content:Text(message),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:Text(petText(s.lang,'انصراف','Cancel','取消'))),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:Text(petText(s.lang,'تأیید','Confirm','确认')))]))??false;
 Future<void> _deletePet(Pet pet)async{if(!await _confirm(petText(s.lang,'حیوان و تمام سوابق مراقبت، وزن و اطلاعات پزشکی او حذف شوند؟','Delete this pet and all its care, weight and medical records?','删除这只宠物及其全部照护、体重和医疗记录？'))||!mounted)return;final ok=await s.removePet(pet);if(!mounted)return;if(ok){Navigator.pop(context);}else{careError(context,s);}}
 Future<void> _settings()async{
  final allowed=await s.care.notifications.allowed();if(!mounted)return;
  await showModalBottomSheet<void>(context:context,builder:(ctx)=>SafeArea(child:Column(mainAxisSize:MainAxisSize.min,children:[ListTile(leading:Icon(allowed?Icons.notifications_active_outlined:Icons.notifications_off_outlined),title:Text(petText(s.lang,allowed?'اعلان گوشی فعال است':'فعال‌کردن اعلان گوشی',allowed?'Device notifications enabled':'Enable device notifications',allowed?'设备通知已启用':'启用设备通知')),onTap:()async{Navigator.pop(ctx);try{await s.care.notifications.enable();await s.care.load();}catch(_){if(mounted)careError(context,s);}}),ListTile(leading:const Icon(Icons.notifications_outlined),title:Text(petText(s.lang,'اعلان آزمایشی؛ حدود یک دقیقه بعد','Test notification: about one minute later','测试通知：约一分钟后')),onTap:()async{Navigator.pop(ctx);try{await s.care.notifications.test(s.lang);if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(petText(s.lang,'اعلان آزمایشی زمان‌بندی شد؛ اندروید ممکن است آن را با تأخیر نشان دهد.','Test scheduled; Android may delay delivery.','测试已安排，Android 可能延迟显示。'))));}catch(_){if(mounted)careError(context,s);}})])));
 }
 @override Widget build(BuildContext context)=>ListenableBuilder(listenable:Listenable.merge([s,s.care]),builder:(ctx,_){
  final matches=s.myPets.where((p)=>p.id==widget.petId);if(matches.isEmpty)return Scaffold(appBar:AppBar(),body:Center(child:Text(petText(s.lang,'پرونده در دسترس نیست.','Pet unavailable.','宠物档案不可用。'))));
  final pet=matches.first,l=s.lang;
  return Scaffold(appBar:AppBar(title:Text(pet.name,maxLines:1,overflow:TextOverflow.ellipsis),actions:[IconButton(tooltip:petText(l,'تنظیمات اعلان','Notifications','通知'),onPressed:_settings,icon:const Icon(Icons.notifications_outlined)),IconButton(onPressed:()=>editPet(context,s,pet:pet),icon:const Icon(Icons.edit_outlined)),IconButton(onPressed:busy?null:()=>_deletePet(pet),icon:const Icon(Icons.delete_outline,color:Colors.redAccent))]),body:RefreshIndicator(onRefresh:()async{await s.loadPets();await s.care.load();await _reload();},child:ListView(physics:const AlwaysScrollableScrollPhysics(),padding:const EdgeInsets.all(16),children:[
   Container(padding:const EdgeInsets.all(16),decoration:AppPal.softCard(),child:Row(children:[petPicture(pet,82),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(pet.name,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text('${speciesOf(pet.species).name(l)} · ${petAgeText(pet,l)}',style:const TextStyle(color:AppPal.inkSoft)),const SizedBox(height:6),Text(petText(l,'پروندهٔ خصوصی','Private journal','私人档案'),style:const TextStyle(color:AppPal.purple,fontSize:11))]))])),const SizedBox(height:12),
   _NextTask(task:s.care.next(pet.id),s:s),const SizedBox(height:16),
   SegmentedButton<int>(segments:[ButtonSegment(value:0,label:Text(petText(l,'مراقبت','Care','照护'))),ButtonSegment(value:1,label:Text(petText(l,'سلامت','Health','健康'))),ButtonSegment(value:2,label:Text(petText(l,'مشخصات','Details','详情')))],selected:{tab},onSelectionChanged:(v)=>setState(()=>tab=v.first)),const SizedBox(height:16),
   if(!s.care.remindersEnabled)TextButton.icon(onPressed:_settings,icon:const Icon(Icons.notifications_off_outlined),label:Text(petText(l,'اعلان گوشی غیرفعال است؛ تنظیمات اعلان','Device alerts disabled: notification settings','设备提醒未启用：通知设置'))),
   if(loading)const LinearProgressIndicator(minHeight:2),
   if(failed)TextButton(onPressed:_reload,child:Text(petText(l,'اطلاعات جدید بارگذاری نشد؛ تلاش دوباره','New records unavailable. Retry','无法加载新记录，重试'))),
   if(!loading&&!failed)...(tab==0?_care(pet):tab==1?_health(pet):_details(pet)),
  ])));
 });
 List<Widget> _care(Pet pet){final l=s.lang;final combined=<String,CareTask>{for(final task in s.care.upcoming.where((t)=>t.petId==pet.id))task.id:task,for(final task in s.care.tasks[pet.id]??<CareTask>[])task.id:task};final pending=combined.values.where((t)=>!t.completed).toList()..sort((a,b)=>a.due.compareTo(b.due));final done=combined.values.where((t)=>t.completed).toList()..sort((a,b)=>b.completedAt!.compareTo(a.completedAt!));return[
  FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CareTaskForm(s:s,petId:pet.id))),icon:const Icon(Icons.add),label:Text(petText(l,'ثبت مراقبت و یادآور','Add care / reminder','添加照护 / 提醒'))),const SizedBox(height:16),
  Text(petText(l,'مراقبت‌های پیش‌رو','Upcoming care','待办照护'),style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
  if(pending.isEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:16),child:Text(petText(l,'مراقبت پیش‌رو ثبت نشده است.','No upcoming care recorded.','暂无待办照护。'),style:const TextStyle(color:AppPal.inkSoft))),
  for(final task in pending)_taskCard(task),const SizedBox(height:16),
  Text(petText(l,'سابقهٔ انجام‌شده','Completed care','已完成照护'),style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
  if(done.isEmpty)Text(petText(l,'هنوز مراقبتی انجام‌شده ثبت نشده است.','No completed care yet.','暂无已完成照护。'),style:const TextStyle(color:AppPal.inkSoft)),
  for(final task in done)_taskCard(task),
  if(s.care.moreCare.contains(pet.id))TextButton(onPressed:busy?null:()=>_run(()=>s.care.more(pet.id,weight:false)),child:Text(petText(l,'سوابق بیشتر','Load more records','加载更多记录'))),
 ];}
 Widget _taskCard(CareTask task){final l=s.lang;return Card(color:task.overdue?const Color(0xFFFFF5ED):Colors.white,child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
  Row(children:[Icon(task.completed?Icons.check_circle_outline:task.overdue?Icons.schedule:Icons.event_note,color:task.completed?Colors.green:task.overdue?Colors.deepOrange:AppPal.purple),const SizedBox(width:8),Expanded(child:Text(task.title,style:const TextStyle(fontWeight:FontWeight.w800))),PopupMenuButton<String>(enabled:!busy,onSelected:(v)async{if(v=='edit'){await Navigator.push(context,MaterialPageRoute(builder:(_)=>CareTaskForm(s:s,petId:task.petId,task:task)));}else if(await _confirm(petText(l,'این مراقبت و سابقهٔ آن حذف شود؟','Delete this care record?','删除这条照护记录？'))){await _run(()=>s.care.deleteTask(task));}},itemBuilder:(_)=>[PopupMenuItem(value:'edit',child:Text(petText(l,'ویرایش','Edit','编辑'))),PopupMenuItem(value:'delete',child:Text(petText(l,'حذف','Delete','删除')))])]),
  Text('${careKind(l,task.kind)} · ${formatDate(task.due,l)} · ${TimeOfDay.fromDateTime(task.due).format(context)}',style:const TextStyle(color:AppPal.inkSoft,fontSize:12)),
  if(task.completedAt!=null)Text('${petText(l,'زمان ثبت انجام','Completion recorded','完成记录时间')}: ${formatDate(task.completedAt!,l)}',style:const TextStyle(fontSize:11,color:Colors.green)),
  if(task.notes.isNotEmpty)Padding(padding:const EdgeInsets.only(top:6),child:Text(task.notes)),
  Row(children:[if(task.notify&&!task.completed)const Icon(Icons.notifications_outlined,size:16,color:AppPal.inkSoft),const Spacer(),TextButton.icon(onPressed:busy?null:()async{if(task.completed&&!await _confirm(petText(l,'به مراقبت‌های پیش‌رو برگردد؟','Move back to upcoming care?','移回待办照护？')))return;await _run(()=>s.care.complete(task,!task.completed));},icon:Icon(task.completed?Icons.undo:Icons.check),label:Text(petText(l,task.completed?'بازگرداندن':'انجام شد',task.completed?'Undo':'Done',task.completed?'撤销':'完成')))]),
 ])));}
 List<Widget> _health(Pet pet){final l=s.lang,care=s.care;final entries=care.weights[pet.id]??<WeightEntry>[];final h=care.health[pet.id]??{};return[
  Row(children:[Expanded(child:Text(petText(l,'وزن و روند تغییرات','Weight trend','体重趋势'),style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold))),SegmentedButton<bool>(segments:const[ButtonSegment(value:false,label:Text('kg')),ButtonSegment(value:true,label:Text('lb'))],selected:{care.pounds},onSelectionChanged:(v)=>care.setPounds(v.first))]),const SizedBox(height:12),
  if(entries.isNotEmpty)Text('${weightText(entries.first.kg,care.pounds)} ${care.pounds?'lb':'kg'} · ${formatDate(entries.first.date,l)}',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:20)),
  if(entries.length>1)WeightChart(entries:entries.take(100).toList(),pounds:care.pounds,lang:l),
  FilledButton.tonalIcon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>WeightForm(s:s,petId:pet.id))),icon:const Icon(Icons.add),label:Text(petText(l,'ثبت وزن','Record weight','记录体重'))),
  if(entries.isEmpty)Text(petText(l,'اولین اندازه‌گیری وزن را ثبت کنید.','Record the first weight measurement.','记录第一次体重测量。'),style:const TextStyle(color:AppPal.inkSoft)),
  for(final entry in entries)ListTile(contentPadding:EdgeInsets.zero,title:Text('${weightText(entry.kg,care.pounds)} ${care.pounds?'lb':'kg'}'),subtitle:Text('${formatDate(entry.date,l)}${entry.notes.isEmpty?'':' · ${entry.notes}'}'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>WeightForm(s:s,petId:pet.id,entry:entry))),trailing:IconButton(onPressed:busy?null:()async{if(await _confirm(petText(l,'این اندازه‌گیری حذف شود؟','Delete this measurement?','删除这次测量？')))await _run(()=>care.deleteWeight(entry));},icon:const Icon(Icons.delete_outline,size:20))),
  if(care.moreWeights.contains(pet.id))TextButton(onPressed:busy?null:()=>_run(()=>care.more(pet.id,weight:true)),child:Text(petText(l,'وزن‌های بیشتر','Load more weights','加载更多体重记录'))),const SizedBox(height:18),
  Text(petText(l,'اطلاعات پزشکی خصوصی','Private medical notes','私人医疗备注'),style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
  _info(petText(l,'حساسیت‌ها','Allergies','过敏'),h['allergies']),_info(petText(l,'بیماری‌ها','Conditions','疾病'),h['conditions']),_info(petText(l,'دارو و دستور دامپزشک','Medication / vet instructions','药物 / 兽医指导'),h['medications']),
  OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>HealthForm(s:s,petId:pet.id))),icon:const Icon(Icons.edit_outlined),label:Text(petText(l,'ویرایش سلامت و دامپزشک','Edit health and vet','编辑健康与兽医'))),const SizedBox(height:16),
  Text(petText(l,'سابقهٔ واکسن شناسنامه','Passport vaccination history','档案疫苗历史'),style:const TextStyle(fontWeight:FontWeight.bold)),
  if(pet.vaccines.isEmpty)Text(petText(l,'واکسن ثبت نشده است.','No vaccinations recorded.','暂无疫苗记录。'),style:const TextStyle(color:AppPal.inkSoft)),
  for(final v in pet.vaccines)ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.vaccines_outlined,color:AppPal.purple),title:Text(v.name),subtitle:Text(v.dateTime==null?'—':formatDate(v.dateTime!,l))),
 ];}
 Widget _info(String title,Object? value)=>Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(color:AppPal.inkSoft,fontSize:12)),const SizedBox(height:4),Text(value==null||value.toString().isEmpty?petText(s.lang,'ثبت نشده','Not recorded','未记录'):value.toString())]));
 List<Widget> _details(Pet pet){final l=s.lang;final h=s.care.health[pet.id]??{};return[
  _info(petText(l,'نام','Name','名字'),pet.name),_info(petText(l,'نوع حیوان','Species','种类'),speciesOf(pet.species).name(l)),_info(petText(l,'سن','Age','年龄'),petAgeText(pet,l)),_info(petText(l,'تاریخ تولد','Birth date','出生日期'),DateTime.tryParse(pet.birth)==null?null:formatDate(DateTime.parse(pet.birth),l)),_info(petText(l,'جنسیت','Sex','性别'),pet.gender=='m'?petText(l,'نر','Male','雄性'):pet.gender=='f'?petText(l,'ماده','Female','雌性'):null),_info(petText(l,'یادداشت','Notes','备注'),pet.notes),const Divider(),
  Text(petText(l,'مخاطب دامپزشک','Vet contact','兽医联系信息'),style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17)),_info(petText(l,'نام کلینیک / دامپزشک','Clinic / vet','诊所 / 兽医'),h['vet_name']),_info(petText(l,'شماره تماس','Phone','电话'),h['vet_phone']),_info(petText(l,'آدرس','Address','地址'),h['vet_address']),
  if((h['vet_phone']?.toString()??'').isNotEmpty)FilledButton.tonalIcon(onPressed:()async{final phone=normalizeDigits(h['vet_phone'].toString()).replaceAll(RegExp(r'[^0-9+]'),'');if(phone.isEmpty)return;try{final ok=await launchUrl(Uri(scheme:'tel',path:phone),mode:LaunchMode.externalApplication);if(!ok&&mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(petText(l,'شماره‌گیر باز نشد.','Could not open dialer.','无法打开拨号器。'))));}catch(_){if(mounted)careError(context,s);}},icon:const Icon(Icons.call_outlined),label:Text(petText(l,'تماس با دامپزشک','Call vet','致电兽医'))),
  OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>HealthForm(s:s,petId:pet.id))),icon:const Icon(Icons.edit_outlined),label:Text(petText(l,'ویرایش اطلاعات دامپزشک','Edit vet contact','编辑兽医信息'))),
 ];}
}

class WeightChart extends StatelessWidget{
 final List<WeightEntry> entries;final bool pounds;final AppLang lang;
 const WeightChart({super.key,required this.entries,required this.pounds,required this.lang});
 @override Widget build(BuildContext context){final sorted=[...entries]..sort((a,b)=>a.date.compareTo(b.date));final values=sorted.map((e)=>pounds?e.kg*poundsPerKg:e.kg).toList();final min=values.reduce(math.min),max=values.reduce(math.max);return Container(margin:const EdgeInsets.symmetric(vertical:14),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFFF5F1FF),borderRadius:BorderRadius.circular(18)),child:Column(children:[Row(children:[Text('${min.toStringAsFixed(2)}–${max.toStringAsFixed(2)} ${pounds?'lb':'kg'}',style:const TextStyle(fontSize:11,color:AppPal.inkSoft)),const Spacer(),Text(petText(lang,'۱۰۰ ثبت اخیر','Latest 100 records','最近 100 条记录'),style:const TextStyle(fontSize:10,color:AppPal.inkSoft))]),Semantics(label:petText(lang,'نمودار تغییرات وزن ثبت‌شده','Recorded weight trend','已记录体重趋势'),child:SizedBox(height:150,width:double.infinity,child:CustomPaint(painter:_WeightPainter(sorted,pounds)))),Row(textDirection:TextDirection.ltr,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(formatDate(sorted.first.date,lang),style:const TextStyle(fontSize:10)),Text(formatDate(sorted.last.date,lang),style:const TextStyle(fontSize:10))]) ]));}
}
class _WeightPainter extends CustomPainter{
 final List<WeightEntry> entries;final bool pounds;_WeightPainter(this.entries,this.pounds);
 @override void paint(Canvas c,Size size){
  if(entries.isEmpty)return;final values=entries.map((e)=>pounds?e.kg*poundsPerKg:e.kg).toList();final lo=values.reduce(math.min),hi=values.reduce(math.max);final span=hi-lo;final range=span==0?1:span*1.2;final low=lo-(span==0 ? 0.5 : span*0.1);final start=entries.first.date.millisecondsSinceEpoch,end=entries.last.date.millisecondsSinceEpoch;
  final area=Rect.fromLTWH(8,12,math.max(1.0,size.width-16),math.max(1.0,size.height-24));final grid=Paint()..color=const Color(0xFFE0D8F4)..strokeWidth=1;
  for(var i=0;i<4;i++){final y=area.top+i*area.height/3;c.drawLine(Offset(area.left,y),Offset(area.right,y),grid);}
  final path=Path();final dots=<Offset>[];
  for(var i=0;i<entries.length;i++){final x=end==start?area.center.dx:area.left+(entries[i].date.millisecondsSinceEpoch-start)/(end-start)*area.width;final y=area.bottom-(values[i]-low)/range*area.height;final point=Offset(x,y);dots.add(point);if(i==0){path.moveTo(x,y);}else{path.lineTo(x,y);}}
  c.drawPath(path,Paint()..color=AppPal.purple..style=PaintingStyle.stroke..strokeWidth=2.5..strokeJoin=StrokeJoin.round);
  for(final dot in dots){c.drawCircle(dot,3,Paint()..color=AppPal.purple);}
 }
 @override bool shouldRepaint(covariant _WeightPainter old)=>true;
}
