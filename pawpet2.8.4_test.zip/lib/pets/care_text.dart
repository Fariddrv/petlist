import '../l10n.dart';
String petText(AppLang l,String fa,String en,String zh)=>l==AppLang.fa?fa:l==AppLang.zh?zh:en;
String careKind(AppLang l,String kind)=>switch(kind){
 'vaccination'=>petText(l,'واکسن','Vaccination','疫苗'),
 'deworming'=>petText(l,'ضدانگل','Parasite care','驱虫'),
 'checkup'=>petText(l,'معاینه','Checkup','体检'),
 'grooming'=>petText(l,'گرومینگ','Grooming','美容'),
 _=>petText(l,'سایر مراقبت‌ها','Other care','其他照护'),
};
