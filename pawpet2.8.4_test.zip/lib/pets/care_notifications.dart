import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../l10n.dart';
import 'care_models.dart';

class CareNotifications {
 final plugin=FlutterLocalNotificationsPlugin();
 bool _ready=false;Future<void> _queue=Future.value();int _generation=0;
 String? pendingUser,pendingPet;
 void Function()? onOpen;
 void _open(String? payload){
  final parts=payload?.split('|');if(parts==null||parts.length!=3||parts[0]!='care')return;
  pendingUser=parts[1];pendingPet=parts[2];onOpen?.call();
 }
 Future<void> initialize()async{
  if(_ready||!Platform.isAndroid)return;
  tzdata.initializeTimeZones();
  await plugin.initialize(const InitializationSettings(android:AndroidInitializationSettings('ic_care')),onDidReceiveNotificationResponse:(r)=>_open(r.payload));
  _ready=true;
  final launch=await plugin.getNotificationAppLaunchDetails();
  if(launch?.didNotificationLaunchApp==true)_open(launch?.notificationResponse?.payload);
 }
 Future<bool> enable()async{
  await initialize();if(!_ready)return false;
  final android=plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
  return await android?.requestNotificationsPermission()??false;
 }
 Future<bool> allowed()async{
  await initialize();if(!_ready)return false;
  return await plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.areNotificationsEnabled()??false;
 }
 Future<void> clear(){
  final gen=++_generation;pendingUser=null;pendingPet=null;
  _queue=_queue.catchError((Object _){}).then((_)async{await initialize();if(gen==_generation&&_ready)await plugin.cancelAll();});return _queue;
 }
 Future<void> sync(String user,List<CareTask> tasks,AppLang lang){
  final gen=++_generation;
  final future=scheduledCare(tasks,DateTime.now());
  _queue=_queue.catchError((Object _){}).then((_)async{
   await initialize();if(gen!=_generation||!_ready)return;
   await plugin.cancelAll();if(gen!=_generation||!await allowed())return;
   var id=6000;
   for(final task in future){
    if(gen!=_generation)return;
    await plugin.zonedSchedule(id++,lang==AppLang.fa?'یادآور مراقبت PawPet':lang==AppLang.zh?'PawPet 照护提醒':'PawPet care reminder',lang==AppLang.fa?'یک مراقبت ثبت‌شده موعد دارد. برای جزئیات اپ را باز کنید.':lang==AppLang.zh?'一项照护任务已到期。请打开应用查看详情。':'A care task is due. Open the app for details.',tz.TZDateTime.from(task.due.toUtc(),tz.UTC),const NotificationDetails(android:AndroidNotificationDetails('pet_care_v1','Pet care reminders',channelDescription:'Reminders entered by the pet owner',importance:Importance.defaultImportance,priority:Priority.defaultPriority,visibility:NotificationVisibility.private)),androidScheduleMode:AndroidScheduleMode.inexactAllowWhileIdle,payload:'care|$user|${task.petId}');
   }
  });return _queue;
 }
 Future<void> test(AppLang lang)async{
  if(!await allowed())throw StateError('notifications disabled');
  await plugin.zonedSchedule(5999,'PawPet',lang==AppLang.fa?'اعلان آزمایشی مراقبت':lang==AppLang.zh?'照护测试通知':'Care reminder test',tz.TZDateTime.now(tz.UTC).add(const Duration(minutes:1)),const NotificationDetails(android:AndroidNotificationDetails('pet_care_v1','Pet care reminders',visibility:NotificationVisibility.private)),androidScheduleMode:AndroidScheduleMode.inexactAllowWhileIdle);
 }
}
