import 'package:flutter/material.dart';
import '../state.dart';
import '../data/jalali.dart';
import '../theme.dart';
import 'care_models.dart';
import 'care_text.dart';

String dayIso(DateTime d)=>'${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
void careError(BuildContext context,AppState s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(petText(s.lang,'ذخیره نشد؛ اتصال و SQL جدید را بررسی کنید. اطلاعات فرم حفظ شده است.','Save failed. Check connection and migration. Your form is preserved.','保存失败，请检查连接和新 SQL。表单内容已保留。'))));

class CareTaskForm extends StatefulWidget{
 final AppState s;final String petId;final CareTask? task;
 const CareTaskForm({super.key,required this.s,required this.petId,this.task});
 @override State<CareTaskForm> createState()=>_CareTaskFormState();
}
class _CareTaskFormState extends State<CareTaskForm>{
 final title=TextEditingController(),notes=TextEditingController();
 late DateTime due;String kind='checkup';bool notify=false,completed=false,busy=false;
 AppState get s=>widget.s;
 @override void initState(){super.initState();final task=widget.task;due=task?.due??DateTime.now().add(const Duration(days:1));if(task!=null){title.text=task.title;notes.text=task.notes;kind=task.kind;notify=task.notify;completed=task.completed;}}
 @override void dispose(){title.dispose();notes.dispose();super.dispose();}
 Future<void> _date()async{final d=await pickDate(context,s.lang,initial:due,firstYear:DateTime.now().year-40,lastYear:DateTime.now().year+10);if(d!=null&&mounted)setState(()=>due=DateTime(d.year,d.month,d.day,due.hour,due.minute));}
 Future<void> _time()async{final t=await showTimePicker(context:context,initialTime:TimeOfDay.fromDateTime(due));if(t!=null&&mounted)setState(()=>due=DateTime(due.year,due.month,due.day,t.hour,t.minute));}
 Future<void> _save()async{
  if(busy||title.text.trim().isEmpty)return;setState(()=>busy=true);
  try{
   if(notify&&!completed){await s.care.notifications.enable();}
   await s.care.saveTask(widget.petId,{'kind':kind,'title':title.text.trim(),'notes':notes.text.trim(),'due_at':due.toUtc().toIso8601String(),'notify':notify,'completed':completed},id:widget.task?.id);
   if(mounted)Navigator.pop(context,true);
  }catch(_){if(mounted){setState(()=>busy=false);careError(context,s);}}
 }
 @override Widget build(BuildContext context){final l=s.lang;return Scaffold(appBar:AppBar(title:Text(petText(l,'ثبت مراقبت','Care task','照护任务'))),body:ListView(padding:const EdgeInsets.all(18),children:[
  Text(petText(l,'زمان و دستور مراقبت را طبق راهنمای دامپزشک ثبت کنید. اپ برنامهٔ درمانی پیشنهاد نمی‌دهد.','Enter the schedule and instructions provided by your vet. The app does not prescribe treatment.','请按兽医指导填写时间和护理要求。应用不会开具治疗方案。'),style:const TextStyle(color:AppPal.inkSoft,fontSize:12)),const SizedBox(height:16),
  DropdownButtonFormField<String>(value:kind,items:[for(final k in ['vaccination','deworming','checkup','grooming','other'])DropdownMenuItem(value:k,child:Text(careKind(l,k)))],onChanged:busy?null:(v)=>setState(()=>kind=v!),decoration:InputDecoration(labelText:petText(l,'نوع مراقبت','Care type','照护类型'))),const SizedBox(height:12),
  TextField(controller:title,maxLength:200,enabled:!busy,onChanged:(_)=>setState((){}),decoration:InputDecoration(labelText:petText(l,'عنوان مراقبت','Task title','任务标题'))),
  ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.calendar_month_outlined,color:AppPal.purple),title:Text(formatDate(due,l)),subtitle:Text(petText(l,'تاریخ مراقبت','Care date','照护日期')),onTap:busy?null:_date),
  ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.schedule,color:AppPal.purple),title:Text(TimeOfDay.fromDateTime(due).format(context)),subtitle:Text(petText(l,'زمان محلی گوشی','Device local time','设备当地时间')),onTap:busy?null:_time),
  TextField(controller:notes,maxLength:2000,minLines:2,maxLines:6,enabled:!busy,decoration:InputDecoration(labelText:petText(l,'یادداشت و دستور دامپزشک','Notes / vet instructions','备注 / 兽医指导'))),
  SwitchListTile(contentPadding:EdgeInsets.zero,value:completed,onChanged:busy?null:(v)=>setState(()=>completed=v),title:Text(petText(l,'انجام شده','Completed','已完成'))),
  SwitchListTile(contentPadding:EdgeInsets.zero,value:notify,onChanged:busy||completed?null:(v)=>setState(()=>notify=v),title:Text(petText(l,'اعلان روی گوشی','Device notification','设备通知'))),
  Text(petText(l,'اعلان به مجوز و تنظیمات باتری گوشی وابسته است و ممکن است با تأخیر برسد. فقط ۵۰ موعد آیندهٔ نزدیک زمان‌بندی می‌شود؛ موعد گذشته اعلان جدید نمی‌گیرد.','Notifications depend on permission and battery settings and may be delayed. Only the nearest 50 future reminders are scheduled; past tasks do not generate new alerts.','通知受权限和电池设置影响，可能延迟。只安排最近的 50 个未来提醒，过去任务不产生新通知。'),style:const TextStyle(fontSize:11,color:AppPal.inkSoft)),const SizedBox(height:16),
  FilledButton(onPressed:busy||title.text.trim().isEmpty?null:_save,child:Text(busy?'…':petText(l,'ذخیره','Save','保存'))),
 ]));}
}

class WeightForm extends StatefulWidget{
 final AppState s;final String petId;final WeightEntry? entry;
 const WeightForm({super.key,required this.s,required this.petId,this.entry});
 @override State<WeightForm> createState()=>_WeightFormState();
}
class _WeightFormState extends State<WeightForm>{
 final weight=TextEditingController(),notes=TextEditingController();late DateTime date;bool busy=false;String? error;
 AppState get s=>widget.s;
 @override void initState(){super.initState();date=widget.entry?.date??DateTime.now();if(widget.entry!=null){weight.text=weightText(widget.entry!.kg,s.care.pounds);notes.text=widget.entry!.notes;}}
 @override void dispose(){weight.dispose();notes.dispose();super.dispose();}
 Future<void> _save()async{
  final value=double.tryParse(normalizeDigits(weight.text));final kg=value==null?null:s.care.pounds?value/poundsPerKg:value;
  if(kg==null||!kg.isFinite||kg<=0||kg>1000||double.parse(kg.toStringAsFixed(3))<=0){setState(()=>error=petText(s.lang,'وزن معتبر وارد کنید؛ حداقل یک گرم و حداکثر ۱۰۰۰ کیلوگرم.','Enter a valid weight between 1 gram and 1000 kg.','请输入 1 克至 1000 千克之间的有效体重。'));return;}
  setState(()=>busy=true);
  try{await s.care.saveWeight(widget.petId,{'weight_kg':kg.toStringAsFixed(3),'measured_on':dayIso(date),'notes':notes.text.trim()},id:widget.entry?.id);if(mounted)Navigator.pop(context,true);}catch(_){if(mounted){setState(()=>busy=false);careError(context,s);}}
 }
 @override Widget build(BuildContext context){final l=s.lang;return Scaffold(appBar:AppBar(title:Text(petText(l,'ثبت وزن','Record weight','记录体重'))),body:ListView(padding:const EdgeInsets.all(18),children:[
  TextField(controller:weight,enabled:!busy,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:petText(l,'وزن','Weight','体重'),suffixText:s.care.pounds?'lb':'kg',errorText:error)),const SizedBox(height:12),
  ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.calendar_month_outlined),title:Text(formatDate(date,l)),onTap:busy?null:()async{final d=await pickDate(context,l,initial:date,firstYear:DateTime.now().year-40,lastYear:DateTime.now().year);if(d!=null&&mounted){if(d.isAfter(DateTime(DateTime.now().year,DateTime.now().month,DateTime.now().day))){setState(()=>error=petText(l,'تاریخ وزن نباید در آینده باشد.','Weight date cannot be in the future.','体重日期不能是未来。'));}else{setState(()=>date=d);}}}),
  TextField(controller:notes,enabled:!busy,maxLength:1000,minLines:2,maxLines:5,decoration:InputDecoration(labelText:petText(l,'یادداشت','Notes','备注'))),const SizedBox(height:16),FilledButton(onPressed:busy?null:_save,child:Text(busy?'…':petText(l,'ذخیره','Save','保存'))),
 ]));}
}

class HealthForm extends StatefulWidget{
 final AppState s;final String petId;
 const HealthForm({super.key,required this.s,required this.petId});
 @override State<HealthForm> createState()=>_HealthFormState();
}
class _HealthFormState extends State<HealthForm>{
 final fields=<String,TextEditingController>{};bool busy=false;
 AppState get s=>widget.s;
 @override void initState(){super.initState();final h=s.care.health[widget.petId]??{};for(final k in ['allergies','conditions','medications','vet_name','vet_phone','vet_address']){fields[k]=TextEditingController(text:h[k]?.toString()??'');}}
 @override void dispose(){for(final c in fields.values){c.dispose();}super.dispose();}
 Future<void> _save()async{setState(()=>busy=true);try{await s.care.saveHealth(widget.petId,{for(final entry in fields.entries)entry.key:entry.value.text.trim()});if(mounted)Navigator.pop(context,true);}catch(_){if(mounted){setState(()=>busy=false);careError(context,s);}}}
 @override Widget build(BuildContext context){final l=s.lang;final labels={'allergies':petText(l,'حساسیت‌ها','Allergies','过敏'),'conditions':petText(l,'بیماری‌های شناخته‌شده','Known conditions','已知疾病'),'medications':petText(l,'دارو و دستور ثبت‌شدهٔ دامپزشک','Medication / recorded vet instructions','药物 / 已记录兽医指导'),'vet_name':petText(l,'نام دامپزشک یا کلینیک','Vet / clinic name','兽医 / 诊所名称'),'vet_phone':petText(l,'شماره تماس دامپزشک','Vet phone','兽医电话'),'vet_address':petText(l,'آدرس دامپزشک','Vet address','兽医地址')};return Scaffold(appBar:AppBar(title:Text(petText(l,'سلامت و دامپزشک','Health and vet','健康与兽医'))),body:ListView(padding:const EdgeInsets.all(18),children:[
  const Icon(Icons.lock_outline,color:AppPal.purple),Text(petText(l,'این اطلاعات فقط برای حساب شما قابل مشاهده است. خالی‌بودن یک قسمت به معنی نبود بیماری یا حساسیت نیست.','Only your account can access this information. An empty field does not mean there is no illness or allergy.','仅你的账号可查看这些信息。空字段并不表示没有疾病或过敏。'),style:const TextStyle(fontSize:12,color:AppPal.inkSoft)),const SizedBox(height:16),
  for(final k in fields.keys)Padding(padding:const EdgeInsets.only(bottom:12),child:TextField(controller:fields[k],enabled:!busy,maxLength:k=='vet_phone'?60:k=='vet_name'?200:k=='vet_address'?1000:4000,minLines:k.startsWith('vet_')?1:2,maxLines:k=='vet_phone'||k=='vet_name'?1:5,keyboardType:k=='vet_phone'?TextInputType.phone:TextInputType.multiline,decoration:InputDecoration(labelText:labels[k]))),
  FilledButton(onPressed:busy?null:_save,child:Text(busy?'…':petText(l,'ذخیره','Save','保存'))),
 ]));}
}
