class CareTask {
 final String id,petId,kind,title,notes;
 final DateTime due;
 final bool notify,completed;
 final DateTime? completedAt;
 CareTask(Map<String,dynamic> r):id=r['id'].toString(),petId=r['pet_id'].toString(),kind=r['kind'].toString(),title=r['title'].toString(),notes=(r['notes']??'').toString(),due=DateTime.parse(r['due_at']).toLocal(),notify=r['notify']==true,completed=r['completed']==true,completedAt=DateTime.tryParse(r['completed_at']?.toString()??'')?.toLocal();
 bool get overdue=>!completed&&due.isBefore(DateTime.now());
}
class WeightEntry {
 final String id,petId,notes;final double kg;final DateTime date;
 WeightEntry(Map<String,dynamic> r):id=r['id'].toString(),petId=r['pet_id'].toString(),notes=(r['notes']??'').toString(),kg=double.parse(r['weight_kg'].toString()),date=DateTime.parse(r['measured_on']);
}
String normalizeDigits(String value){
 const fa='۰۱۲۳۴۵۶۷۸۹',ar='٠١٢٣٤٥٦٧٨٩';var result=value.trim().replaceAll('٫','.');
 for(var i=0;i<10;i++){result=result.replaceAll(fa[i],'$i').replaceAll(ar[i],'$i');}return result;
}
const poundsPerKg=2.2046226218;
String weightText(double kg,bool pounds)=> (pounds?kg*poundsPerKg:kg).toStringAsFixed(3).replaceFirst(RegExp(r'\.?0+$'),'');

List<CareTask> scheduledCare(List<CareTask> tasks,DateTime now){
 final sorted=tasks.where((t)=>t.notify&&!t.completed&&t.due.isAfter(now)).toList()..sort((a,b)=>a.due.compareTo(b.due));
 return sorted.take(50).toList();
}
