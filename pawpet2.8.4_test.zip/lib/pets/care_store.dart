import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../state.dart';
import 'care_models.dart';
import 'care_notifications.dart';

class PetCareStore extends ChangeNotifier {
 final AppState app;PetCareStore(this.app);
 final notifications=CareNotifications();
 SupabaseClient get db=>Supabase.instance.client;
 String? activePet;
 List<CareTask> upcoming=[];
 final Map<String,List<CareTask>> tasks={};
 final Map<String,List<WeightEntry>> weights={};
 final Map<String,Map<String,dynamic>> health={};
 final Set<String> moreCare={},moreWeights={};
 bool loading=false,failed=false,pounds=false,notificationFailed=false,remindersEnabled=false,_disposed=false;
 int _generation=0;
 void changed(){if(!_disposed)notifyListeners();}
 Future<void> load()async{
  final user=app.meId;if(user==null)return;final gen=++_generation;loading=true;changed();
  try{
   final prefs=await SharedPreferences.getInstance();
   // RLS restricts results to this user's pets. No pet data in social profiles.
   final rows=<dynamic>[];
   var offset=0;
   while(true){
    final page=await db.from('pet_care').select().eq('completed',false).order('due_at').order('id').range(offset,offset+199);
    if(_disposed||gen!=_generation||user!=app.meId)return;
    rows.addAll(page);if(page.length<200)break;offset+=page.length;
   }
   if(_disposed||gen!=_generation||user!=app.meId)return;
   upcoming=(rows as List).map((r)=>CareTask(Map<String,dynamic>.from(r))).toList();pounds=prefs.getBool('pet_pounds_$user')??false;failed=false;
   try{await notifications.sync(user,upcoming,app.lang);remindersEnabled=await notifications.allowed();notificationFailed=false;}catch(_){notificationFailed=true;}
  }catch(_){if(gen==_generation)failed=true;}
  if(gen==_generation){if(activePet!=null){try{await loadPet(activePet!);}catch(_){}}loading=false;changed();}
 }
 Future<void> loadPet(String pet)async{
  final user=app.meId,gen=_generation;
  final result=<dynamic>[
   await db.from('pet_health').select().eq('pet_id',pet).limit(1),
   await db.from('pet_care').select().eq('pet_id',pet).order('due_at',ascending:false).order('id').range(0,199),
   await db.from('pet_weights').select().eq('pet_id',pet).order('measured_on',ascending:false).order('id').range(0,199),
  ];
  if(_disposed||user!=app.meId||gen!=_generation)return;
  final h=result[0] as List;health[pet]=h.isEmpty?{}:Map<String,dynamic>.from(h.first);
  tasks[pet]=(result[1] as List).map((r)=>CareTask(Map<String,dynamic>.from(r))).toList();
  weights[pet]=(result[2] as List).map((r)=>WeightEntry(Map<String,dynamic>.from(r))).toList();
  if(tasks[pet]!.length==200){moreCare.add(pet);}else{moreCare.remove(pet);}
  if(weights[pet]!.length==200){moreWeights.add(pet);}else{moreWeights.remove(pet);}changed();
 }
 Future<void> more(String pet,{required bool weight})async{
  final gen=_generation,user=app.meId;final offset=weight?(weights[pet]?.length??0):(tasks[pet]?.length??0);
  final rows=weight?await db.from('pet_weights').select().eq('pet_id',pet).order('measured_on',ascending:false).order('id').range(offset,offset+199):await db.from('pet_care').select().eq('pet_id',pet).order('due_at',ascending:false).order('id').range(offset,offset+199);
  if(gen!=_generation||user!=app.meId||_disposed)return;
  final list=rows as List;
  if(weight){weights.putIfAbsent(pet,()=>[]).addAll(list.map((r)=>WeightEntry(Map<String,dynamic>.from(r))));if(list.length<200)moreWeights.remove(pet);}
  else{tasks.putIfAbsent(pet,()=>[]).addAll(list.map((r)=>CareTask(Map<String,dynamic>.from(r))));if(list.length<200)moreCare.remove(pet);}changed();
 }
 Future<void> setPounds(bool value)async{pounds=value;changed();final user=app.meId;if(user!=null){final prefs=await SharedPreferences.getInstance();await prefs.setBool('pet_pounds_$user',value);}}
 CareTask? next(String pet){final list=upcoming.where((t)=>t.petId==pet).toList();return list.isEmpty?null:list.first;}
 Future<void> _refresh(String pet)async{await load();await loadPet(pet);}
 Future<void> saveTask(String pet,Map<String,dynamic> values,{String? id})async{
  if(id==null){await db.from('pet_care').insert({'pet_id':pet,...values});}else{await db.from('pet_care').update(values).eq('id',id).eq('pet_id',pet);}
  await _refresh(pet);
 }
 Future<void> complete(CareTask task,bool done)async{await db.from('pet_care').update({'completed':done}).eq('id',task.id).eq('pet_id',task.petId);await _refresh(task.petId);}
 Future<void> deleteTask(CareTask task)async{await db.from('pet_care').delete().eq('id',task.id).eq('pet_id',task.petId);await _refresh(task.petId);}
 Future<void> saveWeight(String pet,Map<String,dynamic> values,{String? id})async{
  if(id==null){await db.from('pet_weights').insert({'pet_id':pet,...values});}else{await db.from('pet_weights').update(values).eq('id',id).eq('pet_id',pet);}
  await loadPet(pet);
 }
 Future<void> deleteWeight(WeightEntry entry)async{await db.from('pet_weights').delete().eq('id',entry.id).eq('pet_id',entry.petId);await loadPet(entry.petId);}
 Future<void> saveHealth(String pet,Map<String,dynamic> values)async{
  final exists=await db.from('pet_health').select('pet_id').eq('pet_id',pet).limit(1);
  if((exists as List).isEmpty){await db.from('pet_health').insert({'pet_id':pet,...values});}else{await db.from('pet_health').update(values).eq('pet_id',pet);}
  await loadPet(pet);
 }
 void reset(){_generation++;activePet=null;upcoming=[];tasks.clear();weights.clear();health.clear();moreCare.clear();moreWeights.clear();loading=false;failed=false;pounds=false;remindersEnabled=false;notifications.clear().catchError((Object _){});changed();}
 @override void dispose(){_disposed=true;_generation++;super.dispose();}
}
