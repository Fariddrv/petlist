import 'package:flutter/material.dart';
import '../state.dart';
import '../widgets/avatar.dart';
import '../pages/profile_page.dart';
import 'stories_store.dart';
import 'stories_widgets.dart';

Future<void> openStoryReference(BuildContext context,AppState app,String id)async{
 try{
  final story=await app.stories.find(id);
  if(!context.mounted)return;
  if(story==null){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(storyText(app.lang,'استوری منقضی شده یا اجازهٔ دیدن آن را ندارید.','Story expired or unavailable to you.','动态已过期或你没有查看权限。'))));return;}
  await Navigator.push(context,MaterialPageRoute(builder:(_)=>StoryViewer(app:app,stories:[story])));
 }catch(_){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(storyText(app.lang,'استوری بارگذاری نشد.','Could not load story.','无法加载动态。'))));}
}

class StoryInteractions extends StatefulWidget {
 final AppState app;final PetStory story;final String kind;
 const StoryInteractions({super.key,required this.app,required this.story,required this.kind});
 @override State<StoryInteractions> createState()=>_StoryInteractionsState();
}
class _StoryInteractionsState extends State<StoryInteractions>{
 final text=TextEditingController();
 final List<Map<String,dynamic>> rows=[];
 bool loading=true,failed=false,busy=false,more=false;
 final Set<String> sent={};
 String get kind=>widget.kind;
 AppState get app=>widget.app;
 bool get own=>widget.story.owner==app.meId;
 @override void initState(){super.initState();_load();}
 @override void dispose(){text.dispose();super.dispose();}
 Future<void> _load({bool append=false})async{
  setState(()=>loading=true);
  try{
   List<Map<String,dynamic>> result;
   if(kind=='share'){
    final targets=await app.shareTargets();
    result=targets.map((u)=><String,dynamic>{'user_id':u.id,'username':u.username,'avatar_url':u.avatarUrl}).toList();
   }else if(kind=='comments'){
    result=await app.stories.comments(widget.story.id,append?rows.length:0);
   }else{result=await app.stories.people(widget.story.id,kind,append?rows.length:0);}
   if(!mounted)return;
   setState((){if(!append)rows.clear();rows.addAll(result);more=kind!='share'&&result.length==50;loading=false;failed=false;});
  }catch(_){if(mounted)setState((){loading=false;failed=true;});}
 }
 void _error(){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(storyText(app.lang,'عملیات انجام نشد؛ اتصال، دسترسی یا محدودیت ارسال را بررسی کنید.','Action failed. Check connection, access or sending limits.','操作失败，请检查连接、权限或发送限制。'))));}
 Future<void> _send()async{
  final value=text.text.trim();if(value.isEmpty||busy)return;
  setState(()=>busy=true);
  try{await app.stories.interact(widget.story.id,'comment',text:value);if(!mounted)return;text.clear();await _load();}catch(_){_error();}
  if(mounted)setState(()=>busy=false);
 }
 Future<void> _share(String id)async{
  if(busy||sent.contains(id))return;setState(()=>busy=true);
  try{await app.stories.interact(widget.story.id,'share',recipient:id);if(mounted)setState(()=>sent.add(id));}catch(_){_error();}
  if(mounted)setState(()=>busy=false);
 }
 Future<void> _delete(String id)async{
  final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text(storyText(app.lang,'حذف کامنت؟','Delete comment?','删除评论？')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:Text(storyText(app.lang,'انصراف','Cancel','取消'))),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:Text(storyText(app.lang,'حذف','Delete','删除')))]));
  if(ok!=true||!mounted)return;
  try{await app.stories.deleteComment(id);await _load();}catch(_){_error();}
 }
 Future<void> _profile(String id)async{
  await app.fetchUser(id);if(!mounted||app.userById(id)==null)return;
  await Navigator.push(context,MaterialPageRoute(builder:(_)=>ProfilePage(s:app,userId:id,standalone:true)));
 }
 @override Widget build(BuildContext context){
  final title=kind=='comments'?storyText(app.lang,'کامنت‌های استوری','Story comments','动态评论'):kind=='share'?storyText(app.lang,'ارسال استوری','Send story','发送动态'):kind=='likes'?storyText(app.lang,'لایک‌کنندگان','Liked by','点赞用户'):storyText(app.lang,'بازدیدکنندگان','Viewers','浏览用户');
  return SafeArea(child:Padding(padding:EdgeInsets.only(bottom:MediaQuery.of(context).viewInsets.bottom),child:SizedBox(height:(MediaQuery.sizeOf(context).height-MediaQuery.of(context).viewInsets.bottom)*.68,child:Column(children:[
   Padding(padding:const EdgeInsets.fromLTRB(16,12,8,0),child:Row(children:[Expanded(child:Text(title,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18))),IconButton(onPressed:()=>_load(),icon:const Icon(Icons.refresh)),IconButton(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.close))])),
   Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Text(kind=='comments'?storyText(app.lang,'کامنت فقط برای نویسنده و صاحب استوری دیده می‌شود.','Comments are visible only to their author and the story owner.','评论仅对评论作者和动态发布者可见。'):kind=='share'?storyText(app.lang,'ارسال در پیام‌های PawPet؛ حریم خصوصی و پایان ۲۴ ساعت حفظ می‌شود. هر استوری یک بار برای هر نفر ارسال می‌شود.','Send in PawPet messages. Privacy and 24-hour expiry still apply. Each story can be sent once to each recipient.','通过 PawPet 消息发送，隐私和 24 小时有效期仍适用。每条动态只能向每位收件人发送一次。'):storyText(app.lang,'هر حساب یک بازدید محسوب می‌شود.','Each account counts as one viewer.','每个账号只计为一位浏览者。'),style:const TextStyle(fontSize:11,color:Colors.grey))),
   if(loading)const LinearProgressIndicator(minHeight:2),
   if(failed)TextButton(onPressed:()=>_load(),child:Text(storyText(app.lang,'تلاش دوباره','Retry','重试'))),
   Expanded(child:!loading&&!failed&&rows.isEmpty?Center(child:Text(storyText(app.lang,'هنوز موردی وجود ندارد.','Nothing here yet.','暂无内容。'))):ListView.builder(itemCount:rows.length+(more?1:0),itemBuilder:(ctx,i){
    if(i==rows.length)return TextButton(onPressed:loading?null:()=>_load(append:true),child:Text(storyText(app.lang,'نمایش بیشتر','Load more','加载更多')));
    final r=rows[i],id=r['user_id'].toString();
    return ListTile(leading:GestureDetector(onTap:()=>_profile(id),child:AvatarCircle(url:r['avatar_url']?.toString(),name:r['username']?.toString()??'?',size:42)),title:Text(r['username']?.toString()??'',maxLines:1,overflow:TextOverflow.ellipsis),subtitle:kind=='comments'?Text(r['text'].toString()):null,trailing:kind=='share'?TextButton(onPressed:busy||sent.contains(id)?null:()=>_share(id),child:Text(sent.contains(id)?storyText(app.lang,'ارسال شد','Sent','已发送'):storyText(app.lang,'ارسال','Send','发送'))):kind=='comments'&&(own||id==app.meId)?IconButton(onPressed:()=>_delete(r['id'].toString()),icon:const Icon(Icons.delete_outline,size:20)):null,onTap:()=>_profile(id));
   })),
   if(kind=='comments')Padding(padding:const EdgeInsets.all(12),child:Row(crossAxisAlignment:CrossAxisAlignment.end,children:[Expanded(child:TextField(controller:text,minLines:1,maxLines:3,maxLength:1000,decoration:InputDecoration(hintText:storyText(app.lang,'کامنت بنویسید…','Write a comment…','写评论…'),counterText:''))),IconButton(onPressed:busy?null:_send,icon:busy?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.send))])),
  ]))));
 }
}
