import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../ads/ads_models.dart';
import '../state.dart';

class PetStory {
 final String id, owner, path, name;
 final String? avatar;
 final DateTime expires,created;
 PetStory(Map<String,dynamic> r): id=r['id'].toString(),owner=r['owner_id'].toString(),path=r['file_path'].toString(),expires=DateTime.parse(r['expires_at']),created=DateTime.parse(r['created_at']), name=(r['profiles']?['username']??'').toString(), avatar=r['profiles']?['avatar_url']?.toString();
}
class StoriesStore extends ChangeNotifier {
 final AppState app;
 StoriesStore(this.app);
 final List<PetStory> items=[];
 final Set<String> seen={};
 bool loading=false, failed=false, uploading=false, _disposed=false, hasMore=false, moreLoading=false;
 int _offset=0;
 int _generation=0;
 SupabaseClient get db=>Supabase.instance.client;
 void changed(){if(!_disposed) notifyListeners();}
 List<PetStory> byOwner(String owner)=>items.where((s)=>s.owner==owner&&s.expires.isAfter(DateTime.now().toUtc())).toList()..sort((a,b)=>a.created.compareTo(b.created));
 bool unseen(String owner)=>byOwner(owner).any((s)=>!seen.contains(s.id));
 Future<void> load() async {
  final user=app.meId;if(user==null)return;
  final generation=++_generation;
  loading=true; changed();
  try {
   final prefs=await SharedPreferences.getInstance();
   final rows=await db.from('stories').select('*,profiles!stories_owner_id_fkey(username,avatar_url)').gt('expires_at',DateTime.now().toUtc().toIso8601String()).order('created_at',ascending:false).order('id').range(0,499);
   final result=(rows as List).map((r)=>PetStory(Map<String,dynamic>.from(r))).toList();
   if(_disposed||generation!=_generation||user!=app.meId)return;
   _offset=result.length;hasMore=result.length==500;items..clear()..addAll(result);seen..clear()..addAll(prefs.getStringList('story_seen_$user')??[]);seen.removeWhere((id)=>!items.any((s)=>s.id==id));failed=false;
  }catch(_){if(generation==_generation)failed=true;}
  if(generation==_generation){loading=false;changed();}
 }
 Future<void> loadMore() async {
  if(!hasMore||moreLoading)return;moreLoading=true;changed();final generation=_generation;
  try{final rows=await db.from('stories').select('*,profiles!stories_owner_id_fkey(username,avatar_url)').gt('expires_at',DateTime.now().toUtc().toIso8601String()).order('created_at',ascending:false).order('id').range(_offset,_offset+499);
   if(generation!=_generation||_disposed)return;
   final result=(rows as List).map((r)=>PetStory(Map<String,dynamic>.from(r))).toList();_offset+=result.length;hasMore=result.length==500;for(final story in result){if(!items.any((s)=>s.id==story.id))items.add(story);}
  }catch(_){failed=true;}finally{moreLoading=false;changed();}
 }
 Future<void> loadOwner(String owner)async {
  final generation=_generation, user=app.meId;
  try{final rows=await db.from('stories').select('*,profiles!stories_owner_id_fkey(username,avatar_url)').eq('owner_id',owner).gt('expires_at',DateTime.now().toUtc().toIso8601String()).order('created_at').limit(20);
   if(generation!=_generation||user!=app.meId||_disposed)return;
   items.removeWhere((s)=>s.owner==owner);items.addAll((rows as List).map((r)=>PetStory(Map<String,dynamic>.from(r))));changed();
  }catch(_){}
 }
 Future<void> markSeen(String id) async {
  seen.add(id);changed();final user=app.meId;if(user==null)return;
  final prefs=await SharedPreferences.getInstance();await prefs.setStringList('story_seen_$user',seen.toList());
 }
 Future<PetStory?> find(String id)async {
  final rows=await db.from('stories').select('*,profiles!stories_owner_id_fkey(username,avatar_url)').eq('id',id).gt('expires_at',DateTime.now().toUtc().toIso8601String()).limit(1);
  if((rows as List).isEmpty)return null;
  return PetStory(Map<String,dynamic>.from(rows.first));
 }
 Future<void> interact(String id,String action,{String? text,String? recipient})async {
  await db.rpc('story_interact',params:{'p_story':id,'p_action':action,'p_text':text,'p_recipient':recipient});
 }
 Future<Map<String,dynamic>> summary(String id)async=>Map<String,dynamic>.from(await db.rpc('story_summary',params:{'p_story':id}));
 Future<List<Map<String,dynamic>>> people(String id,String kind,int offset)async {
  final rows=await db.rpc('story_people',params:{'p_story':id,'p_kind':kind,'p_offset':offset});
  return (rows as List).map((r)=>Map<String,dynamic>.from(r)).toList();
 }
 Future<List<Map<String,dynamic>>> comments(String id,int offset)async {
  final rows=await db.rpc('story_comment_list',params:{'p_story':id,'p_offset':offset});
  return (rows as List).map((r)=>Map<String,dynamic>.from(r)).toList();
 }
 Future<void> deleteComment(String id)async {await db.rpc('story_comment_delete',params:{'p_comment':id});}
 Future<String> imageUrl(PetStory story) async {
  final remaining=story.expires.difference(DateTime.now().toUtc()).inSeconds;
  if(remaining<=0)throw StateError('expired');
  return db.storage.from('stories').createSignedUrl(story.path,remaining<60?remaining:60);
 }
 Future<bool> publish(File file) async {
  if(uploading||app.meId==null)return false;
  uploading=true;changed();
  final path='${app.meId}/${requestToken()}.png';bool uploaded=false;
  try {
   if(await file.length()>10*1024*1024)throw StateError('size');
   await db.storage.from('stories').upload(path,file,fileOptions:const FileOptions(contentType:'image/png',upsert:false));uploaded=true;
   await db.from('stories').insert({'owner_id':app.meId,'file_path':path});await load();return true;
  }catch(_){if(uploaded){try{await db.storage.from('stories').remove([path]);}catch(_){}}return false;}
  finally{uploading=false;changed();}
 }
 Future<void> remove(PetStory story) async {
  await db.from('stories').delete().eq('id',story.id);
  items.removeWhere((s)=>s.id==story.id);changed();
  try{await db.storage.from('stories').remove([story.path]);}catch(_){}
 }
 Future<void> report(PetStory story,String reason) async { await db.from('story_reports').upsert({'story_id':story.id,'reporter_id':app.meId,'reason':reason},onConflict:'story_id,reporter_id',ignoreDuplicates:true); }
 void reset(){_generation++;items.clear();seen.clear();loading=false;failed=false;changed();}
 @override void dispose(){_disposed=true;_generation++;super.dispose();}
}
