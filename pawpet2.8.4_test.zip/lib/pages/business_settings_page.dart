import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../state.dart';
import '../stories/stories_widgets.dart';
import '../ads/ads_models.dart';
import '../data/shop_catalog.dart';

class BusinessSettingsPage extends StatefulWidget{
 final AppState s;const BusinessSettingsPage({super.key,required this.s});
 @override State<BusinessSettingsPage> createState()=>_BusinessSettingsPageState();
}
class _BusinessSettingsPageState extends State<BusinessSettingsPage>{
 bool busy=true,failed=false,allowed=false;
 List<Map<String,dynamic>> plans=[],pricing=[],banners=[],reports=[];
 SupabaseClient get db=>Supabase.instance.client;
 String text(String fa,String en,String zh)=>storyText(widget.s.lang,fa,en,zh);
 @override void initState(){super.initState();_load();}
 List<Map<String,dynamic>> rows(dynamic value)=>(value as List).map((r)=>Map<String,dynamic>.from(r)).toList();
 Future<void> _load()async{
 setState(()=>busy=true);
 try{final role=await db.rpc('admin_role');if(role!='owner'&&role!='admin'){if(mounted)setState((){allowed=false;busy=false;});return;}
 final p=await db.from('membership_catalog').select().order('country');final e=await db.from('event_pricing').select().order('country');
 final b=await db.from('banners').select().eq('placement','events').order('sort_order');final r=await db.from('story_reports').select('*,stories(*)').order('created_at',ascending:false).limit(200);
 if(mounted)setState((){plans=rows(p);pricing=rows(e);banners=rows(b);reports=rows(r);allowed=true;busy=false;failed=false;});
 }catch(_){if(mounted)setState((){busy=false;failed=true;});}
 }
 Future<void> _editRule(String table,[Map<String,dynamic>? row])async{
 final plan=table=='membership_catalog';final controllers=<String,TextEditingController>{};
 String country=row?['country']?.toString()??'IR', currency=row?['currency']?.toString()??'IRT',tier=row?['tier']?.toString()??'normal';bool frame=row?['profile_frame']==true;
 final fields=plan?['free_events','monthly_price_minor','boost_discount']:['extra_event_price_minor','boost_price_minor','boost_hours'];
 for(final f in fields){final v=row?[f];controllers[f]=TextEditingController(text:v==null?'':f.contains('price')?moneyToInput((v as num).toInt(),currency):v.toString());}
 String? error;bool saving=false;
 await showDialog<void>(context:context,barrierDismissible:false,builder:(ctx)=>StatefulBuilder(builder:(ctx,setS)=>AlertDialog(title:Text(text('تنظیمات پیش‌نویس','Draft settings','草案设置')),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
 TextFormField(initialValue:country,maxLength:2,enabled:row==null,decoration:InputDecoration(labelText:text('کد کشور (IR/CN/...)','Country code','国家代码')),onChanged:(v)=>country=v.trim().toUpperCase()),
 if(plan)DropdownButtonFormField<String>(value:tier,items:[for(final t in ['normal','supporter','gold'])DropdownMenuItem(value:t,child:Text(t))],onChanged:row==null?(v)=>setS(()=>tier=v!):null),
 DropdownButtonFormField<String>(value:currency,items:[for(final c in ['IRT','CNY','USD','EUR'])DropdownMenuItem(value:c,child:Text(c))],onChanged:(v){setS((){currency=v!;for(final f in fields.where((f)=>f.contains('price')))controllers[f]!.clear();});}),
 for(final f in fields)TextField(controller:controllers[f],keyboardType:TextInputType.number,decoration:InputDecoration(labelText:switch(f){'free_events'=>text('تعداد ایونت رایگان ماهانه','Free events per month','每月免费活动'),'monthly_price_minor'=>text('قیمت اشتراک ماهانه','Monthly subscription price','月费'),'boost_discount'=>text('درصد تخفیف Boost','Boost discount percent','推广折扣百分比'),'extra_event_price_minor'=>text('قیمت هر ایونت اضافه','Extra event price','额外活动价格'),'boost_price_minor'=>text('قیمت Boost','Boost price','推广价格'),_=>text('مدت Boost به ساعت','Boost hours','推广时长（小时）')})),
 if(plan)SwitchListTile(title:Text(text('قاب پروفایل','Profile frame','头像框')),value:frame,onChanged:(v)=>setS(()=>frame=v)),
 if(error!=null)Text(error!),Text(text('پرداخت و اعمال سهمیه هنوز فعال نیست. قیمت خالی یعنی تعیین‌نشده.','Payments and quota enforcement are not enabled. Blank price means unset.','支付和配额限制尚未启用。空白价格表示尚未设定。'),style:const TextStyle(fontSize:11)),
 ])),actions:[TextButton(onPressed:saving?null:()=>Navigator.pop(ctx),child:const Icon(Icons.close)),FilledButton(onPressed:saving?null:()async{
 final data=<String,dynamic>{'country':country,'currency':currency,if(plan)'tier':tier,if(plan)'profile_frame':frame};
 if(!RegExp(r'^[A-Z]{2}$').hasMatch(country)){setS(()=>error=text('کد کشور معتبر نیست.','Invalid country code.','国家代码无效。'));return;}
 for(final f in fields){final input=controllers[f]!.text.trim();final n=f.contains('price')?parseAdPrice(input,currency):int.tryParse(input);if(n==null&&!(f.contains('price')&&input.isEmpty)){setS(()=>error=text('عدد معتبر وارد کنید.','Enter valid numbers.','请输入有效数字。'));return;}data[f]=n;}
 setS(()=>saving=true);try{if(row==null){await db.from(table).upsert(data,onConflict:plan?'country,tier':'country');}else{await db.from(table).update(data).eq('id',row['id']);}if(ctx.mounted)Navigator.pop(ctx);}catch(_){if(ctx.mounted)setS((){saving=false;error=text('ذخیره نشد؛ حدود اعداد را بررسی کنید.','Save failed. Check numeric limits.','保存失败，请检查数字范围。');});}
 },child:Text(text('ذخیره','Save','保存')))])));
 for(final c in controllers.values)c.dispose();await _load();
 }
 Future<void> _banner([Map<String,dynamic>? row])async{
 final image=TextEditingController(text:row?['image_url']??''),link=TextEditingController(text:row?['link_url']??''),country=TextEditingController(text:row?['country']??''),order=TextEditingController(text:'${row?['sort_order']??0}');bool active=row?['active']!=false,saving=false;String? error;
 await showDialog<void>(context:context,barrierDismissible:false,builder:(ctx)=>StatefulBuilder(builder:(ctx,setS)=>AlertDialog(title:Text(text('بنر ایونت‌ها — ارتفاع ۹۶','Event banner — height 96','活动横幅 — 高度 96')),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
 TextField(controller:image,decoration:InputDecoration(labelText:text('URL تصویر HTTPS','HTTPS image URL','HTTPS 图片地址'))),
 TextButton.icon(onPressed:saving?null:()async{try{final picked=await ImagePicker().pickImage(source:ImageSource.gallery,maxWidth:1800,imageQuality:90);if(picked==null)return;setS(()=>saving=true);final url=await widget.s.uploadMedia(picked.path,'event_banners');if(ctx.mounted)setS((){saving=false;if(url!=null)image.text=url;});}catch(_){if(ctx.mounted)setS(()=>saving=false);}},icon:const Icon(Icons.image),label:Text(text('آپلود بنر','Upload banner','上传横幅'))),
 TextField(controller:link,decoration:InputDecoration(labelText:text('لینک مقصد HTTPS','HTTPS destination link','HTTPS 目标链接'))),
 TextField(controller:country,maxLength:2,decoration:InputDecoration(labelText:text('کشور؛ خالی یعنی همه','Country; blank for all','国家；空白表示全部'))),
 TextField(controller:order,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:text('ترتیب نمایش','Display order','显示顺序'))),
 SwitchListTile(title:Text(text('فعال','Active','启用')),value:active,onChanged:(v)=>setS(()=>active=v)),
 if(error!=null)Text(error!),
 ])),actions:[TextButton(onPressed:saving?null:()=>Navigator.pop(ctx),child:const Icon(Icons.close)),FilledButton(onPressed:saving?null:()async{
 if(!validAdDestination('website',image.text.trim())||!validAdDestination('website',link.text.trim())||int.tryParse(order.text)==null||(country.text.isNotEmpty&&!RegExp(r'^[A-Z]{2}$').hasMatch(country.text.trim().toUpperCase()))){setS(()=>error=text('لینک HTTPS و کشور معتبر وارد کنید.','Enter valid HTTPS links and country.','请输入有效的 HTTPS 链接和国家代码。'));return;}
 setS(()=>saving=true);try{final data={'placement':'events','image_url':image.text.trim(),'link_url':link.text.trim(),'country':country.text.trim().isEmpty?null:country.text.trim().toUpperCase(),'sort_order':int.parse(order.text),'active':active};if(row==null){await db.from('banners').insert(data);}else{await db.from('banners').update(data).eq('id',row['id']);}if(ctx.mounted)Navigator.pop(ctx);}catch(_){if(ctx.mounted)setS((){saving=false;error=text('ذخیره نشد.','Save failed.','保存失败。');});}
 },child:Text(text('ذخیره','Save','保存')))])));
 for(final c in [image,link,country,order])c.dispose();await _load();
 }
 Future<void> _reviewReport(Map<String,dynamic> report) async {
  final raw=report['stories'];if(raw==null)return;final story=Map<String,dynamic>.from(raw);
  final url=db.storage.from('stories').createSignedUrl(story['file_path'],60);
  final remove=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text(report['reason']),content:SizedBox(width:320,height:300,child:FutureBuilder<String>(future:url,builder:(ctx,snapshot)=>snapshot.hasData?Image.network(snapshot.data!,fit:BoxFit.contain):snapshot.hasError?const Icon(Icons.broken_image_outlined):const Center(child:CircularProgressIndicator()))),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Icon(Icons.close)),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:Text(text('حذف این استوری','Delete this story','删除此动态')))]));
  if(remove!=true)return;
  try{await db.from('stories').delete().eq('id',report['story_id']);try{await db.storage.from('stories').remove([story['file_path'].toString()]);}catch(_){}await _load();}
  catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text('حذف نشد.','Delete failed.','删除失败。'))));}
 }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(text('تنظیمات کسب‌وکار','Business settings','业务设置'))),body:busy?const Center(child:CircularProgressIndicator()):failed?Center(child:TextButton(onPressed:_load,child:Text(text('تلاش دوباره','Retry','重试')))):!allowed?const Center(child:Icon(Icons.lock_outline)):RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.all(16),children:[
 Text(text('قیمت‌ها و سهمیه‌ها پیش‌نویس‌اند؛ خرید واقعی و محدودیت ایونت فعال نشده است.','Prices and quotas are draft settings; purchases and event limits are not enabled.','价格和配额为草案；购买和活动限制尚未启用。')),
 ExpansionTile(initiallyExpanded:true,title:Text(text('سطوح عضویت','Membership tiers','会员级别')),children:[TextButton(onPressed:()=>_editRule('membership_catalog'),child:const Icon(Icons.add)),for(final p in plans)ListTile(title:Text('${p['country']} · ${p['tier']}'),subtitle:Text('${p['free_events']} · ${p['monthly_price_minor']??"—"} ${p['currency']}'),onTap:()=>_editRule('membership_catalog',p))]),
 ExpansionTile(title:Text(text('قیمت ایونت و Boost','Event and Boost prices','活动和推广价格')),children:[TextButton(onPressed:()=>_editRule('event_pricing'),child:const Icon(Icons.add)),for(final p in pricing)ListTile(title:Text(p['country']),subtitle:Text('${p['extra_event_price_minor']??"—"} / ${p['boost_price_minor']??"—"} ${p['currency']}'),onTap:()=>_editRule('event_pricing',p))]),
 ExpansionTile(title:Text(text('بنرهای ایونت‌ها','Event banners','活动横幅')),children:[TextButton(onPressed:()=>_banner(),child:const Icon(Icons.add)),for(final b in banners)ListTile(title:Text('${b['country']??"All"} · ${b['active']}'),subtitle:Text(b['link_url']??''),onTap:()=>_banner(b))]),
 ExpansionTile(title:Text(text('گزارش استوری‌ها','Story reports','动态举报')),children:[for(final r in reports)ListTile(title:Text(r['reason']),subtitle:Text(r['story_id']),onTap:()=>_reviewReport(r),trailing:const Icon(Icons.chevron_right))]),
 ])));
}
