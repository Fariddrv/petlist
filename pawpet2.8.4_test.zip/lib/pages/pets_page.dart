import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../data/catalog.dart';
import '../data/jalali.dart';
import '../data/media.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets/smart_image.dart';

/// سن از روی تاریخ تولد (سال / ماه)
String petAgeText(Pet p, AppLang l) {
  final b = DateTime.tryParse(p.birth);
  if (b == null) return p.age > 0 ? tr(l, 'ageYears').replaceAll('{n}', '${p.age}') : '';
  final now = DateTime.now();
  var months = (now.year - b.year) * 12 + now.month - b.month;
  if (now.day < b.day) months--;
  if (months < 1) return tr(l, 'ageNewborn');
  if (months < 24) return tr(l, 'ageMonths').replaceAll('{n}', '$months');
  return tr(l, 'ageYears').replaceAll('{n}', '${months ~/ 12}');
}

/// تب «حیوانات من»: فهرست حیوانات؛ با لمس هر کدام، شناسنامه باز می‌شود.
class PetsPage extends StatelessWidget {
  final AppLang lang;
  final List<Pet> pets;
  final ValueChanged<Pet> onAdd;
  final ValueChanged<Pet> onUpdate;
  final ValueChanged<Pet> onRemove;
  const PetsPage({
    super.key,
    required this.lang,
    required this.pets,
    required this.onAdd,
    required this.onUpdate,
    required this.onRemove,
  });

  Future<void> _openForm(BuildContext context, {Pet? pet}) async {
    final res = await Navigator.push<Pet>(
      context,
      MaterialPageRoute(builder: (_) => PetFormPage(lang: lang, pet: pet)),
    );
    if (res == null) return;
    if (pet == null) {
      onAdd(res);
    } else {
      onUpdate(res);
    }
  }

  void _openPassport(BuildContext context, Pet p) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PetPassportPage(
          lang: lang,
          pet: p,
          onEdit: () => _openForm(context, pet: p),
          onDelete: () => onRemove(p),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        FilledButton.icon(
          onPressed: () => _openForm(context),
          icon: const Icon(Icons.add),
          label: Text(tr(lang, 'addPetBtn'),
              style: const TextStyle(fontWeight: FontWeight.w800)),
          style: FilledButton.styleFrom(
            backgroundColor: AppPal.purple,
            minimumSize: const Size.fromHeight(50),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
        ),
        const SizedBox(height: 16),
        if (pets.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Column(children: [
              const Text('🐾', style: TextStyle(fontSize: 48)),
              const SizedBox(height: 10),
              Text(tr(lang, 'petsEmpty'),
                  style: const TextStyle(color: AppPal.inkSoft)),
            ]),
          ),
        for (final p in pets)
          InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () => _openPassport(context, p),
            child: Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(12),
              decoration: AppPal.softCard(),
              child: Row(children: [
                ClipOval(
                  child: SizedBox(
                    width: 64,
                    height: 64,
                    child: SmartImage(
                        src: p.photoPath,
                        fit: BoxFit.cover,
                        fallbackAsset: p.image),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 16)),
                      const SizedBox(height: 4),
                      Text(
                        '${speciesOf(p.species).emoji} ${speciesOf(p.species).name(lang)}'
                        '${petAgeText(p, lang).isEmpty ? '' : ' • ${petAgeText(p, lang)}'}',
                        style: const TextStyle(color: AppPal.inkSoft, fontSize: 13),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, color: AppPal.inkSoft),
              ]),
            ),
          ),
        const SizedBox(height: 4),
        // برای جلوگیری از هشدار استفاده‌نشدن
        if (t.appTitle.isEmpty) const SizedBox(),
      ],
    );
  }
}

// ======================= شناسنامه (نمایش) =======================
class PetPassportPage extends StatelessWidget {
  final AppLang lang;
  final Pet pet;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  const PetPassportPage({
    super.key,
    required this.lang,
    required this.pet,
    required this.onEdit,
    required this.onDelete,
  });

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
              width: 110,
              child: Text(k,
                  style: const TextStyle(
                      color: AppPal.inkSoft, fontWeight: FontWeight.w700))),
          Expanded(child: Text(v.isEmpty ? '—' : v)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(lang);
    final sp = speciesOf(pet.species);
    final b = DateTime.tryParse(pet.birth);
    final gender = pet.gender == 'm'
        ? tr(lang, 'male')
        : pet.gender == 'f'
            ? tr(lang, 'female')
            : '';
    return Scaffold(
      appBar: AppBar(
        title: Text(tr(lang, 'petPassport')),
        actions: [
          IconButton(
            tooltip: tr(lang, 'edit'),
            onPressed: () {
              Navigator.pop(context);
              onEdit();
            },
            icon: const Icon(Icons.edit_outlined),
          ),
          IconButton(
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  content: Text(tr(lang, 'deletePetQ')),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: Text(t.cancel)),
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: Text(t.delete,
                            style: const TextStyle(color: Color(0xFFB3261E)))),
                  ],
                ),
              );
              if (ok == true) {
                onDelete();
                if (context.mounted) Navigator.pop(context);
              }
            },
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Center(
          child: ClipOval(
            child: SizedBox(
              width: 130,
              height: 130,
              child: SmartImage(
                  src: pet.photoPath, fit: BoxFit.cover, fallbackAsset: pet.image),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Center(
          child: Text(pet.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: AppPal.softCard(),
          child: Column(children: [
            _row(tr(lang, 'petSpecies'), '${sp.emoji} ${sp.name(lang)}'),
            _row(tr(lang, 'gender'), gender),
            _row(tr(lang, 'birthDate'),
                b == null ? tr(lang, 'petNoBirth') : formatDate(b, lang)),
            _row(tr(lang, 'age'), petAgeText(pet, lang)),
            if (pet.notes.isNotEmpty) _row(tr(lang, 'petNotes'), pet.notes),
          ]),
        ),
        const SizedBox(height: 16),
        Text(tr(lang, 'vaccines'),
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        const SizedBox(height: 8),
        if (pet.vaccines.isEmpty)
          Text(tr(lang, 'noVaccines'),
              style: const TextStyle(color: AppPal.inkSoft))
        else
          for (final v in pet.vaccines)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: AppPal.softCard(),
              child: Row(children: [
                const Icon(Icons.vaccines_outlined, color: AppPal.purple),
                const SizedBox(width: 10),
                Expanded(
                    child: Text(v.name,
                        style: const TextStyle(fontWeight: FontWeight.w700))),
                Text(v.dateTime == null ? '' : formatDate(v.dateTime!, lang),
                    style: const TextStyle(color: AppPal.inkSoft)),
              ]),
            ),
      ]),
    );
  }
}

// ======================= فرم ساخت / ویرایش =======================
class PetFormPage extends StatefulWidget {
  final AppLang lang;
  final Pet? pet;
  final Future<bool> Function(Pet)? onCommit;
  const PetFormPage({super.key, required this.lang, this.pet, this.onCommit});

  @override
  State<PetFormPage> createState() => _PetFormPageState();
}

class _VaccineRow {
  final TextEditingController name;
  DateTime? date;
  _VaccineRow(String n, this.date) : name = TextEditingController(text: n);
}

class _PetFormPageState extends State<PetFormPage> {
  final _name = TextEditingController();
  final _notes = TextEditingController();
  String _species = 'dog';
  String _gender = '';
  DateTime? _birth;
  String? _photo;
  final List<_VaccineRow> _vaccines = [];
  String? _err;
  bool _busy = false;

  AppLang get l => widget.lang;

  @override
  void initState() {
    super.initState();
    final p = widget.pet;
    if (p != null) {
      _name.text = p.name;
      _notes.text = p.notes;
      _species = p.species;
      _gender = p.gender;
      _birth = DateTime.tryParse(p.birth);
      _photo = p.photoPath;
      for (final v in p.vaccines) {
        _vaccines.add(_VaccineRow(v.name, v.dateTime));
      }
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _notes.dispose();
    for (final v in _vaccines) {
      v.name.dispose();
    }
    super.dispose();
  }

  Future<void> _pickPhoto(ImageSource src) async {
    try {
      final f = await ImagePicker()
          .pickImage(source: src, imageQuality: 85, maxWidth: 1000);
      if (f == null) return;
      final saved = await persistImage(f.path);
      if (mounted) setState(() => _photo = saved);
    } catch (_) {}
  }

  void _photoSheet() {
    final t = L10n.of(l);
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_library_outlined, color: AppPal.purple),
            title: Text(t.gallery),
            onTap: () {
              Navigator.pop(ctx);
              _pickPhoto(ImageSource.gallery);
            },
          ),
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined, color: AppPal.purple),
            title: Text(t.camera),
            onTap: () {
              Navigator.pop(ctx);
              _pickPhoto(ImageSource.camera);
            },
          ),
        ]),
      ),
    );
  }

  Future<void> _chooseSpecies() async {
    final picked = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (ctx) => SizedBox(
        height: MediaQuery.of(ctx).size.height * .7,
        child: Column(children: [
          const SizedBox(height: 14),
          Text(tr(l, 'chooseSpecies'),
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 10),
          Expanded(
            child: GridView.count(
              crossAxisCount: 3,
              padding: const EdgeInsets.all(14),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.05,
              children: [
                for (final sp in speciesList)
                  InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => Navigator.pop(ctx, sp.id),
                    child: Container(
                      decoration: BoxDecoration(
                        color: sp.id == _species
                            ? const Color(0xFFEDE7FF)
                            : const Color(0xFFF3F4F8),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color:
                              sp.id == _species ? AppPal.purple : Colors.transparent,
                          width: 1.5,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(sp.emoji, style: const TextStyle(fontSize: 30)),
                          const SizedBox(height: 4),
                          Text(sp.name(l),
                              textAlign: TextAlign.center,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 12.5, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ]),
      ),
    );
    if (picked != null) setState(() => _species = picked);
  }

  Future<void> _pickBirth() async {
    final d = await pickDate(context, l,
        initial: _birth ?? DateTime.now(),
        firstYear: DateTime.now().year - 40,
        lastYear: DateTime.now().year);
    if (d != null) setState(() => _birth = d);
  }

  Future<void> _pickVaccineDate(_VaccineRow v) async {
    final d = await pickDate(context, l,
        initial: v.date ?? DateTime.now(),
        firstYear: DateTime.now().year - 40,
        lastYear: DateTime.now().year + 5);
    if (d != null) setState(() => v.date = d);
  }

  String _iso(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _save() async {
    if(_busy)return;
    final name = _name.text.trim();
    if (name.isEmpty) {
      setState(() => _err = 'errFill');
      return;
    }
    var age = 0;
    if (_birth != null) {
      final now = DateTime.now();
      age = now.year - _birth!.year;
      if (now.month < _birth!.month ||
          (now.month == _birth!.month && now.day < _birth!.day)) {
        age--;
      }
      if (age < 0) age = 0;
    }
    final vaccines = [
      for (final v in _vaccines)
        if (v.name.text.trim().isNotEmpty)
          PetVaccine(v.name.text.trim(), v.date == null ? '' : _iso(v.date!))
    ];
    final result = Pet(
        id: widget.pet?.id ?? '',
        name: name,
        species: _species,
        age: age,
        gender: _gender,
        birth: _birth == null ? '' : _iso(_birth!),
        notes: _notes.text.trim(),
        vaccines: vaccines,
        photoPath: _photo,
        ownerId: widget.pet?.ownerId ?? '',
      );
    if(widget.onCommit!=null){
      setState(()=>_busy=true);
      final ok=await widget.onCommit!(result);
      if(!mounted)return;
      if(!ok){setState((){_busy=false;_err='errNet';});return;}
    }
    if(mounted)Navigator.pop(context,result);
  }

  @override
  Widget build(BuildContext context) {
    final sp = speciesOf(_species);
    return Scaffold(
      appBar: AppBar(
          title: Text(tr(l, widget.pet == null ? 'addPetBtn' : 'petPassport'))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Center(
          child: GestureDetector(
            onTap: _photoSheet,
            child: Stack(children: [
              ClipOval(
                child: SizedBox(
                  width: 110,
                  height: 110,
                  child: SmartImage(
                      src: _photo,
                      fit: BoxFit.cover,
                      fallbackAsset: 'assets/pets/pet_other.jpg'),
                ),
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.all(7),
                  decoration: const BoxDecoration(
                      color: AppPal.yellow, shape: BoxShape.circle),
                  child: const Icon(Icons.add_a_photo_outlined,
                      size: 16, color: Colors.white),
                ),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 18),
        TextField(
          controller: _name,
          decoration: InputDecoration(labelText: tr(l, 'petName')),
        ),
        const SizedBox(height: 12),
        InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: _chooseSpecies,
          child: InputDecorator(
            decoration: InputDecoration(
              labelText: tr(l, 'petSpecies'),
              suffixIcon: const Icon(Icons.arrow_drop_down),
            ),
            child: Text('${sp.emoji} ${sp.name(l)}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
        ),
        const SizedBox(height: 12),
        InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: _pickBirth,
          child: InputDecorator(
            decoration: InputDecoration(
              labelText: tr(l, 'birthDate'),
              suffixIcon: const Icon(Icons.calendar_month_outlined),
            ),
            child: Text(_birth == null ? tr(l, 'pickDate') : formatDate(_birth!, l),
                style: TextStyle(
                    color: _birth == null ? AppPal.inkSoft : AppPal.ink)),
          ),
        ),
        const SizedBox(height: 14),
        Text(tr(l, 'gender'), style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Wrap(spacing: 10, children: [
          ChoiceChip(
            label: Text(tr(l, 'male')),
            selected: _gender == 'm',
            onSelected: (_) => setState(() => _gender = 'm'),
          ),
          ChoiceChip(
            label: Text(tr(l, 'female')),
            selected: _gender == 'f',
            onSelected: (_) => setState(() => _gender = 'f'),
          ),
        ]),
        const SizedBox(height: 16),
        Text(tr(l, 'vaccines'),
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
        const SizedBox(height: 8),
        for (var i = 0; i < _vaccines.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(children: [
              Expanded(
                flex: 3,
                child: TextField(
                  controller: _vaccines[i].name,
                  decoration: InputDecoration(hintText: tr(l, 'vaccineName')),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                flex: 2,
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => _pickVaccineDate(_vaccines[i]),
                  child: InputDecorator(
                    decoration: const InputDecoration(),
                    child: Text(
                      _vaccines[i].date == null
                          ? tr(l, 'vaccineDate')
                          : formatDate(_vaccines[i].date!, l),
                      style: TextStyle(
                          fontSize: 13,
                          color: _vaccines[i].date == null
                              ? AppPal.inkSoft
                              : AppPal.ink),
                    ),
                  ),
                ),
              ),
              IconButton(
                onPressed: () => setState(() {final row=_vaccines.removeAt(i);row.name.dispose();}),
                icon: const Icon(Icons.close, size: 20),
              ),
            ]),
          ),
        TextButton.icon(
          onPressed: () => setState(() => _vaccines.add(_VaccineRow('', null))),
          icon: const Icon(Icons.add),
          label: Text(tr(l, 'addVaccine')),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _notes,
          minLines: 3,
          maxLines: 8,
          decoration: InputDecoration(labelText: tr(l, 'petNotes')),
        ),
        if (_err != null)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(tr(l, _err!),
                style: const TextStyle(color: Color(0xFFB3261E), fontSize: 13)),
          ),
        const SizedBox(height: 18),
        FilledButton(
          onPressed: _busy ? null : _save,
          style: FilledButton.styleFrom(
            backgroundColor: AppPal.purple,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: Text(_busy ? '…' : tr(l, 'save'),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
      ]),
    );
  }
}
