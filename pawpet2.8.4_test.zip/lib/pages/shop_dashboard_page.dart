import 'package:flutter/material.dart';

import '../data/shop_catalog.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../shop_models.dart';
import '../state.dart';
import '../config.dart';
import '../theme.dart';
import '../widgets/shop_widgets.dart';
import 'listing_form_page.dart';
import 'shop_edit_page.dart';
import 'shop_profile_page.dart';
import 'shop_signup_page.dart';

/// ورودی «فروشگاه من»: اگر فروشگاه ندارد صفحه‌ی ساخت، وگرنه داشبورد.
void openMyShop(BuildContext context, AppState s) {
  if (!kMarketplaceEnabled) return;
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => s.shop.myShop == null
          ? ShopSignupPage(s: s)
          : ShopDashboardPage(s: s),
    ),
  );
}

class ShopDashboardPage extends StatefulWidget {
  final AppState s;
  const ShopDashboardPage({super.key, required this.s});

  @override
  State<ShopDashboardPage> createState() => _ShopDashboardPageState();
}

class _ShopDashboardPageState extends State<ShopDashboardPage> {
  @override
  void initState() {
    super.initState();
    widget.s.shop.loadMyShop();
  }

  Color _statusColor(String st) => switch (st) {
        'approved' => const Color(0xFF2E9E5B),
        'rejected' => const Color(0xFFB3261E),
        'suspended' => const Color(0xFFB3261E),
        _ => const Color(0xFFE08A00),
      };

  Future<void> _confirmDelete(Listing it) async {
    final l = widget.s.lang;
    final t = L10n.of(l);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(tr(l, 'shDeleteConfirm')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(t.cancel)),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(t.delete, style: const TextStyle(color: Color(0xFFB3261E))),
          ),
        ],
      ),
    );
    if (ok == true) await widget.s.shop.deleteListing(it);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return ListenableBuilder(
      listenable: s.shop,
      builder: (c, _) {
        final l = s.lang;
        final sh = s.shop.myShop;
        if (sh == null) {
          return Scaffold(
            appBar: AppBar(title: Text(tr(l, 'shDashboard'))),
            body: const Center(child: CircularProgressIndicator()),
          );
        }
        final stKey = switch (sh.status) {
          'approved' => 'shStatusApproved',
          'rejected' => 'shStatusRejected',
          'suspended' => 'shStatusSuspended',
          _ => 'shStatusPending',
        };
        return Scaffold(
          appBar: AppBar(
            title: Text(tr(l, 'shDashboard')),
            actions: [
              IconButton(
                tooltip: tr(l, 'shViewPublic'),
                icon: const Icon(Icons.visibility_outlined),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => ShopProfilePage(s: s, shopId: sh.id)),
                ),
              ),
            ],
          ),
          body: RefreshIndicator(
            onRefresh: s.shop.loadMyShop,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // ----- سربرگ فروشگاه -----
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: AppPal.softCard(),
                  child: Row(children: [
                    ShopLogo(url: sh.logoUrl, name: sh.name, size: 58),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Flexible(
                              child: Text(sh.name,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w900, fontSize: 17)),
                            ),
                            if (sh.verified) ...[
                              const SizedBox(width: 4),
                              const VerifiedBadge(size: 17),
                            ],
                          ]),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                            decoration: BoxDecoration(
                              color: _statusColor(sh.status).withValues(alpha: .12),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(tr(l, stKey),
                                style: TextStyle(
                                    color: _statusColor(sh.status),
                                    fontWeight: FontWeight.w800,
                                    fontSize: 12)),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.edit_outlined),
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => ShopEditPage(s: s)),
                      ),
                    ),
                  ]),
                ),
                if (sh.status != 'approved')
                  Container(
                    margin: const EdgeInsets.only(top: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF4DC),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tr(l, sh.status == 'pending' ? 'shPendingHelp' : 'shRejectedHelp'),
                          style: const TextStyle(height: 1.6),
                        ),
                        if ((sh.rejectionReason ?? '').isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text('${tr(l, 'shReason')}: ${sh.rejectionReason}',
                                style: const TextStyle(fontWeight: FontWeight.w700)),
                          ),
                        if (sh.status == 'rejected')
                          TextButton(
                            onPressed: s.shop.resubmit,
                            child: Text(tr(l, 'shResubmit')),
                          ),
                      ],
                    ),
                  ),
                const SizedBox(height: 16),

                // ----- مالی و اشتراک (جایگاه مراحل بعد) -----
                Row(children: [
                  Expanded(child: _statCard(Icons.account_balance_wallet_outlined,
                      tr(l, 'shFinance'), '—', tr(l, 'shSoon'))),
                  const SizedBox(width: 12),
                  Expanded(child: _statCard(Icons.workspace_premium_outlined,
                      tr(l, 'shSubscription'), tr(l, 'shTrial'), '')),
                ]),
                const SizedBox(height: 18),

                // ----- محصولات و خدمات من -----
                Row(children: [
                  Expanded(
                    child: Text(tr(l, 'shMyListings'),
                        style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                  ),
                  FilledButton.icon(
                    onPressed: sh.approved
                        ? () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => ListingFormPage(s: s)),
                            )
                        : null,
                    icon: const Icon(Icons.add, size: 18),
                    label: Text(tr(l, 'shAddListing')),
                    style: FilledButton.styleFrom(backgroundColor: AppPal.purple),
                  ),
                ]),
                if (!sh.approved)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(tr(l, 'shNeedApproved'),
                        style: const TextStyle(color: AppPal.inkSoft, fontSize: 12.5)),
                  ),
                const SizedBox(height: 8),
                if (s.shop.myListings.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(30),
                    child: Center(
                        child: Text(tr(l, 'shNoListings'),
                            style: const TextStyle(color: AppPal.inkSoft))),
                  )
                else
                  for (final it in s.shop.myListings)
                    Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(10),
                      decoration: AppPal.softCard(),
                      child: Row(children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: SizedBox(
                            width: 56,
                            height: 56,
                            child: it.images.isEmpty
                                ? Container(
                                    color: AppPal.bg,
                                    alignment: Alignment.center,
                                    child: Text(categoryOf(it.categoryKey)?.emoji ?? '🐾',
                                        style: const TextStyle(fontSize: 26)),
                                  )
                                : ListingThumb(url: it.images.first),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(it.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w800)),
                              Text(formatMoney(it.priceMinor, it.currency, l),
                                  style: const TextStyle(
                                      color: AppPal.purpleDark, fontSize: 12.5)),
                            ],
                          ),
                        ),
                        Switch(
                          value: it.active,
                          activeColor: AppPal.purple,
                          onChanged: (v) => s.shop.setActive(it, v),
                        ),
                        PopupMenuButton<String>(
                          onSelected: (v) {
                            if (v == 'edit') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => ListingFormPage(s: s, item: it)),
                              );
                            } else {
                              _confirmDelete(it);
                            }
                          },
                          itemBuilder: (ctx) => [
                            PopupMenuItem(value: 'edit', child: Text(tr(l, 'shEdit'))),
                            PopupMenuItem(
                                value: 'delete',
                                child: Text(L10n.of(l).delete,
                                    style: const TextStyle(color: Color(0xFFB3261E)))),
                          ],
                        ),
                      ]),
                    ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _statCard(IconData icon, String title, String value, String note) =>
      Container(
        padding: const EdgeInsets.all(14),
        decoration: AppPal.softCard(),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: AppPal.purple),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(color: AppPal.inkSoft, fontSize: 12.5)),
          const SizedBox(height: 2),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
          if (note.isNotEmpty)
            Text(note, style: const TextStyle(color: AppPal.inkSoft, fontSize: 11.5)),
        ]),
      );
}
