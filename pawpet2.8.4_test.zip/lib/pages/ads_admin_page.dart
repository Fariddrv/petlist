import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../state.dart';
import '../ads/ads_store.dart';
import '../ads/ads_models.dart';
import '../ads/ads_text.dart';
import '../widgets/location_fields.dart';
import '../data/places.dart';
import 'business_settings_page.dart';
import '../stories/stories_widgets.dart';
import '../data/shop_catalog.dart';

class AdsAdminPage extends StatefulWidget {
  final AppState s;
  final AdsStore store;
  const AdsAdminPage({super.key, required this.s, required this.store});
  @override
  State<AdsAdminPage> createState() => _AdsAdminPageState();
}

class _AdsAdminPageState extends State<AdsAdminPage> {
  List<Map<String, dynamic>> _ads = [],
      _requests = [],
      _packages = [],
      _events = [];
  bool _loading = true, _failed = false, _allowed = false;
  int _tab = 0;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    try {
      final role = await widget.store.db.rpc('admin_role');
      if (role != 'owner' && role != 'admin') {
        if (mounted)
          setState(() {
            _allowed = false;
            _loading = false;
          });
        return;
      }
      // Await each PostgREST builder explicitly; do not pass heterogeneous
      // builders to Future.wait, whose element type must be Future<T>.
      final results = <dynamic>[
        await widget.store.db
            .from('service_ads')
            .select()
            .order('created_at', ascending: false)
            .limit(500),
        await widget.store.db
            .from('ad_requests')
            .select()
            .order('created_at', ascending: false)
            .limit(200),
        await widget.store.db
            .from('ad_packages')
            .select()
            .order('country')
            .limit(500),
        await widget.store.db.rpc('ad_event_report'),
      ];
      if (!mounted) return;
      List<Map<String, dynamic>> rows(dynamic r) =>
          (r as List).map((v) => Map<String, dynamic>.from(v)).toList();
      setState(() {
        _allowed = true;
        _ads = rows(results[0]);
        _requests = rows(results[1]);
        _packages = rows(results[2]);
        _events = rows(results[3]);
      });
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _editAd([Map<String, dynamic>? row]) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _AdEditor(s: widget.s, store: widget.store, row: row),
      ),
    );
    await _load();
  }

  Future<void> _editPackage([Map<String, dynamic>? row]) async {
    final l = widget.s.lang;
    final price = TextEditingController(
          text: row?['price_minor'] == null ? '' : moneyToInput((row!['price_minor'] as num).toInt(), row!['currency']),
        ),
        currency = TextEditingController(
          text: row?['currency']?.toString() ?? 'USD',
        ),
        days = TextEditingController(
          text: row?['duration_days']?.toString() ?? '30',
        );
    String country =
            row?['country']?.toString() ??
            (widget.store.country.isEmpty ? 'IR' : widget.store.country),
        tier = row?['tier']?.toString() ?? 'basic';
    bool feed = row?['feed_placement'] == true,
        active = row?['active'] != false,
        busy = false;
    String? error;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text(adText(l, 'packages')),
          content: SizedBox(
            width: 480,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<String>(
                    value: country,
                    isExpanded: true,
                    items: [
                      for (final c in countries)
                        DropdownMenuItem(value: c.key, child: Text(c.name(l))),
                    ],
                    onChanged: row != null || busy
                        ? null
                        : (v) => setS(() => country = v!),
                  ),
                  DropdownButtonFormField<String>(
                    value: tier,
                    items: [
                      for (final t in ['basic', 'premium', 'featured', 'event_banner'])
                        DropdownMenuItem(value: t, child: Text(t == 'event_banner' ? storyText(l,'بنر ایونت‌ها','Event banner','活动横幅') : t == 'featured' ? storyText(l,'بنر ویژه خدمات','Services featured banner','服务精选横幅') : t)),
                    ],
                    onChanged: row != null || busy
                        ? null
                        : (v) => setS(() {
                            tier = v!;
                            if (tier == 'basic') feed = false;
                          }),
                  ),
                  TextField(
                    controller: price,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: adText(l, 'price')),
                  ),
                  DropdownButtonFormField<String>(
                    value: currency.text,
                    isExpanded: true,
                    decoration: InputDecoration(labelText: adText(l, 'currency')),
                    items: [for (final c in currencies) DropdownMenuItem(value: c.code, child: Text(c.name(l)))],
                    onChanged: busy ? null : (v) => setS(() => currency.text = v!),
                  ),
                  TextField(
                    controller: days,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: adText(l, 'duration'),
                    ),
                  ),
                  SwitchListTile(
                    title: Text(adText(l, 'feed')),
                    value: feed,
                    onChanged: busy || tier == 'basic'
                        ? null
                        : (v) => setS(() => feed = v),
                  ),
                  SwitchListTile(
                    title: Text(adText(l, 'active')),
                    value: active,
                    onChanged: busy ? null : (v) => setS(() => active = v),
                  ),
                  if (error != null)
                    Text(error!, style: const TextStyle(color: Colors.red)),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: busy ? null : () => Navigator.pop(ctx),
              child: Text(adText(l, 'cancel')),
            ),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      final p = price.text.trim().isEmpty
                          ? null
                          : parseAdPrice(price.text, currency.text);
                      final d = int.tryParse(days.text);
                      final c = currency.text.trim().toUpperCase();
                      if ((price.text.trim().isNotEmpty &&
                              (p == null || p < 0)) ||
                          d == null ||
                          d < 1 ||
                          d > 366 ||
                          !currencies.any((currency) => currency.code == c)) {
                        setS(() => error = adText(l, 'required'));
                        return;
                      }
                      setS(() => busy = true);
                      try {
                        final data = {
                          'country': country,
                          'tier': tier,
                          'price_minor': p,
                          'currency': c,
                          'duration_days': d,
                          'feed_placement': feed,
                          'active': active,
                        };
                        if (row == null) {
                          await widget.store.db
                              .from('ad_packages')
                              .upsert(data, onConflict: 'country,tier');
                        } else {
                          await widget.store.db
                              .from('ad_packages')
                              .update(data)
                              .eq('id', row['id']);
                        }
                        if (ctx.mounted) Navigator.pop(ctx);
                      } catch (_) {
                        if (ctx.mounted)
                          setS(() {
                            error = adText(l, 'failed');
                            busy = false;
                          });
                      }
                    },
              child: Text(adText(l, 'save')),
            ),
          ],
        ),
      ),
    );
    price.dispose();
    currency.dispose();
    days.dispose();
    await _load();
  }

  Future<void> _review(Map<String, dynamic> r) async {
    final l = widget.s.lang;
    var status = r['status'].toString();
    final notes = TextEditingController(text: r['admin_notes'].toString());
    bool busy = false;
    String? error;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text(r['brand']),
          content: SizedBox(
            width: 480,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SelectableText(
                    '${r['contact_name']}\n${adText(l, r['contact_channel'])}: ${r['contact_value']}\n${countryName(r['country'], l)} | ${cityName(r['country'], r['city'], l)}\n${r['destination']}\n${r['description']}\n${r['package_snapshot']['tier']} · ${r['package_snapshot']['price_minor'] == null ? adText(l, 'quote') : formatMoney((r['package_snapshot']['price_minor'] as num).toInt(), r['package_snapshot']['currency'], l)} · ${r['package_snapshot']['duration_days']} ${adText(l, 'days')}\n${r['id']}',
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: status,
                    items: [
                      for (final k in [
                        'new',
                        'reviewing',
                        'awaiting_payment',
                        'paid',
                        'published',
                        'rejected',
                      ])
                        DropdownMenuItem(value: k, child: Text(adText(l, k))),
                    ],
                    onChanged: busy ? null : (v) => setS(() => status = v!),
                  ),
                  TextField(
                    controller: notes,
                    maxLength: 3000,
                    maxLines: 3,
                    decoration: InputDecoration(labelText: adText(l, 'notes')),
                  ),
                  if (error != null) Text(error!),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: busy ? null : () => Navigator.pop(ctx),
              child: Text(adText(l, 'cancel')),
            ),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      setS(() => busy = true);
                      try {
                        await widget.store.db
                            .from('ad_requests')
                            .update({
                              'status': status,
                              'admin_notes': notes.text,
                            })
                            .eq('id', r['id']);
                        if (ctx.mounted) Navigator.pop(ctx);
                      } catch (_) {
                        if (ctx.mounted)
                          setS(() {
                            busy = false;
                            error = adText(l, 'failed');
                          });
                      }
                    },
              child: Text(adText(l, 'save')),
            ),
          ],
        ),
      ),
    );
    notes.dispose();
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(
        title: Text(adText(l, 'manage')),
        actions: [
          IconButton(tooltip: storyText(l,'تنظیمات کسب‌وکار و استوری','Business and stories','业务与动态'), onPressed: () => Navigator.push(context,MaterialPageRoute(builder: (_) => BusinessSettingsPage(s:widget.s))), icon: const Icon(Icons.tune)),
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _failed
          ? Center(
              child: TextButton(
                onPressed: _load,
                child: Text(adText(l, 'retry')),
              ),
            )
          : !_allowed
          ? const Center(child: Icon(Icons.lock_outline))
          : Column(
              children: [
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: SegmentedButton<int>(
                  segments: [
                    ButtonSegment(value: 0, label: Text(adText(l, 'requests'))),
                    ButtonSegment(value: 1, label: Text(adText(l, 'ads'))),
                    ButtonSegment(value: 2, label: Text(adText(l, 'packages'))),
                  ],
                  selected: {_tab},
                  onSelectionChanged: (v) => setState(() => _tab = v.first),
                  ),
                ),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.all(12),
                    children: [
                      if (_tab == 0)
                        for (final r in _requests)
                          Card(
                            child: ListTile(
                              title: Text(r['brand']),
                              subtitle: Text(
                                '${adText(l, r['status'])} · ${r['country']} | ${r['city']}',
                              ),
                              onTap: () => _review(r),
                            ),
                          ),
                      if (_tab == 1) ...[
                        FilledButton.icon(
                          onPressed: () => _editAd(),
                          icon: const Icon(Icons.add),
                          label: Text(adText(l, 'newAd')),
                        ),
                        for (final a in _ads)
                          Card(
                            child: ListTile(
                              title: Text(a['brand']),
                              subtitle: Text(
                                '${a['country']} | ${a['city']} · ${a['tier']} · ${a['active']}\n${adText(l, 'stats')}: ${_count(a['id'], 'view')} / ${_count(a['id'], 'click')}',
                              ),
                              onTap: () => _editAd(a),
                            ),
                          ),
                      ],
                      if (_tab == 2) ...[
                        FilledButton.icon(
                          onPressed: () => _editPackage(),
                          icon: const Icon(Icons.add),
                          label: Text(adText(l, 'newPackage')),
                        ),
                        for (final p in _packages)
                          Card(
                            child: ListTile(
                              title: Text('${p['country']} · ${p['tier'] == 'event_banner' ? storyText(l,'بنر ایونت‌ها','Event banner','活动横幅') : p['tier']}'),
                              subtitle: Text(
                                p['price_minor'] == null
                                    ? adText(l, 'quote')
                                    : formatMoney(
                                        (p['price_minor'] as num).toInt(),
                                        p['currency'],
                                        l,
                                      ),
                              ),
                              onTap: () => _editPackage(p),
                            ),
                          ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  int _count(dynamic id, String kind) {
    var n = 0;
    for (final e in _events) {
      if (e['ad_id'] == id && e['kind'] == kind)
        n += (e['count'] as num).toInt();
    }
    return n;
  }
}

class _AdEditor extends StatefulWidget {
  final AppState s;
  final AdsStore store;
  final Map<String, dynamic>? row;
  const _AdEditor({required this.s, required this.store, this.row});
  @override
  State<_AdEditor> createState() => _AdEditorState();
}

class _AdEditorState extends State<_AdEditor> {
  final _form = GlobalKey<FormState>();
  final _brand = TextEditingController(),
      _image = TextEditingController(),
      _destination = TextEditingController(),
      _priority = TextEditingController(),
      _start = TextEditingController(),
      _end = TextEditingController(),
      _rating = TextEditingController(),
      _ratingSource = TextEditingController();
  final _desc = {
    for (final l in ['fa', 'en', 'zh']) l: TextEditingController(),
  };
  late String _country, _city, _category, _tier, _type;
  bool _active = false, _feed = false, _busy = false;
  final _badges = <String>{};
  String? _imagePath;
  @override
  void initState() {
    super.initState();
    final r = widget.row ?? {};
    _country = (r['country'] ?? widget.store.country).toString();
    _city = (r['city'] ?? widget.store.city).toString();
    _category = (r['category'] ?? 'vet').toString();
    _tier = (r['tier'] ?? 'basic').toString();
    _type = (r['destination_type'] ?? 'website').toString();
    _active = r['active'] == true;
    _feed = r['show_in_feed'] == true;
    _badges.addAll(List<String>.from(r['badges'] ?? []));
    _brand.text = (r['brand'] ?? '').toString();
    _image.text = (r['image_url'] ?? '').toString();
    _destination.text = (r['destination'] ?? '').toString();
    _priority.text = (r['priority'] ?? 0).toString();
    _start.text = (r['starts_at'] ?? DateTime.now().toUtc().toIso8601String())
        .toString();
    _end.text =
        (r['ends_at'] ??
                DateTime.now()
                    .toUtc()
                    .add(const Duration(days: 30))
                    .toIso8601String())
            .toString();
    _rating.text = (r['rating'] ?? '').toString();
    _ratingSource.text = (r['rating_source'] ?? '').toString();
    for (final l in _desc.keys) {
      _desc[l]!.text = (r['description']?[l] ?? '').toString();
    }
  }

  @override
  void dispose() {
    for (final c in [
      _brand,
      _image,
      _destination,
      _priority,
      _start,
      _end,
      _rating,
      _ratingSource,
      ..._desc.values,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Widget _field(
    TextEditingController c,
    String label, {
    bool required = false,
    int lines = 1,
    int max = 2000,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextFormField(
      controller: c,
      maxLines: lines,
      maxLength: max,
      decoration: InputDecoration(labelText: label),
      validator: (v) => required && (v ?? '').trim().isEmpty
          ? adText(widget.s.lang, 'required')
          : null,
    ),
  );
  Widget _dateField(TextEditingController c, String key) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: InkWell(
      onTap: () async {
        final current = DateTime.tryParse(c.text)?.toLocal() ?? DateTime.now();
        final date = await showDatePicker(context: context, initialDate: current,
          firstDate: DateTime(2020), lastDate: DateTime(2100));
        if (date == null || !mounted) return;
        final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(current));
        if (time == null || !mounted) return;
        setState(() => c.text = DateTime(date.year, date.month, date.day, time.hour, time.minute).toUtc().toIso8601String());
      },
      child: InputDecorator(decoration: InputDecoration(labelText: adText(widget.s.lang, key), suffixIcon: const Icon(Icons.calendar_month)),
        child: Text((DateTime.tryParse(c.text)?.toLocal().toString() ?? c.text).substring(0, 16))),
    ),
  );

  Future<void> _save() async {
    final l = widget.s.lang;
    if (!_form.currentState!.validate()) return;
    final start = DateTime.tryParse(_start.text),
        end = DateTime.tryParse(_end.text),
        priority = int.tryParse(_priority.text);
    final rating = _rating.text.trim().isEmpty
        ? null
        : double.tryParse(_rating.text);
    if (_country.isEmpty ||
        _city.trim().isEmpty ||
        start == null ||
        end == null ||
        !end.isAfter(start) ||
        priority == null ||
        priority < 0 ||
        priority > 10000 ||
        !validAdDestination(_type, _destination.text.trim()) ||
        (_rating.text.trim().isNotEmpty &&
            (rating == null || rating < 0 || rating > 5)) ||
        (rating != null && _ratingSource.text.trim().isEmpty) ||
        (_badges.contains('top_rated') && rating == null)) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(adText(l, 'required'))));
      return;
    }
    setState(() => _busy = true);
    try {
      if (_imagePath != null) {
        final uploaded = await widget.s.uploadMedia(_imagePath, 'service_ads');
        if (uploaded == null) throw StateError('image upload failed');
        _image.text = uploaded;
        _imagePath = null;
      }
      if (!validAdDestination('website', _image.text.trim()))
        throw StateError('invalid image');
      final data = <String, dynamic>{
        'brand': _brand.text.trim(),
        'image_url': _image.text.trim(),
        'description': {
          for (final e in _desc.entries) e.key: e.value.text.trim(),
        },
        'country': _country,
        'city': _city.trim(),
        'category': _category,
        'tier': _tier,
        'priority': priority,
        'destination_type': _type,
        'destination': _destination.text.trim(),
        'active': _active,
        'show_in_feed': _feed && _tier != 'basic',
        'starts_at': start.toUtc().toIso8601String(),
        'ends_at': end.toUtc().toIso8601String(),
        'badges': _badges.toList(),
        'rating': rating,
        'rating_source': rating == null ? null : _ratingSource.text.trim(),
      };
      if (widget.row == null) {
        await widget.store.db.from('service_ads').insert(data);
      } else {
        await widget.store.db
            .from('service_ads')
            .update(data)
            .eq('id', widget.row!['id']);
      }
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(adText(l, 'failed'))));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(adText(l, 'ads'))),
      body: AbsorbPointer(
        absorbing: _busy,
        child: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _field(_brand, adText(l, 'brand'), required: true, max: 120),
              OutlinedButton.icon(
                onPressed: () async {
                  final image = await ImagePicker().pickImage(
                    source: ImageSource.gallery,
                    imageQuality: 85,
                    maxWidth: 1800,
                  );
                  if (image != null && mounted)
                    setState(() => _imagePath = image.path);
                },
                icon: const Icon(Icons.image_outlined),
                label: Text(
                  _imagePath == null
                      ? adText(l, 'image')
                      : '✓ ${adText(l, 'image')}',
                ),
              ),
              _field(_image, 'HTTPS ${adText(l, 'image')}'),
              for (final code in _desc.keys)
                _field(
                  _desc[code]!,
                  '${adText(l, 'description')} ($code)',
                  lines: 3,
                  max: 1000,
                ),
              LocationFields(
                lang: l,
                country: _country,
                city: _city,
                onChanged: (c, t) => setState(() {
                  _country = c;
                  _city = t;
                }),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _category,
                items: [
                  for (final c in adCategories)
                    DropdownMenuItem(value: c, child: Text(adText(l, c))),
                ],
                onChanged: (v) => setState(() => _category = v!),
              ),
              DropdownButtonFormField<String>(
                value: _tier,
                items: [
                  for (final t in ['basic', 'premium', 'featured'])
                    DropdownMenuItem(value: t, child: Text(t)),
                ],
                onChanged: (v) => setState(() {
                  _tier = v!;
                  if (_tier == 'basic') _feed = false;
                }),
              ),
              _field(_priority, adText(l, 'priority'), required: true),
              DropdownButtonFormField<String>(
                value: _type,
                isExpanded: true,
                items: [
                  for (final t in adDestinations)
                    DropdownMenuItem(
                      value: t,
                      child: Text(adText(l, t == 'other' ? 'open' : t)),
                    ),
                ],
                onChanged: (v) => setState(() => _type = v!),
              ),
              _field(_destination, adText(l, 'destination'), required: true),
              _dateField(_start, 'start'),
              _dateField(_end, 'end'),
              for (final b in ['local', 'promotion', 'top_rated'])
                CheckboxListTile(
                  title: Text(adText(l, b)),
                  value: _badges.contains(b),
                  onChanged: (v) => setState(() {
                    if (v == true) {
                      _badges.add(b);
                    } else {
                      _badges.remove(b);
                    }
                  }),
                ),
              _field(_rating, '★ 0–5'),
              _field(_ratingSource, adText(l, 'ratingSource'), max: 200),
              SwitchListTile(
                title: Text(adText(l, 'feed')),
                value: _feed,
                onChanged: _tier == 'basic'
                    ? null
                    : (v) => setState(() => _feed = v),
              ),
              SwitchListTile(
                title: Text(adText(l, 'active')),
                value: _active,
                onChanged: (v) => setState(() => _active = v),
              ),
              FilledButton(
                onPressed: _busy ? null : _save,
                child: _busy
                    ? const CircularProgressIndicator()
                    : Text(adText(l, 'save')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
