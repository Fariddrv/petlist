import 'package:flutter/material.dart';
import '../state.dart';
import '../ads/ads_store.dart';
import '../stories/stories_widgets.dart';
import '../ads/ads_models.dart';
import '../ads/ads_text.dart';
import '../widgets/location_fields.dart';
import '../data/shop_catalog.dart';

class AdRequestPage extends StatefulWidget {
  final AppState s;
  final AdsStore store;
  const AdRequestPage({super.key, required this.s, required this.store});
  @override
  State<AdRequestPage> createState() => _AdRequestPageState();
}

class _AdRequestPageState extends State<AdRequestPage> {
  final _form = GlobalKey<FormState>();
  final _brand = TextEditingController(),
      _name = TextEditingController(),
      _contact = TextEditingController(),
      _destination = TextEditingController(),
      _description = TextEditingController();
  late String _country = widget.store.country, _city = widget.store.city;
  String _category = 'vet', _channel = 'whatsapp', _type = 'website';
  final _token = requestToken();
  String? _package;
  List<Map<String, dynamic>> _packages = [];
  bool _accepted = false, _sending = false, _loading = false, _failed = false;
  int _generation = 0;
  @override
  void initState() {
    super.initState();
    _loadPackages();
  }

  @override
  void dispose() {
    for (final c in [_brand, _name, _contact, _destination, _description]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _loadPackages() async {
    final g = ++_generation;
    setState(() {
      _loading = true;
      _failed = false;
      _package = null;
      _packages = [];
    });
    try {
      final rows = await widget.store.packages(_country);
      if (!mounted || g != _generation) return;
      setState(() => _packages = rows);
    } catch (_) {
      if (mounted && g == _generation) setState(() => _failed = true);
    }
    if (mounted && g == _generation) setState(() => _loading = false);
  }

  Widget _field(
    TextEditingController c,
    String key, {
    int max = 120,
    int lines = 1,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextFormField(
      controller: c,
      maxLength: max,
      maxLines: lines,
      decoration: InputDecoration(labelText: adText(widget.s.lang, key)),
      validator: (v) =>
          (v ?? '').trim().isEmpty ? adText(widget.s.lang, 'required') : null,
    ),
  );
  Future<void> _send() async {
    if (!_form.currentState!.validate() ||
        !_accepted ||
        _package == null ||
        _country.isEmpty ||
        _city.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(adText(widget.s.lang, 'required'))),
      );
      return;
    }
    if (!validAdDestination(_type, _destination.text.trim())) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(adText(widget.s.lang, 'badLink'))));
      return;
    }
    setState(() => _sending = true);
    try {
      final id = await widget.store.db.rpc(
        'submit_ad_request',
        params: {
          'p_token': _token,
          'p_data': {
            'brand': _brand.text.trim(),
            'contact_name': _name.text.trim(),
            'contact_channel': _channel,
            'contact_value': _contact.text.trim(),
            'country': _country,
            'city': _city.trim(),
            'category': _category,
            'package_id': _package,
            'destination_type': _type,
            'destination': _destination.text.trim(),
            'description': _description.text.trim(),
            'accepted': true,
            'terms_version': 'ads-2.8.0',
          },
        },
      );
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          content: SelectableText('${adText(widget.s.lang, 'sent')}\n$id'),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(adText(widget.s.lang, 'open')),
            ),
          ],
        ),
      );
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(adText(widget.s.lang, 'failed'))),
        );
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.s.lang;
    return Scaffold(
      appBar: AppBar(title: Text(adText(l, 'rules'))),
      body: AbsorbPointer(
        absorbing: _sending,
        child: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    adText(l, 'terms'),
                    style: const TextStyle(height: 1.7),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              _field(_brand, 'brand'),
              _field(_name, 'contactName'),
              DropdownButtonFormField<String>(
                value: _channel,
                decoration: InputDecoration(
                  labelText: adText(l, 'contactChannel'),
                ),
                items: [
                  for (final k in [
                    'whatsapp',
                    'telegram',
                    'wechat',
                    'email',
                    'phone',
                  ])
                    DropdownMenuItem(value: k, child: Text(adText(l, k))),
                ],
                onChanged: (v) => setState(() => _channel = v!),
              ),
              const SizedBox(height: 12),
              _field(_contact, 'contactValue', max: 200),
              LocationFields(
                lang: l,
                country: _country,
                city: _city,
                onChanged: (c, t) {
                  final changed = c != _country;
                  setState(() {
                    _country = c;
                    _city = t;
                  });
                  if (changed) _loadPackages();
                },
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                value: _category,
                items: [
                  for (final k in adCategories)
                    DropdownMenuItem(value: k, child: Text(adText(l, k))),
                ],
                onChanged: (v) => setState(() => _category = v!),
              ),
              const SizedBox(height: 14),
              Text(
                adText(l, 'package'),
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (_loading) const LinearProgressIndicator(),
              if (_failed)
                TextButton(
                  onPressed: _loadPackages,
                  child: Text(adText(l, 'retry')),
                ),
              if (!_loading && !_failed && _packages.isEmpty)
                Text(adText(l, 'noPackages')),
              for (final p in _packages)
                RadioListTile<String>(
                  value: p['id'].toString(),
                  groupValue: _package,
                  onChanged: (v) => setState(() => _package = v),
                  title: Text(
                    p['tier'] == 'event_banner' ? storyText(l,'بنر بالای ایونت‌ها','Events header banner','活动顶部横幅') : adText(
                      l,
                      p['tier'] == 'featured' ? 'featuredPackage' : p['tier'],
                    ),
                  ),
                  subtitle: Text(
                    '${p['price_minor'] == null ? adText(l, 'quote') : formatMoney((p['price_minor'] as num).toInt(), p['currency'], l)} · ${p['duration_days']} ${adText(l, 'days')}${p['feed_placement'] == true ? '\n${adText(l, 'feed')}' : ''}',
                  ),
                ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _type,
                isExpanded: true,
                decoration: InputDecoration(labelText: adText(l, 'cta')),
                items: [
                  for (final k in adDestinations)
                    DropdownMenuItem(
                      value: k,
                      child: Text(adText(l, k == 'other' ? 'open' : k)),
                    ),
                ],
                onChanged: (v) => setState(() => _type = v!),
              ),
              const SizedBox(height: 12),
              _field(_destination, 'destination', max: 2000),
              _field(_description, 'description', max: 3000, lines: 4),
              CheckboxListTile(
                value: _accepted,
                onChanged: (v) => setState(() => _accepted = v ?? false),
                title: Text(adText(l, 'accept')),
              ),
              FilledButton.icon(
                onPressed: _sending ? null : _send,
                icon: _sending
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.send),
                label: Text(adText(l, 'send')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
