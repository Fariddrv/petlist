import 'dart:io';
import 'package:flutter/material.dart';
import '../l10n.dart';
import '../stories/stories_widgets.dart';
import '../models.dart';
import '../theme.dart';
import '../ads/ads_store.dart';
import '../ads/ads_widgets.dart';
import '../widgets/avatar.dart';
import '../widgets/smart_image.dart';
import '../widgets/image_viewer.dart';
import '../widgets/post_media.dart';
import '../data/timeago.dart';
import '../i18n2.dart';

typedef OnComment = void Function(String postId, String text);
typedef OnShare = void Function(String postId, String author, String text);

/// تب خانه: فیدِ پست‌ها (نمونه + پست‌های خود کاربر) با
/// لایک، نظر، ذخیره و اشتراک‌گذاری — شبیه اینستاگرام.
class HomePage extends StatefulWidget {
  final AppLang lang;
  final AdsStore? adsStore;
  final List<UserPost> userPosts;
  final Map<String, PostInter> interactions;
  final bool showSaved;
  final String meId;
  final Set<String> hiddenOwners;
  final ValueChanged<String>? onOpenUser;
  final Future<void> Function()? onRefresh;
  final String errorText;
  final VoidCallback? onSearch;
  final ValueChanged<String>? onOpenPost;
  final ValueChanged<String>? onOpenComments;
  final ValueChanged<String>? onReport;
  final ValueChanged<String>? onEdit;
  final ValueChanged<UserPost> onRemovePost;
  final ValueChanged<bool> onToggleSavedTab;
  final ValueChanged<String> onToggleLike;
  final ValueChanged<String> onToggleSave;
  final OnComment onComment;
  final OnShare onShare;

  const HomePage({
    super.key,
    required this.lang,
    this.adsStore,
    required this.userPosts,
    required this.interactions,
    required this.showSaved,
    required this.meId,
    this.hiddenOwners = const {},
    this.onOpenUser,
    this.onRefresh,
    this.errorText = '',
    this.onSearch,
    this.onOpenPost,
    this.onOpenComments,
    this.onReport,
    this.onEdit,
    required this.onRemovePost,
    required this.onToggleSavedTab,
    required this.onToggleLike,
    required this.onToggleSave,
    required this.onComment,
    required this.onShare,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  PostInter _inter(String id) =>
      widget.interactions[id] ?? const PostInter(comments: []);

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);

    // ساخت لیست پست‌های قابل‌نمایش
    final items = <Widget>[];
    if (widget.showSaved) {
      var found = 0;
      for (final p in widget.userPosts.reversed) {
        if (_inter(p.id).saved) {
          items.add(_userCard(p));
          found++;
        }
      }
      for (var i = 0; i < samplePosts.length; i++) {
        if (_inter('sample_$i').saved) {
          items.add(_sampleCard(i));
          found++;
        }
      }
      if (found == 0) {
        items.add(_emptySaved());
      }
    } else {
      for (var i = 0; i < widget.userPosts.length; i++) {
        items.add(_userCard(widget.userPosts[i]));
        if (i == 2 && widget.adsStore != null) {
          items.add(SponsoredFeed(store: widget.adsStore!, lang: widget.lang));
        }
      }
      if (widget.userPosts.length < 3 && widget.adsStore != null) {
        items.add(SponsoredFeed(store: widget.adsStore!, lang: widget.lang));
      }
      if (widget.userPosts.isEmpty) {
        items.add(
          Padding(
            padding: const EdgeInsets.only(top: 40),
            child: Column(
              children: [
                const Text('🐾', style: TextStyle(fontSize: 48)),
                const SizedBox(height: 10),
                Text(
                  tr(widget.lang, 'emptyFeed'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppPal.inkSoft, height: 1.6),
                ),
                if (widget.errorText.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(
                      '[${widget.errorText}]',
                      textDirection: TextDirection.ltr,
                      style: const TextStyle(
                        color: Color(0xFFB3261E),
                        fontSize: 11.5,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      }
    }

    return Column(
      children: [
        Expanded(
          child: RefreshIndicator(
            color: AppPal.purple,
            onRefresh: () async {
              await widget.onRefresh?.call();
              await widget.adsStore?.app.stories.load();
            },
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              children: [
                if (!widget.showSaved) ...[
                  if (widget.adsStore != null) StoriesBar(app: widget.adsStore!.app),
                  GestureDetector(
                    onTap: widget.onSearch,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 13,
                      ),
                      decoration: AppPal.softCard(),
                      child: Row(
                        children: [
                          const Icon(Icons.search, color: AppPal.inkSoft),
                          const SizedBox(width: 10),
                          Text(
                            tr(widget.lang, 'searchUsers'),
                            style: const TextStyle(color: AppPal.inkSoft),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
                ...items,
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ---------- نوار فید / ذخیره‌شده‌ها ----------
  Widget _segmentBar(L10n t) {
    Widget seg(String label, bool active, VoidCallback onTap) => Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          margin: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: active ? AppPal.purple : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 13.5,
              color: active ? Colors.white : AppPal.inkSoft,
            ),
          ),
        ),
      ),
    );

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F000000),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          seg(t.feed, !widget.showSaved, () => widget.onToggleSavedTab(false)),
          seg(
            t.savedPosts,
            widget.showSaved,
            () => widget.onToggleSavedTab(true),
          ),
        ],
      ),
    );
  }

  Widget _emptySaved() => Padding(
    padding: const EdgeInsets.only(top: 60),
    child: Column(
      children: [
        const Icon(Icons.bookmark_border, size: 54, color: AppPal.inkSoft),
        const SizedBox(height: 12),
        Text(
          L10n.of(widget.lang).savedPostsEmpty,
          style: const TextStyle(color: AppPal.inkSoft),
        ),
      ],
    ),
  );

  // ---------- برگه‌ی پست (مشترک) ----------
  Widget _postCard({
    required String id,
    required String author,
    required String text,
    required Widget image,
    required int baseLikes,
    required Widget leadingAvatar,
    UserPost? userPost,
    String? ownerId,
    String? imageUrl,
    int? createdAt,
    String? location,
    List<PostTag> tags = const [],
  }) {
    final t = L10n.of(widget.lang);
    final st = _inter(id);
    final likes = baseLikes + (st.liked ? 1 : 0);
    final timeText = createdAt == null ? '' : timeAgo(createdAt, widget.lang);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      clipBehavior: Clip.antiAlias,
      decoration: AppPal.softCard(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // هدر پست
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 10, 10),
            child: Row(
              children: [
                GestureDetector(
                  onTap: ownerId == null
                      ? null
                      : () => widget.onOpenUser?.call(ownerId),
                  child: leadingAvatar,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              author,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 15,
                                color: AppPal.ink,
                              ),
                            ),
                          ),
                          if (userPost != null) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 7,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFFEDE7FF),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                t.myPosts,
                                style: const TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  color: AppPal.purpleDark,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      if (timeText.isNotEmpty)
                        Text(
                          timeText,
                          style: const TextStyle(
                            color: AppPal.inkSoft,
                            fontSize: 11.5,
                          ),
                        ),
                    ],
                  ),
                ),
                if (ownerId != null)
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.more_horiz, color: AppPal.inkSoft),
                    onSelected: (v) {
                      if (v == 'delete' && userPost != null) {
                        _confirmDelete(userPost);
                      }
                      if (v == 'edit') widget.onEdit?.call(id);
                      if (v == 'report') widget.onReport?.call(id);
                    },
                    itemBuilder: (ctx) => [
                      if (userPost != null) ...[
                        PopupMenuItem(
                          value: 'edit',
                          child: Text(tr(widget.lang, 'editPost')),
                        ),
                        PopupMenuItem(
                          value: 'delete',
                          child: Text(t.deletePost),
                        ),
                      ] else
                        PopupMenuItem(
                          value: 'report',
                          child: Text(tr(widget.lang, 'reportPost')),
                        ),
                    ],
                  ),
              ],
            ),
          ),

          // تصویر
          GestureDetector(
            onTap: imageUrl == null
                ? null
                : () {
                    if (widget.onOpenPost != null) {
                      widget.onOpenPost!(id);
                    } else {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ImageViewerPage(src: imageUrl),
                        ),
                      );
                    }
                  },
            child: MediaOverlay(
              location: location,
              tags: tags,
              onTagTap: widget.onOpenUser,
              child: AspectRatio(aspectRatio: 4 / 3, child: image),
            ),
          ),

          // متن
          if (text.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
              child: Text(
                text,
                style: const TextStyle(color: AppPal.ink, height: 1.6),
              ),
            ),

          const SizedBox(height: 4),

          // نوار اقدام‌ها: لایک / نظر / ذخیره / اشتراک
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            child: Row(
              children: [
                _actionBtn(
                  icon: st.liked ? Icons.favorite : Icons.favorite_border,
                  color: st.liked ? const Color(0xFFE0245E) : AppPal.ink,
                  tooltip: t.like,
                  onTap: () => widget.onToggleLike(id),
                ),
                if (st.liked)
                  Padding(
                    padding: const EdgeInsets.only(right: 2),
                    child: Text(
                      t.num(likes),
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        color: AppPal.ink,
                      ),
                    ),
                  ),
                const SizedBox(width: 2),
                _actionBtn(
                  icon: Icons.chat_bubble_outline,
                  color: AppPal.ink,
                  tooltip: t.comment,
                  onTap: () => _openComments(id, author, text),
                ),
                if (st.comments.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(right: 2),
                    child: Text(
                      t.num(st.comments.length),
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        color: AppPal.ink,
                      ),
                    ),
                  ),
                const Spacer(),
                _actionBtn(
                  icon: st.saved ? Icons.bookmark : Icons.bookmark_border,
                  color: st.saved ? AppPal.purple : AppPal.ink,
                  tooltip: st.saved ? t.savedLabel : t.save,
                  onTap: () => widget.onToggleSave(id),
                ),
                _actionBtn(
                  icon: Icons.send_outlined,
                  color: AppPal.ink,
                  tooltip: t.share,
                  onTap: () => widget.onShare(id, author, text),
                ),
              ],
            ),
          ),

          // آخرین نظر
          if (st.comments.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
              child: GestureDetector(
                onTap: () => _openComments(id, author, text),
                child: Text(
                  '${st.comments.last.author}: ${st.comments.last.text}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: AppPal.inkSoft, fontSize: 12.5),
                ),
              ),
            )
          else
            const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _actionBtn({
    required IconData icon,
    required Color color,
    required String tooltip,
    required VoidCallback onTap,
  }) => IconButton(
    tooltip: tooltip,
    onPressed: onTap,
    icon: Icon(icon, color: color, size: 25),
  );

  // ---------- پست کاربران ----------
  Widget _userCard(UserPost p) {
    final has = p.imagePath != null && p.imagePath!.isNotEmpty;
    final img = has
        ? (p.mediaType == 'video'
              ? VideoThumb(thumbUrl: p.thumbUrl)
              : SmartImage(src: p.imagePath, fit: BoxFit.cover))
        : Container(
            color: AppPal.bg,
            alignment: Alignment.center,
            child: const Icon(
              Icons.image_outlined,
              color: AppPal.inkSoft,
              size: 40,
            ),
          );
    return _postCard(
      id: p.id,
      author: p.author,
      text: p.text,
      image: img,
      baseLikes: p.likes,
      userPost: p.ownerId == widget.meId ? p : null,
      ownerId: p.ownerId.isEmpty ? null : p.ownerId,
      imageUrl: has ? p.imagePath : null,
      createdAt: p.createdAt,
      location: p.locationText,
      tags: p.tags,
      leadingAvatar: AvatarCircle(
        url: p.authorAvatar,
        name: p.author,
        size: 44,
      ),
    );
  }

  // ---------- پست نمونه ----------
  Widget _sampleCard(int i) {
    final p = samplePosts[i];
    return _postCard(
      id: 'sample_$i',
      author: p.author,
      text: p.title.of(widget.lang),
      image: Image.asset(p.image, fit: BoxFit.cover),
      baseLikes: p.likes,
      ownerId: 'demo_${p.author.toLowerCase()}',
      leadingAvatar: ClipOval(
        child: Image.asset(p.avatar, width: 44, height: 44, fit: BoxFit.cover),
      ),
    );
  }

  // ---------- دیالوگ حذف ----------
  Future<void> _confirmDelete(UserPost p) async {
    final t = L10n.of(widget.lang);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(t.deleteConfirm),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(t.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(
              t.delete,
              style: const TextStyle(color: Color(0xFFB3261E)),
            ),
          ),
        ],
      ),
    );
    if (ok == true) widget.onRemovePost(p);
  }

  // ---------- پایین‌کش نظرات ----------
  void _openComments(String id, String author, String text) {
    if (widget.onOpenComments != null) {
      widget.onOpenComments!(id);
      return;
    }
    final t = L10n.of(widget.lang);
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: StatefulBuilder(
          builder: (ctx, setSheet) {
            final list = _inter(id).comments;
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 10),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: const Color(0xFFDDDDE3),
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 12, 18, 6),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.chat_bubble_outline,
                        size: 20,
                        color: AppPal.purple,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${t.comments} (${t.num(list.length)})',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                if (list.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 34),
                    child: Column(
                      children: [
                        const Icon(
                          Icons.forum_outlined,
                          size: 44,
                          color: AppPal.inkSoft,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          t.noComments,
                          style: const TextStyle(color: AppPal.inkSoft),
                        ),
                      ],
                    ),
                  )
                else
                  Flexible(
                    child: ListView.separated(
                      shrinkWrap: true,
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      itemCount: list.length,
                      separatorBuilder: (c, i) =>
                          const Divider(height: 1, indent: 60),
                      itemBuilder: (c, i) {
                        final cm = list[i];
                        return ListTile(
                          leading: AppPal.gradientCircle(
                            gradient: AppPal.purpleGradient,
                            size: 38,
                            child: Text(
                              (cm.author.isNotEmpty ? cm.author[0] : '?')
                                  .toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          title: Text(
                            cm.author,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                            ),
                          ),
                          subtitle: Text(cm.text),
                        );
                      },
                    ),
                  ),
                SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: ctrl,
                            textInputAction: TextInputAction.send,
                            onSubmitted: (_) {
                              final v = ctrl.text.trim();
                              if (v.isEmpty) return;
                              widget.onComment(id, v);
                              ctrl.clear();
                              setSheet(() {});
                            },
                            decoration: InputDecoration(
                              hintText: t.commentHint,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          onPressed: () {
                            final v = ctrl.text.trim();
                            if (v.isEmpty) return;
                            widget.onComment(id, v);
                            ctrl.clear();
                            setSheet(() {});
                          },
                          icon: const Icon(Icons.send, color: AppPal.purple),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
