import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../state.dart';
import '../data/places.dart';
import 'ads_models.dart';

class AdsStore extends ChangeNotifier {
  final AppState app;
  AdsStore(this.app);
  SupabaseClient get db => Supabase.instance.client;
  String country = '', city = '';
  List<ServiceAd> ads = [];
  bool loading = false, failed = false, isManager = false;
  bool _disposed = false;
  int _generation = 0;
  Timer? _expiry;
  void changed() {
    if (!_disposed) notifyListeners();
  }

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    if (_disposed) return;
    country = prefs.getString('ads_country') ?? app.me?.country ?? '';
    city = prefs.getString('ads_city') ?? app.me?.city ?? '';
    if (!countries.any((p) => p.key == country)) {
      country = '';
      city = '';
    }
    await load();
    _expiry = Timer.periodic(const Duration(seconds: 30), (_) {
      if (_disposed) return;
      final now = DateTime.now().toUtc();
      final live = ads.where((a) => a.live(now)).toList();
      if (live.length != ads.length) { ads = live; changed(); }
    });
  }

  Future<void> setLocation(String c, String town) async {
    country = c;
    city = town;
    ads = [];
    changed();
    final prefs = await SharedPreferences.getInstance();
    if (_disposed) return;
    await prefs.setString('ads_country', c);
    await prefs.setString('ads_city', town);
    await load();
  }

  Future<void> load() async {
    final gen = ++_generation;
    loading = true;
    failed = false;
    changed();
    try {
      final role = await db.rpc('admin_role');
      final manager = role == 'owner' || role == 'admin';
      List<ServiceAd> results = [];
      if (country.isNotEmpty && city.isNotEmpty) {
        final now = DateTime.now().toUtc();
        final rows = await db
            .from('service_ads')
            .select()
            .eq('country', country)
            .eq('city', city)
            .eq('active', true)
            .lte('starts_at', now.toIso8601String())
            .gt('ends_at', now.toIso8601String())
            .order('priority', ascending: false)
            .limit(500);
        results =
            (rows as List)
                .map((r) => ServiceAd(Map<String, dynamic>.from(r)))
                .where((a) => a.matches(country, city) && a.live(now))
                .toList()
              ..sort(compareAds);
      }
      if (gen != _generation || _disposed) return;
      ads = results;
      isManager = manager;
    } catch (_) {
      if (gen == _generation) {
        ads = [];
        failed = true;
      }
    }
    if (gen == _generation) {
      loading = false;
      changed();
    }
  }

  Future<List<Map<String, dynamic>>> packages(String c) async {
    final rows = await db
        .from('ad_packages')
        .select()
        .eq('country', c)
        .eq('active', true);
    final result = (rows as List)
        .map((r) => Map<String, dynamic>.from(r))
        .toList();
    const tiers = {'basic': 0, 'premium': 1, 'featured': 2, 'event_banner': 3};
    result.sort(
      (a, b) => (tiers[a['tier']] ?? 0).compareTo(tiers[b['tier']] ?? 0),
    );
    return result;
  }

  Future<void> event(String id, String kind) async {
    try {
      await db.rpc('record_ad_event', params: {'p_ad': id, 'p_kind': kind});
    } catch (_) {
      /* Analytics must not block navigation. */
    }
  }

  @override
  void dispose() {
    _expiry?.cancel();
    _disposed = true;
    _generation++;
    super.dispose();
  }
}
