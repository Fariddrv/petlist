import '../l10n.dart';
import 'ads_models.dart';

String previewText(AppLang l, String fa, String en, String zh) =>
    l == AppLang.fa ? fa : l == AppLang.zh ? zh : en;

// Local examples only: never inserted, billed, or counted in analytics.
List<ServiceAd> previewAdvertisements(String country, String city) => [
  for (final item in [
    ['vet','featured','کلینیک دامپزشکی آریا','Aria Veterinary','阿里亚宠物诊所','assets/posts/post_park.jpg','website'],
    ['boarding','featured','خانه حیوانات مهربان','Happy Pets Boarding','快乐宠物寄养','assets/posts/post_box.jpg','website'],
    ['petshop','premium','پت‌شاپ پارس','Pars Pet Shop','帕尔斯宠物店','assets/posts/post_box.jpg','instagram'],
    ['grooming','basic','گرومینگ پاو استایل','Paw & Style','爪爪美容','assets/posts/post_parrot.jpg','message'],
  ]) ServiceAd({
    'id': 'preview-${item[0]}', 'preview': true,
    'brand': item[3], 'brand_localized': {'fa':item[2],'en':item[3],'zh':item[4]},
    'image_url': item[5], 'country': country.isEmpty ? 'IR' : country, 'city': city.isEmpty ? 'Tehran' : city,
    'category':item[0], 'tier':item[1], 'destination_type':item[6],
    'destination':'https://example.com', 'priority':0,
    'description': {'fa':'این آگهی نمونه است؛ تصویر و اطلاعات واقعی کسب‌وکار شما جایگزین می‌شود.','en':'Sample advertisement. Your own banner and business details appear here.','zh':'示例广告。这里将显示您的横幅和商家信息。'},
    'badges':item[0]=='petshop' ? ['promotion'] : <String>[],
    'active':true, 'starts_at':DateTime.now().subtract(const Duration(days:1)).toIso8601String(),
    'ends_at':DateTime.now().add(const Duration(days:1)).toIso8601String(),
  }),
];
