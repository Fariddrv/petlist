import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show Supabase;
import 'package:url_launcher/url_launcher.dart';
import '../i18n2.dart';
import '../l10n.dart';
import '../theme.dart';
import 'smart_image.dart';

/// بنر تبلیغاتی اسلایدی بالای فید.
/// بنرها از جدول `banners` سرور خوانده می‌شوند (ادمین عوضشان می‌کند)؛
/// اگر بنری ثبت نشده باشد، سه تبلیغ نمونه نشان داده می‌شود.
class AdSlider extends StatefulWidget {
  final AppLang lang;
  final String placement; // home | events | shop
  final String? country;
  const AdSlider({super.key, required this.lang, this.placement = 'home', this.country});

  @override
  State<AdSlider> createState() => _AdSliderState();
}

class _AdSliderState extends State<AdSlider> {
  final PageController _ctrl = PageController();
  Timer? _timer;
  int _page = 0;
  int _ticks = 0;
  List<({String image, String? title, String? link})> _remote = [];

  int get _count => _remote.isNotEmpty ? _remote.length : _ads.length;

  Future<void> _loadRemote() async {
    try {
      final rows = await Supabase.instance.client
          .from('banners')
          .select('image_url,title,link_url,starts_at,ends_at,country')
          .eq('active', true)
          .eq('placement', widget.placement)
          .order('sort_order');
      final now = DateTime.now().toUtc();
      final list = <({String image, String? title, String? link})>[];
      for (final r in (rows as List)) {
        final m = Map<String, dynamic>.from(r as Map);
        if (m['country'] != null && m['country'] != widget.country) continue;
        final st = DateTime.tryParse('${m['starts_at'] ?? ''}');
        final en = DateTime.tryParse('${m['ends_at'] ?? ''}');
        if (st != null && st.isAfter(now)) continue;
        if (en != null && en.isBefore(now)) continue;
        list.add((
          image: m['image_url'].toString(),
          title: m['title'] as String?,
          link: m['link_url'] as String?,
        ));
      }
      if (mounted) setState(() { _remote = list; _page = 0; });
    } catch (_) {}
  }

  Widget _remoteCard(({String image, String? title, String? link}) b) {
    return GestureDetector(
      onTap: () async {
        final u = Uri.tryParse(b.link ?? '');
        if (u == null || u.scheme != 'https' || u.host.isEmpty || u.userInfo.isNotEmpty) return;
        try {
          await launchUrl(u, mode: LaunchMode.externalApplication);
        } catch (_) {}
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
        child: Stack(fit: StackFit.expand, children: [
          SmartImage(src: b.image, fit: BoxFit.cover),
          if ((b.link ?? '').isNotEmpty)
            PositionedDirectional(bottom: 6, end: 6, child: const DecoratedBox(decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.all(Radius.circular(8))), child: Padding(padding: EdgeInsets.all(6), child: Icon(Icons.open_in_new, size: 16, color: Colors.white)))),
          PositionedDirectional(
            top: 8,
            end: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: .45),
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(tr(widget.lang, 'ad'),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700)),
            ),
          ),
        ]),
      ),
    );
  }

  static const _ads = [
    ('ad1', '🛍️', BrandColors.purple, Color(0xFF9E86FF)),
    ('ad2', '🩺', BrandColors.gray, Color(0xFF9CA3AF)),
    ('ad3', '📣', BrandColors.yellow, Color(0xFFFFD976)),
  ];

  @override
  void initState() {
    super.initState();
    _loadRemote();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (++_ticks % 15 == 0) _loadRemote();
      if (!_ctrl.hasClients) return;
      final next = (_page + 1) % _count;
      _ctrl.animateToPage(next,
          duration: const Duration(milliseconds: 450), curve: Curves.easeInOut);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 96,
          child: PageView.builder(
            controller: _ctrl,
            itemCount: _count,
            onPageChanged: (i) => setState(() => _page = i),
            itemBuilder: (c, i) {
              if (_remote.isNotEmpty) return _remoteCard(_remote[i]);
              final a = _ads[i];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 2),
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [a.$3, a.$4],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Text(a.$2, style: const TextStyle(fontSize: 30)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        tr(widget.lang, a.$1),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 14.5,
                            height: 1.5),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: .28),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(tr(widget.lang, 'ad'),
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10.5,
                              fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < _count; i++)
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: i == _page ? 18 : 6,
                height: 6,
                decoration: BoxDecoration(
                  color: i == _page ? AppPal.purple : const Color(0xFFD1D5DB),
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
          ],
        ),
      ],
    );
  }
}
