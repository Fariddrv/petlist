import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../state.dart';
import 'post_media.dart';

class ChatAttachment extends StatefulWidget {
  final Msg message;
  const ChatAttachment({super.key, required this.message});
  @override
  State<ChatAttachment> createState() => _ChatAttachmentState();
}
class _ChatAttachmentState extends State<ChatAttachment> {
  late Future<String> _url;
  Future<String> _sign() => Supabase.instance.client.storage.from('chat-media').createSignedUrl(widget.message.mediaPath!, 600);
  @override
  void initState() { super.initState(); _url = _sign(); }
  @override
  Widget build(BuildContext context) => FutureBuilder<String>(future: _url, builder: (context,snapshot) {
    if (snapshot.hasError) return IconButton(onPressed: () => setState(() => _url = _sign()), icon: const Icon(Icons.refresh, color: Colors.white));
    if (!snapshot.hasData) return const SizedBox(height: 100, child: Center(child: CircularProgressIndicator()));
    final url = snapshot.data!;
    if (widget.message.mediaType == 'video') return SizedBox(width: 230, child: PostVideo(url: url));
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(
        backgroundColor: Colors.black, appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
        body: Center(child: InteractiveViewer(child: Image.network(url))),
      ))),
      child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network(url, width: 230, height: 180, fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => IconButton(onPressed: () => setState(() => _url = _sign()), icon: const Icon(Icons.refresh)))),
    );
  });
}
