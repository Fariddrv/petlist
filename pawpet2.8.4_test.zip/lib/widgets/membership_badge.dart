import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Decorative membership mark; never an identity/service verification claim.
class MembershipBadge extends StatelessWidget {
 final String tier;
 final double size;
 final String label;
 const MembershipBadge({super.key,required this.tier,this.size=24,required this.label});
 @override Widget build(BuildContext context)=>Semantics(label:label,child:Tooltip(message:label,child:CustomPaint(size:Size.square(size),painter:_BadgePainter(tier=='gold'?const Color(0xFFE4AD24):const Color(0xFF26A96C)))));
}
class _BadgePainter extends CustomPainter {
 final Color color;const _BadgePainter(this.color);
 @override void paint(Canvas canvas,Size size){
  final c=Offset(size.width/2,size.height/2);final radius=size.shortestSide/2;final path=Path();
  for(var i=0;i<24;i++){
   final angle=-math.pi/2+i*math.pi/12;final r=radius*(i.isEven?1:.84);final point=c+Offset(math.cos(angle)*r,math.sin(angle)*r);
   if(i==0){path.moveTo(point.dx,point.dy);}else{path.lineTo(point.dx,point.dy);}
  }
  path.close();canvas.drawPath(path,Paint()..color=color);
  final check=Path()..moveTo(size.width*.28,size.height*.51)..lineTo(size.width*.43,size.height*.66)..lineTo(size.width*.73,size.height*.35);
  canvas.drawPath(check,Paint()..color=Colors.white..style=PaintingStyle.stroke..strokeWidth=size.width*.11..strokeCap=StrokeCap.round..strokeJoin=StrokeJoin.round);
 }
 @override bool shouldRepaint(covariant _BadgePainter old)=>old.color!=color;
}
