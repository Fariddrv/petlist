import 'dart:async';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import '../ads/ads_store.dart';
import '../ads/ads_preview.dart';
import '../ads/ads_text.dart';
import '../ads/ads_widgets.dart';
import '../state.dart';
import '../theme.dart';
import 'ad_request_page.dart';
import 'ads_admin_page.dart';

class ServicesPage extends StatefulWidget {
  final AppState s;
  final AdsStore store;
  const ServicesPage({super.key, required this.s, required this.store});
  @override
  State<ServicesPage> createState() => _ServicesPageState();
}

class _ServicesPageState extends State<ServicesPage> {
  bool _preview = false;
  String? _previewImage;
  String? _category;
  String _query = '';
  final _pages = PageController();
  int _slide = 0;
  Timer? _timer;
  String _featuredIds = '';
  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 6), (_) {
      if (!mounted || !_pages.hasClients) return;
      final n = (_preview ? previewAdvertisements(widget.store.country, widget.store.city) : widget.store.ads)
          .where(
            (a) =>
                a.tier == 'featured' &&
                (_category == null || a.category == _category) &&
                a.brand.toLowerCase().contains(_query),
          )
          .length;
      if (n > 1)
        _pages.animateToPage(
          (_slide + 1) % n,
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeInOut,
        );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pages.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: widget.store,
    builder: (ctx, _) {
      final store = widget.store, l = widget.s.lang;
      final ads = (_preview ? previewAdvertisements(store.country, store.city) : store.ads)
          .where(
            (a) =>
                (_category == null || a.category == _category) &&
                a.brand.toLowerCase().contains(_query),
          )
          .toList();
      if (_preview && _previewImage != null && ads.isNotEmpty) ads.first.row['image_url'] = _previewImage;
      final featured = ads.where((a) => a.tier == 'featured').toList();
      final ids = featured.map((a) => a.id).join(',');
      if (ids != _featuredIds) {
        _featuredIds = ids;
        _slide = 0;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && _pages.hasClients) _pages.jumpToPage(0);
        });
      }
      return RefreshIndicator(
        onRefresh: store.load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
          children: [
            Row(children: [
              Expanded(child: AdsLocationBar(store: store, lang: l)),
              TextButton.icon(
                icon: Icon(_preview ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 18),
                label: Text(previewText(l, _preview ? 'خروج از تست' : 'پیش‌نمایش', _preview ? 'Exit demo' : 'Preview', _preview ? '退出演示' : '预览')),
                onPressed: () => setState(() { _preview = !_preview; _category = null; _query = ''; }),
              ),
            ]),
            if (_preview) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(previewText(l, 'حالت تست: آگهی‌ها نمونه‌اند و ثبت یا شمارش نمی‌شوند.', 'Demo: sample ads are not saved or counted.', '演示：示例广告不会保存或计入统计。'), style: const TextStyle(fontSize: 11, color: AppPal.purple))),
            if (_preview) TextButton.icon(
              icon: const Icon(Icons.add_photo_alternate_outlined),
              label: Text(previewText(l, 'تست بنر خودم روی آگهی ویژه', 'Try my banner on the featured ad', '预览自己的精选广告横幅')),
              onPressed: () async {
                try {
                  final image = await ImagePicker().pickImage(source: ImageSource.gallery);
                  if (mounted && image != null) setState(() => _previewImage = image.path);
                } catch (_) {
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(previewText(l, 'تصویر انتخاب نشد.', 'Could not select image.', '无法选择图片。'))));
                }
              },
            ),
            if (store.isManager)
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: TextButton.icon(
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AdsAdminPage(s: widget.s, store: store),
                      ),
                    );
                    await store.load();
                  },
                  icon: const Icon(Icons.admin_panel_settings_outlined),
                  label: Text(adText(l, 'manage')),
                ),
              ),
            if (store.loading) const LinearProgressIndicator(),
            if (store.failed)
              Column(
                children: [
                  Text(adText(l, 'failed')),
                  TextButton(
                    onPressed: store.load,
                    child: Text(adText(l, 'retry')),
                  ),
                ],
              ),
            if (featured.isNotEmpty) ...[
              Text(
                adText(l, 'featured'),
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 19,
                ),
              ),
              SizedBox(
                height: MediaQuery.textScalerOf(context).scale(1) > 1.3 ? 420 : 220,
                child: PageView.builder(
                  controller: _pages,
                  itemCount: featured.length,
                  onPageChanged: (i) => setState(() => _slide = i),
                  itemBuilder: (ctx, i) => SingleChildScrollView(
                    child: AdvertisementCard(
                      key: ValueKey(featured[i].id),
                      ad: featured[i],
                      store: store,
                      lang: l,
                      featured: true,
                    ),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (var i = 0; i < featured.length; i++)
                    Container(
                      width: i == _slide ? 20 : 6,
                      height: 6,
                      margin: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: i == _slide
                            ? AppPal.purple
                            : Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                ],
              ),
            ],
            const SizedBox(height: 12),
            SizedBox(
              height: 82,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (final c in ['all', ...adCategories])
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () =>
                            setState(() => _category = c == 'all' ? null : c),
                        child: Container(
                          width: 74,
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color:
                                (_category == c ||
                                    (_category == null && c == 'all'))
                                ? const Color(0xFFE4DAFF)
                                : switch (c) {
                                    'vet' => const Color(0xFFEEE7FF),
                                    'petshop' => const Color(0xFFE3F3E8),
                                    'grooming' => const Color(0xFFFFE6EE),
                                    'training' => const Color(0xFFE0F1FC),
                                    'boarding' => const Color(0xFFFFE8E7),
                                    'transport' => const Color(0xFFFFE9DC),
                                    _ => const Color(0xFFEBEDF4),
                                  },
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(_icon(c), color: AppPal.purple),
                              const SizedBox(height: 6),
                              Text(
                                adText(l, c),
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                style: const TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
              decoration: InputDecoration(
                hintText: adText(l, 'search'),
                prefixIcon: const Icon(Icons.search),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              adText(l, 'sponsored'),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            Text(
              adText(l, 'ranking'),
              style: const TextStyle(fontSize: 11, color: AppPal.inkSoft),
            ),
            if (!store.loading && !store.failed && ads.isEmpty)
              Padding(
                padding: const EdgeInsets.all(28),
                child: Text(
                  store.country.isEmpty || store.city.isEmpty
                      ? adText(l, 'location')
                      : adText(l, 'empty'),
                  textAlign: TextAlign.center,
                ),
              ),
            for (final ad in ads)
              AdvertisementCard(
                key: ValueKey('list-${ad.id}'),
                ad: ad,
                store: store,
                lang: l,
              ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFFEDE7FF),
                borderRadius: BorderRadius.circular(20),
              ),
              child: LayoutBuilder(builder: (ctx, constraints) {
                final content = Text(adText(l, 'advertise'), textAlign: TextAlign.start,
                    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15));
                final button = FilledButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AdRequestPage(s: widget.s, store: store))),
                  child: Text(adText(l,'request'), style: const TextStyle(fontSize: 11)),
                );
                if (constraints.maxWidth < 280 || MediaQuery.textScalerOf(context).scale(1) > 1.3) return Column(children: [const Icon(Icons.campaign, color: AppPal.purple, size: 32), content, button]);
                return Row(children: [const Icon(Icons.campaign, color: AppPal.purple, size: 32), const SizedBox(width: 10), Expanded(child: content), const SizedBox(width: 6), button]);
              }),
            ),
          ],
        ),
      );
    },
  );
  IconData _icon(String c) => switch (c) {
    'vet' => Icons.medical_services_outlined,
    'petshop' => Icons.storefront,
    'grooming' => Icons.content_cut,
    'training' => Icons.school,
    'boarding' => Icons.home_work_outlined,
    'transport' => Icons.local_taxi,
    _ => Icons.more_horiz,
  };
}
