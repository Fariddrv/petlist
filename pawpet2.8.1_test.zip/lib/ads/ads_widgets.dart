import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../l10n.dart';
import '../data/places.dart';
import '../theme.dart';
import '../widgets/location_fields.dart';
import '../pages/profile_page.dart';
import 'ads_models.dart';
import 'ads_store.dart';
import 'ads_text.dart';

Future<void> chooseAdsLocation(
  BuildContext context,
  AdsStore store,
  AppLang lang,
) async {
  var country = store.country, city = store.city;
  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => SafeArea(
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            20,
            20,
            20 + MediaQuery.of(ctx).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                adText(lang, 'location'),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              const SizedBox(height: 16),
              LocationFields(
                lang: lang,
                country: country,
                city: city,
                onChanged: (c, t) {
                  country = c;
                  city = t;
                },
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: Text(adText(lang, 'save')),
              ),
            ],
          ),
        ),
      ),
    ),
  );
  if (ok == true &&
      countries.any((p) => p.key == country) &&
      city.trim().isNotEmpty) {
    await store.setLocation(country, city.trim());
  }
}

class AdsLocationBar extends StatelessWidget {
  final AdsStore store;
  final AppLang lang;
  const AdsLocationBar({super.key, required this.store, required this.lang});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (ctx, _) => TextButton.icon(
      style: TextButton.styleFrom(foregroundColor: AppPal.purple),
      onPressed: () => chooseAdsLocation(context, store, lang),
      icon: const Icon(Icons.location_on_outlined, size: 18),
      label: Text(
        store.country.isEmpty || store.city.isEmpty
            ? adText(lang, 'location')
            : '${countryName(store.country, lang)} | ${cityName(store.country, store.city, lang)}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    ),
  );
}

Future<void> openAdvertisement(
  BuildContext context,
  AdsStore store,
  ServiceAd ad,
  AppLang lang,
) async {
  if (ad.row['preview'] == true) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(lang == AppLang.fa ? 'این آگهی نمونه است؛ لینک واقعی باز نمی‌شود.' : lang == AppLang.zh ? '这是示例广告，不会打开真实链接。' : 'Sample advertisement: no real link is opened.')));
    return;
  }
  if (!validAdDestination(ad.type, ad.destination)) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(adText(lang, 'badLink'))));
    return;
  }
  if (ad.type == 'profile') {
    await store.app.fetchUser(ad.destination);
    if (!context.mounted) return;
    if (store.app.userById(ad.destination) == null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(adText(lang, 'badLink'))));
      return;
    }
    store.event(ad.id, 'click');
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            ProfilePage(s: store.app, userId: ad.destination, standalone: true),
      ),
    );
    return;
  }
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(ad.brand),
      content: Text('${adText(lang, 'external')}\n${ad.destination}'),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: Text(adText(lang, 'cancel')),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(adText(lang, 'open')),
        ),
      ],
    ),
  );
  if (ok != true) return;
  try {
    final launched = await launchUrl(
      Uri.parse(ad.destination),
      mode: LaunchMode.externalApplication,
    );
    if (!launched) throw StateError('unable to open');
    store.event(ad.id, 'click');
  } catch (_) {
    if (context.mounted)
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(adText(lang, 'badLink'))));
  }
}

class AdvertisementCard extends StatefulWidget {
  final ServiceAd ad;
  final AdsStore store;
  final AppLang lang;
  final bool featured;
  const AdvertisementCard({
    super.key,
    required this.ad,
    required this.store,
    required this.lang,
    this.featured = false,
  });
  @override
  State<AdvertisementCard> createState() => _AdvertisementCardState();
}

class _AdvertisementCardState extends State<AdvertisementCard> {
  ScrollPosition? _position;
  bool _seen = false;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final p = Scrollable.maybeOf(context)?.position;
    if (p != _position) {
      _position?.removeListener(_check);
      _position = p;
      _position?.addListener(_check);
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => _check());
  }

  void _check() {
    if (_seen || !mounted || widget.ad.row['preview'] == true) return;
    final box = context.findRenderObject();
    if (box is! RenderBox || !box.hasSize) return;
    final m = MediaQuery.of(context);
    final origin = box.localToGlobal(Offset.zero);
    final rect = origin & box.size;
    final screen = Rect.fromLTRB(
      0,
      m.padding.top + 56,
      m.size.width,
      m.size.height - 80,
    );
    final visible = rect.intersect(screen);
    if (visible.width > 0 &&
        visible.height > 0 &&
        visible.width * visible.height >= rect.width * rect.height * .5) {
      _seen = true;
      widget.store.event(widget.ad.id, 'view');
    }
  }

  @override
  void dispose() {
    _position?.removeListener(_check);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ad = widget.ad, l = widget.lang;
    final names = ad.row['brand_localized'] as Map?;
    final brand = (names?[l.name] ?? ad.brand).toString();
    final image = ad.row['preview'] == true && !ad.image.startsWith('assets/')
        ? Image.file(File(ad.image), fit: BoxFit.cover)
        : ad.image.startsWith('assets/') ? Image.asset(ad.image, fit: BoxFit.cover)
        : Image.network(ad.image, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFFEDE7FF), child: Center(child: Icon(Icons.pets, color: AppPal.purple))));
    final button = FilledButton.icon(
      onPressed: () => openAdvertisement(context, widget.store, ad, l),
      icon: const Icon(Icons.open_in_new, size: 14),
      label: Text(adText(l, ad.type == 'other' ? 'open' : ad.type), maxLines: 1, overflow: TextOverflow.ellipsis),
      style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), textStyle: const TextStyle(fontSize: 11)),
    );
    final details = Padding(
      padding: const EdgeInsets.all(10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        Text(adText(l, 'sponsored'), style: const TextStyle(fontSize: 9, color: AppPal.inkSoft)),
        if (ad.tier == 'featured') Text('★ ${adText(l, 'featured')}', style: const TextStyle(color: AppPal.purple, fontSize: 11, fontWeight: FontWeight.bold)),
        Text(brand, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: widget.featured ? 19 : 16, fontWeight: FontWeight.w900)),
        if (ad.row['rating'] != null) Text('★ ${ad.row['rating']} · ${ad.row['rating_source']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10)),
        Text(ad.description(l), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, height: 1.5)),
        if (ad.badges.isNotEmpty) Text(ad.badges.map((b) => adText(l,b)).join(' · '), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: AppPal.purple)),
        const SizedBox(height: 5),
        Text('📍 ${cityName(ad.country, ad.city, l)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: AppPal.inkSoft)),
        button,
      ]),
    );
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      clipBehavior: Clip.antiAlias,
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: LayoutBuilder(builder: (context, constraints) {
        // Use a vertical layout on narrow screens or with large accessibility text.
        final compact = constraints.maxWidth < 300 || MediaQuery.textScalerOf(context).scale(1) > 1.3;
        if (compact) return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [AspectRatio(aspectRatio: 2.2, child: image), details]);
        return IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(flex: 6, child: details),
          Expanded(flex: 5, child: ConstrainedBox(constraints: BoxConstraints(minHeight: widget.featured ? 170 : 150), child: image)),
        ]));
      }),
    );
  }
}

class SponsoredFeed extends StatelessWidget {
  final AdsStore store;
  final AppLang lang;
  const SponsoredFeed({super.key, required this.store, required this.lang});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (ctx, _) {
      final items = store.ads.where((a) => a.inFeed).take(2);
      return Column(
        children: [
          for (final ad in items)
            AdvertisementCard(
              key: ValueKey('feed-${ad.id}'),
              ad: ad,
              store: store,
              lang: lang,
            ),
        ],
      );
    },
  );
}
