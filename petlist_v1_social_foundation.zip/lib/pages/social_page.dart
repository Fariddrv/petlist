
import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';

/// Social UI foundation. Actions are local demo interactions for this phase.
/// Backend, authentication, real-time messaging and notifications come later.
class SocialPage extends StatefulWidget {
  final AppLang lang;
  const SocialPage({super.key, required this.lang});

  @override
  State<SocialPage> createState() => _SocialPageState();
}

class _SocialPageState extends State<SocialPage> {
  final Set<int> _liked = {};
  final Set<int> _following = {};
  final Set<int> _friends = {};

  @override
  Widget build(BuildContext context) {
    final t = L10n.of(widget.lang);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppPal.gradientBanner(
          gradient: AppPal.purpleGradient,
          children: [
            Row(
              children: [
                const Icon(Icons.people_alt_rounded,
                    color: Colors.white, size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    t.socialTitle,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {},
                  color: Colors.white,
                  icon: const Icon(Icons.add_box_outlined),
                  tooltip: t.createPost,
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              t.socialSub,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withValues(alpha: .94),
                height: 1.5,
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        for (var i = 0; i < samplePosts.length; i++)
          _postCard(context, i, samplePosts[i]),
      ],
    );
  }

  Widget _postCard(BuildContext context, int i, Post p) {
    final t = L10n.of(widget.lang);
    final liked = _liked.contains(i);
    final following = _following.contains(i);
    final friend = _friends.contains(i);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      clipBehavior: Clip.antiAlias,
      decoration: AppPal.softCard(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 10, 10),
            child: Row(
              children: [
                ClipOval(
                  child: Image.asset(p.avatar,
                      width: 46, height: 46, fit: BoxFit.cover),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.author,
                          style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              color: AppPal.ink)),
                      const SizedBox(height: 3),
                      Text('PetList',
                          style: TextStyle(
                              fontSize: 11, color: AppPal.inkSoft)),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (_) {},
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'hide', child: Text('پنهان کردن')),
                    PopupMenuItem(value: 'report', child: Text('گزارش')),
                  ],
                ),
              ],
            ),
          ),
          AspectRatio(
            aspectRatio: 1.05,
            child: Image.asset(p.image, fit: BoxFit.cover),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 6, 8, 2),
            child: Row(
              children: [
                IconButton(
                  onPressed: () => setState(
                      () => liked ? _liked.remove(i) : _liked.add(i)),
                  icon: Icon(
                    liked ? Icons.favorite : Icons.favorite_border,
                    color: liked ? AppPal.purple : AppPal.inkSoft,
                  ),
                ),
                Text('${p.likes + (liked ? 1 : 0)}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.chat_bubble_outline),
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.send_outlined),
                ),
                const Spacer(),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.bookmark_border),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
            child: Text(p.title.of(widget.lang),
                style: const TextStyle(
                    color: AppPal.ink, height: 1.45)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 12),
            child: Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                OutlinedButton.icon(
                  onPressed: () => setState(() => following
                      ? _following.remove(i)
                      : _following.add(i)),
                  icon: Icon(following ? Icons.person : Icons.person_add_alt_1,
                      size: 17),
                  label: Text(following ? t.following : t.follow),
                ),
                OutlinedButton.icon(
                  onPressed: () => setState(() => friend
                      ? _friends.remove(i)
                      : _friends.add(i)),
                  icon: Icon(friend ? Icons.check : Icons.group_add_outlined,
                      size: 17),
                  label: Text(friend ? t.friendRequested : t.addFriend),
                ),
                OutlinedButton.icon(
                  onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('${t.message}: ${p.author}')),
                  ),
                  icon: const Icon(Icons.message_outlined, size: 17),
                  label: Text(t.message),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
